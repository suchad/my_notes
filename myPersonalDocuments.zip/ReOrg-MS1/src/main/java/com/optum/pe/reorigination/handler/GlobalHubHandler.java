package com.optum.pe.reorigination.handler;

import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.BundledResponse;
import com.optum.pe.reorigination.utils.Constants;
import com.optum.pe.reorigination.utils.Status;
import org.springframework.stereotype.Service;

@Service
class GlobalHubHandler implements Handler {

    @Override
    public boolean handle(BundledRequest bundledRequest, BundledResponse bundledResponse) {

        if (bundledRequest.isGlobalHubPayment()) {
            bundledResponse.add(Status.REJECTING, Constants.ERR_GLOBAL_HUB_PAYMENT, bundledRequest);

            return false;
        }

        return true;
    }
}
