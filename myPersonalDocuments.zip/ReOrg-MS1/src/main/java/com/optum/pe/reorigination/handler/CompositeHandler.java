package com.optum.pe.reorigination.handler;

import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.BundledResponse;

import java.util.List;

public interface CompositeHandler {

    void executeBusinessValidations(List<BundledRequest> bundledRequests, BundledResponse bundledResponse);
}
