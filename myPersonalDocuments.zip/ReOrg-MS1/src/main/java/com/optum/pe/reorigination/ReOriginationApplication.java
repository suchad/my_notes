package com.optum.pe.reorigination;

import com.optum.pe.elasticsearchlibrary.EnableElasticSearchLibrary;
import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

@EnableEncryptableProperties
@EnableCaching
@EnableElasticSearchLibrary
@SpringBootApplication
public class ReOriginationApplication {

    public static void main(String[] args) {
        SpringApplication.run(ReOriginationApplication.class);
    }
}
