package com.optum.pe.reorigination.handler;

import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.BundledResponse;
import com.optum.pe.reorigination.utils.Constants;
import io.micrometer.core.instrument.util.StringUtils;
import org.springframework.stereotype.Service;

@Service
public class RequestReasonHandler implements Handler {

    @Override
    public boolean handle(BundledRequest bundledRequest, BundledResponse bundledResponse) {

        if (StringUtils.isEmpty(bundledRequest.getRequestReason())) {

            bundledResponse.addWithOutPayment(Constants.ERR_REQUEST_REASON, bundledRequest);

            return false;

        }else if (bundledRequest.getRequestReason().length()>Constants.REQUEST_REASON_LENGTH) {

            bundledResponse.addWithOutPayment(Constants.ERR_REQUEST_REASON_LENGTH, bundledRequest);

            return false;
        }


        return true;
    }
}
