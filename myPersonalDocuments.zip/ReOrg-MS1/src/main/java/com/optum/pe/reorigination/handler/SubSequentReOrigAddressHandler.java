package com.optum.pe.reorigination.handler;

import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.BundledResponse;
import com.optum.pe.reorigination.utils.Constants;
import org.springframework.stereotype.Service;

@Service
public class SubSequentReOrigAddressHandler implements Handler {

    @Override
    public boolean handle(BundledRequest bundledRequest, BundledResponse bundledResponse) {

        if (bundledRequest.getAddress() != null) {
            return true;
        } else {
            bundledResponse.addWithOutPayment(Constants.ERR_SUB_SEQ_REORIG_ADDRESS_NOT_PRESENT,
                    bundledRequest);
        }

        return false;
    }
}
