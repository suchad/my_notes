package com.optum.pe.reorigination.handler;

import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.BundledResponse;
import com.optum.pe.reorigination.utils.Status;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReOriginationCompositeHandler implements CompositeHandler {

    private final Handler partnerConfigHandler;
    private final Handler reOriginationAllowedHandler;
    private final Handler reOriginationTypeAllowedHandler;
    private final Handler zeroPaymentHandler;
    private final Handler suppressedPaymentHandler;
    private final Handler taxLevyHandler;
    private final Handler specialPayeeHandler;
    private final Handler reOriginationRulesHandler;
    private final Handler interfacesHandler;
    private final Handler globalHubHandler;
    private final Handler pseudoPaymentHandler;
    private final Handler reOriginationHierarchyHandler;

    ReOriginationCompositeHandler(PartnerConfigHandler partnerConfigHandler,
                                  ReOriginationAllowedHandler reOriginationAllowedHandler,
                                  ReOriginationTypeAllowedHandler reOriginationTypeAllowedHandler,
                                  ZeroPaymentHandler zeroPaymentHandler,
                                  SuppressedPaymentHandler suppressedPaymentHandler,
                                  TaxLevyHandler taxLevyHandler,
                                  SpecialPayeeHandler specialPayeeHandler,
                                  ReOriginationRulesHandler reOriginationRulesHandler,
                                  InterfacesHandler interfacesHandler,
                                  GlobalHubHandler globalHubHandler,
                                  PseudoPaymentHandler pseudoPaymentHandler,
                                  ReOriginationHierarchyHandler reOriginationHierarchyHandler) {
        this.partnerConfigHandler = partnerConfigHandler;
        this.reOriginationAllowedHandler = reOriginationAllowedHandler;
        this.reOriginationTypeAllowedHandler = reOriginationTypeAllowedHandler;
        this.zeroPaymentHandler = zeroPaymentHandler;
        this.suppressedPaymentHandler = suppressedPaymentHandler;
        this.taxLevyHandler = taxLevyHandler;
        this.specialPayeeHandler = specialPayeeHandler;
        this.reOriginationRulesHandler = reOriginationRulesHandler;
        this.interfacesHandler = interfacesHandler;
        this.globalHubHandler = globalHubHandler;
        this.pseudoPaymentHandler = pseudoPaymentHandler;
        this.reOriginationHierarchyHandler = reOriginationHierarchyHandler;
    }

    @Override
    public void executeBusinessValidations(List<BundledRequest> bundledRequests, BundledResponse bundledResponse) {

        bundledRequests.parallelStream()
                .filter(BundledRequest::isPayment)
                .filter(bundledRequest -> partnerConfigHandler.handle(bundledRequest, bundledResponse))
                .filter(bundledRequest -> reOriginationRulesHandler.handle(bundledRequest, bundledResponse))
                .filter(bundledRequest -> interfacesHandler.handle(bundledRequest, bundledResponse))
                .filter(bundledRequest -> reOriginationAllowedHandler.handle(bundledRequest, bundledResponse))
                .filter(bundledRequest -> reOriginationTypeAllowedHandler.handle(bundledRequest, bundledResponse))
                .filter(bundledRequest -> reOriginationHierarchyHandler.handle(bundledRequest, bundledResponse))
                .filter(bundledRequest -> zeroPaymentHandler.handle(bundledRequest, bundledResponse))
                .filter(bundledRequest -> suppressedPaymentHandler.handle(bundledRequest, bundledResponse))
                .filter(bundledRequest -> taxLevyHandler.handle(bundledRequest, bundledResponse))
                .filter(bundledRequest -> specialPayeeHandler.handle(bundledRequest, bundledResponse))
                .filter(bundledRequest -> globalHubHandler.handle(bundledRequest, bundledResponse))
                .filter(bundledRequest -> pseudoPaymentHandler.handle(bundledRequest, bundledResponse))
                .forEach(bundledRequest ->
                        bundledResponse.add(Status.ACCEPTING, bundledRequest.getRequestReason(), bundledRequest)
                );
    }
}
