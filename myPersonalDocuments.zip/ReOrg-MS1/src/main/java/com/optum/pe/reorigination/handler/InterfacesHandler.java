package com.optum.pe.reorigination.handler;

import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.BundledResponse;
import com.optum.pe.reorigination.entity.LookupData;
import com.optum.pe.reorigination.service.LookupDataService;
import com.optum.pe.reorigination.utils.Constants;
import com.optum.pe.reorigination.utils.LookUpDataNotFoundException;
import com.optum.pe.reorigination.utils.Status;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Service
class InterfacesHandler implements Handler {

    private final LookupDataService lookupDataService;

    InterfacesHandler(LookupDataService lookupDataService) {
        this.lookupDataService = lookupDataService;
    }

    @Override
    public boolean handle(BundledRequest bundledRequest, BundledResponse bundledResponse) {

        try {

            LookupData lookupData = lookupDataService.findOneSourceRequest(LocalDate.now(),
                    Constants.PAYMENT_REORIGINATION_INTERFACES_SET_CODE,
                    bundledRequest.getPartnerId(), bundledRequest.getRemitTypeCode(),
                    bundledRequest.getPaymentMethodCode(), bundledRequest.getSourceOfRequest());

            bundledRequest.setInterfaces(lookupData);

        } catch (LookUpDataNotFoundException ex) {

            bundledResponse.add(Status.REJECTING, Constants.ERR_REORIGINATION_INTERFACES_NOT_FOUND,
                    bundledRequest);

            return false;
        }

        return true;
    }
}
