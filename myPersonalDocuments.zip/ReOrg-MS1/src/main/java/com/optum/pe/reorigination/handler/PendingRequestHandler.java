package com.optum.pe.reorigination.handler;

import com.optum.pe.reorigination.bean.Response;
import com.optum.pe.reorigination.entity.ReOriginationRequest;
import com.optum.pe.reorigination.utils.Constants;
import com.optum.pe.reorigination.utils.Status;
import org.springframework.stereotype.Service;

import java.time.format.DateTimeFormatter;

@Service
public class PendingRequestHandler {

    public boolean handle(ReOriginationRequest reOriginationRequest, Response selectedResponse) {

        if (Constants.REORIGINATION_REQUEST_READY.equals(reOriginationRequest.getLatestReOriginationPaymentStatusCode())) {

            selectedResponse.setStatus(Status.REJECTING);
            selectedResponse.setReason(Constants.ERR_REORIGINATION_IN_PROGRESS
                    + reOriginationRequest.getLatestReOriginationRequestDate().format(DateTimeFormatter.ofPattern("MM/dd/yyyy")));

            return false;
        }

        return true;
    }
}
