package com.optum.pe.reorigination.handler;

import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.BundledResponse;
import com.optum.pe.reorigination.utils.Constants;
import com.optum.pe.reorigination.utils.Status;
import org.springframework.stereotype.Service;

@Service
public class ReOriginationAllowedHandler implements Handler {

    @Override
    public boolean handle(BundledRequest bundledRequest, BundledResponse bundledResponse) {

        if (!bundledRequest.isReOriginationAllowed()) {
            bundledResponse.add(Status.REJECTING, Constants.ERR_REORIGINATION_NOT_ALLOWED, bundledRequest);

            return false;
        }

        return true;
    }
}
