package com.optum.pe.reorigination.service;

import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.Payment;
import com.optum.pe.reorigination.bean.Request;
import com.optum.pe.reorigination.bean.Response;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;

import static junit.framework.TestCase.assertNotNull;

@ExtendWith(MockitoExtension.class)
class JsonReadRequestDataConverterTest {

    @InjectMocks
    private JsonDataConverter converter;

    @Test
    void getJsonData() {

        assertNotNull(converter.getJsonData(Response.builder()
                .partnerProcGroupId("UNET")
                .checkTraceNumber("1")
                .build(), getBundledRequests()));
    }

    private List<BundledRequest> getBundledRequests() {

        Request request = new Request();
        request.setPartnerProcGroupId("UNET");
        request.setCheckTraceNumber("1");

        BundledRequest bundledRequest = new BundledRequest(request, Payment.builder().build());

        return Collections.singletonList(bundledRequest);
    }
}