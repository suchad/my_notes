package com.optum.pe.reorigination.handler;

import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.BundledResponse;
import com.optum.pe.reorigination.bean.Request;
import com.optum.pe.reorigination.entity.LookupData;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class ReOriginationHierarchyHandlerTest {

    @InjectMocks
    private ReOriginationHierarchyHandler handler;

    @Test
    void handle() {

        BundledRequest bundledRequest = new BundledRequest(new Request());

        LookupData lookupData = new LookupData();
        lookupData.setResultField02("1");
        lookupData.setResultField03("2");
        lookupData.setResultField04("3");

        bundledRequest.setAdoptionLookup(lookupData);

        assertTrue(handler.handle(bundledRequest, new BundledResponse(2)));
    }

    @Test
    void handle_result_fields() {

        BundledRequest bundledRequest = new BundledRequest(new Request());

        LookupData lookupData = new LookupData();
        lookupData.setResultField02("N");
        lookupData.setResultField03("N");
        lookupData.setResultField04("N");

        bundledRequest.setAdoptionLookup(lookupData);

        assertTrue(handler.handle(bundledRequest, new BundledResponse(2)));
    }
}