package com.optum.pe.reorigination.service;

import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.Payment;
import com.optum.pe.reorigination.bean.Request;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class InitializationMapperTest {

    @InjectMocks
    private InitializationMapper mapper;

    @Test
    void map_ISET_Test() {

        BundledRequest bundledRequest = new BundledRequest(new Request());
        Request request = new Request();
        request.setSourceOfRequest("ISET");
        bundledRequest.setRequest(request);

        mapper.map(bundledRequest);
        assertTrue(true);

    }

    @Test
    void mapTest() {

        BundledRequest bundledRequest = new BundledRequest(new Request());
        Request request = new Request();
        request.setSourceOfRequest("CS");
        bundledRequest.setRequest(request);

        mapper.map(bundledRequest);
        assertTrue(true);

    }

    @Test
    void map_Exclude_ExcludeOriginalRemittanceIndicator_Test() {

        BundledRequest bundledRequest = new BundledRequest(new Request());
        Request request = new Request();
        request.setSourceOfRequest("CS");
        request.setExcludeOriginalRemittanceIndicator("Y");
        bundledRequest.setRequest(request);

        mapper.map(bundledRequest);
        assertTrue(true);

    }
}