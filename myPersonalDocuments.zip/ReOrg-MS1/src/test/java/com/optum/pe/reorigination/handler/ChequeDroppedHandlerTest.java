package com.optum.pe.reorigination.handler;

import com.optum.pe.reorigination.bean.Response;
import com.optum.pe.reorigination.entity.ReOriginationRequest;
import com.optum.pe.reorigination.utils.Constants;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class ChequeDroppedHandlerTest {

    @InjectMocks
    private ChequeDroppedHandler chequeDroppedHandler;

    @Test
    void handle() {
        assertTrue(chequeDroppedHandler.handle(new ReOriginationRequest(),
                Response.builder().build(),
                Constants.RE_ORIGINATION_FLOW));
    }

    @Test
    void handleFalse() {

        ReOriginationRequest reOriginationRequest = new ReOriginationRequest();
        reOriginationRequest.setOriginalPayId(1);
        reOriginationRequest.setReOriginationPaymentMethodCode("CHK");

        assertFalse(chequeDroppedHandler.handle(reOriginationRequest, Response.builder()
                        .payId("1")
                        .build(),
                Constants.FORCE_EXPIRE_FLOW));
    }
}