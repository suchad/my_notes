package com.optum.pe.reorigination.handler;

import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.BundledResponse;
import com.optum.pe.reorigination.bean.Payment;
import com.optum.pe.reorigination.bean.Request;
import com.optum.pe.reorigination.entity.PartnerConfig;
import com.optum.pe.reorigination.service.PartnerConfigService;
import com.optum.pe.reorigination.utils.PartnerConfigNotFoundException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
class PartnerConfigHandlerTest {

    @InjectMocks
    private PartnerConfigHandler handler;

    @Mock
    private PartnerConfigService service;

    @Test
    void handle() throws PartnerConfigNotFoundException {

        Payment payment = Payment.builder().partnerId("1").build();

        Mockito.when(service.findOne("1")).thenReturn(new PartnerConfig());

        assertTrue(handler.handle(new BundledRequest(new Request(), payment),
                new BundledResponse(2)));
    }

    @Test
    void handleException() throws PartnerConfigNotFoundException {

        Payment payment = Payment.builder().partnerId("1").build();

        Mockito.doThrow(new PartnerConfigNotFoundException(""))
                .when(service).findOne("1");

//        Mockito.doNothing()
//                .when(responseService).add(any(), any(), any(), any());

        assertFalse(handler.handle(new BundledRequest(new Request(), payment),
                new BundledResponse(2)));
    }
}