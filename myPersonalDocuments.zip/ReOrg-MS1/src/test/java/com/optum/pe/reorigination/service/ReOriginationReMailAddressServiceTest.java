package com.optum.pe.reorigination.service;

import com.optum.pe.reorigination.bean.Address;
import com.optum.pe.reorigination.bean.Response;
import com.optum.pe.reorigination.entity.ReOriginationRequest;
import com.optum.pe.reorigination.repository.ReOriginationReMailAddressRepository;
import com.optum.pe.reorigination.utils.Constants;
import com.optum.pe.reorigination.utils.Status;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class ReOriginationReMailAddressServiceTest {

    @InjectMocks
    private ReOriginationReMailAddressService service;

    @Mock
    private ReOriginationReMailAddressRepository repository;

    @Test
    void saveAll() {

        ReOriginationRequest reOriginationRequest = new ReOriginationRequest();
        reOriginationRequest.setOriginalPayId(1);
        reOriginationRequest.setReOriginationPaymentRecordId(1L);

        Response response = Response.builder()
                .status(Status.ACCEPTING)
                .addressOverrideIndicator(Constants.ADDRESS_OVERRIDE_INDICATOR_REQUEST)
                .payId("1")
                .reOriginationPaymentRecordId(1L)
                .isSubSequentReOrigination(false)
                .addressFromHierarchy(Address.builder()
                        .zipCode("")
                        .zipCodeExtension("1")
                        .build())
                .build();

        service.saveAll(Collections.singletonList(response), Collections.singletonList(reOriginationRequest));

        assertTrue(true);
    }

    @Test
    void saveAll_Non_Accept() {

        ReOriginationRequest reOriginationRequest = new ReOriginationRequest();
        reOriginationRequest.setOriginalPayId(1);
        reOriginationRequest.setReOriginationPaymentRecordId(1L);

        Response response = Response.builder()
                .addressOverrideIndicator(Constants.ADDRESS_OVERRIDE_INDICATOR_REQUEST)
                .payId("1")
                .isSubSequentReOrigination(true)
                .reOriginationPaymentRecordId(1L)
                .addressFromHierarchy(Address.builder()
                        .zipCode("")
                        .zipCodeExtension("1")
                        .build())
                .build();

        service.saveAll(Collections.singletonList(response), Collections.singletonList(reOriginationRequest));

        assertTrue(true);
    }

    @Test
    void saveAll_SubSequentReOrigination() {

        ReOriginationRequest reOriginationRequest = new ReOriginationRequest();
        reOriginationRequest.setOriginalPayId(1);
        reOriginationRequest.setReOriginationPaymentRecordId(1L);

        Response response = Response.builder()
                .status(Status.ACCEPTING)
                .addressOverrideIndicator(Constants.ADDRESS_OVERRIDE_INDICATOR_REQUEST)
                .payId("1")
                .reOriginationPaymentRecordId(1L)
                .isSubSequentReOrigination(true)
                .addressFromHierarchy(Address.builder()
                        .zipCode("")
                        .zipCodeExtension("1")
                        .build())
                .build();

        service.saveAll(Collections.singletonList(response), Collections.singletonList(reOriginationRequest));

        assertTrue(true);
    }

    @Test
    void saveAll_No_Zip_CodeExt() {

        ReOriginationRequest reOriginationRequest = new ReOriginationRequest();
        reOriginationRequest.setOriginalPayId(1);
        reOriginationRequest.setReOriginationPaymentRecordId(1L);

        Response response = Response.builder()
                .status(Status.ACCEPTING)
                .addressOverrideIndicator(Constants.ADDRESS_OVERRIDE_INDICATOR_REQUEST)
                .payId("1")
                .reOriginationPaymentRecordId(1L)
                .isSubSequentReOrigination(false)
                .addressFromHierarchy(Address.builder()
                        .zipCode("")
                        .zipCodeExtension(" ")
                        .build())
                .build();

        service.saveAll(Collections.singletonList(response), Collections.singletonList(reOriginationRequest));

        assertTrue(true);
    }
}