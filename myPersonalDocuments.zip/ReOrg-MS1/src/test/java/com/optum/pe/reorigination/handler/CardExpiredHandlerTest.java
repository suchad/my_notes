package com.optum.pe.reorigination.handler;

import com.optum.pe.reorigination.bean.Response;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class CardExpiredHandlerTest {

    @InjectMocks
    private CardExpiredHandler cardExpiredHandler;

    @Test
    void handle() {

        assertTrue(cardExpiredHandler.handle(Response.builder().cardStatusEndDate(LocalDate.now()).build()));
    }
}