package com.optum.pe.reorigination.service;

import com.optum.pe.reorigination.bean.Request;
import com.optum.pe.reorigination.bean.SeriesDesignatorAndCheckNumber;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static junit.framework.TestCase.assertEquals;

@ExtendWith(MockitoExtension.class)
class RequestToMapConverterTest {

    @InjectMocks
    private RequestToMapConverter converter;

    @Test
    void convert() {

        SeriesDesignatorAndCheckNumber seriesDesignatorAndCheckNumber = new SeriesDesignatorAndCheckNumber();
        seriesDesignatorAndCheckNumber.setCheckNumberForParentQuery("1");

        Request request = new Request();
        request.setSeriesDesignatorAndCheckNumber(seriesDesignatorAndCheckNumber);

        assertEquals(1, converter.convert(request).size());
    }
}