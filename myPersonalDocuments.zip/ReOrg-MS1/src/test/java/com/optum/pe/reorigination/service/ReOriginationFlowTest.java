package com.optum.pe.reorigination.service;

import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.Payment;
import com.optum.pe.reorigination.bean.Request;
import com.optum.pe.reorigination.entity.LookupData;
import com.optum.pe.reorigination.handler.AddressHandler;
import com.optum.pe.reorigination.handler.PartnerProcGroupIdHandler;
import com.optum.pe.reorigination.handler.ReOriginationCompositeHandler;
import com.optum.pe.reorigination.handler.RequestReasonHandler;
import com.optum.pe.reorigination.handler.SeriesDesignatorIdHandler;
import com.optum.pe.reorigination.handler.StateCodeHandler;
import com.optum.pe.reorigination.handler.SubSequentReOriginationCompositeHandler;
import com.optum.pe.reorigination.handler.ZipCodeHandler;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static junit.framework.TestCase.assertEquals;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
class ReOriginationFlowTest {

    @InjectMocks
    private ReOriginationFlow service;

    @Mock
    private ElasticSearchPaymentService elasticSearchPaymentService;

    @Mock
    private PaymentDecorator paymentDecorator;

    @Mock
    private ServiceErrorsService serviceErrorsService;

    @Mock
    private ReOriginationRequestService reOriginationRequestService;

    @Mock
    private ReOriginationReMailAddressService reOriginationReMailAddressService;

    @Mock
    private ReOriginationCompositeHandler reOriginationCompositeHandler;

    @Mock
    private InitializationMapper initializationHandler;

    @Mock
    private SeriesDesignatorIdHandler seriesDesignatorIdHandler;

    @Mock
    private PartnerProcGroupIdHandler partnerProcGroupIdHandler;

    @Mock
    private AddressHandler addressHandler;

    @Mock
    private StateCodeHandler stateCodeHandler;

    @Mock
    RequestReasonHandler requestReasonHandler;

    @Mock
    SubSequentReOriginationDecorator subSequentReOriginationDecorator;

    @Mock
    SubSequentReOriginationCompositeHandler subSequentReOriginationCompositeHandler;

    @Mock
    private ZipCodeHandler zipCodeHandler;

    @Test
    void reOriginate() {

        List<Request> requests = new ArrayList<>(2);
        requests.add(getRequest());

        List<Payment> indices = getPayments();

        Mockito.when(initializationHandler.map(any())).thenReturn(getBundledRequest(indices));
        Mockito.when(partnerProcGroupIdHandler.handle(any(), any())).thenReturn(true);
        Mockito.when(seriesDesignatorIdHandler.handle(any(), any())).thenReturn(true);
        Mockito.when(seriesDesignatorIdHandler.handle(any(), any())).thenReturn(true);
        Mockito.when(addressHandler.handle(any(), any())).thenReturn(true);
        Mockito.when(stateCodeHandler.handle(any(), any())).thenReturn(true);
        Mockito.when(requestReasonHandler.handle(any(), any())).thenReturn(true);
        Mockito.when(zipCodeHandler.handle(any(), any())).thenReturn(true);

        Mockito.when(elasticSearchPaymentService.getPayments(any()))
                .thenReturn(indices);

        Mockito.doNothing().when(paymentDecorator).decorate(any(), any(), any(), any());

        Mockito.doNothing().when(subSequentReOriginationDecorator).decorate(any(), any());

        Mockito.when(reOriginationRequestService.handle(any(), any(), any())).thenReturn(Collections.emptyList());

        Mockito.doNothing().when(serviceErrorsService).log(any(), any());

        Mockito.doNothing().when(subSequentReOriginationCompositeHandler).executeBusinessValidations(any(), any());


        Mockito.doNothing().when(reOriginationCompositeHandler).executeBusinessValidations(any(), any());

//        Mockito.doAnswer(invocation -> {
//            BundledResponse bundledResponse = invocation.getArgument(3);
//
//            bundledResponse.addResponse(Response.builder().build());
//
//            return bundledResponse;
//        }).when(responseService).add(any(), any(), any(), any());

        assertEquals(0, service.execute(requests).size());
    }

    private BundledRequest getBundledRequest(List<Payment> indices) {
        BundledRequest bundledRequest = new BundledRequest(getRequest(), (Payment) indices.get(0));

        bundledRequest.setReOriginationRules(new LookupData());

        return bundledRequest;
    }

    private List<Payment> getPayments() {
        return Collections.singletonList(Payment.builder().build());
    }

    private Request getRequest() {

        Request request = new Request();
        request.setSourceOfRequest("PEA");

        return request;
    }
}