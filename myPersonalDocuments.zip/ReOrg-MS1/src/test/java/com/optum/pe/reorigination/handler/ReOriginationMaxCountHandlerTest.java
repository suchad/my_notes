package com.optum.pe.reorigination.handler;

import com.optum.pe.reorigination.bean.Response;
import com.optum.pe.reorigination.entity.ReOriginationRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class ReOriginationMaxCountHandlerTest {

    @InjectMocks
    private ReOriginationMaxCountHandler handler;

    @Test
    void handle() {

        ReOriginationRequest reOriginationRequest = new ReOriginationRequest();
        reOriginationRequest.setNumberOfRequests(1);

        assertTrue(handler.handle(reOriginationRequest, Response.builder().paymentReOriginationMaxCount(3).build()));
    }

    @Test
    void handleFalse() {

        ReOriginationRequest reOriginationRequest = new ReOriginationRequest();
        reOriginationRequest.setNumberOfRequests(1);

        assertFalse(handler.handle(reOriginationRequest, Response.builder().paymentReOriginationMaxCount(0).build()));
    }
}