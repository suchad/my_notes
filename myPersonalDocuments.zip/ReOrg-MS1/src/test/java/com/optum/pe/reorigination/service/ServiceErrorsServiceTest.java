package com.optum.pe.reorigination.service;

import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.Payment;
import com.optum.pe.reorigination.bean.Request;
import com.optum.pe.reorigination.bean.Response;
import com.optum.pe.reorigination.repository.ServiceErrorsRepository;
import com.optum.pe.reorigination.utils.Status;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;

import static junit.framework.TestCase.assertTrue;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
class ServiceErrorsServiceTest {

    @InjectMocks
    private ServiceErrorsService service;

    @Mock
    private ServiceErrorsRepository repository;

    @Mock
    private JsonDataConverter jsonDataConverter;

    @Mock
    private StringToLongParser parser;

    @Test
    void log() {

        BundledRequest bundledRequest = new BundledRequest(new Request(), Payment.builder().build());

        Response response = Response.builder()
                .status(Status.REJECTING)
                .checkTraceNumber("1")
                .seriesDesignatorId("1")
                .build();

        Mockito.when(repository.saveAll(any()))
                .thenReturn(Collections.emptyList());

        Mockito.when(jsonDataConverter.getJsonData(any(), any()))
                .thenReturn("");

        Mockito.when(parser.parseWithOutLogging(any())).thenReturn(1L);

        service.log(Collections.singletonList(bundledRequest),
                Collections.singletonList(response));

        assertTrue(true);
    }
}