package com.optum.pe.reorigination.handler;

import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.BundledResponse;
import com.optum.pe.reorigination.bean.Payment;
import com.optum.pe.reorigination.bean.Request;
import com.optum.pe.reorigination.entity.VirtualCardPayment;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
class ForceExpireCompositeHandlerTest {

    @InjectMocks
    private ForceExpireCompositeHandler forceExpireCompositeHandler;

    @Mock
    private ExpiryDaysHandler expiryDaysHandler;

    @Mock
    private CardAlreadyUsedHandler cardAlreadyUsedHandler;

    @Mock
    private ForceExpireLookupHandler forceExpireLookupHandler;

    @Mock
    private CardStatusEndDateHandler cardStatusEndDateHandler;

    @Mock
    private ReOriginationRulesHandler reOriginationRulesHandler;

    @Mock
    private ElectronicPaymentMethodCodeHandler electronicPaymentMethodCodeHandler;

    @Test
    void executeBusinessValidations() {

        BundledRequest bundledRequest = new BundledRequest(new Request());

        Payment payment = Payment.builder()
                .paymentId("1")
                .finalPaymentAmount(BigDecimal.ONE)
                .seriesDesignatorId("1")
                .paymentMethodCode("CHK")
                .vcpFundingArrangementType("1")
                .build();

        bundledRequest.setPayment(payment);

        VirtualCardPayment virtualCardPayment = new VirtualCardPayment();
        virtualCardPayment.setCardStatusEndDate(LocalDate.now());

        bundledRequest.setVirtualCardPayment(virtualCardPayment);

        Mockito.when(expiryDaysHandler.handle(any(), any())).thenReturn(true);
        Mockito.when(cardAlreadyUsedHandler.handle(any(), any())).thenReturn(true);
        Mockito.when(forceExpireLookupHandler.handle(any(), any())).thenReturn(true);
        Mockito.when(cardStatusEndDateHandler.handle(any(), any())).thenReturn(true);
        Mockito.when(reOriginationRulesHandler.handle(any(), any())).thenReturn(true);
        Mockito.when(electronicPaymentMethodCodeHandler.handle(any(), any())).thenReturn(true);

        forceExpireCompositeHandler.executeBusinessValidations(Collections.singletonList(bundledRequest), new BundledResponse(2));

        assertTrue(true);
    }
}