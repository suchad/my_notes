package com.optum.pe.reorigination.service;

import com.optum.pe.reorigination.bean.Request;
import com.optum.pe.reorigination.bean.VcpActivity;
import com.optum.pe.reorigination.utils.Constants;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class SeriesDesignatorAndCheckNumberServiceTest {

    @InjectMocks
    private SeriesDesignatorAndCheckNumberService service;

    @Test
    void getSeriesDesignatorIdAndCheckNumberForQuery() {

        Request request = new Request();
        request.setCheckTraceNumber("1");
        request.setSeriesDesignatorId("1");

        assertNotNull(service.getSeriesDesignatorIdAndCheckNumberForQuery(request));
    }

    @Test
    void getSeriesDesignatorIdAndCheckNumberForQueryCosmos() {

        Request request = new Request();
        request.setPartnerProcGroupId(Constants.PARTNER_PROC_GROUP_ID_COSMOS);
        request.setCheckTraceNumber("1");
        request.setSeriesDesignatorId("1");

        assertNotNull(service.getSeriesDesignatorIdAndCheckNumberForQuery(request));
    }

    @Test
    void decorateSeriesDesignatorIdAndCheckNumberForActivity() {

        VcpActivity vcpActivity = VcpActivity.builder()
                .consolidationPaymentNumber("123456789")
                .reOriginationCheckNumber("123456789")
                .build();

        assertNotNull(service.decorateSeriesDesignatorIdAndCheckNumberForActivity(vcpActivity, "UNET"));
    }

    @Test
    void decorateSeriesDesignatorIdAndCheckNumberForActivityBlank() {

        VcpActivity vcpActivity = VcpActivity.builder()
                .consolidationPaymentNumber("123456789")
                .reOriginationCheckNumber(" ")
                .build();

        assertNotNull(service.decorateSeriesDesignatorIdAndCheckNumberForActivity(vcpActivity, "UNET"));
    }

    @Test
    void decorateSeriesDesignatorIdAndCheckNumberForActivityCosmos() {

        VcpActivity vcpActivity = VcpActivity.builder()
                .consolidationPaymentNumber("123456789")
                .reOriginationCheckNumber("123456789")
                .build();

        assertNotNull(service.decorateSeriesDesignatorIdAndCheckNumberForActivity(vcpActivity, Constants.PARTNER_PROC_GROUP_ID_COSMOS));
    }

    @Test
    void decorateSeriesDesignatorIdAndCheckNumberForActivityCosmosBlank() {

        VcpActivity vcpActivity = VcpActivity.builder()
                .consolidationPaymentNumber("123456789")
                .reOriginationCheckNumber(" ")
                .build();

        assertNotNull(service.decorateSeriesDesignatorIdAndCheckNumberForActivity(vcpActivity, Constants.PARTNER_PROC_GROUP_ID_COSMOS));
    }

    @Test
    void decorateSeriesDesignatorIdAndCheckNumberForActivityCsp() {

        VcpActivity vcpActivity = VcpActivity.builder()
                .consolidationPaymentNumber("123456789")
                .reOriginationCheckNumber("123456789")
                .build();

        assertNotNull(service.decorateSeriesDesignatorIdAndCheckNumberForActivity(vcpActivity, Constants.PARTNER_PROC_GROUP_ID_CSP));
    }

    @Test
    void decorateSeriesDesignatorIdAndCheckNumberForActivityCspBlank() {

        VcpActivity vcpActivity = VcpActivity.builder()
                .consolidationPaymentNumber("123456789")
                .reOriginationCheckNumber(" ")
                .build();

        assertNotNull(service.decorateSeriesDesignatorIdAndCheckNumberForActivity(vcpActivity, Constants.PARTNER_PROC_GROUP_ID_CSP));
    }
}