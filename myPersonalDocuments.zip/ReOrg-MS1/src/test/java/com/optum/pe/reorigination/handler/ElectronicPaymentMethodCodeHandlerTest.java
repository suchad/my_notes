package com.optum.pe.reorigination.handler;

import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.BundledResponse;
import com.optum.pe.reorigination.bean.Payment;
import com.optum.pe.reorigination.bean.Request;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
public class ElectronicPaymentMethodCodeHandlerTest {


    @InjectMocks
    ElectronicPaymentMethodCodeHandler electronicPaymentMethodCodeHandler;

    @Test
    void handle_electronicPaymentMethodCode_payment() {

        BundledRequest bundledRequest = new BundledRequest(new Request());
        Payment payment = Payment.builder()
                .paymentId("1")
                .finalPaymentAmount(BigDecimal.ONE)
                .electronicPaymentMethodCode("VCP")
                .build();
        bundledRequest.setPayment(payment);
        electronicPaymentMethodCodeHandler.handle(bundledRequest, new BundledResponse(2));
        assertTrue(true);
    }

    @Test
    void handle_no_electronicPaymentMethodCode_payment() {

        BundledRequest bundledRequest = new BundledRequest(new Request());
        Payment payment = Payment.builder()
                .paymentId("1")
                .finalPaymentAmount(BigDecimal.ONE)
                .build();
        bundledRequest.setPayment(payment);
        electronicPaymentMethodCodeHandler.handle(bundledRequest, new BundledResponse(2));
        assertTrue(true);
    }

}
