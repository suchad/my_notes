package com.optum.pe.reorigination.service;

import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.Payment;
import com.optum.pe.reorigination.bean.Request;
import com.optum.pe.reorigination.bean.VcpActivity;
import com.optum.pe.reorigination.handler.AddressHandler;
import com.optum.pe.reorigination.handler.ForceExpireCompositeHandler;
import com.optum.pe.reorigination.handler.PartnerProcGroupIdHandler;
import com.optum.pe.reorigination.handler.RequesterIdHandler;
import com.optum.pe.reorigination.handler.StateCodeHandler;
import com.optum.pe.reorigination.utils.Constants;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
class ForceExpireFlowTest {

    @InjectMocks
    private ForceExpireFlow flow;

    @Mock
    private PaymentService paymentService;

    @Mock
    private PaymentDecorator paymentDecorator;

    @Mock
    private ServiceErrorsService serviceErrorsService;

    @Mock
    private ReOriginationRequestService reOriginationRequestService;

    @Mock
    private VirtualCardPaymentService virtualCardPaymentService;

    @Mock
    private CardBlockRequestInfoService cardBlockRequestInfoService;

    @Mock
    private ReOriginationReMailAddressService reOriginationReMailAddressService;

    @Mock
    private ReturnReMailService returnReMailService;

    @Mock
    private AddressHandler addressHandler;

    @Mock
    private RequesterIdHandler requesterIdHandler;

    @Mock
    private StateCodeHandler stateCodeHandler;

    @Mock
    private PartnerProcGroupIdHandler partnerProcGroupIdHandler;

    @Mock
    private ForceExpireCompositeHandler compositeHandler;

    @Mock
    private InitializationMapper initializationMapper;

    @Mock
    private ActivityDateComparator activityDateComparator;

    @Mock
    private StringToLongParser stringToLongParser;

    @Test
    void execute() {

        Request request = new Request();
        request.setCheckTraceNumber("1");
        request.setSeriesDesignatorId("1");
        request.setSourceOfRequest("PHOW");
        request.setSourceSystem("CO");
        request.setRequestReason("");

//        Mockito.when(activityDateComparator.compare(any(), any())).thenReturn(-1);
        Mockito.when(stringToLongParser.parse("1")).thenReturn(1L);

        BundledRequest bundledRequest = new BundledRequest(request);
        bundledRequest.setPayment(Payment.builder()
                .paymentId("1")
                .vcpActivities(Collections.singletonList(VcpActivity.builder().build())).build());
        bundledRequest.setParentQueryMatch(false);

        Mockito.when(initializationMapper.map(any())).thenReturn(bundledRequest);

        Mockito.when(addressHandler.handle(any(), any())).thenReturn(true);
        Mockito.when(requesterIdHandler.handle(any(), any())).thenReturn(true);
        Mockito.when(partnerProcGroupIdHandler.handle(any(), any())).thenReturn(true);
        Mockito.when(stateCodeHandler.handle(any(), any())).thenReturn(true);

        List<Payment> payments = Collections.singletonList(Payment.builder().build());

        Mockito.when(paymentService.getPayments(any())).thenReturn(payments);

        Mockito.doNothing().when(paymentDecorator).decorate(any(), any(), any(), any());

        Mockito.when(virtualCardPaymentService.findByPayId(any())).thenReturn(Collections.emptyList());

        Mockito.doNothing().when(compositeHandler).executeBusinessValidations(any(), any());

        Mockito.when(reOriginationRequestService.handle(any(), any(), any())).thenReturn(Collections.emptyList());

        Mockito.doNothing().when(reOriginationReMailAddressService).saveAll(any(), any());
        Mockito.doNothing().when(returnReMailService).saveAll(any());
        Mockito.doNothing().when(cardBlockRequestInfoService).saveAll(any());
        Mockito.doNothing().when(serviceErrorsService).log(any(), any());

        flow.execute(Collections.singletonList(request));

        assertTrue(true);
    }
}