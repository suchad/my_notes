package com.optum.pe.reorigination.service;

import com.optum.pe.reorigination.repository.LookupDataDao;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.Collections;

import static junit.framework.TestCase.assertEquals;

@ExtendWith(MockitoExtension.class)
class LookupDataCacheTest {

    @InjectMocks
    private LookupDataCache cache;

    @Mock
    private LookupDataDao lookupDataDao;

    @Test
    void findAll() {

        Mockito.when(lookupDataDao.findAll(LocalDate.now()))
                .thenReturn(Collections.emptyList());

        assertEquals(0, cache.findAll(LocalDate.now()).size());
    }
}