package com.optum.pe.reorigination.service;

import com.optum.pe.elasticsearchlibrary.document.Payment;
import com.optum.pe.elasticsearchlibrary.document.VcpActivity;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
class PaymentToPaymentConverterTest {

    @InjectMocks
    private PaymentToPaymentConverter converter;

    @Mock
    private SeriesDesignatorAndCheckNumberService seriesDesignatorAndCheckNumberService;

    @Test
    void convert() {

        Mockito.when(seriesDesignatorAndCheckNumberService.decorateSeriesDesignatorIdAndCheckNumberForActivity(any(), any()))
                .thenReturn(com.optum.pe.reorigination.bean.VcpActivity.builder().build());

        Payment payment = new Payment();
        payment.setVcpActivities(Collections.singletonList(new VcpActivity()));

        assertNotNull(converter.convert(payment));
    }
}