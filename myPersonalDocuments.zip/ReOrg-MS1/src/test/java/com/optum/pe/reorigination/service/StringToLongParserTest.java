package com.optum.pe.reorigination.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static junit.framework.TestCase.assertEquals;

@ExtendWith(MockitoExtension.class)
class StringToLongParserTest {

    @InjectMocks
    private StringToLongParser parser;

    @Test
    void parse() {
        assertEquals(1, parser.parse("1"));
    }

    @Test
    void parseException() {
        assertEquals(0, parser.parse("sdj"));
    }

    @Test
    void parseWithOutLogging() {
        assertEquals(1, parser.parseWithOutLogging("1"));
    }

    @Test
    void parseWithOutLoggingException() {
        assertEquals(0, parser.parseWithOutLogging("sdj"));
    }
}