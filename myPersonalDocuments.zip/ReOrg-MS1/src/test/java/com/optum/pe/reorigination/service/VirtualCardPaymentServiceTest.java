package com.optum.pe.reorigination.service;

import com.optum.pe.reorigination.repository.VirtualCardPaymentRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
class VirtualCardPaymentServiceTest {

    @InjectMocks
    private VirtualCardPaymentService service;

    @Mock
    private VirtualCardPaymentRepository repository;

    @Test
    void saveAll() {

        Mockito.when(repository.saveAll(any())).thenReturn(Collections.emptyList());

        service.saveAll(Collections.emptyList());

        assertTrue(true);
    }

    @Test
    void findByPayId() {

        Mockito.when(repository.findByPayIdInAndReOriginationPaymentRecordIdNotOrderByCycleDateDesc(Collections.emptyList(), 0L))
                .thenReturn(Collections.emptyList());

        service.findByPayId(Collections.emptyList());

        assertTrue(true);
    }
}