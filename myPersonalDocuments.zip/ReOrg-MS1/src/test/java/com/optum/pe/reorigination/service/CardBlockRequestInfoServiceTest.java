package com.optum.pe.reorigination.service;

import com.optum.pe.reorigination.bean.Response;
import com.optum.pe.reorigination.handler.CardExpiredHandler;
import com.optum.pe.reorigination.repository.CardBlockRequestInfoRepository;
import com.optum.pe.reorigination.utils.Status;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
class CardBlockRequestInfoServiceTest {

    @InjectMocks
    private CardBlockRequestInfoService service;

    @Mock
    private CardBlockRequestInfoRepository repository;

    @Mock
    private CardExpiredHandler cardExpiredHandler;

    @Test
    void saveAll() {

        Mockito.when(cardExpiredHandler.handle(any())).thenReturn(true);

        Mockito.when(repository.saveAll(any())).thenReturn(Collections.emptyList());

        service.saveAll(Collections.singletonList(Response.builder()
                .status(Status.ACCEPTING)
                .build()));

        assertTrue(true);
    }
}