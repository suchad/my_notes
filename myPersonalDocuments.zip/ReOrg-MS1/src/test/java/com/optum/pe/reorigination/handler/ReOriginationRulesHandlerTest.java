package com.optum.pe.reorigination.handler;

import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.BundledResponse;
import com.optum.pe.reorigination.bean.Payment;
import com.optum.pe.reorigination.bean.Request;
import com.optum.pe.reorigination.entity.LookupData;
import com.optum.pe.reorigination.entity.PartnerConfig;
import com.optum.pe.reorigination.service.LookupDataService;
import com.optum.pe.reorigination.utils.Constants;
import com.optum.pe.reorigination.utils.LookUpDataNotFoundException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class ReOriginationRulesHandlerTest {

    @InjectMocks
    private ReOriginationRulesHandler handler;

    @Mock
    private LookupDataService lookupDataService;

    @Test
    void handle() throws LookUpDataNotFoundException {

        PartnerConfig partnerConfig = new PartnerConfig();
        partnerConfig.setReOriginationAllowedIndicator("Y");
        partnerConfig.setPartnerId("1");
        partnerConfig.setPartnerProcGroupId("1");

        BundledRequest bundledRequest = new BundledRequest(new Request(), Payment.builder().partnerId("1").build());
        bundledRequest.setPartnerConfig(partnerConfig);

        Mockito.when(lookupDataService.findOne(LocalDate.now(),
                Constants.REORIGINATION_RULES_SET_CODE,
                "1"))
                .thenReturn(new LookupData());

        assertTrue(handler.handle(bundledRequest, new BundledResponse(2)));
    }

    @Test
    void handleException() throws LookUpDataNotFoundException {

        PartnerConfig partnerConfig = new PartnerConfig();
        partnerConfig.setReOriginationAllowedIndicator("Y");
        partnerConfig.setPartnerId("1");
        partnerConfig.setPartnerProcGroupId("1");

        BundledRequest bundledRequest = new BundledRequest(new Request(), Payment.builder().partnerId("1").build());
        bundledRequest.setPartnerConfig(partnerConfig);

        Mockito.doThrow(new LookUpDataNotFoundException(""))
                .when(lookupDataService).findOne(LocalDate.now(),
                Constants.REORIGINATION_RULES_SET_CODE,
                "1");

        assertFalse(handler.handle(bundledRequest, new BundledResponse(2)));
    }
}