package com.optum.pe.reorigination.handler;

import com.optum.pe.reorigination.bean.Address;
import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.BundledResponse;
import com.optum.pe.reorigination.bean.Request;
import com.optum.pe.reorigination.entity.LookupData;
import com.optum.pe.reorigination.service.LookupDataService;
import com.optum.pe.reorigination.utils.Constants;
import com.optum.pe.reorigination.utils.LookUpDataNotFoundException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class StateCodeHandlerTest {

    @InjectMocks
    private StateCodeHandler handler;

    @Mock
    private LookupDataService lookupDataService;

    @Test
    void handle() {

        Request request = new Request();

        assertTrue(handler.handle(new BundledRequest(request), new BundledResponse(2)));
    }

    @Test
    void handleTrue() throws LookUpDataNotFoundException {

        Request request = new Request();
        request.setAddressOverrideIndicator("R");

        Address address = Address.builder()
                .state("")
                .build();

        BundledRequest bundledRequest = new BundledRequest(request);
        bundledRequest.setAddress(address);

        Mockito.when(lookupDataService.findOne(LocalDate.now(), Constants.STATE_CODE_SET_CODE, ""))
                .thenReturn(new LookupData());

        assertTrue(handler.handle(bundledRequest, new BundledResponse(2)));
    }

    @Test
    void handleException() throws LookUpDataNotFoundException {

        Request request = new Request();
        request.setAddressOverrideIndicator("R");

        Address address = Address.builder()
                .state("")
                .build();

        BundledRequest bundledRequest = new BundledRequest(request);
        bundledRequest.setAddress(address);

        Mockito.when(lookupDataService.findOne(LocalDate.now(), Constants.STATE_CODE_SET_CODE, ""))
                .thenThrow(new LookUpDataNotFoundException(""));

        assertFalse(handler.handle(bundledRequest, new BundledResponse(2)));
    }
}