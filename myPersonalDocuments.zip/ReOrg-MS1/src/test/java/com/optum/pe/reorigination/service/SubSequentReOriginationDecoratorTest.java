package com.optum.pe.reorigination.service;

import com.optum.pe.reorigination.bean.Address;
import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.BundledResponse;
import com.optum.pe.reorigination.bean.Payment;
import com.optum.pe.reorigination.bean.Request;
import com.optum.pe.reorigination.bean.VcpActivity;
import com.optum.pe.reorigination.entity.ReOriginationPayment;
import com.optum.pe.reorigination.entity.ReOriginationRequest;
import com.optum.pe.reorigination.handler.Handler;
import com.optum.pe.reorigination.handler.SubSequentReOrigAddressHandler;
import com.optum.pe.reorigination.repository.ReOriginationPaymentRepository;
import com.optum.pe.reorigination.repository.ReOriginationRequestRepository;
import com.optum.pe.reorigination.utils.Constants;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
public class SubSequentReOriginationDecoratorTest {

    @InjectMocks
    SubSequentReOriginationDecorator subSequentReOriginationDecorator;

    @Mock
    ReOriginationRequestRepository repository;

    @Mock
    ReOriginationPaymentRepository reOriginationPaymentRepository;

    @Mock
    SubSequentReOrigAddressHandler subSequentReOrigAddressHandler;


    @Test
    public void decorate_SubsequentReOrig_Test() {

        BundledRequest bundledRequest = new BundledRequest(new Request());
        BundledResponse bundledResponse = new BundledResponse(1);


        Mockito.when(repository.findByReorigSeriesDesignatorIdAndReorigCheckTraceNumber(null,null)).thenReturn(getSubSequentReOrigRequest());
        Mockito.when(reOriginationPaymentRepository.findByreOriginatedPaymentRecordId(getSubSequentReOrigRequest().getReOriginationPaymentRecordId())).thenReturn(getReOrigPayment());

        Mockito.when(subSequentReOrigAddressHandler.handle(any(),any())).thenReturn(true);


        subSequentReOriginationDecorator.decorate(Collections.singletonList(new BundledRequest(new Request())),bundledResponse);
        assertTrue(true);
    }

    @Test
    public void decorate_non_SubsequentReOrig_Test() {

        BundledRequest bundledRequest = new BundledRequest(new Request());
        bundledRequest.setPayment(null);
        BundledResponse bundledResponse = new BundledResponse(1);


        Mockito.when(repository.findByReorigSeriesDesignatorIdAndReorigCheckTraceNumber(null,null)).thenReturn(null);
        Mockito.when(subSequentReOrigAddressHandler.handle(any(),any())).thenReturn(true);


        subSequentReOriginationDecorator.decorate(Collections.singletonList(new BundledRequest(new Request())),bundledResponse);
        assertTrue(true);
    }

    @Test
    public void decorate_SubsequentReOrig_without_Payment_Test() {

        BundledRequest bundledRequest = new BundledRequest(new Request());
        BundledResponse bundledResponse = new BundledResponse(1);

        Mockito.when(subSequentReOrigAddressHandler.handle(any(),any())).thenReturn(true);


        Mockito.when(repository.findByReorigSeriesDesignatorIdAndReorigCheckTraceNumber(null,null)).thenReturn(null);

        subSequentReOriginationDecorator.decorate(Collections.singletonList(new BundledRequest(new Request())),bundledResponse);
        assertTrue(true);
    }

    @Test
    public void decorate_SubsequentReOrig_Payment_Test() {
        BundledResponse bundledResponse = new BundledResponse(1);
        subSequentReOriginationDecorator.decorate(Collections.singletonList(new BundledRequest(new Request(),getPayments())),bundledResponse);
        assertTrue(true);
    }


    @Test
    public void decorate_SubsequentReOrig_No_Payment_Record_Test() {

        BundledRequest bundledRequest = new BundledRequest(new Request());
        BundledResponse bundledResponse = new BundledResponse(1);


        Mockito.when(repository.findByReorigSeriesDesignatorIdAndReorigCheckTraceNumber(null,null)).thenReturn(getSubSequentReOrigRequest());

        Mockito.when(subSequentReOrigAddressHandler.handle(any(),any())).thenReturn(true);


        subSequentReOriginationDecorator.decorate(Collections.singletonList(new BundledRequest(new Request())),bundledResponse);
        assertTrue(true);
    }


    @Test
    public void decorate_SubsequentReOrig_No_ReOrig_Record_Test() {

        BundledRequest bundledRequest = new BundledRequest(new Request());
        BundledResponse bundledResponse = new BundledResponse(1);


        Mockito.when(subSequentReOrigAddressHandler.handle(any(),any())).thenReturn(true);
        Mockito.when(repository.findByReorigSeriesDesignatorIdAndReorigCheckTraceNumber(null,null)).thenReturn(getSubSequentReOrigRequest());
        Mockito.when(reOriginationPaymentRepository.findByreOriginatedPaymentRecordId(getSubSequentReOrigRequest().getReOriginationPaymentRecordId())).thenReturn(getReOrigPayment());


        subSequentReOriginationDecorator.decorate(Collections.singletonList(new BundledRequest(new Request())),bundledResponse);
        assertTrue(true);
    }


    @Test
    public void decorate_SubsequentReOrig_No_Payment_Test() {
        Address addressFromRequest = Address.builder()
                .line1("1")
                .city("Chicago")
                .state("IL")
                .zipCode("60608")
                .countryCode("1")
                .build();

        BundledRequest bundledRequest = new BundledRequest(new Request());
        bundledRequest.setAddress(addressFromRequest);

        BundledResponse bundledResponse = new BundledResponse(1);
        subSequentReOriginationDecorator.decorate(Collections.singletonList(bundledRequest),bundledResponse);
        assertTrue(true);
    }


    @Test
    public void decorate_SubsequentReOrig_With_Address_Test() {


        Address addressFromRequest = Address.builder()
                .line1("1")
                .city("Chicago")
                .state("IL")
                .zipCode("60608")
                .countryCode("1")
                .build();

        BundledRequest bundledRequest = new BundledRequest(new Request());

        bundledRequest.setAddress(addressFromRequest);
        BundledResponse bundledResponse = new BundledResponse(1);
        Mockito.when(subSequentReOrigAddressHandler.handle(any(),any())).thenReturn(true);

        Mockito.when(repository.findByReorigSeriesDesignatorIdAndReorigCheckTraceNumber(null,null)).thenReturn(getSubSequentReOrigRequest());
        Mockito.when(reOriginationPaymentRepository.findByreOriginatedPaymentRecordId(getSubSequentReOrigRequest().getReOriginationPaymentRecordId())).thenReturn(getReOrigPayment());

        subSequentReOriginationDecorator.decorate(Collections.singletonList(bundledRequest),bundledResponse);
        assertTrue(true);
    }



    private Payment getPayments() {

        return Payment.builder()
                .partnerProcGroupId("UNET")
                .checkTraceNumber("1")
                .seriesDesignatorId("1")
                .paymentId("1")
                .vcpActivities(Collections.singletonList(VcpActivity.builder().reOriginationCheckNumber("1").build()))
                .specialPayeeIndicators(Collections.singletonList(""))
                .build();

    }

    private ReOriginationRequest getSubSequentReOrigRequest() {

            return ReOriginationRequest.builder()
                    .reOriginationPaymentRecordId(123L)
                    .originalPayId(1234L)
                    .partnerProcGroupId("UNET")
                    .sequenceNumber(3)
                    .vendorCardId("VCP")
                    .originalPaymentAmount(new BigDecimal("20"))
                    .reOriginationPaymentAmount(new BigDecimal("20"))
                    .reOriginationRequestDate(LocalDate.now())
                    .reOriginationReasonCode("Lost Check")
                    .originalPaymentMethodCode("CHK")
                    .reOriginationPaymentMethodCode("CHK")
                    .reOriginationPaymentStatusCode(Constants.REORIGINATION_REQUEST_READY)
                    .blockVerifiedIndicator("Y")
                    .vcpFundingArngType("P")
                    .reOriginationReMailAddressIndicator("Y")
                    .addressOverrideIndicator("Y")
                    .excludeOriginalRemittanceIndicator("Y")
                    .data("json")
                    .seriesDesignatorId("QK")
                    .checkTraceNumber("123456")
                    .origCheckTraceNumber("123456")
                    .origSeriesDesignatorId("QK")
                    .origElectronicPaymentMethodCode("CHK")
                    .checkIssueDt("20210202")
                    .creationDate(LocalDate.now())
                    .lastUpdateDate(LocalDate.now())
                    .isSubSequentReOrigination(true)
                    .build();


        }

    private ReOriginationPayment getReOrigPayment() {

        return ReOriginationPayment.builder()
                .partnerId("1823-1")
                .build();


    }

    }

