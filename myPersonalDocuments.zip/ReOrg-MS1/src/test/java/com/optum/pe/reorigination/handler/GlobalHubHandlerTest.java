package com.optum.pe.reorigination.handler;

import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.BundledResponse;
import com.optum.pe.reorigination.bean.Indicator;
import com.optum.pe.reorigination.bean.Payment;
import com.optum.pe.reorigination.bean.Request;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class GlobalHubHandlerTest {

    @InjectMocks
    private GlobalHubHandler handler;

    @Test
    void handle() {

        BundledRequest bundledRequest = new BundledRequest(new Request());

        Indicator indicator = Indicator.builder()
                .globalHubPayment("N").build();

        bundledRequest.setIndicator(indicator);

        assertTrue(handler.handle(bundledRequest, new BundledResponse(2)));
    }

    @Test
    void handleFalse() {

        BundledRequest bundledRequest = new BundledRequest(new Request());

        Indicator indicator = Indicator.builder()
                .globalHubPayment("Y").build();

        Payment payment = Payment.builder()
                .partnerProcGroupId("")
                .build();

        bundledRequest.setPayment(payment);
        bundledRequest.setIndicator(indicator);

        assertFalse(handler.handle(bundledRequest, new BundledResponse(2)));
    }
}