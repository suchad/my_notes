package com.optum.pe.reorigination.service;

import com.optum.pe.reorigination.entity.LookupData;
import com.optum.pe.reorigination.utils.Constants;
import com.optum.pe.reorigination.utils.LookUpDataNotFoundException;
import com.optum.pe.reorigination.utils.TreasuryStatus;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

import static junit.framework.TestCase.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(MockitoExtension.class)
class LookupDataServiceTest {

    @InjectMocks
    private LookupDataService service;

    @Mock
    private LookupDataCache cache;

    @Test
    void findOne() throws LookUpDataNotFoundException {

        LookupData lookupData = new LookupData();
        lookupData.setLookupSetCode("");
        lookupData.setKeyField01("");
        lookupData.setKeyField02("");
        lookupData.setKeyField03("");
        lookupData.setKeyField04("");

        List<LookupData> lookupDataList = Collections.singletonList(lookupData);

        Mockito.when(cache.findAll(LocalDate.now()))
                .thenReturn(lookupDataList);

        assertEquals(lookupData, service.findOne(LocalDate.now(), "", "", "", "",""));
    }

    @Test
    void findOneException() {

        LookupData lookupData = new LookupData();

        List<LookupData> lookupDataList = Collections.singletonList(lookupData);

        Mockito.when(cache.findAll(LocalDate.now()))
                .thenReturn(lookupDataList);

        assertThrows(LookUpDataNotFoundException.class, () -> service.findOne(LocalDate.now(), "", "", "", "",""));
    }

    @Test
    void findOne1() throws LookUpDataNotFoundException {

        LookupData lookupData = new LookupData();

        lookupData.setLookupSetCode("");
        lookupData.setKeyField01("");
        lookupData.setKeyField02("");

        List<LookupData> lookupDataList = Collections.singletonList(lookupData);

        Mockito.when(cache.findAll(LocalDate.now()))
                .thenReturn(lookupDataList);

        assertEquals(lookupData, service.findOne(LocalDate.now(), "", ""));
    }

    @Test
    void findOne1Exception() {

        LookupData lookupData = new LookupData();

        List<LookupData> lookupDataList = Collections.singletonList(lookupData);

        Mockito.when(cache.findAll(LocalDate.now()))
                .thenReturn(lookupDataList);

        assertThrows(LookUpDataNotFoundException.class, () -> service.findOne(LocalDate.now(), "", ""));
    }

    @Test
    void findOne2() throws LookUpDataNotFoundException {

        LookupData lookupData = new LookupData();

        lookupData.setLookupSetCode("");
        lookupData.setKeyField01("");
        lookupData.setKeyField02(TreasuryStatus.VOID + "");

        List<LookupData> lookupDataList = Collections.singletonList(lookupData);

        Mockito.when(cache.findAll(LocalDate.now()))
                .thenReturn(lookupDataList);

        assertEquals(lookupData, service.findOne(LocalDate.now(), "", "", TreasuryStatus.VOID));
    }

    @Test
    void findOne2Exception() {

        LookupData lookupData = new LookupData();

        List<LookupData> lookupDataList = Collections.singletonList(lookupData);

        Mockito.when(cache.findAll(LocalDate.now()))
                .thenReturn(lookupDataList);

        assertThrows(LookUpDataNotFoundException.class, () -> service.findOne(LocalDate.now(), "", "", TreasuryStatus.VOID));
    }

    @Test
    void findOne3() throws LookUpDataNotFoundException {

        LookupData lookupData = new LookupData();

        lookupData.setLookupSetCode(Constants.CHECK_SERIES_DESIGNATOR_SET_CODE);
        lookupData.setPartnerDataOwnerGrpId("");

        List<LookupData> lookupDataList = Collections.singletonList(lookupData);

        Mockito.when(cache.findAll(LocalDate.now()))
                .thenReturn(lookupDataList);

        assertEquals(lookupData, service.findOne(LocalDate.now(), ""));
    }

    @Test
    void findOne3Exception() {

        LookupData lookupData = new LookupData();

        List<LookupData> lookupDataList = Collections.singletonList(lookupData);

        Mockito.when(cache.findAll(LocalDate.now()))
                .thenReturn(lookupDataList);

        assertThrows(LookUpDataNotFoundException.class, () -> service.findOne(LocalDate.now(), ""));
    }

    @Test
    void findOne5Exception() {

        LookupData lookupData = new LookupData();
        lookupData.setLookupSetCode("");
        lookupData.setKeyField01("");
        lookupData.setKeyField02("");
        lookupData.setKeyField03("");

        List<LookupData> lookupDataList = Collections.singletonList(lookupData);

        Mockito.when(cache.findAll(LocalDate.now()))
                .thenReturn(lookupDataList);

        assertThrows(LookUpDataNotFoundException.class,
                () -> service.findOneSourceRequest(LocalDate.now(), "", "",
                        "", "", ""));
    }
}