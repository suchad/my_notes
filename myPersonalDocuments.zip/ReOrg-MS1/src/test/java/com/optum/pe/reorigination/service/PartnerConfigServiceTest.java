package com.optum.pe.reorigination.service;

import com.optum.pe.reorigination.entity.PartnerConfig;
import com.optum.pe.reorigination.utils.PartnerConfigNotFoundException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;

import static junit.framework.TestCase.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(MockitoExtension.class)
class PartnerConfigServiceTest {

    @InjectMocks
    private PartnerConfigService service;

    @Mock
    private PartnerConfigCache cache;

    @Test
    void findOne() throws PartnerConfigNotFoundException {

        PartnerConfig partnerConfig = new PartnerConfig();
        partnerConfig.setPartnerId("");

        List<PartnerConfig> partnerConfigs = Collections.singletonList(partnerConfig);

        Mockito.when(cache.findAll()).thenReturn(partnerConfigs);

        assertEquals(partnerConfig, service.findOne(""));
    }

    @Test
    void findOneException() {

        PartnerConfig partnerConfig = new PartnerConfig();
        partnerConfig.setPartnerId("1");

        List<PartnerConfig> partnerConfigs = Collections.singletonList(partnerConfig);

        Mockito.when(cache.findAll()).thenReturn(partnerConfigs);

        assertThrows(PartnerConfigNotFoundException.class, () ->
                service.findOne(""));
    }
}