package com.optum.pe.reorigination.service;

import com.optum.pe.reorigination.entity.PartnerConfig;
import com.optum.pe.reorigination.repository.PartnerConfigRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;

import static junit.framework.TestCase.assertEquals;

@ExtendWith(MockitoExtension.class)
class PartnerConfigCacheTest {

    @InjectMocks
    private PartnerConfigCache cache;

    @Mock
    private PartnerConfigRepository repository;

    @Test
    void findAll() {

        List<PartnerConfig> partnerConfigs = Collections.singletonList(new PartnerConfig());

        Mockito.when(repository.findAll())
                .thenReturn(partnerConfigs);

        assertEquals(1, cache.findAll().size());
    }
}