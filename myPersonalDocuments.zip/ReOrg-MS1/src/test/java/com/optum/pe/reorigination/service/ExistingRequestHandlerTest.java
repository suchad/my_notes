package com.optum.pe.reorigination.service;

import com.optum.pe.reorigination.bean.BundledResponse;
import com.optum.pe.reorigination.bean.Response;
import com.optum.pe.reorigination.entity.ReOriginationRequest;
import com.optum.pe.reorigination.utils.Constants;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class ExistingRequestHandlerTest {

    @InjectMocks
    private ExistingRequestHandler handler;

    @Test
    void handle() {

        ReOriginationRequest reOriginationRequest = new ReOriginationRequest();
        reOriginationRequest.setPartnerProcGroupId("1");
        reOriginationRequest.setSequenceNumber(1);
        reOriginationRequest.setVendorCardId("1");

        handler.handle(Collections.singletonList(reOriginationRequest),
                Collections.singletonList(reOriginationRequest), Constants.RE_ORIGINATION_FLOW);

        assertTrue(true);
    }

    @Test
    void handleN() {

        ReOriginationRequest reOriginationRequest = new ReOriginationRequest();
        reOriginationRequest.setPartnerProcGroupId("1");
        reOriginationRequest.setSequenceNumber(1);
        reOriginationRequest.setVendorCardId("11");
        reOriginationRequest.setOriginalPayId(1);

        BundledResponse bundledResponse = new BundledResponse(2);
        bundledResponse.addResponse(Response.builder()
                .partnerProcGroupId("1")
                .seriesDesignatorId("1")
                .checkTraceNumber("1")
                .payId("1")
                .paymentReOriginationMaxCount(4)
                .build());

        handler.handle(Collections.singletonList(reOriginationRequest),
                Collections.singletonList(reOriginationRequest), Constants.RE_ORIGINATION_FLOW);

        assertTrue(true);
    }
}