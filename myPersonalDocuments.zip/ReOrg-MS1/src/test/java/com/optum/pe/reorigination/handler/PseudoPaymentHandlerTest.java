package com.optum.pe.reorigination.handler;

import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.BundledResponse;
import com.optum.pe.reorigination.bean.Indicator;
import com.optum.pe.reorigination.bean.Payment;
import com.optum.pe.reorigination.bean.Request;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class PseudoPaymentHandlerTest {

    @InjectMocks
    private PseudoPaymentHandler handler;

    @Test
    void handle() {

        BundledRequest bundledRequest = new BundledRequest(new Request());
        bundledRequest.setIndicator(Indicator.builder().pseudoPayment("N").build());

        assertTrue(handler.handle(bundledRequest, new BundledResponse(2)));
    }

    @Test
    void handleFalse() {

        Payment payment = Payment.builder()
                .partnerProcGroupId("")
                .build();

        BundledRequest bundledRequest = new BundledRequest(new Request());
        bundledRequest.setIndicator(Indicator.builder().pseudoPayment("Y").build());

        bundledRequest.setPayment(payment);

        assertFalse(handler.handle(bundledRequest, new BundledResponse(2)));
    }
}