package com.optum.pe.reorigination.handler;

import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.BundledResponse;
import com.optum.pe.reorigination.bean.Payment;
import com.optum.pe.reorigination.bean.Request;
import com.optum.pe.reorigination.entity.VirtualCardPayment;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class CardStatusEndDateHandlerTest {

    @InjectMocks
    private CardStatusEndDateHandler cardStatusEndDateHandler;

    @Test
    void handle() {

        VirtualCardPayment virtualCardPayment = new VirtualCardPayment();
        virtualCardPayment.setCardStatusEndDate(LocalDate.now());

        BundledRequest bundledRequest = new BundledRequest(new Request());
        bundledRequest.setVirtualCardPayment(virtualCardPayment);

        assertTrue(cardStatusEndDateHandler.handle(bundledRequest, new BundledResponse(1)));
    }

    @Test
    void handleFalse() {

        VirtualCardPayment virtualCardPayment = new VirtualCardPayment();

        Payment payment = Payment.builder()
                .paymentId("1")
                .finalPaymentAmount(BigDecimal.ONE)
                .seriesDesignatorId("1")
                .paymentMethodCode("CHK")
                .vcpFundingArrangementType("1")
                .build();

        BundledRequest bundledRequest = new BundledRequest(new Request());
        bundledRequest.setVirtualCardPayment(virtualCardPayment);
        bundledRequest.setPayment(payment);

        assertFalse(cardStatusEndDateHandler.handle(bundledRequest, new BundledResponse(1)));
    }
}