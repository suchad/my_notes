package com.optum.pe.reorigination.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class StringToLocalDateConverterTest {

    @InjectMocks
    private StringToLocalDateConverter converter;

    @Test
    void convert() {
        assertNotNull(converter.convert("2011-12-03T10:15:30+01:00"));
    }

    @Test
    void convertException() {
        assertEquals(LocalDate.MIN, converter.convert(LocalDate.now().format(DateTimeFormatter.ISO_DATE)));
    }
}