package com.optum.pe.reorigination.handler;

import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.BundledResponse;
import com.optum.pe.reorigination.bean.Payment;
import com.optum.pe.reorigination.bean.Request;
import com.optum.pe.reorigination.entity.LookupData;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
class ZeroPaymentHandlerTest {

    @InjectMocks
    private ZeroPaymentHandler handler;

    @Test
    void handle() {

        LookupData lookupData = new LookupData();
        lookupData.setResultField01("N");

        Payment payment = Payment.builder()
                .finalPaymentAmount(BigDecimal.ONE)
                .build();

        BundledRequest bundledRequest = new BundledRequest(new Request(), payment);
        bundledRequest.setReOriginationRules(lookupData);

        assertTrue(handler.handle(bundledRequest, new BundledResponse(2)));
    }

    @Test
    void handleN() {

        LookupData lookupData = new LookupData();
        lookupData.setResultField01("N");

        Payment payment = Payment.builder()
                .finalPaymentAmount(BigDecimal.ZERO)
                .build();

        BundledRequest bundledRequest = new BundledRequest(new Request(), payment);
        bundledRequest.setReOriginationRules(lookupData);

//        Mockito.doNothing()
//                .when(responseService).add(any(), any(), any(), any());

        assertFalse(handler.handle(bundledRequest, new BundledResponse(2)));
    }
}