package com.optum.pe.reorigination.handler;

import com.optum.pe.reorigination.bean.Response;
import com.optum.pe.reorigination.entity.ReOriginationRequest;
import com.optum.pe.reorigination.utils.Constants;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class PendingRequestHandlerTest {

    @InjectMocks
    private PendingRequestHandler handler;

    @Test
    void handle() {

        ReOriginationRequest reOriginationRequest = new ReOriginationRequest();
        reOriginationRequest.setLatestReOriginationPaymentStatusCode("");

        assertTrue(handler.handle(reOriginationRequest, Response.builder().build()));
    }

    @Test
    void handleFalse() {

        ReOriginationRequest reOriginationRequest = new ReOriginationRequest();
        reOriginationRequest.setLatestReOriginationPaymentStatusCode("R");
        reOriginationRequest.setLatestReOriginationRequestDate(LocalDate.now());

        assertFalse(handler.handle(reOriginationRequest, Response.builder().build()));
    }
}