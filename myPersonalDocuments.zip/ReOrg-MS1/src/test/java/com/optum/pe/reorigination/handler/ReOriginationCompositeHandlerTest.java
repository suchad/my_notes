package com.optum.pe.reorigination.handler;

import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.BundledResponse;
import com.optum.pe.reorigination.bean.Request;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class ReOriginationCompositeHandlerTest {

    @InjectMocks
    private ReOriginationCompositeHandler handler;

    @Mock
    private Handler partnerConfigHandler;

    @Mock
    private Handler reOriginationAllowedHandler;

    @Mock
    private Handler reOriginationTypeAllowedHandler;

    @Mock
    private Handler zeroPaymentHandler;

    @Mock
    private Handler suppressedPaymentHandler;

    @Mock
    private Handler taxLevyHandler;

    @Mock
    private Handler specialPayeeHandler;

    @Mock
    private Handler treasuryHandler;

    @Mock
    private Handler reOriginationRulesHandler;

    @Mock
    private Handler interfacesHandler;

    @Mock
    private Handler globalHubHandler;

    @Mock
    private Handler pseudoPaymentHandler;

    @Mock
    private Handler reOriginationHierarchyHandler;

    @Test
    void executeBusinessValidations() {

        handler.executeBusinessValidations(Collections.singletonList(new BundledRequest(new Request())),
                new BundledResponse(2));

        assertTrue(true);
    }
}