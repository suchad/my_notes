package com.optum.pe.reorigination.handler;

import com.optum.pe.reorigination.bean.Address;
import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.BundledResponse;
import com.optum.pe.reorigination.bean.Payment;
import com.optum.pe.reorigination.bean.Request;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
public class SubSequentReOrigAddressHandlerTest {

    @InjectMocks
    SubSequentReOrigAddressHandler subSequentReOrigAddressHandler;

    @Test
    void handle_No_Address() {

        BundledRequest bundledRequest = new BundledRequest(new Request());

        subSequentReOrigAddressHandler.handle(bundledRequest, new BundledResponse(2));

        assertTrue(true);
    }

    @Test
    void handle_Address() {

        BundledRequest bundledRequest = new BundledRequest(new Request());

        Address addressFromRequest = Address.builder()
                .line1("1")
                .city("Chicago")
                .state("IL")
                .zipCode("60608")
                .countryCode("1")
                .build();

        bundledRequest.setAddress(addressFromRequest);

        subSequentReOrigAddressHandler.handle(bundledRequest, new BundledResponse(2));

        assertTrue(true);
    }
}
