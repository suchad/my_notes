package com.optum.pe.reorigination.handler;

import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.BundledResponse;
import com.optum.pe.reorigination.bean.Payment;
import com.optum.pe.reorigination.bean.Request;
import com.optum.pe.reorigination.bean.Response;
import com.optum.pe.reorigination.entity.LookupData;
import com.optum.pe.reorigination.entity.PartnerConfig;
import com.optum.pe.reorigination.entity.ReOriginationRequest;
import com.optum.pe.reorigination.service.TreasuryService;
import com.optum.pe.reorigination.utils.Constants;
import com.optum.pe.reorigination.utils.TreasuryStatus;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class TreasuryUpdateHandlerTest {

    @InjectMocks
    private TreasuryUpdateHandler handler;

    @Mock
    private TreasuryService service;

    @Test
    void handle() {

        LookupData lookupData = new LookupData();
        lookupData.setResultField01("Y");

        BundledRequest bundledRequest = new BundledRequest(new Request());
        bundledRequest.setInterfaces(lookupData);
        bundledRequest.setFinalReOriginationRequest(getReOrigRequest());

        Mockito.doNothing().when(service).initiateVoid(bundledRequest);

        assertTrue(handler.handle(bundledRequest, new BundledResponse(2)));
    }

    @Test
    void handleN() {

        LookupData lookupData = new LookupData();
        lookupData.setResultField01("N");

        BundledRequest bundledRequest = new BundledRequest(new Request());
        bundledRequest.setInterfaces(lookupData);
        bundledRequest.setFinalReOriginationRequest(getReOrigRequest());


        assertTrue(handler.handle(bundledRequest, new BundledResponse(2)));
    }

    @Test
    void handleError_N() {

        Response response = Response.builder().payId("1").build();

        BundledResponse bundledResponse = new BundledResponse(2);
        bundledResponse.addResponse(response);

        PartnerConfig partnerConfig = new PartnerConfig();
        partnerConfig.setPartnerId("1");

        LookupData lookupData = new LookupData();
        lookupData.setResultField01("Y");
        lookupData.setResultField07("Y");

        BundledRequest bundledRequest = new BundledRequest(new Request(), Payment.builder().build());
        bundledRequest.setPartnerConfig(partnerConfig);
        bundledRequest.setReOriginationRules(lookupData);
        bundledRequest.setTreasuryUpdateStatus(TreasuryStatus.NOT_FOUND);

        bundledRequest.setInterfaces(lookupData);
        bundledRequest.setFinalReOriginationRequest(getReOrigRequest());


        assertFalse(handler.handle(bundledRequest, bundledResponse));
    }

    @Test
    void handleError() {

        Response response = Response.builder().payId("1").build();

        BundledResponse bundledResponse = new BundledResponse(2);
        bundledResponse.addResponse(response);

        PartnerConfig partnerConfig = new PartnerConfig();
        partnerConfig.setPartnerId("1");

        LookupData lookupData = new LookupData();
        lookupData.setResultField01("Y");
        lookupData.setResultField07("Y");

        BundledRequest bundledRequest = new BundledRequest(new Request(), Payment.builder().build());
        bundledRequest.setPartnerConfig(partnerConfig);
        bundledRequest.setReOriginationRules(lookupData);
        bundledRequest.setTreasuryUpdateStatus(TreasuryStatus.ERROR);

        bundledRequest.setInterfaces(lookupData);
        bundledRequest.setFinalReOriginationRequest(getReOrigRequest());


        assertFalse(handler.handle(bundledRequest, bundledResponse));
    }

    private ReOriginationRequest getReOrigRequest() {

        return ReOriginationRequest.builder()
                .reOriginationPaymentRecordId(123L)
                .originalPayId(1234L)
                .partnerProcGroupId("UNET")
                .sequenceNumber(3)
                .vendorCardId("VCP")
                .originalPaymentAmount(new BigDecimal("20"))
                .reOriginationPaymentAmount(new BigDecimal("20"))
                .reOriginationRequestDate(LocalDate.now())
                .reOriginationReasonCode("Lost Check")
                .originalPaymentMethodCode("CHK")
                .reOriginationPaymentMethodCode("CHK")
                .reOriginationPaymentStatusCode(Constants.REORIGINATION_REQUEST_READY)
                .blockVerifiedIndicator("Y")
                .vcpFundingArngType("P")
                .reOriginationReMailAddressIndicator("Y")
                .addressOverrideIndicator("Y")
                .excludeOriginalRemittanceIndicator("Y")
                .data("json")
                .seriesDesignatorId("QK")
                .checkTraceNumber("123456")
                .origCheckTraceNumber("123456")
                .origSeriesDesignatorId("QK")
                .origElectronicPaymentMethodCode("CHK")
                .checkIssueDt("20210202")
                .creationDate(LocalDate.now())
                .lastUpdateDate(LocalDate.now())
                .isSubSequentReOrigination(true)
                .build();


    }
}