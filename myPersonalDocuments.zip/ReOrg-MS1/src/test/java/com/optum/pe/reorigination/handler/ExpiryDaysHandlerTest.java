package com.optum.pe.reorigination.handler;

import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.BundledResponse;
import com.optum.pe.reorigination.bean.Payment;
import com.optum.pe.reorigination.bean.Request;
import com.optum.pe.reorigination.entity.LookupData;
import com.optum.pe.reorigination.entity.VirtualCardPayment;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class ExpiryDaysHandlerTest {

    @InjectMocks
    private ExpiryDaysHandler expiryDaysHandler;

    @Test
    void handle() {

        BundledRequest bundledRequest = new BundledRequest(new Request());

        Payment payment = Payment.builder()
                .paymentId("1")
                .finalPaymentAmount(BigDecimal.ONE)
                .seriesDesignatorId("1")
                .paymentMethodCode("CHK")
                .vcpFundingArrangementType("1")
                .build();

        bundledRequest.setPayment(payment);

        VirtualCardPayment virtualCardPayment = new VirtualCardPayment();
        virtualCardPayment.setCardStatusEndDate(LocalDate.now());

        bundledRequest.setVirtualCardPayment(virtualCardPayment);

        LookupData lookupData = new LookupData();
        lookupData.setResultField01("10");

        bundledRequest.setForceExpire(lookupData);

        assertTrue(expiryDaysHandler.handle(bundledRequest, new BundledResponse(2)));
    }

    @Test
    void handleFalse() {

        BundledRequest bundledRequest = new BundledRequest(new Request());

        Payment payment = Payment.builder()
                .paymentId("1")
                .finalPaymentAmount(BigDecimal.ONE)
                .seriesDesignatorId("1")
                .paymentMethodCode("CHK")
                .vcpFundingArrangementType("1")
                .build();

        bundledRequest.setPayment(payment);

        VirtualCardPayment virtualCardPayment = new VirtualCardPayment();
        virtualCardPayment.setCardStatusEndDate(LocalDate.MAX);

        bundledRequest.setVirtualCardPayment(virtualCardPayment);

        LookupData lookupData = new LookupData();
        lookupData.setResultField01("10");

        bundledRequest.setForceExpire(lookupData);

        assertFalse(expiryDaysHandler.handle(bundledRequest, new BundledResponse(2)));
    }
}