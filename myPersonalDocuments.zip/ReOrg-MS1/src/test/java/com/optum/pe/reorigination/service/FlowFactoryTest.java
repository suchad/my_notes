package com.optum.pe.reorigination.service;

import com.optum.pe.reorigination.utils.Constants;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class FlowFactoryTest {

    @InjectMocks
    private FlowFactory factory;

    @Mock
    private ReOriginationFlow reOriginationFlow;

    @Mock
    private ForceExpireFlow forceExpireFlow;

    @Test
    void supplyReOrg() {

        assertEquals(reOriginationFlow, factory.supply(Constants.REQUEST_SOURCE_PHOW));
    }

    @Test
    void supplyForce() {

        assertEquals(forceExpireFlow, factory.supply(""));
    }
}