package com.optum.pe.reorigination.service;

import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.BundledResponse;
import com.optum.pe.reorigination.bean.Payment;
import com.optum.pe.reorigination.bean.Request;
import com.optum.pe.reorigination.bean.Response;
import com.optum.pe.reorigination.entity.ReOriginationRequest;
import com.optum.pe.reorigination.handler.ReOriginationRequestCompositeHandler;
import com.optum.pe.reorigination.repository.ReOriginationRequestRepository;
import com.optum.pe.reorigination.utils.Constants;
import com.optum.pe.reorigination.utils.Status;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
class ReOriginationRequestServiceTest {

    @InjectMocks
    private ReOriginationRequestService service;

    @Mock
    private ReOriginationRequestRepository repository;

    @Mock
    private JsonDataConverter jsonDataConverter;

    @Mock
    private ExistingRequestHandler existingRequestHandler;

    @Mock
    private ReOriginationRequestCompositeHandler reOriginationRequestCompositeHandler;

    @Test
    void handleReOrg() {

        Request request = new Request();
        request.setCheckTraceNumber("1");
        request.setSeriesDesignatorId("1");

        BundledRequest bundledRequest = new BundledRequest(request, Payment.builder().build());
        bundledRequest.setReOriginationRequest(getSubSequentReOrigRequest());

        BundledResponse bundledResponse = new BundledResponse(2);

        bundledResponse.addResponse(Response.builder()
                .status(Status.ACCEPTING)
                .checkTraceNumber("1")
                .payId("1")
                .checkTraceNumber("1")
                .seriesDesignatorId("1")
                .build());

        Mockito.when(jsonDataConverter.getJsonData(any(), any()))
                .thenReturn("");

        Object[] row = {BigDecimal.ONE, new Timestamp(1000L), BigDecimal.ONE, BigDecimal.ONE, ""};

        Mockito.when(repository.findByValuesIn(any()))
                .thenReturn(Collections.singletonList(row));

        Mockito.doNothing().when(existingRequestHandler).handle(any(), any(), any());

        Mockito.when(reOriginationRequestCompositeHandler.handle(any(), any(), any(),any())).thenReturn(true);

        service.handle(Collections.singletonList(bundledRequest), bundledResponse, Constants.RE_ORIGINATION_FLOW);

        assertTrue(true);
    }

    @Test
    void handleReOrg_SubSeqReOrig_Empty() {

        Request request = new Request();
        request.setCheckTraceNumber("1");
        request.setSeriesDesignatorId("1");

        BundledRequest bundledRequest = new BundledRequest(request, Payment.builder().build());

        BundledResponse bundledResponse = new BundledResponse(2);

        bundledResponse.addResponse(Response.builder()
                .status(Status.ACCEPTING)
                .checkTraceNumber("1")
                .payId("1")
                .checkTraceNumber("1")
                .seriesDesignatorId("1")
                .build());

        Mockito.when(jsonDataConverter.getJsonData(any(), any()))
                .thenReturn("");

        Object[] row = {BigDecimal.ONE, new Timestamp(1000L), BigDecimal.ONE, BigDecimal.ONE, ""};

        Mockito.when(repository.findByValuesIn(any()))
                .thenReturn(Collections.singletonList(row));

        Mockito.doNothing().when(existingRequestHandler).handle(any(), any(), any());

        Mockito.when(reOriginationRequestCompositeHandler.handle(any(), any(), any(),any())).thenReturn(true);

        service.handle(Collections.singletonList(bundledRequest), bundledResponse, Constants.RE_ORIGINATION_FLOW);

        assertTrue(true);
    }

    @Test
    void handleReOrg_SubSeqReOrig() {

        Request request = new Request();
        request.setCheckTraceNumber("1");
        request.setSeriesDesignatorId("1");

        BundledRequest bundledRequest = new BundledRequest(request, Payment.builder().build());

        BundledResponse bundledResponse = new BundledResponse(2);
        bundledResponse.addResponse(Response.builder()
                .status(Status.ACCEPTING)
                .checkTraceNumber("1")
                .payId("1")
                .checkTraceNumber("1")
                .seriesDesignatorId("1")
                .isSubSequentReOrigination(true)
                .build());
        service.handle(Collections.singletonList(bundledRequest), bundledResponse, Constants.RE_ORIGINATION_FLOW);

        assertTrue(true);
    }

    @Test
    void testSubSeqReOrigPaymentData() {
        final Request request = new Request();
        request.setCheckTraceNumber("1");
        request.setSeriesDesignatorId("1");
        final String data = "{\"request\":{\"checkTraceNumber\":\"10008116\",\"seriesDesignatorId\":\"WO\",\"excludeOriginalRemittanceIndicator\":\"Y\",\"addressOverrideIndicator\":\"R\",\"sourceOfRequest\":\"PHOW\",\"sourceSystem\":\"CS\",\"requestReason\":\"Lost Check\",\"addressLine1\":\"221B, baker street\",\"addressLine2\":null,\"addressLine3\":null,\"addressCity\":\"new york\",\"addressState\":\"NY\",\"addressZipCode\":\"123\",\"addressZipCodeExtension\":null,\"addressCountryCode\":\"1\",\"requesterId\":\"v58\"},\"payment\":{\"finalPaymentAmount\":100.0,\"consolidationTypeCode\":\"PRA-P\",\"partnerId\":\"1083-1\",\"paymentMethodCode\":\"P\",\"paymentId\":\"1001700000004866576\",\"seriesDesignatorId\":\"WO\",\"partnerProcGroupId\":\"UNET\",\"checkTraceNumber\":\"10008116\",\"payeeId\":\"570849851\",\"adjudicatedAssignedPayeeId\":\"00005\",\"payeeNpiNumber\":null,\"partnerDataOwnerGroupId\":\"UNET\",\"paymentIssueDate\":\"2020-11-10T00:00:00-06:00\",\"payeeName\":\"GRAND STRAND VISION SERVICES\",\"payerId\":\"87726\",\"payerIdTypeCode\":\" \",\"payerTinNumber\":\"411289245\",\"payerName\":\"UnitedHealth Group\",\"payeeAddressLine1Text\":\"4886 SOCASTEE BLVD\",\"payeeAddressLine2Text\":\" \",\"payeeAddressLine3Text\":\" \",\"payeeCityText\":\"MYRTLE BEACH\",\"payeeStateCode\":\"SC\",\"payeeZipCode\":\"29588\",\"payeeCountryCode\":\" \",\"payerAddressLine1Text\":\"Temp Address\",\"payerAddressLine2Text\":\" \",\"payerAddressLine3Text\":\" \",\"payerCityText\":\"Crystal\",\"payerStateCode\":\"MN\",\"payerZipCode\":\"55427\",\"payerCountryCode\":\" \",\"paymentCycleDate\":\"2020-11-10T00:00:00-06:00\",\"preRecoveryPaymentAmount\":0.0,\"creationDate\":\"2021-05-31T08:13:31-05:00\",\"lastUpdateDate\":null,\"consolidationId\":\"1001700000002791183\",\"subPayerId\":\" \",\"sndBankName\":\"Bank of America\",\"vcpFundingArrangementType\":\"ASO\",\"sndBankAccountNumber\":\"*****************\",\"payerTechFaxNumber\":\" \",\"checkLegalEntityGroupImageId\":\"NONE-UHS2\",\"payerTechTelephoneExtensionNumber\":\" \",\"remittanceCoverPageLogoImageId\":\"DN008P\",\"payerTechContactName\":\" \",\"payerCountrySubDivisionCode\":\" \",\"payeeEntitySupplementalName\":\"MARK T DEAN OD\",\"serviceCenterTelephoneNumber\":\"8778423210\",\"serviceCenterCityName\":\"SALT LAKE CITY\",\"sndBankStateCode\":\"CT\",\"serviceCenterStateCode\":\"UT\",\"serviceCenterEmailAddressText\":\" \",\"payerTechWebUrlText\":\"UHCProvider.com/en/contact-us.html\",\"sndBankZipCode\":\"06120\",\"serviceCenterTelephoneExtensionNumber\":\" \",\"sndBankFractionDenominator\":\"119\",\"checkCashPhraseText\":\"PLEASE PRESENT PROMPTLY FOR PAYMENT\",\"checkCashCityName\":\"Hartford\",\"checkLogoImageId\":\" \",\"serviceCenterAddressLine1Text\":\"PO BOX 30555\",\"partnerConsolidationId\":\"                              \",\"currencyCode\":\"USD\",\"checkLegalEntityGroupText\":\"United HealthCare Services, Inc.\",\"payerWebUrlText\":\" \",\"vendorId\":\"COM12345\",\"payerTechTelephoneNumber\":\" \",\"sndBankDfiQualifierId\":\"01\",\"payeeIdTypeCode\":\"TIN\",\"sndBankAddressLine2Text\":\" \",\"sndBankAccountSignatureImageId\":\"DN526P\",\"sndBankCode\":\"          \",\"paymentConsolidationGroupCode\":\"C07ASOBOATOPS\",\"serviceCenterFaxNumber\":\" \",\"payerTechEmailAddressText\":\" \",\"sndBankAddressLine1Text\":\".\",\"sndBankDfiId\":\"011900445\",\"sndBankAccountQualifierNumber\":\"DA\",\"serviceCenterZipCode\":\"84130-0555\",\"serviceCenterAddressLine2Text\":\" \",\"sndBankFractionNumerator\":\"51-44\",\"serviceCenterAddressLine3Text\":\" \",\"serviceCenterName\":\"RICHARDSON/SPRGFLD SRVC CNTR\",\"sndBankAccountOwnerText\":\" \",\"sndBankAddressLine3Text\":\" \",\"electronicPaymentMethodCode\":\"VCP\",\"paymentCapAmount\":\"9.99999999E8\",\"vendorCardId\":\"F35RNA9F6D\",\"expirationDate\":\"2021-07-01T00:00:00-05:00\",\"claims\":[\"1001700000013697034\",\"1001700000013643346\"],\"vcpActivities\":[{\"paymentSettlementDate\":\"2020-11-10T00:00:00-06:00\",\"originalPaymentMethodCode\":\"VCP\",\"consolidationPaymentAmount\":100.0,\"revisedPaymentMethodCode\":\" \",\"reOriginationDate\":\"0001-01-01T00:00:00-06:00\",\"consolidationPaymentNumber\":\"WO10008116\",\"norCode\":\" \",\"reOriginationCheckNumber\":\" \",\"virtualCardPaymentStatusCode\":\"O\",\"seriesDesignatorAndCheckNumber\":{\"seriesDesignatorIdForNestedQuery\":null,\"checkNumberForNestedQuery\":null,\"seriesDesignatorIdForParentQuery\":null,\"checkNumberForParentQuery\":null,\"seriesDesignatorIdForActivity\":\"WO\",\"checkNumberForActivity\":\"10008116\"}}],\"puserDefinedField2\":\" \",\"puserDefinedField5\":\" \",\"puserDefinedField3\":\" \",\"puserDefinedField4\":\"00005\",\"puserDefinedField1\":\" \"},\"address\":{\"line1\":\"221B, baker street\",\"line2\":null,\"line3\":null,\"city\":\"new york\",\"state\":\"NY\",\"zipCode\":\"123\",\"zipCodeExtension\":null,\"countryCode\":\"1\"},\"partnerConfig\":{\"partnerId\":\"1083-1\",\"partnerProcGroupId\":\"UNET\",\"reOriginationAllowedIndicator\":\"Y\",\"vcpAssignOriginalPayIdIndicator\":null,\"vcpPartnerReOriginateToCheckIndicator\":null},\"treasuryStatus\":null,\"treasuryResponse\":null,\"treasuryErrorMessage\":null,\"indicator\":{\"suppressedPayment\":\"N\",\"taxLevy\":\"N\",\"specialPayee\":\"N\"},\"reOriginationHierarchy\":[\"CHK\",\"EFT\",\"VCP\"]}";
        final BundledRequest bundledRequest = new BundledRequest(request, Payment.builder().paymentMethodCode("CHK").partnerId("1").paymentId("1").build());
        final ReOriginationRequest reOriginationRequest = getSubSequentReOrigRequest();
        reOriginationRequest.setData(data);
        bundledRequest.setReOriginationRequest(reOriginationRequest);
        final BundledResponse bundledResponse = new BundledResponse(2);
        bundledResponse.addResponse(Response.builder()
                .status(Status.ACCEPTING)
                .checkTraceNumber("1")
                .payId("1")
                .checkTraceNumber("1")
                .seriesDesignatorId("1")
                .isSubSequentReOrigination(true)
                .build());

        List<BundledRequest> bundledRequests = new  ArrayList<>();
        bundledRequests.add(bundledRequest);
        final List<ReOriginationRequest> reOriginationRequests = service.subSequentReOriginationRequests(bundledRequests, bundledResponse);
        assertNotNull(reOriginationRequests);
        assertNotNull(reOriginationRequests.get(0).getData());
    }


    @Test
    void handleForceExpire() {

        Request request = new Request();
        request.setCheckTraceNumber("1");
        request.setSeriesDesignatorId("1");

        BundledRequest bundledRequest = new BundledRequest(request, Payment.builder().build());

        BundledResponse bundledResponse = new BundledResponse(2);

        bundledResponse.addResponse(Response.builder()
                .status(Status.ACCEPTING)
                .checkTraceNumber("1")
                .payId("1")
                .checkTraceNumber("1")
                .seriesDesignatorId("1")
                .cardStatusEndDate(LocalDate.now())
                .build());

        Mockito.when(jsonDataConverter.getJsonData(any(), any()))
                .thenReturn("");

        Mockito.when(repository.findByValuesIn(any()))
                .thenReturn(Collections.emptyList());

        Mockito.doNothing().when(existingRequestHandler).handle(any(), any(), any());

        Mockito.when(reOriginationRequestCompositeHandler.handle(any(), any(), any(),any())).thenReturn(true);

        service.handle(Collections.singletonList(bundledRequest), bundledResponse, Constants.FORCE_EXPIRE_FLOW);

        assertTrue(true);
    }




    private ReOriginationRequest getSubSequentReOrigRequest() {

        return ReOriginationRequest.builder()
                .reOriginationPaymentRecordId(123L)
                .originalPayId(1234L)
                .partnerProcGroupId("UNET")
                .sequenceNumber(3)
                .vendorCardId("VCP")
                .originalPaymentAmount(new BigDecimal("20"))
                .reOriginationPaymentAmount(new BigDecimal("20"))
                .reOriginationRequestDate(LocalDate.now())
                .reOriginationReasonCode("Lost Check")
                .originalPaymentMethodCode("CHK")
                .reOriginationPaymentMethodCode("CHK")
                .reOriginationPaymentStatusCode(Constants.REORIGINATION_REQUEST_READY)
                .blockVerifiedIndicator("Y")
                .vcpFundingArngType("P")
                .reOriginationReMailAddressIndicator("Y")
                .addressOverrideIndicator("Y")
                .excludeOriginalRemittanceIndicator("Y")
                .data(" ")
                .seriesDesignatorId("QK")
                .checkTraceNumber("123456")
                .origCheckTraceNumber("123456")
                .origSeriesDesignatorId("QK")
                .origElectronicPaymentMethodCode("CHK")
                .checkIssueDt("20210202")
                .creationDate(LocalDate.now())
                .lastUpdateDate(LocalDate.now())
                .isSubSequentReOrigination(true)
                .build();


    }


}