package com.optum.pe.reorigination.handler;

import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.BundledResponse;
import com.optum.pe.reorigination.bean.Request;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
public class SubSequentReOriginationCompositeHandlerTest {

    @InjectMocks
    SubSequentReOriginationCompositeHandler subSequentReOriginationCompositeHandler;

    @Mock
    private Handler partnerConfigHandler;

    @Mock
    private Handler reOriginationAllowedHandler;


    @Test
    void executeBusinessValidations() {


        subSequentReOriginationCompositeHandler.executeBusinessValidations(Collections.singletonList(new BundledRequest(new Request())),
                new BundledResponse(2));



        assertTrue(true);
    }
}
