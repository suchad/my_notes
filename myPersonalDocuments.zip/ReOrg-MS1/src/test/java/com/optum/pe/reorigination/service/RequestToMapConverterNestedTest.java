package com.optum.pe.reorigination.service;

import com.optum.pe.reorigination.bean.Request;
import com.optum.pe.reorigination.bean.SeriesDesignatorAndCheckNumber;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class RequestToMapConverterNestedTest {

    @InjectMocks
    private RequestToMapConverterNested converterNested;

    @Test
    void convert() {

        SeriesDesignatorAndCheckNumber seriesDesignatorAndCheckNumber = new SeriesDesignatorAndCheckNumber();
        seriesDesignatorAndCheckNumber.setCheckNumberForNestedQuery("1");

        Request request = new Request();
        request.setSeriesDesignatorAndCheckNumber(seriesDesignatorAndCheckNumber);

        assertEquals(1, converterNested.convert(request).size());
    }
}