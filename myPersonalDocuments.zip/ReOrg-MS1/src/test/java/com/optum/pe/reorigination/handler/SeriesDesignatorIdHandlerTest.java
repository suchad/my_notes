package com.optum.pe.reorigination.handler;

import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.BundledResponse;
import com.optum.pe.reorigination.bean.Request;
import com.optum.pe.reorigination.entity.LookupData;
import com.optum.pe.reorigination.service.LookupDataService;
import com.optum.pe.reorigination.utils.LookUpDataNotFoundException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class SeriesDesignatorIdHandlerTest {

    @InjectMocks
    private SeriesDesignatorIdHandler handler;

    @Mock
    private LookupDataService lookupDataService;

    @Test
    void handle() {

        Request request = new Request();
        request.setSeriesDesignatorId("1");

        assertTrue(handler.handle(new BundledRequest(request), new BundledResponse(2)));
    }

    @Test
    void handleTrue() throws LookUpDataNotFoundException {

        Request request = new Request();
        request.setSeriesDesignatorId("");
        request.setPartnerProcGroupId("");

        LookupData lookupData = new LookupData();
        lookupData.setResultField01("N");

        Mockito.when(lookupDataService.findOne(LocalDate.now(), ""))
                .thenReturn(lookupData);

        assertTrue(handler.handle(new BundledRequest(request), new BundledResponse(2)));
    }

    @Test
    void handleFalse() throws LookUpDataNotFoundException {

        Request request = new Request();
        request.setSeriesDesignatorId("");
        request.setPartnerProcGroupId("");

        LookupData lookupData = new LookupData();
        lookupData.setResultField01("Y");

        Mockito.when(lookupDataService.findOne(LocalDate.now(), ""))
                .thenReturn(lookupData);

        assertFalse(handler.handle(new BundledRequest(request), new BundledResponse(2)));
    }

    @Test
    void handleException() throws LookUpDataNotFoundException {

        Request request = new Request();
        request.setSeriesDesignatorId("");
        request.setPartnerProcGroupId("");

        LookupData lookupData = new LookupData();
        lookupData.setResultField01("Y");

        Mockito.when(lookupDataService.findOne(LocalDate.now(), ""))
                .thenThrow(new LookUpDataNotFoundException(""));

        assertFalse(handler.handle(new BundledRequest(request), new BundledResponse(2)));
    }
}