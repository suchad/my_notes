package com.optum.pe.reorigination.handler;

import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.BundledResponse;
import com.optum.pe.reorigination.bean.Request;
import com.optum.pe.reorigination.bean.Response;
import com.optum.pe.reorigination.entity.ReOriginationRequest;
import com.optum.pe.reorigination.utils.Constants;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
class ReOriginationRequestCompositeHandlerTest {

    @InjectMocks
    private ReOriginationRequestCompositeHandler handler;

    @Mock
    private ChequeDroppedHandler chequeDroppedHandler;

    @Mock
    private ReOriginationMaxCountHandler reOriginationMaxCountHandler;

    @Mock
    private PendingRequestHandler pendingRequestHandler;

    @Mock
    private TreasuryReadHandler treasuryReadHandler;

    @Mock
    private TreasuryUpdateHandler treasuryUpdateHandler;

    @Test
    void handle() {

        ReOriginationRequest reOriginationRequest = ReOriginationRequest.builder()
                .originalPayId(1)
                .build();

        Response response = Response.builder().payId("1").build();
        response.setPaymentReOriginationMaxCount(0);

        Request request = new Request();
        request.setSourceOfRequest("CS");
        request.setCheckTraceNumber("123456");
        request.setSeriesDesignatorId("QK");
        List<BundledRequest> bundledRequestList = new ArrayList<BundledRequest>();

        BundledRequest bundledRequest = new BundledRequest(request);

        bundledRequestList.add(new BundledRequest(request));

        BundledResponse bundledResponse = new BundledResponse(2);
        bundledResponse.addResponse(response);


        handler.handle(getReOrigRequest(), bundledResponse, Constants.RE_ORIGINATION_FLOW,bundledRequestList );

        assertTrue(true);

    }

    @Test
    void handle_pending_request() {

        ReOriginationRequest reOriginationRequest = ReOriginationRequest.builder()
                .originalPayId(1)
                .build();

        Response response = Response.builder().payId("1").build();
        response.setPaymentReOriginationMaxCount(0);

        Request request = new Request();
        request.setSourceOfRequest("CS");
        request.setCheckTraceNumber("123456");
        request.setSeriesDesignatorId("QK");
        List<BundledRequest> bundledRequestList = new ArrayList<BundledRequest>();

        BundledRequest bundledRequest = new BundledRequest(request);

        bundledRequestList.add(new BundledRequest(request));

        BundledResponse bundledResponse = new BundledResponse(2);
        bundledResponse.addResponse(response);

        Mockito.when(pendingRequestHandler.handle(any(), any())).thenReturn(true);

        handler.handle(getReOrigRequest(), bundledResponse, Constants.RE_ORIGINATION_FLOW,bundledRequestList );

        assertTrue(true);

    }

    @Test
    void handle_ForceExpire() {

        ReOriginationRequest reOriginationRequest = ReOriginationRequest.builder()
                .originalPayId(1)
                .build();

        Response response = Response.builder().payId("1").build();

        Request request = new Request();
        request.setSourceOfRequest("CS");
        request.setCheckTraceNumber("123456");
        request.setSeriesDesignatorId("QK");
        List<BundledRequest> bundledRequestList = new ArrayList<BundledRequest>();

        BundledRequest bundledRequest = new BundledRequest(request);

        bundledRequestList.add(new BundledRequest(request));

        BundledResponse bundledResponse = new BundledResponse(2);
        bundledResponse.addResponse(response);

        Mockito.when(chequeDroppedHandler.handle(any(), any(), any())).thenReturn(true);

        handler.handle(getReOrigRequest(), bundledResponse, Constants.FORCE_EXPIRE_FLOW,bundledRequestList );

        assertTrue(true);

    }


    @Test
    void handleFalse() {

        ReOriginationRequest reOriginationRequest = ReOriginationRequest.builder()
                .originalPayId(1)
                .build();

        Response response = Response.builder().payId("1").build();

        BundledResponse bundledResponse = new BundledResponse(2);
        bundledResponse.addResponse(response);

        Mockito.when(chequeDroppedHandler.handle(reOriginationRequest, response, "1")).thenReturn(false);


        List<BundledRequest> bundledRequestList = new ArrayList<BundledRequest>();
        bundledRequestList.add(new BundledRequest(new Request()));

        assertFalse(handler.handle(reOriginationRequest, bundledResponse, "1",bundledRequestList));
    }


    private ReOriginationRequest getReOrigRequest() {

        return ReOriginationRequest.builder()
                .reOriginationPaymentRecordId(123L)
                .originalPayId(1234L)
                .partnerProcGroupId("UNET")
                .sequenceNumber(3)
                .vendorCardId("VCP")
                .originalPaymentAmount(new BigDecimal("20"))
                .reOriginationPaymentAmount(new BigDecimal("20"))
                .reOriginationRequestDate(LocalDate.now())
                .reOriginationReasonCode("Lost Check")
                .originalPaymentMethodCode("CHK")
                .reOriginationPaymentMethodCode("CHK")
                .reOriginationPaymentStatusCode(Constants.REORIGINATION_REQUEST_READY)
                .blockVerifiedIndicator("Y")
                .vcpFundingArngType("P")
                .reOriginationReMailAddressIndicator("Y")
                .addressOverrideIndicator("Y")
                .excludeOriginalRemittanceIndicator("Y")
                .data("json")
                .seriesDesignatorId("QK")
                .checkTraceNumber("123456")
                .origCheckTraceNumber("123456")
                .origSeriesDesignatorId("QK")
                .origElectronicPaymentMethodCode("CHK")
                .checkIssueDt("20210202")
                .creationDate(LocalDate.now())
                .lastUpdateDate(LocalDate.now())
                .isSubSequentReOrigination(true)
                .build();


    }
}