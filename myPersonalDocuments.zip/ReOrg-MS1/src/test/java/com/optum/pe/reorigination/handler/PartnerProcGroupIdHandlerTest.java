package com.optum.pe.reorigination.handler;

import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.BundledResponse;
import com.optum.pe.reorigination.bean.Request;
import com.optum.pe.reorigination.configuration.PartnerProcGroupIdMapping;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class PartnerProcGroupIdHandlerTest {

    @InjectMocks
    private PartnerProcGroupIdHandler handler;

    @Mock
    private PartnerProcGroupIdMapping mapping;

    @Test
    void handle() {

        Request request = new Request();
        request.setSourceSystem("");

        Mockito.when(mapping.getPartnerProcGroupId("")).thenReturn("");

        assertTrue(handler.handle(new BundledRequest(request), new BundledResponse(2)));
    }

    @Test
    void handleNull() {

        Request request = new Request();
        request.setSourceSystem("");

        Mockito.when(mapping.getPartnerProcGroupId("")).thenReturn(null);

        assertFalse(handler.handle(new BundledRequest(request), new BundledResponse(2)));
    }
}