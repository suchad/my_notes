package com.optum.pe.reorigination.handler;

import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.BundledResponse;
import com.optum.pe.reorigination.bean.Payment;
import com.optum.pe.reorigination.bean.Request;
import com.optum.pe.reorigination.entity.PartnerConfig;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
class ReOriginationAllowedHandlerTest {

    @InjectMocks
    private ReOriginationAllowedHandler handler;

    @Test
    void handle() {

        PartnerConfig partnerConfig = new PartnerConfig();
        partnerConfig.setReOriginationAllowedIndicator("Y");

        BundledRequest bundledRequest = new BundledRequest(new Request(), Payment.builder().build());
        bundledRequest.setPartnerConfig(partnerConfig);

        assertTrue(handler.handle(bundledRequest, new BundledResponse(2)));
    }

    @Test
    void handleN() {

        PartnerConfig partnerConfig = new PartnerConfig();
        partnerConfig.setReOriginationAllowedIndicator("N");

        BundledRequest bundledRequest = new BundledRequest(new Request(), Payment.builder().build());
        bundledRequest.setPartnerConfig(partnerConfig);

//        Mockito.doNothing()
//                .when(responseService).add(any(), any(), any(), any());

        assertFalse(handler.handle(bundledRequest, new BundledResponse(2)));
    }
}