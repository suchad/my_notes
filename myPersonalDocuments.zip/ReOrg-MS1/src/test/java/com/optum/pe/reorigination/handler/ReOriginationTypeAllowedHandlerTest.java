package com.optum.pe.reorigination.handler;

import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.BundledResponse;
import com.optum.pe.reorigination.bean.Payment;
import com.optum.pe.reorigination.bean.Request;
import com.optum.pe.reorigination.entity.LookupData;
import com.optum.pe.reorigination.service.LookupDataService;
import com.optum.pe.reorigination.service.PaymentMethodCodeConverter;
import com.optum.pe.reorigination.utils.Constants;
import com.optum.pe.reorigination.utils.LookUpDataNotFoundException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
class ReOriginationTypeAllowedHandlerTest {

    @InjectMocks
    private ReOriginationTypeAllowedHandler handler;

    @Mock
    private LookupDataService lookupDataService;

    @Mock
    private PaymentMethodCodeConverter paymentMethodCodeConverter;

    @Test
    void handle() throws LookUpDataNotFoundException {

        Payment payment = Payment.builder()
                .partnerId("1")
                .paymentMethodCode("P")
                .consolidationTypeCode("1" + Constants.CONSOLIDATION_TYPE_CODE_SPLITTER + "1")
                .electronicPaymentMethodCode("VCP")
                .build();

        BundledRequest bundledRequest = new BundledRequest(new Request(), payment);

        LookupData lookupData = new LookupData();
        lookupData.setResultField01("N");

        Mockito.when(lookupDataService.findOne(LocalDate.now(),
                Constants.PAYMENT_REORIGINATION_ADOPTION_SET_CODE,
                "1", "1", "P","VCP"))
                .thenReturn(lookupData);

//        Mockito.doNothing()
//                .when(responseService).add(any(), any(), any(), any());

        assertFalse(handler.handle(bundledRequest, new BundledResponse(2)));
    }

    @Test
    void handleY() throws LookUpDataNotFoundException {

        Payment payment = Payment.builder()
                .partnerId("1")
                .paymentMethodCode("P")
                .consolidationTypeCode("1" + Constants.CONSOLIDATION_TYPE_CODE_SPLITTER + "1")
                .electronicPaymentMethodCode("VCP")
                .build();

        BundledRequest bundledRequest = new BundledRequest(new Request(), payment);

        LookupData lookupData = new LookupData();
        lookupData.setResultField01("Y");

        Mockito.when(lookupDataService.findOne(LocalDate.now(),
                Constants.PAYMENT_REORIGINATION_ADOPTION_SET_CODE,
                "1", "1", "P","VCP"))
                .thenReturn(lookupData);

        assertTrue(handler.handle(bundledRequest, new BundledResponse(2)));
    }

    @Test
    void handleException() throws LookUpDataNotFoundException {

        Payment payment = Payment.builder()
                .partnerId("1")
                .paymentMethodCode("P")
                .consolidationTypeCode("1" + Constants.CONSOLIDATION_TYPE_CODE_SPLITTER + "1")
                .electronicPaymentMethodCode("VCP")
                .build();

        BundledRequest bundledRequest = new BundledRequest(new Request(), payment);

        LookupData lookupData = new LookupData();
        lookupData.setResultField01("Y");

        Mockito.doThrow(new LookUpDataNotFoundException(""))
                .when(lookupDataService).findOne(LocalDate.now(),
                Constants.PAYMENT_REORIGINATION_ADOPTION_SET_CODE,
                "1", "1", "P","VCP");

        assertFalse(handler.handle(bundledRequest, new BundledResponse(2)));
    }

    @Test
    void LookUpDataElectronicPaymentMethodCode_Null() throws LookUpDataNotFoundException {

        Payment payment = Payment.builder()
                .partnerId("1")
                .paymentMethodCode("P")
                .consolidationTypeCode("1" + Constants.CONSOLIDATION_TYPE_CODE_SPLITTER + "1")
                .electronicPaymentMethodCode(null)
                .build();

        BundledRequest bundledRequest = new BundledRequest(new Request(), payment);

        LookupData lookupData = new LookupData();
        lookupData.setResultField01("*");

        Mockito.when(lookupDataService.findOne(LocalDate.now(),
                Constants.PAYMENT_REORIGINATION_ADOPTION_SET_CODE,
                "1", "1", "P","*"))
                .thenReturn(lookupData);

        assertFalse(handler.handle(bundledRequest, new BundledResponse(2)));
    }
}