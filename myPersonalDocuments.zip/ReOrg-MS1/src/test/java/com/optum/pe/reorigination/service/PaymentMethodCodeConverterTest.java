package com.optum.pe.reorigination.service;

import com.optum.pe.reorigination.utils.Constants;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static junit.framework.TestCase.assertEquals;

@ExtendWith(MockitoExtension.class)
class PaymentMethodCodeConverterTest {

    @InjectMocks
    private PaymentMethodCodeConverter converter;

    @Test
    void convertP() {

        assertEquals(Constants.TRANSLATED_CHECK, converter.convert(Constants.PAYMENT_METHOD_CODE_P,
                "*"));
    }

    @Test
    void convertE() {

        assertEquals(Constants.TRANSLATED_ELECTRONIC, converter.convert(Constants.PAYMENT_METHOD_CODE_E,
                "*"));
    }

    @Test
    void convertVCP() {

        assertEquals(Constants.TRANSLATED_VCP, converter.convert(Constants.PAYMENT_METHOD_CODE_P,
                "VCP"));
    }

    @Test
    void convertX() {

        assertEquals("", converter.convert("", ""));
    }
}