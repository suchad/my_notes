package com.optum.pe.reorigination.handler;

import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.BundledResponse;
import com.optum.pe.reorigination.bean.Request;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class RequesterIdHandlerTest {

    @InjectMocks
    private RequesterIdHandler handler;

    @Test
    void handle() {

        Request request = new Request();
        request.setRequesterId("1");

        assertTrue(handler.handle(new BundledRequest(request), new BundledResponse(2)));
    }

    @Test
    void handleFalse() {

        Request request = new Request();
        request.setRequesterId("");

        assertFalse(handler.handle(new BundledRequest(request), new BundledResponse(2)));
    }
}