package com.optum.pe.reorigination.handler;

import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.BundledResponse;
import com.optum.pe.reorigination.bean.Payment;
import com.optum.pe.reorigination.bean.Request;
import com.optum.pe.reorigination.entity.VirtualCardPayment;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class CardAlreadyUsedHandlerTest {

    @InjectMocks
    private CardAlreadyUsedHandler cardAlreadyUsedHandler;

    @Test
    void handleFalse() {

        BundledRequest bundledRequest = new BundledRequest(new Request());

        Payment payment = Payment.builder()
                .paymentId("1")
                .finalPaymentAmount(BigDecimal.ONE)
                .seriesDesignatorId("1")
                .paymentMethodCode("CHK")
                .vcpFundingArrangementType("1")
                .build();

        bundledRequest.setPayment(payment);

        VirtualCardPayment virtualCardPayment = new VirtualCardPayment();
        virtualCardPayment.setAc30TotalDueAmount(BigDecimal.ONE);
        virtualCardPayment.setUsedAmount(BigDecimal.ONE);

        bundledRequest.setVirtualCardPayment(virtualCardPayment);

        assertFalse(cardAlreadyUsedHandler.handle(bundledRequest, new BundledResponse(1)));
    }

    @Test
    void handle() {

        BundledRequest bundledRequest = new BundledRequest(new Request());
        bundledRequest.setVirtualCardPayment(new VirtualCardPayment());

        assertTrue(cardAlreadyUsedHandler.handle(bundledRequest, new BundledResponse(1)));
    }
}