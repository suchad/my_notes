package com.optum.pe.reorigination.service;

import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.BundledResponse;
import com.optum.pe.reorigination.bean.Payment;
import com.optum.pe.reorigination.bean.Request;
import com.optum.pe.reorigination.bean.SeriesDesignatorAndCheckNumber;
import com.optum.pe.reorigination.bean.VcpActivity;
import com.optum.pe.reorigination.entity.ReOriginationRequest;
import com.optum.pe.reorigination.utils.Constants;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class PaymentDecoratorTest {

    @InjectMocks
    private PaymentDecorator supplier;

    @Test
    void supply() {

        SeriesDesignatorAndCheckNumber seriesDesignatorAndCheckNumber = new SeriesDesignatorAndCheckNumber();
        seriesDesignatorAndCheckNumber.setCheckNumberForParentQuery("1");
        seriesDesignatorAndCheckNumber.setSeriesDesignatorIdForParentQuery("1");

        Request request = new Request();
        request.setPartnerProcGroupId("UNET");
        request.setCheckTraceNumber("1");
        request.setSeriesDesignatorAndCheckNumber(seriesDesignatorAndCheckNumber);

        BundledResponse bundledResponse = new BundledResponse(1);

        supplier.decorate(getPayments(), new BundledRequest(request), bundledResponse,Constants.RE_ORIGINATION_FLOW);

        assertTrue(true);
    }

    @Test
    void supply2() {

        SeriesDesignatorAndCheckNumber seriesDesignatorAndCheckNumber = new SeriesDesignatorAndCheckNumber();
        seriesDesignatorAndCheckNumber.setCheckNumberForParentQuery("2");
        seriesDesignatorAndCheckNumber.setSeriesDesignatorIdForParentQuery("2");
        seriesDesignatorAndCheckNumber.setCheckNumberForNestedQuery("1");

        Request request = new Request();
        request.setPartnerProcGroupId("UNET");
        request.setCheckTraceNumber("1");
        request.setSeriesDesignatorAndCheckNumber(seriesDesignatorAndCheckNumber);

        BundledResponse bundledResponse = new BundledResponse(1);


        supplier.decorate(getPayments(), new BundledRequest(request), bundledResponse,Constants.RE_ORIGINATION_FLOW);

        assertTrue(true);
    }

    @Test
    void supply3() {

        SeriesDesignatorAndCheckNumber seriesDesignatorAndCheckNumber = new SeriesDesignatorAndCheckNumber();
        seriesDesignatorAndCheckNumber.setCheckNumberForParentQuery("2");
        seriesDesignatorAndCheckNumber.setSeriesDesignatorIdForParentQuery("2");
        seriesDesignatorAndCheckNumber.setCheckNumberForNestedQuery("2");

        Request request = new Request();
        request.setPartnerProcGroupId("UNET");
        request.setCheckTraceNumber("1");
        request.setSeriesDesignatorAndCheckNumber(seriesDesignatorAndCheckNumber);

        BundledResponse bundledResponse = new BundledResponse(1);

        supplier.decorate(getPayments(), new BundledRequest(request), bundledResponse,Constants.FORCE_EXPIRE_FLOW);

        assertTrue(true);
    }


    @Test
    void supply4() {

        SeriesDesignatorAndCheckNumber seriesDesignatorAndCheckNumber = new SeriesDesignatorAndCheckNumber();
        seriesDesignatorAndCheckNumber.setCheckNumberForParentQuery("2");
        seriesDesignatorAndCheckNumber.setSeriesDesignatorIdForParentQuery("2");
        seriesDesignatorAndCheckNumber.setCheckNumberForNestedQuery("2");

        Request request = new Request();
        request.setPartnerProcGroupId("UNET");
        request.setCheckTraceNumber("1");
        request.setSeriesDesignatorAndCheckNumber(seriesDesignatorAndCheckNumber);


        BundledResponse bundledResponse = new BundledResponse(1);

        BundledRequest bundledRequest = new BundledRequest(request);
        bundledRequest.setReOriginationRequest(getSubSequentReOrigRequest());

        supplier.decorate(getPayments(), bundledRequest, bundledResponse,Constants.FORCE_EXPIRE_FLOW);

        assertTrue(true);
    }


    @Test
    void supply5() {

        SeriesDesignatorAndCheckNumber seriesDesignatorAndCheckNumber = new SeriesDesignatorAndCheckNumber();
        seriesDesignatorAndCheckNumber.setCheckNumberForParentQuery("2");
        seriesDesignatorAndCheckNumber.setSeriesDesignatorIdForParentQuery("2");
        seriesDesignatorAndCheckNumber.setCheckNumberForNestedQuery("2");

        Request request = new Request();
        request.setPartnerProcGroupId("UNET");
        request.setCheckTraceNumber("1");
        request.setSeriesDesignatorAndCheckNumber(seriesDesignatorAndCheckNumber);


        BundledResponse bundledResponse = new BundledResponse(1);

        BundledRequest bundledRequest = new BundledRequest(request);
        bundledRequest.setReOriginationRequest(getSubSequentReOrigRequest());

        supplier.decorate(getPaymentsForceExpire(), bundledRequest, bundledResponse,Constants.FORCE_EXPIRE_FLOW);

        assertTrue(true);
    }

    private List<Payment> getPayments() {

        Payment payment = Payment.builder()
                .partnerProcGroupId("UNET")
                .checkTraceNumber("1")
                .seriesDesignatorId("1")
                .paymentId("1")
                .vcpActivities(Collections.singletonList(VcpActivity.builder().reOriginationCheckNumber("1").build()))
                .specialPayeeIndicators(Collections.singletonList(""))
                .build();

        return Collections.singletonList(payment);
    }

    private List<Payment> getPaymentsForceExpire() {

        Payment payment = Payment.builder()
                .partnerProcGroupId("UNET")
                .checkTraceNumber("2")
                .seriesDesignatorId("1")
                .paymentId("1")
                .vcpActivities(Collections.singletonList(VcpActivity.builder().reOriginationCheckNumber("2").build()))
                .specialPayeeIndicators(Collections.singletonList(""))
                .build();

        return Collections.singletonList(payment);
    }

    private ReOriginationRequest getSubSequentReOrigRequest() {

        return ReOriginationRequest.builder()
                .reOriginationPaymentRecordId(123L)
                .originalPayId(1234L)
                .partnerProcGroupId("UNET")
                .sequenceNumber(3)
                .vendorCardId("VCP")
                .originalPaymentAmount(new BigDecimal("20"))
                .reOriginationPaymentAmount(new BigDecimal("20"))
                .reOriginationRequestDate(LocalDate.now())
                .reOriginationReasonCode("Lost Check")
                .originalPaymentMethodCode("CHK")
                .reOriginationPaymentMethodCode("CHK")
                .reOriginationPaymentStatusCode(Constants.REORIGINATION_REQUEST_READY)
                .blockVerifiedIndicator("Y")
                .vcpFundingArngType("P")
                .reOriginationReMailAddressIndicator("Y")
                .addressOverrideIndicator("Y")
                .excludeOriginalRemittanceIndicator("Y")
                .data("json")
                .seriesDesignatorId("QK")
                .checkTraceNumber("123456")
                .origCheckTraceNumber("123456")
                .origSeriesDesignatorId("QK")
                .origElectronicPaymentMethodCode("CHK")
                .checkIssueDt("20210202")
                .creationDate(LocalDate.now())
                .lastUpdateDate(LocalDate.now())
                .isSubSequentReOrigination(true)
                .build();


    }
}