package com.optum.pe.reorigination.handler;

import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.BundledResponse;
import com.optum.pe.reorigination.bean.Request;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
public class ZipCodeHandlerTest {

    @InjectMocks
    private ZipCodeHandler handler;

    @Test
    void handle() {

        BundledResponse bundledResponse = new BundledResponse(1);

        Request request = new Request();

        request.setAddressZipCode("1");
        request.setAddressOverrideIndicator("R");

        handler.handle(new BundledRequest(request), bundledResponse);

        assertTrue(true);

    }


    @Test
    void handle_valid_zip() {

        BundledResponse bundledResponse = new BundledResponse(1);

        Request request = new Request();

        request.setAddressZipCode("63368");
        request.setAddressOverrideIndicator("R");

        handler.handle(new BundledRequest(request), bundledResponse);

        assertTrue(true);    }

}
