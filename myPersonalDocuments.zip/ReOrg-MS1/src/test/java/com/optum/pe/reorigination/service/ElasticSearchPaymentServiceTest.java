package com.optum.pe.reorigination.service;

import com.optum.pe.elasticsearchlibrary.ElasticSearchLibraryTemplate;
import com.optum.pe.reorigination.bean.Request;
import com.optum.pe.reorigination.utils.Constants;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static junit.framework.TestCase.assertEquals;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
class ElasticSearchPaymentServiceTest {

    @InjectMocks
    private ElasticSearchPaymentService service;

    @Mock
    private RequestToMapConverter converter;

    @Mock
    private PaymentToPaymentConverter paymentToPaymentConverter;

    @Mock
    private ElasticSearchLibraryTemplate template;

    @Mock
    private SeriesDesignatorAndCheckNumberService seriesDesignatorAndCheckNumberService;

    @Mock
    private RequestToMapConverterNested converterNested;

    @Test
    void getPayments() {

        Request request = new Request();
        request.setSourceOfRequest(Constants.REQUEST_SOURCE_ISET);

        List<Request> requests = new ArrayList<>(2);
        requests.add(request);

        Mockito.when(converter.convert(any())).thenReturn(Collections.emptyMap());

        Mockito.when(converterNested.convert(request)).thenReturn(Collections.emptyMap());

        Mockito.when(template.get(any())).thenReturn(Collections.emptyList());

        Mockito.when(seriesDesignatorAndCheckNumberService.getSeriesDesignatorIdAndCheckNumberForQuery(request))
                .thenReturn(request);

        assertEquals(0, service.getPayments(requests).size());
    }
}