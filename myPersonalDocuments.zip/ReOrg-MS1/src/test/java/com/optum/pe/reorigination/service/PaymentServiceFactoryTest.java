package com.optum.pe.reorigination.service;

import com.optum.pe.reorigination.utils.Constants;
import com.optum.pe.reorigination.utils.PaymentServiceNotFoundException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(MockitoExtension.class)
class PaymentServiceFactoryTest {

    @InjectMocks
    private PaymentServiceFactory factory;

    @Mock
    private ElasticSearchPaymentService elasticSearchPaymentService;

    @Test
    void getPaymentService() throws PaymentServiceNotFoundException {

        assertNotNull(factory.getPaymentService(Constants.PAYMENT_SERVICE_PEA));
    }

    @Test
    void getPaymentServiceException() {

        assertThrows(PaymentServiceNotFoundException.class,
                () -> factory.getPaymentService(""));
    }
}