package com.optum.pe.reorigination.handler;

import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.BundledResponse;
import com.optum.pe.reorigination.bean.Indicator;
import com.optum.pe.reorigination.bean.Payment;
import com.optum.pe.reorigination.bean.Request;
import com.optum.pe.reorigination.entity.LookupData;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class SuppressedPaymentHandlerTest {

    @InjectMocks
    private SuppressedPaymentHandler handler;

    @Test
    void handle() {

        LookupData lookupData = new LookupData();
        lookupData.setResultField03("Y");

        BundledRequest bundledRequest = new BundledRequest(new Request(), Payment.builder().build());
        bundledRequest.setIndicator(Indicator.builder()
                .suppressedPayment("N")
                .build());
        bundledRequest.setReOriginationRules(lookupData);

        assertTrue(handler.handle(bundledRequest, new BundledResponse(2)));
    }

    @Test
    void handleN() {

        LookupData lookupData = new LookupData();
        lookupData.setResultField03("N");

        BundledRequest bundledRequest = new BundledRequest(new Request(), Payment.builder().build());
        bundledRequest.setIndicator(Indicator.builder()
                .suppressedPayment("Y")
                .build());
        bundledRequest.setReOriginationRules(lookupData);

//        Mockito.doNothing()
//                .when(responseService).add(any(), any(), any(), any());

        assertFalse(handler.handle(bundledRequest, new BundledResponse(2)));
    }
}