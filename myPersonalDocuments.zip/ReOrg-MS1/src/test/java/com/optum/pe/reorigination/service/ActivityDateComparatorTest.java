package com.optum.pe.reorigination.service;

import com.optum.pe.reorigination.bean.VcpActivity;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class ActivityDateComparatorTest {

    @InjectMocks
    private ActivityDateComparator comparator;

    @Mock
    private StringToLocalDateConverter converter;

    @Test
    void compare() {

        Mockito.when(converter.convert("2011-12-03T10:15:30+01:00"))
                .thenReturn(LocalDate.now());

        assertEquals(0, comparator.compare(VcpActivity.builder()
                .virtualCardPaymentStatusCode("O")
                .paymentSettlementDate("2011-12-03T10:15:30+01:00")
                .build(), VcpActivity.builder()
                .reOriginationDate("2011-12-03T10:15:30+01:00")
                .build()));
    }
}
