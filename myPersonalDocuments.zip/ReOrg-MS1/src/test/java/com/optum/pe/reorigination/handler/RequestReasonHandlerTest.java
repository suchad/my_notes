package com.optum.pe.reorigination.handler;

import com.optum.pe.reorigination.bean.BundledRequest;
import com.optum.pe.reorigination.bean.BundledResponse;
import com.optum.pe.reorigination.bean.Request;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;


@ExtendWith(MockitoExtension.class)
public class RequestReasonHandlerTest{

    @InjectMocks
    RequestReasonHandler requestReasonHandle;

    @Test
    void handle() {

       Request request = new Request();
        request.setRequestReason("Lost Check");
        BundledRequest bundledRequest = new BundledRequest(request);
        assertTrue(requestReasonHandle.handle(bundledRequest, new BundledResponse(2)));
    }

    @Test
    void handle_Empty_Reason() {

        BundledRequest bundledRequest = new BundledRequest( new Request());
        assertFalse(requestReasonHandle.handle(bundledRequest, new BundledResponse(2)));
    }


    @Test
    void handle_Request_Reason_Length() {

        Request request = new Request();
        request.setRequestReason("Lost Check due to the postal handling issues and need a new check.");
        BundledRequest bundledRequest = new BundledRequest(request);
        assertFalse(requestReasonHandle.handle(bundledRequest, new BundledResponse(2)));
    }
}
