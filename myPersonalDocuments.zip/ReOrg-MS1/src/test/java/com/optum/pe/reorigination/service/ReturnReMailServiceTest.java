package com.optum.pe.reorigination.service;

import com.optum.pe.reorigination.bean.Response;
import com.optum.pe.reorigination.repository.ReturnReMailRepository;
import com.optum.pe.reorigination.utils.Status;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
class ReturnReMailServiceTest {

    @InjectMocks
    private ReturnReMailService service;

    @Mock
    private ReturnReMailRepository repository;

    @Test
    void saveAll() {

        Mockito.when(repository.saveAll(any())).thenReturn(Collections.emptyList());

        service.saveAll(Collections.singletonList(Response.builder()
                .status(Status.ACCEPTING)
                .isParentQueryMatch(true)
                .build()));

        assertTrue(true);
    }
}