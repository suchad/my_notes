package com.optum.pe.service;

import com.jcraft.jsch.ChannelSftp;
import com.optum.pe.model.FileInfo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.modules.junit4.PowerMockRunner;

import java.io.File;
import java.math.BigInteger;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.time.LocalDateTime;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

@RunWith(PowerMockRunner.class)
public class JSchServiceTest2 {

    @InjectMocks
    private JSchService jSchService;

    @Mock
    private Path path;

    @Mock
    private File file;

    @Mock
    private SMTPService smtpService;

    @Mock
    private FileTransferService fileTransferService;

    @Mock
    private ChannelSftp channelSftp;

    @Test
    public void sendEmail() {

        Mockito.when(path.toString()).thenReturn("");

        jSchService.sendEmail(getFileInfoWithPassword(), path,
                'S', "");

        assertTrue(true);
    }

//    @Test
//    public void generateFileTransferDetails() {
//
//        Mockito.when(path.toFile()).thenReturn(file);
//
//        Mockito.when(file.length()).thenReturn(0L);
//
//        Mockito.when(fileTransferService.insertOrUpdateFile(Mockito.any()))
//                .thenReturn(new FileTransferDetails());
//
//        jSchService.generateFileTransferDetails(getFileInfoWithPassword(), path, 'S');
//
//        assertTrue(true);
//    }

    @Test
    public void fileNameFilterAccepted() {

        Mockito.when(path.getFileName()).thenReturn(path);
        Mockito.when(path.toString()).thenReturn("PE");

        assertTrue(jSchService.fileNameFilter(path, getFileInfoWithPassword()));
    }

    @Test
    public void fileNameFilterRejected() {

        Mockito.when(path.getFileName()).thenReturn(path);
        Mockito.when(path.toString()).thenReturn("PE");

        assertFalse(jSchService.fileNameFilter(path, getFileInfoWithPasswordIgnorePattern()));
    }

    private BasicFileAttributes getBasicFileAttributes() {
        return new BasicFileAttributes() {
            @Override
            public FileTime lastModifiedTime() {
                return FileTime.fromMillis(126712671);
            }

            @Override
            public FileTime lastAccessTime() {
                return FileTime.fromMillis(126712671);
            }

            @Override
            public FileTime creationTime() {
                return FileTime.fromMillis(126712671);
            }

            @Override
            public boolean isRegularFile() {
                return true;
            }

            @Override
            public boolean isDirectory() {
                return false;
            }

            @Override
            public boolean isSymbolicLink() {
                return false;
            }

            @Override
            public boolean isOther() {
                return false;
            }

            @Override
            public long size() {
                return 0;
            }

            @Override
            public Object fileKey() {
                return null;
            }
        };
    }

    private FileInfo getFileInfoWithPassword() {
        FileInfo fileInfo = new FileInfo();
        fileInfo.setFileId(BigInteger.ONE);
        fileInfo.setPartnerProcGroupId("POWR");
        fileInfo.setPartnerId("1291");
        fileInfo.setFilePattern("PE*");
        fileInfo.setFileIgnorePattern("");
        fileInfo.setTransferType("OUTBOUND");
        fileInfo.setHostname("localhost");
        fileInfo.setConnectionType("USERPASS");
        fileInfo.setPortNumber("80");
        fileInfo.setUsername("vivek");
        fileInfo.setPassword("vivek");
        fileInfo.setKey("");
        fileInfo.setPassphrase("");
        fileInfo.setKnownHosts("");
        fileInfo.setRemoteLocation("somelocation");
        fileInfo.setNativeLocation("somelocation");
        fileInfo.setMailRecipients("mmm");
        fileInfo.setCreateDateTime(LocalDateTime.now());
        fileInfo.setCreatedBy("v58");
        fileInfo.setConflictFolder("archive/");
        fileInfo.setConfigActiveFlag("Y");
        fileInfo.setConfigIdentifier("id");
        fileInfo.setEnv("test");

        return fileInfo;
    }

    private FileInfo getFileInfoWithPasswordIgnorePattern() {
        FileInfo fileInfo = new FileInfo();
        fileInfo.setFileId(BigInteger.ONE);
        fileInfo.setPartnerProcGroupId("POWR");
        fileInfo.setPartnerId("1291");
        fileInfo.setFilePattern("*");
        fileInfo.setFileIgnorePattern("PE*");
        fileInfo.setTransferType("OUTBOUND");
        fileInfo.setHostname("localhost");
        fileInfo.setConnectionType("USERPASS");
        fileInfo.setPortNumber("80");
        fileInfo.setUsername("vivek");
        fileInfo.setPassword("vivek");
        fileInfo.setKey("");
        fileInfo.setPassphrase("");
        fileInfo.setKnownHosts("");
        fileInfo.setRemoteLocation("somelocation");
        fileInfo.setNativeLocation("somelocation");
        fileInfo.setMailRecipients("mmm");
        fileInfo.setCreateDateTime(LocalDateTime.now());
        fileInfo.setCreatedBy("v58");
        fileInfo.setConflictFolder("archive/");
        fileInfo.setConfigActiveFlag("Y");
        fileInfo.setConfigIdentifier("id");
        fileInfo.setEnv("test");

        return fileInfo;
    }
}
