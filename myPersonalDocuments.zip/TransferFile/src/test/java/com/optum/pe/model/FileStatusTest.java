package com.optum.pe.model;

import com.optum.pe.model.FileStatus;
import org.junit.Test;

import java.math.BigInteger;

public class FileStatusTest {

    @Test
    public void testFileStatusEntity(){

        FileStatus fileStatus = new FileStatus();

        fileStatus.setFileId(BigInteger.ZERO);
        fileStatus.getFileId();

        fileStatus.setPartnerName("");
        fileStatus.getPartnerName();

        fileStatus.setPartnerId("");
        fileStatus.getPartnerId();

        fileStatus.setFileName("");
        fileStatus.getFileName();

        fileStatus.setStatus("");
        fileStatus.getStatus();
    }
}
