package com.optum.pe.controller;

import com.optum.pe.model.FileInfo;
import com.optum.pe.service.FileInfoService;
import com.optum.pe.service.JSchService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;

@RunWith(MockitoJUnitRunner.Silent.class)
public class SFTPControllerTest {

    @InjectMocks
    private SFTPController sftpController;

    @Mock
    private FileInfoService fileInfoService;

    @Mock
    private JSchService jSchService;

    private List<FileInfo> fileInfoList;

    @Before
    public void setUp() {
        fileInfoList = new ArrayList<>();
        fileInfoList.add(getFileInfo());
    }

    @Test
    public void testUpload() {

        Mockito.when(fileInfoService.getFileInfoFor(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(fileInfoList);

        Mockito.when(jSchService.uploadFile(getFileInfo())).thenReturn(false);

        assertFalse(sftpController.upload("dummyPpid", "dummyIdentifier", "dummyEnv"));

    }

    @Test
    public void testUploadElse() {

        Mockito.when(fileInfoService.getFileInfoFor(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(fileInfoList);

        Mockito.when(jSchService.uploadFile(any())).thenReturn(true);

        assertTrue(sftpController.upload("dummyPpid", "dummyIdentifier", "dummyEnv"));

    }

    private FileInfo getFileInfo() {
        FileInfo fileInfo = new FileInfo();
        fileInfo.setFileId(BigInteger.ZERO);
        fileInfo.setPartnerProcGroupId("");
        fileInfo.setPartnerId("");
        fileInfo.setFilePattern("");
        fileInfo.setFileIgnorePattern("");
        fileInfo.setTransferType("");
        fileInfo.setHostname("");
        fileInfo.setConnectionType("");
        fileInfo.setPortNumber("");
        fileInfo.setUsername("");
        fileInfo.setPassword("");
        fileInfo.setKey("");
        fileInfo.setPassphrase("");
        fileInfo.setKnownHosts("");
        fileInfo.setRemoteLocation("");
        fileInfo.setNativeLocation("");
        fileInfo.setMailRecipients("");
        fileInfo.setCreateDateTime(LocalDateTime.now());
        fileInfo.setCreatedBy("");
        fileInfo.setConflictFolder("");
        fileInfo.setConfigActiveFlag("");
        fileInfo.setConfigIdentifier("");
        fileInfo.setEnv("");

        return fileInfo;
    }
}

