package com.optum.pe.model;

import com.optum.pe.model.DirectoryMapping;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;


public class DirectoryMappingTest {

    @Test
    public void testDirectoryMappingEntity() {

        DirectoryMapping directoryMapping = new DirectoryMapping();

        directoryMapping.setLocal("");
        directoryMapping.getLocal();

        directoryMapping.setRemote("");
        directoryMapping.getRemote();

        directoryMapping.setAcceptedFileNamePattern(new ArrayList<>());
        directoryMapping.getAcceptedFileNamePattern();

        directoryMapping.setIgnoredFileNamePattern(new ArrayList<>());
        directoryMapping.getIgnoredFileNamePattern();

        directoryMapping.setRecipients(new ArrayList<>());
        directoryMapping.getRecipients();

        directoryMapping.setConflictFolder("");
        directoryMapping.getConflictFolder();
    }
}
