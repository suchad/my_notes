package com.optum.pe.service;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import com.optum.pe.model.FileInfo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.Vector;

import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.spy;

@RunWith(MockitoJUnitRunner.Silent.class)
public class SFTPInboundTest2 {

    @Mock
    private JSch mockJSch;

    @Mock
    private Session mockSession;

    @Mock
    private ChannelSftp channelSftp;

    private SFTPInbound mockedClass = spy(SFTPInbound.class);

    @Test
    public void inboundProcessor() {

        Mockito.when(mockedClass.getJSch()).thenReturn(mockJSch);

        try {
            Mockito.when(mockJSch.getSession(any(), any(), Mockito.anyInt()))
                    .thenReturn(mockSession);

            Mockito.doNothing().when(mockSession).connect();

            Mockito.when(mockSession.openChannel("sftp")).thenReturn(channelSftp);

            Mockito.doNothing().when(channelSftp).connect();

            Mockito.when(channelSftp.ls(any())).thenReturn(new Vector());

        } catch (JSchException | SftpException ex) {
        }

        mockedClass.sftpConnection(getFileInfoWithPassword());

        assertTrue(true);
    }

    @Test
    public void createSessionWithKey() {

        Mockito.when(mockedClass.getJSch()).thenReturn(mockJSch);

        try {
            Mockito.when(mockJSch.getSession(any(), any(), Mockito.anyInt()))
                    .thenReturn(mockSession);

            Mockito.doNothing().when(mockSession).connect();

            Mockito.when(mockSession.openChannel("sftp")).thenReturn(channelSftp);

            Mockito.doNothing().when(channelSftp).connect();

            mockedClass.createSessionWithKey(getFileInfoWithKey());
        } catch (JSchException ex) {
        }

        assertTrue(true);
    }

    private FileInfo getFileInfoWithPassword() {
        FileInfo fileInfo = new FileInfo();
        fileInfo.setFileId(BigInteger.ONE);
        fileInfo.setPartnerProcGroupId("POWR");
        fileInfo.setPartnerId("1291");
        fileInfo.setFilePattern("PE*");
        fileInfo.setFileIgnorePattern("");
        fileInfo.setTransferType("OUTBOUND");
        fileInfo.setHostname("localhost");
        fileInfo.setConnectionType("USERPASS");
        fileInfo.setPortNumber("80");
        fileInfo.setUsername("vivek");
        fileInfo.setPassword("vivek");
        fileInfo.setKey("");
        fileInfo.setPassphrase("");
        fileInfo.setKnownHosts("");
        fileInfo.setRemoteLocation("somelocation");
        fileInfo.setNativeLocation("somelocation");
        fileInfo.setMailRecipients("mmm");
        fileInfo.setCreateDateTime(LocalDateTime.now());
        fileInfo.setCreatedBy("v58");
        fileInfo.setConflictFolder("archive/");
        fileInfo.setConfigActiveFlag("Y");
        fileInfo.setConfigIdentifier("id");
        fileInfo.setEnv("test");

        return fileInfo;
    }

    private FileInfo getFileInfoWithKey() {
        FileInfo fileInfo = new FileInfo();
        fileInfo.setFileId(BigInteger.ONE);
        fileInfo.setPartnerProcGroupId("POWR");
        fileInfo.setPartnerId("1291");
        fileInfo.setFilePattern("PE*");
        fileInfo.setFileIgnorePattern("");
        fileInfo.setTransferType("OUTBOUND");
        fileInfo.setHostname("localhost");
        fileInfo.setConnectionType("KEYS");
        fileInfo.setPortNumber("80");
        fileInfo.setUsername("vivek");
        fileInfo.setPassword("vivek");
        fileInfo.setKey("");
        fileInfo.setPassphrase("");
        fileInfo.setKnownHosts("");
        fileInfo.setRemoteLocation("somelocation");
        fileInfo.setNativeLocation("somelocation");
        fileInfo.setMailRecipients("mmm");
        fileInfo.setCreateDateTime(LocalDateTime.now());
        fileInfo.setCreatedBy("v58");
        fileInfo.setConflictFolder("archive/");
        fileInfo.setConfigActiveFlag("Y");
        fileInfo.setConfigIdentifier("id");
        fileInfo.setEnv("test");

        return fileInfo;
    }
}