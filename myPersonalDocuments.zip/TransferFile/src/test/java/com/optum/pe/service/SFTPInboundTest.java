package com.optum.pe.service;

import com.optum.pe.model.FileInfo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.Arrays;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.Silent.class)
public class SFTPInboundTest {

    @InjectMocks
    private SFTPInbound sftpInbound;

    @Mock
    private SMTPService smtpService;

    @Mock
    private FileInfoService fileInfoService;

    @Test
    public void inboundProcessor() {

        Mockito.when(fileInfoService.getFileInfoForTransferType())
                .thenReturn(Arrays.asList(getFileInfoWithPassword()));

        sftpInbound.inboundProcessor();

        assertTrue(true);
    }

    @Test
    public void sendEmail() {

//        Mockito.doNothing().when(smtpService).sendMail(Mockito.any(), Mockito.anyString()
//                , Mockito.anyString(), Mockito.anyChar(), Mockito.any());

        sftpInbound.sendEmail(getFileInfoWithPassword(), "",
                'S', "");

        assertTrue(true);
    }

    @Test
    public void waitForSeconds() {
        sftpInbound.waitForSeconds(3);

        assertTrue(true);
    }

    @Test
    public void generateFileTransferDetails() {

        sftpInbound.generateFileTransferDetails("", 'S', 0L,
                getFileInfoWithPassword());

        assertTrue(true);
    }

    @Test
    public void fileNameFilterAccepted() {

        assertTrue(sftpInbound.fileNameFilter("PE", getFileInfoWithPassword()));
    }

    @Test
    public void fileNameFilterRejected() {

        assertFalse(sftpInbound.fileNameFilter("PE", getFileInfoWithPasswordIgnorePattern()));
    }

    private FileInfo getFileInfoWithPasswordIgnorePattern() {
        FileInfo fileInfo = new FileInfo();
        fileInfo.setFileId(BigInteger.ONE);
        fileInfo.setPartnerProcGroupId("POWR");
        fileInfo.setPartnerId("1291");
        fileInfo.setFilePattern("*");
        fileInfo.setFileIgnorePattern("PE*");
        fileInfo.setTransferType("OUTBOUND");
        fileInfo.setHostname("localhost");
        fileInfo.setConnectionType("USERPASS");
        fileInfo.setPortNumber("80");
        fileInfo.setUsername("vivek");
        fileInfo.setPassword("vivek");
        fileInfo.setKey("");
        fileInfo.setPassphrase("");
        fileInfo.setKnownHosts("");
        fileInfo.setRemoteLocation("somelocation");
        fileInfo.setNativeLocation("somelocation");
        fileInfo.setMailRecipients("mmm");
        fileInfo.setCreateDateTime(LocalDateTime.now());
        fileInfo.setCreatedBy("v58");
        fileInfo.setConflictFolder("archive/");
        fileInfo.setConfigActiveFlag("Y");
        fileInfo.setConfigIdentifier("id");
        fileInfo.setEnv("test");

        return fileInfo;
    }

    private FileInfo getFileInfoWithPassword() {
        FileInfo fileInfo = new FileInfo();
        fileInfo.setFileId(BigInteger.ONE);
        fileInfo.setPartnerProcGroupId("POWR");
        fileInfo.setPartnerId("1291");
        fileInfo.setFilePattern("PE*");
        fileInfo.setFileIgnorePattern("");
        fileInfo.setTransferType("OUTBOUND");
        fileInfo.setHostname("localhost");
        fileInfo.setConnectionType("USERPASS");
        fileInfo.setPortNumber("80");
        fileInfo.setUsername("vivek");
        fileInfo.setPassword("vivek");
        fileInfo.setKey("");
        fileInfo.setPassphrase("");
        fileInfo.setKnownHosts("");
        fileInfo.setRemoteLocation("somelocation");
        fileInfo.setNativeLocation("somelocation");
        fileInfo.setMailRecipients("mmm");
        fileInfo.setCreateDateTime(LocalDateTime.now());
        fileInfo.setCreatedBy("v58");
        fileInfo.setConflictFolder("archive/");
        fileInfo.setConfigActiveFlag("Y");
        fileInfo.setConfigIdentifier("id");
        fileInfo.setEnv("test");

        return fileInfo;
    }
}