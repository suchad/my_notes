package com.optum.pe.model;

import com.optum.pe.model.FileDetails;
import org.junit.Test;

public class FileDetailsTest {

    @Test
    public void testFileDetailsEntity(){

        FileDetails fileDetails = new FileDetails();

        fileDetails.setDirectory("");
        fileDetails.getDirectory();

        fileDetails.setFileName("");
        fileDetails.getFileName();

        fileDetails.setLink("");
        fileDetails.getLink();

        fileDetails.setModified("");
        fileDetails.getModified();

        fileDetails.setPermissions("");
        fileDetails.getPermissions();

        fileDetails.setRemoteDirectory("");
        fileDetails.getRemoteDirectory();

        fileDetails.setSize("");
        fileDetails.getSize();

    }

}
