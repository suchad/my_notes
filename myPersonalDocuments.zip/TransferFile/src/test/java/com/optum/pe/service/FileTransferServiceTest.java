package com.optum.pe.service;

import com.optum.pe.model.FileTransferDetails;
import com.optum.pe.repository.FileTransferRepository;
import com.optum.pe.service.FileTransferService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigInteger;
import java.time.LocalDateTime;

import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.Silent.class)
public class FileTransferServiceTest {

    @InjectMocks
    private FileTransferService fileTransferService;

    @Mock
    private FileTransferRepository fileTransferRepository;

    @Test
    public void testInsertOrUpdatefile(){
        Mockito.when(fileTransferRepository.save(getFileTransferDetails())).thenReturn(getFileTransferDetails());

        fileTransferService.insertOrUpdateFile(getFileTransferDetails());
        assertTrue(true);
    }

    private FileTransferDetails getFileTransferDetails(){

        FileTransferDetails fileTransferDetails = new FileTransferDetails();
        fileTransferDetails.setId(BigInteger.ZERO);
        fileTransferDetails.setPartnerProcGroupId("");
        fileTransferDetails.setFileId(BigInteger.ZERO);
        fileTransferDetails.setRemoteHostName("");
        fileTransferDetails.setRemoteDirectoryPath("");
        fileTransferDetails.setDataFileName("");
        fileTransferDetails.setRemoteAuditFileName("");
        fileTransferDetails.setRemoteTriggerFileName("");
        fileTransferDetails.setDataFileName("");
        fileTransferDetails.setCreatedByName("");
        fileTransferDetails.setCreatedDateTime(LocalDateTime.now());
        fileTransferDetails.setUpdatedByName("");
        fileTransferDetails.setUpdatedDateTime(LocalDateTime.now());
        fileTransferDetails.setPartnerId("");
        fileTransferDetails.setTransferTypeCode("");
        fileTransferDetails.setAuditFileName("");
        fileTransferDetails.setTransferStartDateTime(LocalDateTime.now());
        fileTransferDetails.setTransferEndDateTime(LocalDateTime.now());
        fileTransferDetails.setStatusCode('a');
        fileTransferDetails.setDataFileSizeInBytes(0);
        fileTransferDetails.setAuditFileSizeInBytes(0);

        return fileTransferDetails;
    }

}
