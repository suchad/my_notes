package com.optum.pe.service;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import com.optum.pe.model.FileInfo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.io.IOException;
import java.math.BigInteger;
import java.nio.file.Path;
import java.time.LocalDateTime;

import static org.junit.Assert.assertFalse;
import static org.mockito.Mockito.spy;

@RunWith(MockitoJUnitRunner.Silent.class)
public class JSchServiceTest {

    @InjectMocks
    private JSchService jSchService;

    @Mock
    private SMTPService smtpService;

    @Mock
    private FileTransferService fileTransferService;

    @Mock
    private JSch mockJSch;

    @Mock
    private Session mockSession;

    @Mock
    private ChannelSftp channelSftp;

    @Mock
    private Path path;

    private JSchService mockedClass = spy(new JSchService(fileTransferService, smtpService));

    @Test
    public void sendFile() {

        try {
            Mockito.when(mockedClass.zipAndMoveFile(path, "archive/"))
                    .thenReturn(true);
        } catch (IOException ex) {
        }

        Mockito.when(path.getFileName()).thenReturn(path);
        Mockito.when(path.getParent()).thenReturn(path);

        Mockito.when(path.toString()).thenReturn("");

        try {
            Mockito.doNothing().when(channelSftp).put("", "somelocation");
        } catch (SftpException ex) {

        }

        assertFalse(mockedClass.sendFile(channelSftp, "somelocation", path,
                "archive/"));
    }

    @Test
    public void testUploadFileWithException() {

        assertFalse(jSchService.uploadFile(getFileInfoWithPassword()));
    }

    @Test
    public void uploadFileWithPassword() {
        Mockito.when(mockedClass.getJSch()).thenReturn(mockJSch);

        try {
            Mockito.when(mockJSch.getSession(Mockito.any(), Mockito.any()))
                    .thenReturn(mockSession);

            Mockito.doNothing().when(mockSession).connect();

            Mockito.when(mockSession.openChannel("sftp")).thenReturn(channelSftp);

            Mockito.doNothing().when(channelSftp).connect();
        } catch (JSchException ex) {
        }

        assertFalse(mockedClass.uploadFile(getFileInfoWithPassword()));
    }

    @Test
    public void uploadFileWithKeys() {
        Mockito.when(mockedClass.getJSch()).thenReturn(mockJSch);

        try {
            Mockito.when(mockJSch.getSession(Mockito.any(), Mockito.any()))
                    .thenReturn(mockSession);

            Mockito.doNothing().when(mockJSch).addIdentity("", "");

            Mockito.doNothing().when(mockSession).connect();

            Mockito.when(mockSession.openChannel("sftp")).thenReturn(channelSftp);

            Mockito.doNothing().when(channelSftp).connect();
        } catch (JSchException ex) {
        }

        assertFalse(mockedClass.uploadFile(getFileInfoWithKeys()));
    }

    private FileInfo getFileInfoWithPassword() {
        FileInfo fileInfo = new FileInfo();
        fileInfo.setFileId(BigInteger.ONE);
        fileInfo.setPartnerProcGroupId("POWR");
        fileInfo.setPartnerId("1291");
        fileInfo.setFilePattern("PE*");
        fileInfo.setFileIgnorePattern("");
        fileInfo.setTransferType("OUTBOUND");
        fileInfo.setHostname("localhost");
        fileInfo.setConnectionType("USERPASS");
        fileInfo.setPortNumber("80");
        fileInfo.setUsername("vivek");
        fileInfo.setPassword("vivek");
        fileInfo.setKey("");
        fileInfo.setPassphrase("");
        fileInfo.setKnownHosts("");
        fileInfo.setRemoteLocation("somelocation");
        fileInfo.setNativeLocation("somelocation");
        fileInfo.setMailRecipients("mmm");
        fileInfo.setCreateDateTime(LocalDateTime.now());
        fileInfo.setCreatedBy("v58");
        fileInfo.setConflictFolder("archive/");
        fileInfo.setConfigActiveFlag("Y");
        fileInfo.setConfigIdentifier("id");
        fileInfo.setEnv("test");

        return fileInfo;
    }

    private FileInfo getFileInfoWithKeys() {
        FileInfo fileInfo = new FileInfo();
        fileInfo.setFileId(BigInteger.ONE);
        fileInfo.setPartnerProcGroupId("POWR");
        fileInfo.setPartnerId("1291");
        fileInfo.setFilePattern("PE*");
        fileInfo.setFileIgnorePattern("");
        fileInfo.setTransferType("OUTBOUND");
        fileInfo.setHostname("localhost");
        fileInfo.setConnectionType("KEYS");
        fileInfo.setPortNumber("80");
        fileInfo.setUsername("vivek");
        fileInfo.setPassword("vivek");
        fileInfo.setKey("");
        fileInfo.setPassphrase("");
        fileInfo.setKnownHosts("");
        fileInfo.setRemoteLocation("somelocation");
        fileInfo.setNativeLocation("somelocation");
        fileInfo.setMailRecipients("mmm");
        fileInfo.setCreateDateTime(LocalDateTime.now());
        fileInfo.setCreatedBy("v58");
        fileInfo.setConflictFolder("archive/");
        fileInfo.setConfigActiveFlag("Y");
        fileInfo.setConfigIdentifier("id");
        fileInfo.setEnv("test");

        return fileInfo;
    }

}
