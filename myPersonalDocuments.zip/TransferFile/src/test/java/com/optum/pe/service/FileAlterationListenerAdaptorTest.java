package com.optum.pe.service;

import org.apache.commons.io.monitor.FileAlterationObserver;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.io.File;
import java.nio.file.Path;

import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.Silent.class)
public class FileAlterationListenerAdaptorTest {

    @Mock
    private Path path;

    private FileLinkedList fileLinkedList = new FileLinkedList();

    @Mock
    private File file;

    @Test
    public void testOnFileCreate() {
        File testFile = new File("dummyPath");

        Mockito.when(path.toFile()).thenReturn(file);
        Mockito.when(file.listFiles()).thenReturn(new File[]{});

        FileAlterationListenerAdaptor fileAlterationListenerAdaptor =
                new FileAlterationListenerAdaptor(fileLinkedList, path);

        fileAlterationListenerAdaptor.onFileCreate(testFile);

        assertTrue(true);
    }

    @Test
    public void testOnFileChange() {
        File testFile = new File("dummyPath");

        Mockito.when(path.toFile()).thenReturn(file);
        Mockito.when(file.listFiles()).thenReturn(new File[]{});

        FileAlterationListenerAdaptor fileAlterationListenerAdaptor =
                new FileAlterationListenerAdaptor(fileLinkedList, path);

        fileAlterationListenerAdaptor.onFileChange(testFile);

        assertTrue(true);
    }

    @Test
    public void test() {

        Mockito.when(path.toFile()).thenReturn(file);
        Mockito.when(file.listFiles()).thenReturn(new File[]{});

        FileAlterationListenerAdaptor fileAlterationListenerAdaptor =
                new FileAlterationListenerAdaptor(fileLinkedList, path);

        fileAlterationListenerAdaptor.onStart(new FileAlterationObserver(""));
        fileAlterationListenerAdaptor.onDirectoryCreate(file);
        fileAlterationListenerAdaptor.onDirectoryChange(file);
        fileAlterationListenerAdaptor.onDirectoryDelete(file);
        fileAlterationListenerAdaptor.onFileDelete(file);
        fileAlterationListenerAdaptor.onStop(new FileAlterationObserver(""));

        assertTrue(true);
    }
}
