package com.optum.pe.service;

import com.optum.pe.model.FileInfo;
import com.optum.pe.repository.FileInfoRepository;
import com.optum.pe.service.FileInfoService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.Silent.class)
public class FileInfoServiceTest {

    @InjectMocks
    private FileInfoService fileInfoService;

    @Mock
    private FileInfoRepository fileInfoRepository;

    private  List<FileInfo> fileInfoList;

    @Before
    public void setUp(){
        fileInfoList = new ArrayList<>();
        fileInfoList.add(getFileInfo());
    }

    @Test
    public void testGetFileInfo(){
        Mockito.when(fileInfoRepository.findAll()).thenReturn(fileInfoList);

        assertEquals(fileInfoList,fileInfoService.getFileInfo());

    }

    @Test
    public void testGetFileInfoFor(){
        Mockito.when(fileInfoRepository.findByPartnerNameAndPartnerId(Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(fileInfoList);

        assertEquals(fileInfoList,fileInfoService.getFileInfoFor("dummyPpid","dummyIdentifier","dummyEnv"));


    }

    @Test
    public void testGetFileForTransferType(){
        Mockito.when(fileInfoRepository.findByTransferType()).thenReturn(fileInfoList);

        assertEquals(fileInfoList,fileInfoService.getFileInfoForTransferType());
    }

    private FileInfo getFileInfo(){
        FileInfo fileInfo = new FileInfo();
        fileInfo.setFileId(BigInteger.ZERO);
        fileInfo.setPartnerProcGroupId("");
        fileInfo.setPartnerId("");
        fileInfo.setFilePattern("");
        fileInfo.setFileIgnorePattern("");
        fileInfo.setTransferType("");
        fileInfo.setHostname("");
        fileInfo.setConnectionType("");
        fileInfo.setPortNumber("");
        fileInfo.setUsername("");
        fileInfo.setPassword("");
        fileInfo.setKey("");
        fileInfo.setPassphrase("");
        fileInfo.setKnownHosts("");
        fileInfo.setRemoteLocation("");
        fileInfo.setNativeLocation("");
        fileInfo.setMailRecipients("");
        fileInfo.setCreateDateTime(LocalDateTime.now());
        fileInfo.setCreatedBy("");
        fileInfo.setConflictFolder("");
        fileInfo.setConfigActiveFlag("");
        fileInfo.setConfigIdentifier("");
        fileInfo.setEnv("");

        return fileInfo;
    }


}
