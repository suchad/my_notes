package com.optum.pe.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import java.nio.file.FileSystems;
import java.nio.file.Path;

import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.Silent.class)
public class FileNameComparatorTest {

    @InjectMocks
    private FileNameComparator fileNameComparator;

    private Path datFile = FileSystems.getDefault().getPath("dummy1.dat");
    private Path ctlFile = FileSystems.getDefault().getPath("dummy2.ctl");
    private Path testFile = FileSystems.getDefault().getPath("dummyWithoutAny");
    private Path testFile2 = FileSystems.getDefault().getPath("dummyWithoutAny");

    @Test
    public void testCompare1() {
        int actual = fileNameComparator.compare(datFile, ctlFile);
        assertEquals(1, actual);
    }

    @Test
    public void testCompareNegative1() {
        int actual = fileNameComparator.compare(ctlFile, datFile);
        assertEquals(-1, actual);
    }

    @Test
    public void testCompareNegative2() {
        assertEquals(1, fileNameComparator.compare(ctlFile, testFile));
    }

    @Test
    public void testCompareNegative3() {
        assertEquals(-1, fileNameComparator.compare(testFile2, ctlFile));
    }

    @Test
    public void testCompareNegativeAll() {
        assertEquals(0, fileNameComparator.compare(testFile2, testFile));
    }
}
