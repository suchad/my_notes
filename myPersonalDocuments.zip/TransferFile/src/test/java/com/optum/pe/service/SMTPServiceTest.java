package com.optum.pe.service;

import com.optum.pe.configuration.DefaultConfiguration;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.mail.javamail.JavaMailSender;

import javax.mail.Session;
import javax.mail.internet.MimeMessage;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.Silent.class)
public class SMTPServiceTest {

    @InjectMocks
    private SMTPService smtpService;

    @Mock
    private DefaultConfiguration defaultConfiguration;

    @Mock
    private JavaMailSender javaMailSender;

    private List<String> recipients;

    private MimeMessage mimeMessage;

    @Before
    public void setUp() {
        recipients = new ArrayList<>();
        recipients.add("recipient1");
        recipients.add("recipient2");

        Properties properties = new Properties();
        properties.put("dummyKey", "dummyValue");
        Session session = Session.getDefaultInstance(properties, null);
        mimeMessage = new MimeMessage(session);
    }

    @Test
    public void testSendMail() {

        Mockito.when(javaMailSender.createMimeMessage()).thenReturn(mimeMessage);

        Mockito.doNothing().when(javaMailSender).send(mimeMessage);

        Mockito.when(defaultConfiguration.getEnvironment()).thenReturn("dev");

        smtpService.sendMail(BigInteger.ZERO, "dummyFileName", "dummyID", 'a', recipients);

        assertTrue(true);
    }
}
