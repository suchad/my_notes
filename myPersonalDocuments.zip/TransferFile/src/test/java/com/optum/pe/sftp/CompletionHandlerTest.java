package com.optum.pe.sftp;

import com.optum.pe.configuration.DefaultConfiguration;
import com.optum.pe.model.FileTransferDetails;
import com.optum.pe.service.FileTransferService;
import com.optum.pe.service.SMTPService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.integration.file.FileHeaders;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.messaging.MessageHeaders;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.Silent.class)
public class CompletionHandlerTest {

    @Mock
    private JavaMailSender javaMailSender;

    @Mock
    private FileTransferService fileTransferService;

    @Mock
    private DefaultConfiguration defaultConfiguration;

    private CompletionHandler completionHandler = new CompletionHandler(fileTransferService,
            "", new SMTPService(javaMailSender, defaultConfiguration));

    @Test
    public void getFileDetails() {

        Map<String, Object> headers = new HashMap<>();
        headers.put("remoteDirectory", "");
        headers.put(FileHeaders.FILENAME, "");
        headers.put("modified", 2637273L);
        headers.put("size", 0L);

        completionHandler.getFileDetails(new MessageHeaders(headers), 'S');

        assertTrue(true);
    }

    private FileTransferDetails getFileTransferDetails() {

        FileTransferDetails fileTransferDetails = new FileTransferDetails();
        fileTransferDetails.setId(BigInteger.ZERO);
        fileTransferDetails.setPartnerProcGroupId("");
        fileTransferDetails.setFileId(BigInteger.ZERO);
        fileTransferDetails.setRemoteHostName("");
        fileTransferDetails.setRemoteDirectoryPath("");
        fileTransferDetails.setDataFileName("");
        fileTransferDetails.setRemoteAuditFileName("");
        fileTransferDetails.setRemoteTriggerFileName("");
        fileTransferDetails.setDataFileName("");
        fileTransferDetails.setCreatedByName("");
        fileTransferDetails.setCreatedDateTime(LocalDateTime.now());
        fileTransferDetails.setUpdatedByName("");
        fileTransferDetails.setUpdatedDateTime(LocalDateTime.now());
        fileTransferDetails.setPartnerId("");
        fileTransferDetails.setTransferTypeCode("");
        fileTransferDetails.setAuditFileName("");
        fileTransferDetails.setTransferStartDateTime(LocalDateTime.now());
        fileTransferDetails.setTransferEndDateTime(LocalDateTime.now());
        fileTransferDetails.setStatusCode('a');
        fileTransferDetails.setDataFileSizeInBytes(0);
        fileTransferDetails.setAuditFileSizeInBytes(0);

        return fileTransferDetails;
    }
}