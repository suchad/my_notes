package com.optum.pe.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import java.io.File;
import java.util.HashMap;
import java.util.LinkedList;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.Silent.class)
public class FileLinkedListRegistryTest {

    @InjectMocks
    private FileLinkedListRegistry fileLinkedListRegistry;

    @Test
    public void of() {
        FileLinkedListRegistry.of();

        assertTrue(true);
    }

    @Test
    public void testAddToRegistry() {
        fileLinkedListRegistry.addToRegistry("dummyKey", getFileLinkedList());

        assertTrue(true);
    }

    @Test
    public void testGetFromRegistry() {
        assertEquals(null, fileLinkedListRegistry.getFromRegistry("dummyKey"));
    }

    @Test
    public void testGetRegistry() {
        assertEquals(new HashMap<>(), fileLinkedListRegistry.getRegistry());
    }

    private FileLinkedList getFileLinkedList() {
        FileLinkedList fileLinkedList = new FileLinkedList();

        LinkedList<File> fileList = new LinkedList<>();

        fileLinkedList.setFileList(fileList);
        fileLinkedList.setLocalDir("");
        fileLinkedList.setRemoteDir("");
        fileLinkedList.setHostname("");

        return fileLinkedList;

    }
}
