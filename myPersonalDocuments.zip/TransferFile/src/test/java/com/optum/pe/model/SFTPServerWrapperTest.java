package com.optum.pe.model;

import com.optum.pe.model.SFTPServerWrapper;
import org.junit.Test;

import java.util.ArrayList;

public class SFTPServerWrapperTest {

    @Test
    public void testSFTPServerWrapperEntity(){

        SFTPServerWrapper sftpServerWrapper = new SFTPServerWrapper();

        sftpServerWrapper.setSftpServer(new ArrayList<>());
        sftpServerWrapper.getSftpServer();

    }
}
