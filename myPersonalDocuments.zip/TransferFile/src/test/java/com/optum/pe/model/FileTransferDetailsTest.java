package com.optum.pe.model;

import com.optum.pe.model.FileTransferDetails;
import org.junit.Before;
import org.junit.Test;

import java.math.BigInteger;
import java.time.LocalDateTime;

public class FileTransferDetailsTest {

    private LocalDateTime testDate;

    @Before
    public void setUp() {
        testDate = LocalDateTime.now();
    }

    @Test
    public void testFileTransferDetailsEntity(){

        FileTransferDetails fileTransferDetails = new FileTransferDetails();

        fileTransferDetails.setId(BigInteger.ZERO);
        fileTransferDetails.getId();

        fileTransferDetails.setFileId(BigInteger.ZERO);
        fileTransferDetails.getFileId();

        fileTransferDetails.setRemoteHostName("");
        fileTransferDetails.getRemoteHostName();

        fileTransferDetails.setRemoteDirectoryPath("");
        fileTransferDetails.getRemoteDirectoryPath();

        fileTransferDetails.setRemoteDataFileName("");
        fileTransferDetails.getRemoteDataFileName();

        fileTransferDetails.setRemoteAuditFileName("");
        fileTransferDetails.getRemoteAuditFileName();

        fileTransferDetails.setRemoteTriggerFileName("");
        fileTransferDetails.getRemoteTriggerFileName();

        fileTransferDetails.setDataFileName("");
        fileTransferDetails.getDataFileName();

        fileTransferDetails.setCreatedByName("");
        fileTransferDetails.getCreatedByName();

        fileTransferDetails.setCreatedDateTime(testDate);
        fileTransferDetails.getCreatedDateTime();

        fileTransferDetails.setUpdatedByName("");
        fileTransferDetails.getUpdatedByName();

        fileTransferDetails.setUpdatedDateTime(testDate);
        fileTransferDetails.getUpdatedDateTime();

        fileTransferDetails.setPartnerId("");
        fileTransferDetails.getPartnerId();

        fileTransferDetails.setTransferTypeCode("");
        fileTransferDetails.getTransferTypeCode();

        fileTransferDetails.setAuditFileName("");
        fileTransferDetails.getAuditFileName();

        fileTransferDetails.setTransferStartDateTime(testDate);
        fileTransferDetails.getTransferStartDateTime();

        fileTransferDetails.setTransferEndDateTime(testDate);
        fileTransferDetails.getTransferEndDateTime();

        fileTransferDetails.setStatusCode('a');
        fileTransferDetails.getStatusCode();

        fileTransferDetails.setDataFileSizeInBytes(0);
        fileTransferDetails.getDataFileSizeInBytes();

        fileTransferDetails.setAuditFileSizeInBytes(0);
        fileTransferDetails.getAuditFileSizeInBytes();
    }
}
