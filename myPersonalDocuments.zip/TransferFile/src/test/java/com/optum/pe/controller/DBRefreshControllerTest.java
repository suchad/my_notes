package com.optum.pe.controller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.ConfigurableApplicationContext;

import static org.junit.Assert.assertFalse;

@RunWith(MockitoJUnitRunner.Silent.class)
public class DBRefreshControllerTest {

    @InjectMocks
    private DBRefreshController dbRefreshController;

    @Mock
    private ConfigurableApplicationContext context;

    @Test(expected = NullPointerException.class)
    public void testRefreshMappingWithException() {

        assertFalse(dbRefreshController.refreshMapping());
    }
}