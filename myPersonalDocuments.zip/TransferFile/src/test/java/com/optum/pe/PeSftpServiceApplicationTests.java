package com.optum.pe;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class PeSftpServiceApplicationTests {

    @Test
    public void demo() {
        assertTrue(true);
    }
}