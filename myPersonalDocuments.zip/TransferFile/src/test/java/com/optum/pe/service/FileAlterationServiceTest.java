package com.optum.pe.service;

import com.optum.pe.service.FileAlterationService;
import org.apache.commons.io.monitor.FileAlterationListener;
import org.apache.commons.io.monitor.FileAlterationObserver;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import java.nio.file.FileSystems;
import java.nio.file.Path;

import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.Silent.class)
public class FileAlterationServiceTest {

    private Path path = FileSystems.getDefault().getPath("");

    private FileAlterationListener fileAlterationListener;

    @InjectMocks
    private FileAlterationService fileAlterationService = new FileAlterationService(path,fileAlterationListener);

    @Test
    public void testGetObserver(){
        fileAlterationService.getObserver();

        assertTrue(true);
    }
}
