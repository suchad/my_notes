package com.optum.pe.model;

import com.optum.pe.model.FileInfo;
import org.junit.Before;
import org.junit.Test;

import java.math.BigInteger;
import java.time.LocalDateTime;

public class FileInfoTest {

    private LocalDateTime testDate;

    @Before
    public void setUp() {
        testDate = LocalDateTime.now();
    }

    @Test
    public void testFileInfoEntity(){

        FileInfo fileInfo = new FileInfo();

        fileInfo.setFileId(BigInteger.ZERO);
        fileInfo.getFileId();

        fileInfo.setPartnerProcGroupId("");
        fileInfo.getPartnerProcGroupId();

        fileInfo.setPartnerId("");
        fileInfo.getPartnerId();

        fileInfo.setFilePattern("");
        fileInfo.getFilePattern();

        fileInfo.setFileIgnorePattern("");
        fileInfo.getFileIgnorePattern();

        fileInfo.setTransferType("");
        fileInfo.getTransferType();

        fileInfo.setHostname("");
        fileInfo.getHostname();

        fileInfo.setConnectionType("");
        fileInfo.getConnectionType();

        fileInfo.setPortNumber("");
        fileInfo.getPortNumber();

        fileInfo.setUsername("");
        fileInfo.getUsername();

        fileInfo.setPassword("");
        fileInfo.getPassword();

        fileInfo.setKey("");
        fileInfo.getKey();

        fileInfo.setPassphrase("");
        fileInfo.getPassphrase();

        fileInfo.setKnownHosts("");
        fileInfo.getKnownHosts();

        fileInfo.setRemoteLocation("");
        fileInfo.getRemoteLocation();

        fileInfo.setNativeLocation("");
        fileInfo.getNativeLocation();

        fileInfo.setMailRecipients("");
        fileInfo.getMailRecipients();

        fileInfo.setCreateDateTime(testDate);
        fileInfo.getCreateDateTime();

        fileInfo.setCreatedBy("");
        fileInfo.getCreatedBy();

        fileInfo.setConflictFolder("");
        fileInfo.getConflictFolder();
    }
}
