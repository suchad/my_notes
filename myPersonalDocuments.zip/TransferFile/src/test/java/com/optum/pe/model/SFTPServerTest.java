package com.optum.pe.model;

import com.optum.pe.model.SFTPServer;
import org.junit.Test;

import java.util.ArrayList;

public class SFTPServerTest {

    @Test
    public void testSFTPServerEntity(){

        SFTPServer sftpServer = new SFTPServer();

        sftpServer.setHostname("");
        sftpServer.getHostname();

        sftpServer.setPort(0);
        sftpServer.getPort();

        sftpServer.setUsername("");
        sftpServer.getUsername();

        sftpServer.setPassword("");
        sftpServer.getPassword();

        sftpServer.setKey("");
        sftpServer.getKey();

        sftpServer.setPassphrase("");
        sftpServer.getPassphrase();

        sftpServer.setConnectionType("");
        sftpServer.getConnectionType();

        sftpServer.setKnownHosts("");
        sftpServer.getKnownHosts();

        sftpServer.setInbound(new ArrayList<>());
        sftpServer.getInbound();

        sftpServer.setOutbound(new ArrayList<>());
        sftpServer.getOutbound();

    }
}
