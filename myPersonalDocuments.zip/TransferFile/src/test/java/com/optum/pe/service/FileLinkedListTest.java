package com.optum.pe.service;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.io.File;
import java.util.LinkedList;

import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.Silent.class)
public class FileLinkedListTest {

    @InjectMocks
    private FileLinkedList fileLinkedList;

    @Mock
    private File file;

    @Before
    public void setUp() {
        LinkedList<File> fileList = new LinkedList<>();
        File file = new File("dummyPath");
        fileList.add(file);

        fileLinkedList.setFileList(fileList);
        fileLinkedList.setLocalDir("");
        fileLinkedList.setRemoteDir("");
        fileLinkedList.setHostname("");

        fileLinkedList.getLocalDir();
        fileLinkedList.getRemoteDir();
        fileLinkedList.getHostname();

        assertTrue(true);
    }

    @Test
    public void testAddFileToQueue() {
        fileLinkedList.addFileToQueue(file);

        fileLinkedList.popFileFromQueue();

        fileLinkedList.getQueueSize();

        assertTrue(true);
    }
}
