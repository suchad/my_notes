package com.optum.pe.service;

import java.util.HashMap;
import java.util.Map;

public final class FileLinkedListRegistry {

    private static FileLinkedListRegistry instance = null;

    private FileLinkedListRegistry() {
    }

    public static synchronized FileLinkedListRegistry of() {

        if (instance == null)
            instance = new FileLinkedListRegistry();

        return instance;
    }

    private Map<String, FileLinkedList> registry = new HashMap<>();

    public void addToRegistry(String key, FileLinkedList fileLinkedList) {
        registry.put(key, fileLinkedList);
    }

    public FileLinkedList getFromRegistry(String key) {
        return registry.get(key);
    }

    Map<String, FileLinkedList> getRegistry() {
        return registry;
    }
}
