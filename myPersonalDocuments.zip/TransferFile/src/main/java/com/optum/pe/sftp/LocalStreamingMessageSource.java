package com.optum.pe.sftp;

import com.optum.pe.model.DirectoryMapping;
import com.optum.pe.model.SFTPServerWrapper;
import com.optum.pe.service.FileLinkedList;
import com.optum.pe.service.FileLinkedListRegistry;
import com.optum.pe.util.Constants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.springframework.integration.file.FileHeaders;
import org.springframework.lang.Nullable;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.support.MessageBuilder;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Streaming message source doesn't have any default impl so created this custom impl.
 * Not using the classes of this package as we have migrated to JSch usage.
 *
 * @author vivek v58
 */
@Slf4j
class LocalStreamingMessageSource {

    private MessageChannel channel;
    static Map<String, List<String>> fileNameMap = new HashMap<>();
    private SFTPServerWrapper sftpServerWrapper;

    LocalStreamingMessageSource(SFTPServerWrapper sftpServerWrapper,
                                @Nullable MessageChannel channel) {
        this.channel = channel;
        this.sftpServerWrapper = sftpServerWrapper;
    }

    void receive() {

        sftpServerWrapper.getSftpServer().forEach(sftpServer -> {
            if (sftpServer.getOutbound() != null)
                sftpServer.getOutbound().forEach(this::sendStreamsToChannel);
        });
    }

    private void sendStreamsToChannel(DirectoryMapping directoryMapping) {

        log.debug("getting from registry - " + directoryMapping.getLocal());

        FileLinkedList fileLinkedList = FileLinkedListRegistry.of()
                .getFromRegistry(directoryMapping.getLocal());

        if (fileLinkedList == null)
            return;

        listToChannel(directoryMapping, fileLinkedList);
    }

    private void listToChannel(DirectoryMapping directoryMapping, FileLinkedList fileLinkedList) {
        int size = fileLinkedList.getQueueSize();

        for (int i = 0; i < size; i++) {
            File file = fileLinkedList.popFileFromQueue();

            log.debug("file popped - " + file.getName());
            log.debug("exists - " + file.exists());
            log.debug("abs path - " + file.getAbsolutePath());
            log.debug("length - " + file.length());
            log.debug("isFile - " + file.isFile());

            if (new CustomSftpPatternFileListFilter(directoryMapping.getAcceptedFileNamePattern(),
                    directoryMapping.getIgnoredFileNamePattern(), file.getName()).accept()) {
                fileToChannel(directoryMapping, file, fileLinkedList.getHostname());
            }
        }
    }

    private void fileToChannel(DirectoryMapping directoryMapping, File file, String hostname) {

        String fileName = file.getName();
        long fileSize = file.length();
        long modified = file.lastModified();

        InputStream inputStream = null;
        try {
            inputStream = getInputStream(directoryMapping, file, fileName);

            log.debug("Got Input Stream.");

            inputStreamToChannel(directoryMapping, inputStream, fileName, fileSize, modified, hostname);
        }catch(Exception ex){
            log.error("Exception thrown during usage of inputStream: " + ex);
        }
        finally{
            if(inputStream != null){
                safeClose(inputStream);
            }
        }
    }

    private static void safeClose(InputStream inputStream) {
        if (inputStream != null) {
            try {
                inputStream.close();
            } catch (IOException e) {
                log.error("Exception thrown while trying to close InputStream: " + e);
            }
        }
    }

    private InputStream getInputStream(DirectoryMapping directoryMapping, File file,
                                       String fileName) {

        InputStream inputStream = null;

        try {
            List<String> filesList = fileNameMap.computeIfAbsent(
                    directoryMapping.getLocal(), key -> new ArrayList<>());

            if (!filesList.contains(fileName)) {
                inputStream = FileUtils.openInputStream(file);

                filesList.add(fileName);
            }

        } catch (IOException ex) {
            log.debug("Error while fetching the file " + fileName + " from "
                    + directoryMapping.getLocal());
            log.error("", ex);
        }

        return inputStream;
    }

    private void inputStreamToChannel(DirectoryMapping directoryMapping, InputStream inputStream,
                                      String fileName, long fileSize, long modified, String hostname) {

        log.debug("Adding file " + fileName + " to channel.");

        if (channel != null && inputStream != null) {
            channel.send(MessageBuilder
                    .withPayload(inputStream)
                    .setHeader("hostname", hostname)
                    .setHeader(Constants.LOCAL_DIRECTORY, directoryMapping.getLocal())
                    .setHeader(Constants.RECIPIENTS, directoryMapping.getRecipients())
                    .setHeader("remoteDirectory", directoryMapping.getRemote())
                    .setHeader(FileHeaders.FILENAME, fileName)
                    .setHeader("size", fileSize)
                    .setHeader("modified", modified).build());
        }
    }
}
