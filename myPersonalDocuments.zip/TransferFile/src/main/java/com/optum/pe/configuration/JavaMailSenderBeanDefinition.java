package com.optum.pe.configuration;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.lang.Nullable;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

import java.util.Properties;

/**
 * Defining JavaMailSender Bean
 *
 * @author vivek v58
 */
@Configuration
public class JavaMailSenderBeanDefinition {

    private SMTPConfiguration smtpConfiguration;

    JavaMailSenderBeanDefinition(@Nullable SMTPConfiguration smtpConfiguration){
        this.smtpConfiguration = smtpConfiguration;
    }

    /**
     * Conditional bean on mail property value
     *
     * @return JavaMailSender
     */
    @ConditionalOnProperty(
            value="default.mail",
            havingValue = "true",
            matchIfMissing = false)
    @Bean
    public JavaMailSender getJavaMailSender() {

        JavaMailSenderImpl javaMailSender = new JavaMailSenderImpl();
        javaMailSender.setHost(smtpConfiguration.getHost());
        javaMailSender.setPort(smtpConfiguration.getPort());

        if (smtpConfiguration.isAuth()){
            javaMailSender.setUsername(smtpConfiguration.getUsername());
            javaMailSender.setPassword(smtpConfiguration.getPassword());
        }

        Properties props = javaMailSender.getJavaMailProperties();
        props.put("mail.transport.protocol", smtpConfiguration.getProtocol());
        props.put("mail.smtp.auth", smtpConfiguration.isAuth());

        return javaMailSender;
    }

    @Bean
    public SimpleMailMessage templateSimpleMessage() {
        SimpleMailMessage message = new SimpleMailMessage();

        message.setText("------ File Details ------ \n\n\n" + "ID - %s\n" + "File Name - %s\n" + "Partner Id - %s\n");

        return message;
    }
}
