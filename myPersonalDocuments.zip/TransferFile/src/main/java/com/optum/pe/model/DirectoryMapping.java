package com.optum.pe.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class DirectoryMapping {
    private String local;
    private String remote;

    private List<String> acceptedFileNamePattern;
    private List<String> ignoredFileNamePattern;
    private List<String> recipients;
    private String conflictFolder;
}
