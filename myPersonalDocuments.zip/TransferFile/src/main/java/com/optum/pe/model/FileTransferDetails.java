package com.optum.pe.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.math.BigInteger;
import java.time.LocalDateTime;

/**
 * POJO to hold file details and acts as entity to database table 'ms_transfer_file'
 *
 * @author vivek v58
 */
@NoArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "ms_transfer_file")
public class FileTransferDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private BigInteger id;

    @Column(name = "partner_proc_grp_id")
    private String partnerProcGroupId;

    @Column(name = "FL_ID")
    private BigInteger fileId;

    @Column(name = "FTP_HST_NM")
    private String remoteHostName;

    @Column(name = "RMOT_DIR_NM")
    private String remoteDirectoryPath;

    @Column(name = "RMOT_DATA_FL_NM")
    private String remoteDataFileName;

    @Column(name = "RMOT_AUD_FL_NM")
    private String remoteAuditFileName;

    @Column(name = "RMOT_TRIG_FL_NM")
    private String remoteTriggerFileName;

    @Column(name = "DATA_FL_NM")
    private String dataFileName;

    @Column(name = "CREAT_BY_NM")
    private String createdByName;

    @Column(name = "CREAT_DTTM")
    private LocalDateTime createdDateTime;

    @Column(name = "UPDT_BY_NM")
    private String updatedByName;

    @Column(name = "UPDT_DTTM")
    private LocalDateTime updatedDateTime;

    @Column(name = "PRTN_ID")
    private String partnerId;

    @Column(name = "TRNSF_TYP_CD")
    private String transferTypeCode;

    @Column(name = "AUD_NM")
    private String auditFileName;

    @Column(name = "STRT_DTTM")
    private LocalDateTime transferStartDateTime;

    @Column(name = "END_DTTM")
    private LocalDateTime transferEndDateTime;

    @Column(name = "STS_CD")
    private char statusCode;

    @Column(name = "DATA_BYTE_NBR")
    private int dataFileSizeInBytes;

    @Column(name = "AUD_BYTE_NBR")
    private int auditFileSizeInBytes;

}
