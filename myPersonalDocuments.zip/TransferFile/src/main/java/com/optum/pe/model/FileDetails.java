package com.optum.pe.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

public class FileDetails {

	@JsonPropertyOrder({ "directory", "fileName", "link", "modified", "permissions", "remoteDirectory", "size" })

	@JsonProperty("directory")
	private String directory;

	@JsonProperty("filename")
	private String fileName;

	@JsonProperty("link")
	private String link;

	@JsonProperty("modified")
	private String modified;

	@JsonProperty("permissions")
	private String permissions;

	@JsonProperty("remoteDirectory")
	private String remoteDirectory;

	@JsonProperty("size")
	private String size;

	@JsonProperty("directory")
	public String getDirectory() {
		return directory;
	}

	@JsonProperty("directory")
	public void setDirectory(String directory) {
		this.directory = directory;
	}

	@JsonProperty("filename")
	public String getFileName() {
		return fileName;
	}

	@JsonProperty("filename")
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	@JsonProperty("link")
	public String getLink() {
		return link;
	}

	@JsonProperty("link")
	public void setLink(String link) {
		this.link = link;
	}

	@JsonProperty("modified")
	public String getModified() {
		return modified;
	}

	@JsonProperty("modified")
	public void setModified(String modified) {
		this.modified = modified;
	}

	@JsonProperty("permissions")
	public String getPermissions() {
		return permissions;
	}

	@JsonProperty("permissions")
	public void setPermissions(String permissions) {
		this.permissions = permissions;
	}

	@JsonProperty("remoteDirectory")
	public String getRemoteDirectory() {
		return remoteDirectory;
	}

	@JsonProperty("remoteDirectory")
	public void setRemoteDirectory(String remoteDirectory) {
		this.remoteDirectory = remoteDirectory;
	}

	@JsonProperty("size")
	public String getSize() {
		return size;
	}

	@JsonProperty("size")
	public void setSize(String size) {
		this.size = size;
	}

}
