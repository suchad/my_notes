/*
package com.optum.pe.sftp;

import com.jcraft.jsch.ChannelSftp;
import com.optum.pe.configuration.DefaultConfiguration;
import com.optum.pe.init.StartUpInitProperties;
import com.optum.pe.model.SFTPServerWrapper;
import com.optum.pe.service.FileTransferService;
import com.optum.pe.service.SMTPService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.annotation.InboundChannelAdapter;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.annotation.Transformer;
import org.springframework.integration.core.MessageSource;
import org.springframework.integration.dsl.Pollers;
import org.springframework.integration.file.filters.ChainFileListFilter;
import org.springframework.integration.file.remote.aop.RotatingServerAdvice;
import org.springframework.integration.file.remote.session.DelegatingSessionFactory;
import org.springframework.integration.handler.advice.ExpressionEvaluatingRequestHandlerAdvice;
import org.springframework.integration.metadata.SimpleMetadataStore;
import org.springframework.integration.scheduling.PollerMetadata;
import org.springframework.integration.sftp.filters.SftpPersistentAcceptOnceFileListFilter;
import org.springframework.integration.sftp.inbound.SftpStreamingMessageSource;
import org.springframework.integration.sftp.session.SftpRemoteFileTemplate;
import org.springframework.integration.transformer.StreamTransformer;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import reactor.util.annotation.Nullable;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

*/
/**
 * Configuration Class to Listen to Remote Folder after fixed intervals as
 * defined in the poller Spring SFTP Integration Module has been used to develop
 * the code, Configure the properties of SFTP Event Listeners in the
 * application.yml file
 *
 * @author Akshaydeep
 *//*

@ConditionalOnProperty(value = "default.inbound",
        havingValue = "true",
        matchIfMissing = false)
@Configuration
@Slf4j
public class SFTPInboundPipeline {

    private static final String STREAM = "stream";
    private DefaultConfiguration defaultConfiguration;

    private SMTPService smtpService;
    private SftpRemoteFileTemplate template;
    private SFTPServerWrapper sftpServerWrapper;
    private DelegatingSessionFactory delegatingSessionFactory;
    private StartUpInitProperties startUpInitProperties;

    public SFTPInboundPipeline(@Nullable SMTPService smtpService,
                               @Nullable DefaultConfiguration defaultConfiguration,
                               SftpRemoteFileTemplate template,
                               SFTPServerWrapper sftpServerWrapper,
                               DelegatingSessionFactory delegatingSessionFactory,
                               StartUpInitProperties startUpInitProperties) {
        this.defaultConfiguration = defaultConfiguration;
        this.smtpService = smtpService;
        this.template = template;
        this.sftpServerWrapper = sftpServerWrapper;
        this.delegatingSessionFactory = delegatingSessionFactory;
        this.startUpInitProperties = startUpInitProperties;
    }

    */
/**
     * ExecutorService for poller to implement multi threading.
     *
     * @return ThreadPoolTaskExecutor
     *//*

    @Bean
    ThreadPoolTaskExecutor executor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setMaxPoolSize(5);
        return executor;
    }

    */
/**
     * Default Poller implementation.
     *
     * @return PollerMetadata
     *//*

    @Autowired
    @Bean(name = PollerMetadata.DEFAULT_POLLER)
    public PollerMetadata defaultPoller() {
        return Pollers
                .fixedRate(30000000)
                .advice(advice(delegatingSessionFactory))
                .get();
    }

    RotatingServerAdvice advice(DelegatingSessionFactory delegatingSessionFactory) {
        List<RotatingServerAdvice.KeyDirectory> keyDirectories = new ArrayList<>();

        sftpServerWrapper.getSftpServer().stream().filter(sftpServer -> sftpServer.getInbound() != null)
                .forEach(sftpServer -> {
                    sftpServer.getInbound().forEach(directoryMapping -> {
                        keyDirectories.add(new RotatingServerAdvice
                                .KeyDirectory(sftpServer.getHostname(), directoryMapping.getRemote()));
                    });
                });

        return new RotatingServerAdvice(new MyStandardRotationPolicy(delegatingSessionFactory,
                keyDirectories, true));
    }

    */
/*
     * The Message source bean uses the @InboundChannelAdapter annotation. This
     * message source connects the synchronizer we defined above to a message queue
     * (sftpChannel). The adapter will take files from the sftp server and place
     * them in the message queue as messages
     *
     * @return MessageSource
     *//*

    @Bean
    @InboundChannelAdapter(channel = STREAM)
    public MessageSource<InputStream> ftpMessageSource() {
        SftpStreamingMessageSource messageSource = new SftpStreamingMessageSource(template);

        try (ChainFileListFilter<ChannelSftp.LsEntry> chainFileListFilter =
                     new ChainFileListFilter<>();) {

            chainFileListFilter.addFilter(
                    new SftpPersistentAcceptOnceFileListFilter(
                            new SimpleMetadataStore(), ""));
            chainFileListFilter.addFilter(new CustomDirectoryFilter());
            chainFileListFilter.addFilter(new CustomFileNameFilter());

            messageSource.setRemoteDirectory(".");
            messageSource.setFilter(chainFileListFilter);
        } catch (IOException ex) {
            log.debug("Error while Using Filters.");
            log.error("", ex);
        }

        return messageSource;
    }

    */
/**
     * Transformer for DB insertion and file movement.
     *
     * @return StreamTransformer
     *//*

    @Bean
    @Transformer(inputChannel = STREAM, outputChannel = "data")
    @Autowired(required = false)
    public StreamTransformer transformer(@Nullable FileTransferService fileTransferService) {
        return new FileTransformer(fileTransferService, defaultConfiguration, sftpServerWrapper);
    }

    */
/**
     * SMTPHandler hook - to send out mails. REMOVE ADVICE CHAIN FOR ECG.
     *
     * @return SMTPHandler MessageHandler
     *//*

    @ServiceActivator(inputChannel = "data", adviceChain = "after")
    @Bean
    public SMTPHandler smtpHandler() {
        return new SMTPHandler(smtpService);
    }

    */
/**
     * Remove file from remote advice
     *
     * @return ExpressionEvaluatingRequestHandlerAdvice
     *//*

    @Bean
    public ExpressionEvaluatingRequestHandlerAdvice after() {
        ExpressionEvaluatingRequestHandlerAdvice advice = new ExpressionEvaluatingRequestHandlerAdvice();
        advice.setOnSuccessExpressionString(
                "@template.remove(headers['file_remoteDirectory'] + headers['file_remoteFile'])");
        advice.setPropagateEvaluationFailures(true);
        return advice;
    }
}
*/
