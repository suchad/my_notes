package com.optum.pe.controller;

import com.optum.pe.model.FileInfo;
import com.optum.pe.service.FileInfoService;
import com.optum.pe.service.JSchService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/sftp")
class SFTPController {

    private final FileInfoService fileInfoService;
    private final JSchService jSchService;

    SFTPController(FileInfoService fileInfoService, JSchService jSchService) {
        this.fileInfoService = fileInfoService;
        this.jSchService = jSchService;
    }

    @GetMapping("/upload/{ppid}/{identifier}/{env}")
    public boolean upload(@PathVariable("ppid") String ppid,
                          @PathVariable("identifier") String identifier,
                          @PathVariable("env") String env) {

        List<FileInfo> fileInfoList = fileInfoService.getFileInfoFor(ppid, identifier, env);

        if (fileInfoList.isEmpty() || !jSchService.uploadFile(fileInfoList.get(0))) {
            return false;
        }

        return true;
    }
}
