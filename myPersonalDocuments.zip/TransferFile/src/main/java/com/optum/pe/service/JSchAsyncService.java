package com.optum.pe.service;

import com.optum.pe.model.FileInfo;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.nio.file.Path;

@Service
public class JSchAsyncService {

    private final JSchService jSchService;
    private final FileGetterService fileGetterService;

    public JSchAsyncService(JSchService jSchService, FileGetterService fileGetterService) {
        this.jSchService = jSchService;
        this.fileGetterService = fileGetterService;
    }

    @Async
    public void bulkUpload(FileInfo fileInfo, Path triggerPath) {
        boolean uploadStatus = jSchService.uploadFile(fileInfo);

        fileGetterService.renameTriggerFile(triggerPath, uploadStatus);
    }
}
