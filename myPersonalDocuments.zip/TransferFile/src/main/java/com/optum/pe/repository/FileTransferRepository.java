package com.optum.pe.repository;

import com.optum.pe.model.FileTransferDetails;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;

/**
 * Repository for FileTransferDetails entity.
 *
 * @author vivek v58
 */
@ConditionalOnProperty(
        value="default.db",
        havingValue = "true",
        matchIfMissing = false)
@Repository
public interface FileTransferRepository extends CrudRepository<FileTransferDetails, BigInteger> {
}
