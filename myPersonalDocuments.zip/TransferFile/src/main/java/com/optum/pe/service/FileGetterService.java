package com.optum.pe.service;

import com.optum.pe.configuration.DefaultConfiguration;
import com.optum.pe.util.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

@Slf4j
@Service
public class FileGetterService {

    private final DefaultConfiguration defaultConfiguration;

    FileGetterService(DefaultConfiguration defaultConfiguration) {
        this.defaultConfiguration = defaultConfiguration;
    }

    public Optional<Path> createTriggerFile() throws IOException {

        return Optional.of(Files.createFile(Paths.get(this.defaultConfiguration.getTriggerLocation()
                + Constants.TRIGGER_FILE_NAME
                + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"))
                + Constants.TRIGGER_FILE_EXTENSION)));
    }

    void renameTriggerFile(Path triggerPath, boolean status) {

        Path newName = getNewTriggerFileName(triggerPath, status);

        try {
            Files.move(triggerPath, newName);
        } catch (IOException ex) {
            log.error("", ex);
        }
    }

    private Path getNewTriggerFileName(Path triggerPath, boolean status) {

        String newName;

        if (status) {
            newName = triggerPath.toString().replace(Constants.TRIGGER_FILE_EXTENSION, Constants.SUCCESS_FILE_EXTENSION);
        } else {
            newName = triggerPath.toString().replace(Constants.TRIGGER_FILE_EXTENSION, Constants.FAILURE_FILE_EXTENSION);
        }

        return Paths.get(newName);
    }
}
