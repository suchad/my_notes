package com.optum.pe.sftp;

import com.optum.pe.model.DirectoryMapping;
import com.optum.pe.model.FileTransferDetails;
import com.optum.pe.service.SMTPService;
import com.optum.pe.util.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHandler;

import java.util.ArrayList;
import java.util.List;

/**
 * SMTPHandler to send mails based on the configuration.
 *
 * @author vivek v58
 */
@Slf4j
class SMTPHandler implements MessageHandler {

    private SMTPService smtpService;

    SMTPHandler(SMTPService smtpService){
        this.smtpService = smtpService;
    }

    /**
     * Will use SMTPService to send mail based on configurations.
     *
     * @param message from channel data
     */
    @Override
    public void handleMessage(Message<?> message) {
        FileTransferDetails fileTransferDetails = (FileTransferDetails) message.getPayload();

        List<String> recipients;

        DirectoryMapping mapping = (DirectoryMapping) message.getHeaders()
                .get(Constants.DIRECTORY_MAPPING);

        if (mapping != null && mapping.getRecipients() != null){
            recipients = mapping.getRecipients();
        } else recipients = new ArrayList<>(1);

        if (smtpService != null && fileTransferDetails.getStatusCode() != '\u0000'){
            log.debug("----- Sending Mail -----");
            smtpService.sendMail(fileTransferDetails.getFileId() ,
                    fileTransferDetails.getRemoteDataFileName() != null ?
                            fileTransferDetails.getRemoteDataFileName() : "",
                    fileTransferDetails.getPartnerId(),
                    fileTransferDetails.getStatusCode(), recipients);
        }
    }
}
