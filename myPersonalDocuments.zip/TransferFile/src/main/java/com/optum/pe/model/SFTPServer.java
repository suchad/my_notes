package com.optum.pe.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter @Setter
@NoArgsConstructor
public class SFTPServer {

    private String hostname;
    private int port;
    private String username;
    private String password;
    private String key;
    private String passphrase;
    private String connectionType;
    private String knownHosts;

    private List<DirectoryMapping> inbound;

    private List<DirectoryMapping> outbound;

}
