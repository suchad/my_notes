package com.optum.pe.sftp;

import com.optum.pe.model.SFTPServerWrapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.channel.ExecutorChannel;
import org.springframework.integration.file.FileHeaders;
import org.springframework.integration.file.remote.session.DelegatingSessionFactory;
import org.springframework.integration.file.support.FileExistsMode;
import org.springframework.integration.handler.advice.ExpressionEvaluatingRequestHandlerAdvice;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessageHandler;
import org.springframework.scheduling.annotation.Scheduled;
import reactor.util.annotation.Nullable;

import java.util.concurrent.Executors;


/**
 * Outbound Pipeline class to upload data from local/persistence volume to sftp server.
 *
 * @author vivek v58
 */
@ConditionalOnProperty(value = "default.outbound",
        havingValue = "true",
        matchIfMissing = false)
@Configuration
@Slf4j
public class SFTPOutboundPipeline {

    @Qualifier("ErrorHandler")
    private MessageHandler errorHandler;

    @Qualifier("SuccessHandler")
    private MessageHandler successHandler;

    private DelegatingSessionFactory delegatingSessionFactory;
    private SFTPServerWrapper sftpServerWrapper;

    SFTPOutboundPipeline(@Nullable MessageHandler errorHandler,
                         @Nullable MessageHandler successHandler,
                         SFTPServerWrapper sftpServerWrapper,
                         DelegatingSessionFactory delegatingSessionFactory) {
        this.errorHandler = errorHandler;
        this.successHandler = successHandler;
        this.sftpServerWrapper = sftpServerWrapper;
        this.delegatingSessionFactory = delegatingSessionFactory;
    }

    @Bean
    MessageChannel outboundStream() {
        return new ExecutorChannel(Executors.newFixedThreadPool(5));
    }

    @Scheduled(initialDelay = 1200000, fixedRate = 1200000)
    public void fileReadingMessageSource() {
        new LocalStreamingMessageSource(sftpServerWrapper, outboundStream()).receive();
    }

    @Autowired
    @Bean
    @ServiceActivator(inputChannel = "outboundStream", adviceChain = "successAdvice")
    public MessageHandler handler(BeanFactory beanFactory) {

        CustomSFTPMessageHandler messageHandler =
                new CustomSFTPMessageHandler(delegatingSessionFactory, FileExistsMode.FAIL, beanFactory);

        messageHandler.setRemoteDirectoryExpression(new SpelExpressionParser()
                .parseExpression("headers['remoteDirectory']"));

        messageHandler.setUseTemporaryFileName(Boolean.TRUE);
        messageHandler.setTemporaryFileSuffix(".writing");

        messageHandler.setFileNameGenerator((Message<?> message) -> message.getHeaders()
                .get(FileHeaders.FILENAME) + "");

        return messageHandler;
    }

    @Bean
    public ExpressionEvaluatingRequestHandlerAdvice successAdvice() {

        ExpressionEvaluatingRequestHandlerAdvice advice = new ExpressionEvaluatingRequestHandlerAdvice();
        advice.setSuccessChannelName("successChannel");

        return advice;
    }

    @Bean
    MessageChannel successChannel() {
        return new ExecutorChannel(Executors.newFixedThreadPool(5));
    }

    @Bean
    MessageChannel errorStream() {
        return new ExecutorChannel(Executors.newFixedThreadPool(5));
    }

    @Bean
    @ServiceActivator(inputChannel = "successChannel")
    public MessageHandler getSuccessHandler() {
        return this.successHandler;
    }

    @Bean
    @ServiceActivator(inputChannel = "errorStream")
    public MessageHandler getErrorHandler() {
        return this.errorHandler;
    }
}
