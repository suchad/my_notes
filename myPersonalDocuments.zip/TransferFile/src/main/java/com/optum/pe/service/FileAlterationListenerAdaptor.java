package com.optum.pe.service;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.monitor.FileAlterationListener;
import org.apache.commons.io.monitor.FileAlterationObserver;

import java.io.File;
import java.nio.file.Path;
import java.util.Arrays;

@Slf4j
public class FileAlterationListenerAdaptor implements FileAlterationListener {

    private static final String WRITING = ".writing";
    private FileLinkedList linkedList;

    public FileAlterationListenerAdaptor(FileLinkedList linkedList, Path path) {
        this.linkedList = linkedList;

        File[] files = path.toFile().listFiles();

        if (files != null)
            Arrays.stream(files).filter(file -> !file.isDirectory()).filter(file -> !file.getName().contains(WRITING))
                    .forEach(this::onFileCreate);
    }

    @Override
    public void onStart(FileAlterationObserver observer) {
        log.debug("");
    }

    @Override
    public void onDirectoryCreate(File directory) {
        log.debug("");

    }

    @Override
    public void onDirectoryChange(File directory) {
        log.debug("");

    }

    @Override
    public void onDirectoryDelete(File directory) {
        log.debug("");

    }

    @Override
    public void onFileCreate(File file) {
        log.debug("Adding File Name to queue - " + file.getName());
        if (!file.isDirectory() && !file.getName().contains(WRITING))
            linkedList.addFileToQueue(file);
    }

    @Override
    public void onFileChange(File file) {
        log.debug("File Name - " + file.getName() + " changed.");
        if (!file.isDirectory() && !file.getName().contains(WRITING))
            linkedList.addFileToQueue(file);
    }

    @Override
    public void onFileDelete(File file) {
        log.debug("");
    }

    @Override
    public void onStop(FileAlterationObserver observer) {
        log.debug("");
    }
}
