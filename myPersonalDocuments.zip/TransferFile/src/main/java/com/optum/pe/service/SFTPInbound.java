package com.optum.pe.service;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;
import com.optum.pe.model.FileInfo;
import com.optum.pe.model.FileTransferDetails;
import com.optum.pe.util.Constants;
import lombok.extern.slf4j.Slf4j;
import org.awaitility.core.ConditionTimeoutException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.AntPathMatcher;

import java.io.File;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.Vector;
import java.util.stream.Collectors;

import static org.awaitility.Awaitility.await;

@Slf4j
@Component
class SFTPInbound {

    @Autowired
    private FileInfoService fileInfoService;

    @Autowired
    private FileTransferService fileTransferService;

    @Autowired
    private SMTPService emailService;

    private AntPathMatcher matcher = new AntPathMatcher();

    @Scheduled(fixedDelayString = "120000", initialDelayString = "3000")
    public void inboundProcessor() {
        List<FileInfo> fileInfoList = fileInfoService.getFileInfoForTransferType();
        fileInfoList.forEach(this::sftpConnection);
    }

    void sftpConnection(FileInfo fileInfo) {
        try {

            Session session = getSession(fileInfo);

            ChannelSftp channelSftp = getChannel(session);

            Vector<ChannelSftp.LsEntry> fileList = channelSftp.ls(fileInfo.getRemoteLocation());

            if (fileList.isEmpty()) {
                log.info("No file exist in the specified sftp folder location.");
                return;
            }

            fileDownload(fileList, fileInfo, channelSftp, session);

            channelSftp.exit();
            session.disconnect();

        } catch (SftpException | JSchException ex) {
            log.warn("", ex);
        }
    }

    private ChannelSftp getSftpChannelIfInvalidSession(ChannelSftp channelSftp, Session session)
            throws JSchException {
        if (!channelSftp.isConnected() || channelSftp.isClosed()) {
            channelSftp = getChannel(session);
        }

        return channelSftp;
    }

    private void fileDownload(Vector<ChannelSftp.LsEntry> fileList, FileInfo fileInfo,
                              ChannelSftp channelSftp, Session session) {
        long initialFileSize = 0;

        for (ChannelSftp.LsEntry entry : fileList) {

            String remoteFileSourcePath;

            if (acceptFileFilter(entry, fileInfo)) {

                try {
                    boolean isCopyInProcess = true;

                    do {
                        remoteFileSourcePath = fileInfo.getRemoteLocation() + "/" + entry.getFilename();
                        log.debug("remoteFileSourcePath:" + remoteFileSourcePath);

                        SftpATTRS intialFileAttributes = getSftpChannelIfInvalidSession(channelSftp, session).lstat(remoteFileSourcePath);
                        initialFileSize = intialFileAttributes.getSize();

                        waitForSeconds(3);

                        SftpATTRS currentFileAttributes = getSftpChannelIfInvalidSession(channelSftp, session).lstat(remoteFileSourcePath);

                        long currentFileSize = currentFileAttributes.getSize();

                        if (initialFileSize != currentFileSize) {
                            isCopyInProcess = true;
                            log.info("File copying in process so waiting for file to complete transfer "
                                    + entry.getFilename());
                        } else {
                            isCopyInProcess = false;
                            log.info("File copied and ready to download " + entry.getFilename());
                        }

                    } while (isCopyInProcess);

                    String destFilePathTemp = new StringBuilder(fileInfo.getNativeLocation()).append(File.separator)
                            .append(entry.getFilename()).toString() + ".writing";

                    String destFilePath = new StringBuilder(fileInfo.getNativeLocation()).append(File.separator)
                            .append(entry.getFilename()).toString();

                    // downloading the file from remote to local location
                    getSftpChannelIfInvalidSession(channelSftp, session).get(remoteFileSourcePath, destFilePathTemp);

                    // After complete download renaming the file to original name
                    File tempFile = new File(destFilePathTemp);
                    boolean renameStatus = tempFile.renameTo(new File(destFilePath));

                    if (renameStatus) {
                        log.info("File downloaded to local folder " + fileInfo.getNativeLocation() + File.separator
                                + entry.getFilename());
                    }

                    // Deleting the file from the sftp remote server
                    if (fileInfo.getHostname().contains("ecg")) {
                        log.info("Ignoring Remote file deleting on ecg: " + entry.getFilename());
                    } else {
                        getSftpChannelIfInvalidSession(channelSftp, session).rm(remoteFileSourcePath);
                        log.info("Remote file deleting completed: " + entry.getFilename());
                    }

                    // Creating an entry in the db
                    fileTransferService.insertOrUpdateFile(generateFileTransferDetails(entry.getFilename(),
                            'S', initialFileSize, fileInfo));

                    sendEmail(fileInfo, entry.getFilename(), 'S', fileInfo.getMailRecipients());

                } catch (Exception ex) {
                    log.warn("Exception in fileDownload", ex);

                    // Creating an entry in the db
                    fileTransferService.insertOrUpdateFile(generateFileTransferDetails(entry.getFilename(),
                            'F', initialFileSize, fileInfo));
                }
            } else {
                log.debug("download file filter not matching.." + entry.getFilename());
            }
        }
    }

    void waitForSeconds(int i) {
        try {
            await().atMost(Duration.ofSeconds(i)).until(() -> false);
        } catch (ConditionTimeoutException ex) {
            log.debug("");
        }
    }

    private ChannelSftp getChannel(Session session) throws JSchException {

        return createChannel(session);
    }

    private ChannelSftp createChannel(Session session) throws JSchException {
        Channel channel = session.openChannel("sftp");
        channel.connect();
        return (ChannelSftp) channel;
    }

    private Session getSession(FileInfo fileInfo) throws JSchException {

        Session session;

        if (Constants.CONNECTION_TYPE.equalsIgnoreCase(fileInfo.getConnectionType())) {
            session = createSessionWithPassword(fileInfo);
        } else {
            session = createSessionWithKey(fileInfo);
        }

        return session;
    }

    JSch getJSch() {
        return new JSch();
    }

    private Session createSessionWithPassword(FileInfo fileInfo) throws JSchException {
        Session session = null;
        // Creating and instantiating the jsch specific instance
        JSch jsch = getJSch();
        // Fetching and setting the parameters like: user name, host and port
        session = jsch.getSession(fileInfo.getUsername(), fileInfo.getHostname(), Integer.valueOf(fileInfo.getPortNumber()));

        session.setPassword(fileInfo.getPassword());
        // Setting the configuration specific properties
        Properties config = new Properties();
        config.put("StrictHostKeyChecking", "no");
        session.setConfig(config);
        // Connecting to the sftp
        session.connect();
        return session;
    }

    Session createSessionWithKey(FileInfo fileInfo) throws JSchException {
        Session session = null;
        // Creating and instantiating the jsch specific instance
        JSch jsch = getJSch();

        jsch.addIdentity(fileInfo.getKey(), fileInfo.getPassphrase());
        // Fetching and setting the parameters like: user name, host and port
        session = jsch.getSession(fileInfo.getUsername(), fileInfo.getHostname(), Integer.valueOf(fileInfo.getPortNumber()));
        // Setting the configuration specific properties
        Properties config = new Properties();
        config.put("StrictHostKeyChecking", "no");
        session.setConfig(config);
        // Connecting to the sftp
        session.connect();
        return session;
    }

    private boolean acceptFileFilter(ChannelSftp.LsEntry file, FileInfo fileInfo) {
        String fileName = file.getFilename().trim();
        // to ignore hidden files . and ..
        if (fileName.length() < 3) {
            return false;
        } else {
            return fileNameFilter(fileName, fileInfo);
        }
    }

    boolean fileNameFilter(String fileName, FileInfo fileInfo) {
        return matchAcceptedPattern(fileInfo.getFilePattern(), fileName)
                && !matchRejectedPattern(fileInfo.getFileIgnorePattern(), fileName);
    }

    private boolean matchAcceptedPattern(String pattern, String fileName) {

        return pattern == null || pattern.isEmpty() || this.matcher.match(pattern, fileName);
    }

    private boolean matchRejectedPattern(String pattern, String fileName) {

        if (pattern == null || pattern.isEmpty())
            return false;
        else
            return this.matcher.match(pattern, fileName);
    }

    /**
     * Create a new FileTransferDetails Object and insert in database.
     *
     * @return FileTransferDetails
     */
    FileTransferDetails generateFileTransferDetails(String fileName, char status,
                                                    long fileSize, FileInfo fileInfo) {

        FileTransferDetails fileTransferDetails = new FileTransferDetails();

        fileTransferDetails.setPartnerProcGroupId(fileInfo.getPartnerProcGroupId());
        fileTransferDetails.setFileId(fileInfo.getFileId());
        fileTransferDetails.setRemoteHostName(fileInfo.getHostname());
        fileTransferDetails.setRemoteDirectoryPath(fileInfo.getRemoteLocation());
        fileTransferDetails.setRemoteDataFileName(fileName);
        fileTransferDetails.setRemoteAuditFileName("");
        fileTransferDetails.setRemoteTriggerFileName("");

        fileTransferDetails.setCreatedByName("");
        fileTransferDetails.setCreatedDateTime(LocalDateTime.now());
        fileTransferDetails.setUpdatedByName("");
        fileTransferDetails.setUpdatedDateTime(LocalDateTime.now());
        fileTransferDetails.setPartnerId(fileInfo.getPartnerId());
        fileTransferDetails.setTransferTypeCode("INB");
        fileTransferDetails.setAuditFileName("");
        fileTransferDetails.setTransferStartDateTime(LocalDateTime.now());

        // to be reset at the end of processing
        fileTransferDetails.setDataFileName(fileName);
        fileTransferDetails.setTransferEndDateTime(LocalDateTime.now());
        fileTransferDetails.setStatusCode(status);
        fileTransferDetails.setCreatedByName(Constants.APP_NAME);
        fileTransferDetails.setUpdatedByName(Constants.APP_NAME);
        fileTransferDetails.setDataFileSizeInBytes((int) fileSize);
        fileTransferDetails.setAuditFileSizeInBytes(0);

        return fileTransferDetails;
    }

    void sendEmail(FileInfo fileInfo, String fileName, char statusCd, String recipientsString) {

        List<String> recipients = Arrays.stream(recipientsString.split(","))
                .collect(Collectors.toList());

        emailService.sendMail(fileInfo.getFileId(), fileName,
                fileInfo.getPartnerId(), statusCd, recipients);
    }
}
