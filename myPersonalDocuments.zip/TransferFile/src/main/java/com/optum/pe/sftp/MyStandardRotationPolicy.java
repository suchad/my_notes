package com.optum.pe.sftp;

import com.optum.pe.util.Constants;
import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.integration.core.MessageSource;
import org.springframework.integration.file.remote.AbstractRemoteFileStreamingMessageSource;
import org.springframework.integration.file.remote.aop.RotatingServerAdvice;
import org.springframework.integration.file.remote.session.DelegatingSessionFactory;
import org.springframework.integration.file.remote.synchronizer.AbstractInboundFileSynchronizingMessageSource;

import java.util.*;

public class MyStandardRotationPolicy implements RotatingServerAdvice.RotationPolicy {

    private RotatingServerAdvice.KeyDirectory current;
    private final DelegatingSessionFactory<?> factory;
    private final List<RotatingServerAdvice.KeyDirectory> keyDirectories = new ArrayList<>();
    private final boolean fair;
    private Iterator<RotatingServerAdvice.KeyDirectory> iterator;
    private volatile boolean initialized;

    MyStandardRotationPolicy(final DelegatingSessionFactory<?> factory,
                                    final List<RotatingServerAdvice.KeyDirectory> keyDirectories,
                                    final boolean fair) {

        this.factory = factory;
        this.keyDirectories.addAll(keyDirectories);
        this.fair = fair;
        this.iterator = this.keyDirectories.iterator();
    }

    protected Iterator<RotatingServerAdvice.KeyDirectory> getIterator() {
        return this.iterator;
    }

    protected void setIterator(final Iterator<RotatingServerAdvice.KeyDirectory> iterator) {
        this.iterator = iterator;
    }

    protected DelegatingSessionFactory<?> getFactory() {
        return this.factory;
    }

    protected List<RotatingServerAdvice.KeyDirectory> getKeyDirectories() {
        return this.keyDirectories;
    }

    protected boolean isFair() {
        return this.fair;
    }

    private void configureSource(final MessageSource<?> source) {

        if (!this.iterator.hasNext()) {
            this.iterator = this.keyDirectories.iterator();
        }
        this.current = this.iterator.next();

        if (source instanceof AbstractRemoteFileStreamingMessageSource) {
            Map<String, Expression> headers = new HashMap<>(2);
            ExpressionParser parser = new SpelExpressionParser();

            headers.put(Constants.HEADER_HOSTNAME_KEY,
                    parser.parseExpression("'"+this.current.getKey().toString()+"'"));

            ((AbstractRemoteFileStreamingMessageSource<?>) source).setHeaderExpressions(headers);
            ((AbstractRemoteFileStreamingMessageSource<?>) source)
                    .setRemoteDirectory(this.current.getDirectory());
        } else {
            ((AbstractInboundFileSynchronizingMessageSource<?>) source).getSynchronizer()
                    .setRemoteDirectory(this.current.getDirectory());
        }
    }

    @Override
    public void beforeReceive(MessageSource<?> source) {
        if (this.fair || !this.initialized) {
            configureSource(source);
            this.initialized = true;
        }

        this.factory.setThreadKey(this.current.getKey());
    }

    @Override
    public void afterReceive(boolean messageReceived, MessageSource<?> source) {
        this.factory.clearThreadKey();
        if (!this.fair && !messageReceived) {
            configureSource(source);
        }
    }
}
