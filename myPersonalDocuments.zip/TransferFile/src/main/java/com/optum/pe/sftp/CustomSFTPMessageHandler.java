package com.optum.pe.sftp;

import com.optum.pe.util.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.expression.Expression;
import org.springframework.integration.file.FileNameGenerator;
import org.springframework.integration.file.remote.session.DelegatingSessionFactory;
import org.springframework.integration.file.remote.session.SessionFactory;
import org.springframework.integration.file.support.FileExistsMode;
import org.springframework.integration.sftp.outbound.SftpMessageHandler;
import org.springframework.integration.sftp.session.SftpRemoteFileTemplate;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHandler;

@Slf4j
public class CustomSFTPMessageHandler implements MessageHandler {

    private DelegatingSessionFactory delegatingSessionFactory;
    private FileExistsMode mode;
    private Expression remoteDirectoryExpression;
    private Boolean useTemporaryFileName;
    private String temporaryFileSuffix;
    private FileNameGenerator fileNameGenerator;
    private BeanFactory beanFactory;

    CustomSFTPMessageHandler(DelegatingSessionFactory delegatingSessionFactory, FileExistsMode mode,
                             BeanFactory beanFactory) {
        this.delegatingSessionFactory = delegatingSessionFactory;
        this.mode = mode;
        this.beanFactory = beanFactory;
    }

    void setRemoteDirectoryExpression(Expression expression) {
        this.remoteDirectoryExpression = expression;
    }

    void setUseTemporaryFileName(Boolean useTemporaryFileName) {
        this.useTemporaryFileName = useTemporaryFileName;
    }

    void setTemporaryFileSuffix(String temporaryFileSuffix) {
        this.temporaryFileSuffix = temporaryFileSuffix;
    }

    void setFileNameGenerator(FileNameGenerator fileNameGenerator) {
        this.fileNameGenerator = fileNameGenerator;
    }

    @Override
    public void handleMessage(Message<?> message) {

        SessionFactory factory = delegatingSessionFactory
                .getFactoryLocator()
                .getSessionFactory(message.getHeaders().get(Constants.HEADER_HOSTNAME_KEY));

        SftpMessageHandler sftpMessageHandler = new SftpMessageHandler(
                new SftpRemoteFileTemplate(factory), mode);
        sftpMessageHandler.setBeanFactory(this.beanFactory);

        sftpMessageHandler.setRemoteDirectoryExpression(this.remoteDirectoryExpression);
        
        if (message.getHeaders().get(Constants.HEADER_HOSTNAME_KEY)
                .equals(Constants.ECG_HOSTNAME) || message.getHeaders().get(Constants.HEADER_HOSTNAME_KEY)
                .equals(Constants.ECG_HOSTNAME_2)) {
            sftpMessageHandler.setUseTemporaryFileName(Boolean.FALSE);
            log.info("ecg config - " + message.getHeaders().get(Constants.HEADER_HOSTNAME_KEY));
        } else {
            sftpMessageHandler.setUseTemporaryFileName(this.useTemporaryFileName);
            sftpMessageHandler.setTemporaryFileSuffix(this.temporaryFileSuffix);
        }

        sftpMessageHandler.setFileNameGenerator(this.fileNameGenerator);
        sftpMessageHandler.setShouldTrack(Boolean.TRUE);
        sftpMessageHandler.setStatsEnabled(Boolean.TRUE);
        sftpMessageHandler.setLoggingEnabled(Boolean.TRUE);

        sftpMessageHandler.afterPropertiesSet();

        sftpMessageHandler.handleMessage(message);
    }
}
