package com.optum.pe.service;

import com.optum.pe.model.FileInfo;
import com.optum.pe.repository.FileInfoRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FileInfoService {

    private FileInfoRepository fileInfoRepository;

    FileInfoService(FileInfoRepository fileInfoRepository) {
        this.fileInfoRepository = fileInfoRepository;
    }

    public List<FileInfo> getFileInfo() {
        return fileInfoRepository.findAll();
    }

    public List<FileInfo> getFileInfoFor(String ppid, String identifier, String env) {
        return fileInfoRepository.findByPartnerNameAndPartnerId(ppid, identifier, env);
    }

    public List<FileInfo> getFileInfoForTransferType() {
        return fileInfoRepository.findByTransferType();
    }
}
