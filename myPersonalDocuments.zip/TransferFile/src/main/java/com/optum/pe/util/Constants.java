package com.optum.pe.util;

public class Constants {
    public static final String HEADER_HOSTNAME_KEY = "hostname";
    public static final String LOCAL_DIRECTORY = "localDirectory";
    public static final String DIRECTORY_MAPPING = "directory_mapping";
    public static final String RECIPIENTS = "recipients";
    public static final String ECG_HOSTNAME = "ecgpe.healthtechnologygroup.com";
    public static final String ECG_HOSTNAME_2 = "ecgpi.healthtechnologygroup.com";
    public static final String AUTH_TYPE_PASS = "USERPASS";
    public static final String TEMP_FILE_SUFFIX = ".writing";
    public static final String APP_NAME = "SFTP_FILE_TRANSFER";
    public static final String CONNECTION_TYPE = "USERPASS";
    public static final String DAT_EXT = ".DAT";
    public static final String CTL_EXT = ".CTL";
    public static final String TRIGGER_FILE_NAME = "SFTP_TRIGGER_FILE_";
    public static final String TRIGGER_FILE_EXTENSION = ".INPROGRESS";
    public static final String SUCCESS_FILE_EXTENSION = ".SUCCESS";
    public static final String FAILURE_FILE_EXTENSION = ".FAILURE";

    private Constants() {
    }
}
