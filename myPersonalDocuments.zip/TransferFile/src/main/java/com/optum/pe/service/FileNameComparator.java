package com.optum.pe.service;

import java.nio.file.Path;

public class FileNameComparator implements java.util.Comparator {

    private static final String DAT_EXT = ".dat";
    private static final String CTL_EXT = ".ctl";

    @Override
    public int compare(Object o1, Object o2) {

        String fileName1 = ((Path) o1).getFileName() + "";
        String fileName2 = ((Path) o2).getFileName() + "";

        if (fileName1.contains(DAT_EXT) && !fileName2.contains(DAT_EXT)) {
            return 1;
        } else if (!fileName1.contains(DAT_EXT) && fileName2.contains(DAT_EXT)) {
            return -1;
        } else if (fileName1.contains(CTL_EXT) && !fileName2.contains(CTL_EXT)) {
            return 1;
        } else if (!fileName1.contains(CTL_EXT) && fileName2.contains(CTL_EXT)) {
            return -1;
        }

        return 0;
    }
}
