package com.optum.pe.init;

import com.optum.pe.model.DirectoryMapping;
import com.optum.pe.model.FileInfo;
import com.optum.pe.model.SFTPServer;
import com.optum.pe.model.SFTPServerWrapper;
import com.optum.pe.service.FileInfoService;
import com.optum.pe.util.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.DependsOn;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@ConditionalOnProperty(value = "default.db",
        havingValue = "true",
        matchIfMissing = false)
@Component
@Slf4j
public class StartUpInitProperties {

    private FileInfoService fileInfoService;
    private SFTPServerWrapper sftpServerWrapper;

    StartUpInitProperties(FileInfoService fileInfoService,
                          SFTPServerWrapper sftpServerWrapper) {
        this.fileInfoService = fileInfoService;
        this.sftpServerWrapper = sftpServerWrapper;
    }

    @DependsOn("SFTPServerWrapper")
    @PostConstruct
    public void addPropsFromDB() {

        try {
            // get data from db.
            List<FileInfo> fileInfoList = fileInfoService.getFileInfo();

            // map fileInfoList to sftpServer
            List<SFTPServer> sftpServerList = getSftpServers(fileInfoList);
            List<SFTPServer> newSftpServerList = addSftpServers(sftpServerWrapper.getSftpServer() != null
                            ? sftpServerWrapper.getSftpServer() : new ArrayList<>(1),
                    sftpServerList);

            sftpServerWrapper.setSftpServer(newSftpServerList);

            log.debug("Different host - ");
            sftpServerWrapper.getSftpServer().stream().map(SFTPServer::getHostname)
                    .forEach(log::debug);
        } catch (Exception ex) {
            log.debug("Error parsing fileInfoList.");
            log.error("", ex);
        }
    }

    private List<SFTPServer> addSftpServers(List<SFTPServer> sftpServerList,
                                            List<SFTPServer> sftpServerToAdd) {

        List<SFTPServer> newSFTPServer = new ArrayList<>(sftpServerList);

        sftpServerToAdd.forEach(sftpServer -> {

            Optional<SFTPServer> sftpServerOptional = newSFTPServer.stream()
                    .filter(serverToAdd -> serverToAdd.getHostname()
                            .equals(sftpServer.getHostname())).findFirst();

            SFTPServer server = sftpServerOptional.orElse(null);

            if (server != null) {
                if (server.getOutbound() != null)
                    sftpServer.getOutbound().addAll(server.getOutbound());

                if (server.getInbound() != null)
                    sftpServer.getInbound().addAll(server.getInbound());
            }

            newSFTPServer.add(sftpServer);

        });

        return newSFTPServer;
    }

    private List<SFTPServer> getSftpServers(List<FileInfo> fileInfoList) {
        List<SFTPServer> sftpServerList = new ArrayList<>();

        if (fileInfoList == null)
            return sftpServerList;

        // iterate and map to sftpServer
        fileInfoList.forEach(fileInfo -> {

            // check if host exists.
            Optional<SFTPServer> optionalSFTPServer = sftpServerList.stream()
                    .filter(sftpServer -> sftpServer.getHostname().equals(fileInfo.getHostname()))
                    .findFirst();

            // create new if not
            SFTPServer sftpServer = optionalSFTPServer
                    .orElseGet(() -> getSftpServer(sftpServerList, fileInfo));

            DirectoryMapping directoryMapping = getDirectoryMapping(fileInfo);

            // add mapping as per inbound/outbound
            if (fileInfo.getTransferType().equals("INBOUND")) {
                sftpServer.getInbound().add(directoryMapping);
            } else
                sftpServer.getOutbound().add(directoryMapping);

        });
        return sftpServerList;
    }

    private SFTPServer getSftpServer(List<SFTPServer> sftpServerList, FileInfo fileInfo) {

        SFTPServer sftpServer = new SFTPServer();

        sftpServer.setHostname(fileInfo.getHostname());
        sftpServer.setPort(Integer.parseInt(fileInfo.getPortNumber()));
        sftpServer.setConnectionType(fileInfo.getConnectionType());
        sftpServer.setInbound(new ArrayList<>());
        sftpServer.setOutbound(new ArrayList<>());
        sftpServer.setUsername(fileInfo.getUsername());

        if (fileInfo.getConnectionType().equals(Constants.AUTH_TYPE_PASS)) {
            sftpServer.setPassword(fileInfo.getPassword());
        } else {
            sftpServer.setKey(fileInfo.getKey());
            sftpServer.setPassphrase(fileInfo.getPassphrase());
            sftpServer.setKnownHosts(fileInfo.getKnownHosts());
        }

        sftpServerList.add(sftpServer);

        return sftpServer;
    }

    private DirectoryMapping getDirectoryMapping(FileInfo fileInfo) {

        DirectoryMapping directoryMapping = new DirectoryMapping();

        directoryMapping.setLocal(fileInfo.getNativeLocation());
        directoryMapping.setRemote(fileInfo.getRemoteLocation());
        directoryMapping.setRecipients(Arrays.asList(fileInfo.getMailRecipients().split(",")));

        directoryMapping.setAcceptedFileNamePattern(Arrays.asList(fileInfo.getFilePattern()
                .split(",")));

        directoryMapping.setIgnoredFileNamePattern(Arrays.asList(fileInfo.getFileIgnorePattern()
                .split(",")));

        directoryMapping.setConflictFolder(fileInfo.getConflictFolder());

        return directoryMapping;
    }
}
