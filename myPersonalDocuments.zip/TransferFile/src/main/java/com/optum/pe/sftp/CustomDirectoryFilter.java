package com.optum.pe.sftp;

import com.jcraft.jsch.ChannelSftp;
import org.springframework.integration.file.filters.AbstractDirectoryAwareFileListFilter;

public class CustomDirectoryFilter extends AbstractDirectoryAwareFileListFilter<ChannelSftp.LsEntry> {

    @Override
    protected boolean isDirectory(ChannelSftp.LsEntry file) {
        return file.getAttrs().isDir();
    }

    @Override
    public boolean accept(ChannelSftp.LsEntry file) {
        return !isDirectory(file);
    }
}
