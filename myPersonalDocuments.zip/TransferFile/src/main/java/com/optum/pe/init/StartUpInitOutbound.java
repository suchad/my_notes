package com.optum.pe.init;

import com.optum.pe.model.SFTPServerWrapper;
import com.optum.pe.service.FileAlterationListenerAdaptor;
import com.optum.pe.service.FileAlterationService;
import com.optum.pe.service.FileLinkedList;
import com.optum.pe.service.FileLinkedListRegistry;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.monitor.FileAlterationMonitor;
import org.apache.commons.io.monitor.FileAlterationObserver;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.DependsOn;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.nio.file.Path;
import java.nio.file.Paths;

@ConditionalOnProperty(value = "default.outbound",
        havingValue = "true",
        matchIfMissing = false)
@Component
@Slf4j
public class StartUpInitOutbound {

    private static final String FILE_SUFFIX = "/";
    private SFTPServerWrapper sftpServerWrapper;
    private StartUpInitProperties startUpInitProperties;

    StartUpInitOutbound(SFTPServerWrapper sftpServerWrapper, StartUpInitProperties startUpInitProperties) {
        this.sftpServerWrapper = sftpServerWrapper;
        this.startUpInitProperties = startUpInitProperties;
    }

    @PostConstruct
    @DependsOn("StartUpInitProperties")
    public void init() {

        FileAlterationMonitor monitor = new FileAlterationMonitor(500);

        sftpServerWrapper.getSftpServer().forEach(sftpServer -> {

            String hostName = sftpServer.getHostname();

            if (sftpServer.getOutbound() != null)
                sftpServer.getOutbound().stream()
                        .map(directoryMapping -> getObserver(Paths.get(directoryMapping.getLocal()),
                                hostName, directoryMapping.getRemote()))
                        .forEach(monitor::addObserver);
        });

        try {
            monitor.start();
        } catch (Exception e) {
            log.debug("Outbound Local Init Failed - " + e.getMessage());
            log.error("", e);
        }
    }

    private FileAlterationObserver getObserver(Path path, String hostName, String remoteDir) {

        String pathString = path.toString() + FILE_SUFFIX;

        FileLinkedListRegistry registry = FileLinkedListRegistry.of();

        FileLinkedList fileLinkedList = new FileLinkedList();
        fileLinkedList.setHostname(hostName);
        fileLinkedList.setLocalDir(pathString);
        fileLinkedList.setRemoteDir(remoteDir);

        log.debug("setting in registry - " + pathString);
        log.debug("remote - " + remoteDir);

        registry.addToRegistry(pathString, fileLinkedList);

        return new FileAlterationService(path,
                new FileAlterationListenerAdaptor(registry.getFromRegistry(pathString), path))
                .getObserver();
    }
}
