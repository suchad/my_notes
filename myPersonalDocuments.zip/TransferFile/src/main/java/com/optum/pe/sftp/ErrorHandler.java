package com.optum.pe.sftp;

import com.optum.pe.model.FileTransferDetails;
import com.optum.pe.service.FileTransferService;
import com.optum.pe.service.SMTPService;
import com.optum.pe.util.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.integration.message.AdviceMessage;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageDeliveryException;
import org.springframework.messaging.MessageHandler;
import org.springframework.stereotype.Component;
import reactor.util.annotation.Nullable;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

@Slf4j
@Component
public class ErrorHandler implements MessageHandler {

    private FileTransferService service;
    private SMTPService smtpService;

    ErrorHandler(@Nullable FileTransferService service, @Nullable SMTPService smtpService){
        this.service = service;
        this.smtpService = smtpService;
    }

    @Override
    public void handleMessage(Message<?> message) {

        CompletionHandler completionHandler = new CompletionHandler(service,
                message.getHeaders().get("hostname")+"", smtpService);

        FileTransferDetails fileTransferDetails = getFileTransferDetails(message, completionHandler);

        updateDatabase(completionHandler, fileTransferDetails);

        sendMail(completionHandler, fileTransferDetails, (List<String>) message.getHeaders()
                .get(Constants.RECIPIENTS));

        LocalStreamingMessageSource.fileNameMap
                .get(message.getHeaders().get(Constants.LOCAL_DIRECTORY)+"")
                .remove(fileTransferDetails.getDataFileName());

        tryClosingInputStream((AdviceMessage) message);
    }

    private FileTransferDetails getFileTransferDetails(Message<?> message, CompletionHandler completionHandler) {
        return completionHandler.getFileDetails(
                    ((MessageDeliveryException) message.getPayload())
                            .getFailedMessage().getHeaders(), 'F');
    }

    private void tryClosingInputStream(AdviceMessage message) {
        try {
            ((FileInputStream) message.getInputMessage().getPayload()).close();
        } catch (IOException ex){
            log.debug("Error while closing Input Stream.");
            log.debug(ex.getMessage());
            log.error("", ex);
        }
    }

    private void sendMail(CompletionHandler completionHandler, FileTransferDetails fileTransferDetails,
                          List<String> recipients) {
        if (smtpService != null)
            completionHandler.sendMail(fileTransferDetails, recipients);
    }

    private void updateDatabase(CompletionHandler completionHandler, FileTransferDetails fileTransferDetails) {
        if (service != null)
            completionHandler.updateDatabase(fileTransferDetails);
    }
}
