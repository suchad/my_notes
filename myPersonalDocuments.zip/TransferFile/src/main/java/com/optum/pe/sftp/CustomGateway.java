package com.optum.pe.sftp;

import org.springframework.integration.annotation.Gateway;
import org.springframework.integration.annotation.MessagingGateway;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import java.io.InputStream;

@Component
@MessagingGateway(errorChannel = "errorStream")
public interface CustomGateway {

    @Gateway(requestChannel = "outboundStream")
    void sendToSftp(Message<InputStream> message);
}
