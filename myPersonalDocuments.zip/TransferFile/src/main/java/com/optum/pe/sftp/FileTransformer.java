package com.optum.pe.sftp;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.pe.configuration.DefaultConfiguration;
import com.optum.pe.model.DirectoryMapping;
import com.optum.pe.model.FileDetails;
import com.optum.pe.model.FileTransferDetails;
import com.optum.pe.model.SFTPServerWrapper;
import com.optum.pe.service.FileTransferService;
import com.optum.pe.util.Constants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileExistsException;
import org.apache.commons.io.FileUtils;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.integration.transformer.StreamTransformer;
import org.springframework.messaging.Message;
import reactor.util.annotation.Nullable;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SecureRandom;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Optional;

/**
 * Class extracted from SFTPInboundPipeline class to reduce complexity
 *
 * @author vivek v58
 */
@Slf4j
public class FileTransformer extends StreamTransformer {

    private static final String TEMP_SUFFIX = ".writing";
    private static final String FILE_REMOTE_FILE_INFO = "file_remoteFileInfo";
    private static final String SEPARATOR = "-";
    private SFTPServerWrapper sftpServerWrapper;

    private FileTransferService fileTransferService;
    private DefaultConfiguration configuration;

    FileTransformer(@Nullable FileTransferService fileTransferService,
                    DefaultConfiguration configuration,
                    SFTPServerWrapper sftpServerWrapper){
        this.fileTransferService = fileTransferService;
        this.configuration = configuration;
        this.sftpServerWrapper = sftpServerWrapper;
    }

    /**
     * Download the input message stream from the Inbound channel adapter.
     *
     * @param message message pushed to the channel by poller
     * @return Object to be added to the output channel
     * @throws Exception based on the operations.
     */
    @Override
    protected Object doTransform(Message<?> message) throws IOException, NoSuchAlgorithmException, NoSuchProviderException {

        char status = 'N';
        FileTransferDetails fileTransferDetails = new FileTransferDetails();
        File file = null;

        // Map the channel message to FileDetails POJO
        FileDetails fileDetails = new ObjectMapper().readValue(message.getHeaders()
                .get(FILE_REMOTE_FILE_INFO) + "", FileDetails.class);

        String remoteHostName = message.getHeaders().get(Constants.HEADER_HOSTNAME_KEY) + "";

        DirectoryMapping mapping = getDirectoryMapping(fileDetails, remoteHostName);
        String localDir = mapping.getLocal();

        if(!new CustomSftpPatternFileListFilter(mapping.getAcceptedFileNamePattern(),
                mapping.getIgnoredFileNamePattern(), fileDetails.getFileName()).accept()){
            return MessageBuilder.withPayload(fileTransferDetails)
                    .copyHeaders(message.getHeaders())
                    .build();
        }

        // get the new name
        String localFileName = fileDetails.getFileName();

        try(InputStream inputStream = (InputStream) message.getPayload()){

            logger.debug(fileDetails.getFileName() + " - processing @ " + LocalDateTime.now());

            // generate FileTransferDetails from FileDetails.
            fileTransferDetails = getFileTransferDetails(fileDetails, status, fileTransferDetails, remoteHostName);

            // handle file - take input stream and write to file
            file = handleFile(inputStream, fileDetails, localDir);

            // rename the file
            renameFile(file, fileDetails.getFileName(), localDir);

            logMessage(fileTransferDetails, " - File moved.");

        } catch (FileExistsException ex){
            status = 'F';

            logMessage(fileTransferDetails, " - Exception while moving files - " + ex.getMessage());

            // move the file if it already exists - null check included.
            if (file != null)
                localFileName = moveFileToConflict(file, localDir, mapping.getConflictFolder());

            logMessage(fileTransferDetails, " - Deleted");

        } catch (IOException ex){
            status = 'F';

            logMessage(fileTransferDetails, " - IOException thrown - " + ex.getMessage());

            logger.error(ex.getMessage());
        } catch (Exception ex){
            status = 'F';

            logMessage(fileTransferDetails, " - Exception thrown - " + ex.getMessage());

            logger.error(ex.getMessage());
        }

        // set status in FileStatus, based on status value
        setStatusAndTransferEndTimeAndFileName(status, fileTransferDetails, localFileName);

        // update the status in database and generate logs.
        updateDatabaseFinalStatus(fileTransferDetails);

        logMessage(fileTransferDetails, " - Finished processing file.");

        return MessageBuilder.withPayload(fileTransferDetails)
                .copyHeaders(message.getHeaders())
                .setHeader(Constants.DIRECTORY_MAPPING, mapping)
                .build();
    }

    private DirectoryMapping getDirectoryMapping(FileDetails fileDetails, String remoteHostName) {
        Optional<DirectoryMapping> optionalDirectoryMapping = sftpServerWrapper.getSftpServer().stream()
                .filter(sftpServer -> sftpServer.getHostname().equals(remoteHostName))
                .flatMap(sftpServer -> sftpServer.getInbound().stream())
                .filter(directoryMapping -> directoryMapping.getRemote()
                        .equals(fileDetails.getRemoteDirectory())).findFirst();

        return optionalDirectoryMapping.orElse(new DirectoryMapping());
    }

    private void renameFile(File file, String fileName, String directory) throws IOException {

        // rename the file by moving
        FileUtils.moveFile(file, FileUtils.getFile(directory + fileName));
    }

    /**
     *  Insert record in DB, if enabled + create temporary file + write input stream to file
     *  + rename the file
     *
     * @param inputStream stream from message payload
     * @param fileDetails FileDetails
     * @throws IOException based on file operations.
     */
    private File handleFile(InputStream inputStream, FileDetails fileDetails,
                            String directory) throws IOException {

        // name of temporary file
        String tempFileName = directory + fileDetails.getFileName() + TEMP_SUFFIX;

        // create temporary file, while being written to.
        File file = new File(tempFileName);

        // copy input stream to file using commons-io
        FileUtils.copyInputStreamToFile(inputStream, file);

        return file;
    }

    /**
     * Get FileTransferDetails object
     *
     * @param fileDetails file details from message
     * @param status status of processing
     * @return FileTransferDetails
     */
    private FileTransferDetails getFileTransferDetails(FileDetails fileDetails, char status,
                                                       FileTransferDetails fileTransferDetails,
                                                       String remoteHostName){

        // if DbSupport is enabled insert record in DB
        if (configuration.isDb()) {

            fileTransferDetails = fileTransferService
                    .insertOrUpdateFile(generateFileTransferDetails(fileDetails, status,
                            fileTransferDetails, remoteHostName));

            logMessage(fileTransferDetails, " - Inserted record in DB.");
        }

        return fileTransferDetails;
    }

    /**
     * Check for null and log the message.
     *
     * @param fileTransferDetails file details
     * @param message to be logged
     */
    private void logMessage(FileTransferDetails fileTransferDetails, String message) {
        logger.debug(isNull(fileTransferDetails.getRemoteDataFileName()) ? "" : fileTransferDetails.getRemoteDataFileName() + message);
    }

    /**
     * Check if the Object is null.
     *
     * @param object object to be check for null
     * @return status
     */
    private boolean isNull(Object object){
        return object == null;
    }

    /**
     * Update the FileStatus in the database.
     *
     * @param fileTransferDetails Object to be updated to
     */
    private void updateDatabaseFinalStatus(FileTransferDetails fileTransferDetails) {
        if (fileTransferDetails != null && configuration.isDb()) {
            fileTransferService.insertOrUpdateFile(fileTransferDetails);

            logger.debug(fileTransferDetails.getRemoteDataFileName() + " - Updated file status in DB.");

            logger.debug(fileTransferDetails.getRemoteDataFileName()
                    + " - done processing @ " + LocalDateTime.now());
        }
    }

    /**
     * Set the given status to FileStatus
     *
     * @param status status of the file
     * @param fileTransferDetails final Object with the value
     */
    private void setStatusAndTransferEndTimeAndFileName(char status, FileTransferDetails fileTransferDetails,
                                                        String fileName) {

        if (fileTransferDetails != null){
            if (status == 'N'){
                status = 'S';
            }

            fileTransferDetails.setStatusCode(status);
            fileTransferDetails.setTransferEndDateTime(LocalDateTime.now());
            fileTransferDetails.setDataFileName(fileName);
        }
    }

    /**
     * Moves file to conflict folder and returns new name.
     *
     * @param file file
     * @return String new name
     * @throws IOException in case of file operations
     */
    private String moveFileToConflict(File file, String directory, String conflictFolderName) throws IOException, NoSuchAlgorithmException, NoSuchProviderException {

        // generate a random number for conflict file and get a new name
        SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG", "SUN");
        byte[] randomBytes = new byte[128];
        secureRandom.nextBytes(randomBytes);
        String randomString = secureRandom.nextInt() + "";
        String newName = file.getName().replace(TEMP_SUFFIX, "") + SEPARATOR + randomString;

        // rename the file
        FileUtils.moveFile(file,
                FileUtils.getFile(directory + newName));

        // move the file to directory
        FileUtils.moveFileToDirectory(FileUtils.getFile(directory + newName),
                FileUtils.getFile(directory + conflictFolderName), true);

        return newName;

    }

    /**
     * Create a new FileStatus Object and insert in database.
     *
     * @param fileDetails fileDetails pertaining the file
     * @param status status of the file
     * @return FileStatus
     */
    private FileTransferDetails generateFileTransferDetails(FileDetails fileDetails, char status,
                                                            FileTransferDetails fileTransferDetails,
                                                            String remoteHostName){

        fileTransferDetails.setFileId(BigInteger.ONE);
        fileTransferDetails.setRemoteHostName(remoteHostName);
        fileTransferDetails.setRemoteDirectoryPath(fileDetails.getRemoteDirectory());
        fileTransferDetails.setRemoteDataFileName(fileDetails.getFileName());
        fileTransferDetails.setRemoteAuditFileName("");
        fileTransferDetails.setRemoteTriggerFileName("");

        fileTransferDetails.setCreatedByName("");
        fileTransferDetails.setCreatedDateTime(LocalDateTime.now());
        fileTransferDetails.setUpdatedByName("");
        fileTransferDetails.setUpdatedDateTime(
                LocalDateTime.ofInstant(Instant.ofEpochMilli(Long.parseLong(fileDetails.getModified())),
                        ZoneId.systemDefault()));
        fileTransferDetails.setPartnerId("");
        fileTransferDetails.setTransferTypeCode("INB");
        fileTransferDetails.setAuditFileName("");
        fileTransferDetails.setTransferStartDateTime(LocalDateTime.now());

        // to be reset at the end of processing
        fileTransferDetails.setDataFileName(fileDetails.getFileName());
        fileTransferDetails.setTransferEndDateTime(LocalDateTime.now());
        fileTransferDetails.setStatusCode(status);

        fileTransferDetails.setDataFileSizeInBytes(Integer.parseInt(fileDetails.getSize()));
        fileTransferDetails.setAuditFileSizeInBytes(0);

        return fileTransferDetails;
    }
}
