package com.optum.pe.service;

import com.optum.pe.configuration.DefaultConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.math.BigInteger;
import java.util.List;

/**
 * Service to compose and send mails.
 *
 * @author vivek
 */
@ConditionalOnProperty(
        value = "default.mail",
        havingValue = "true",
        matchIfMissing = false)
@Service
@Slf4j
public class SMTPService {

    private final JavaMailSender mailSender;
    private final DefaultConfiguration defaultConfiguration;

    public SMTPService(JavaMailSender mailSender, DefaultConfiguration defaultConfiguration) {
        this.mailSender = mailSender;
        this.defaultConfiguration = defaultConfiguration;
    }

    /**
     * to send mail to the recipients mentioned in configuration.
     *
     * @param id        database id
     * @param fileName  file name
     * @param partnerId partner id
     */
    public void sendMail(BigInteger id, String fileName, String partnerId, char statusCode,
                         List<String> recipients) {

        MimeMessage message = mailSender.createMimeMessage();

        try {
            MimeMessageHelper messageHelper = new MimeMessageHelper(message, true);

            messageHelper.setTo(recipients.toArray(new String[0]));
            messageHelper.setFrom("admin_" + defaultConfiguration.getEnvironment() + "@optum.com");

            messageHelper.setSubject("SFTP Service - " + fileName + " File Moved ");

            messageHelper.setText("<h1 style=\"text-align:center\"> File Details </h1>\n" +
                    "    <table border=\"1\" style=\"border-collapse:collapse;\">\n" +
                    "        <tr style=\"height: 30px;\">\n" +
                    "        \t<td style=\"text-align:center;font-weight:bold;\"> Param </td>\n" +
                    "            <td style=\"text-align:center;font-weight:bold;\"> Value </td>\n" +
                    "        </tr>" +
                    "        \t<tr style=\"height: 30px;\">\n" +
                    "        \t<td style=\"text-align:center\"> ID </td>\n" +
                    "            <td style=\"text-align:center\"> " + id.toString() + " </td>\n" +
                    "        </tr>\n" +
                    "        <tr style=\"height: 30px;\">\n" +
                    "        \t<td style=\"text-align:center\"> File Name </td>\n" +
                    "            <td style=\"text-align:center\"> " + fileName + " </td>\n" +
                    "        </tr>\n" +
                    "        <tr style=\"height: 30px;\">\n" +
                    "        \t<td style=\"text-align:center\"> Partner ID </td>\n" +
                    "            <td style=\"text-align:center\"> " + partnerId + " </td>\n" +
                    "        </tr>\n" +
                    "        <tr style=\"height: 30px;\">\n" +
                    "        \t<td style=\"text-align:center\"> Status Code </td>\n" +
                    "            <td style=\"text-align:center\"> " + statusCode + " </td>\n" +
                    "        </tr>\n" +
                    "    </table>", true);

        } catch (MessagingException ex) {
            log.error("Error while sending mail - " + ex.getMessage());
        }

        mailSender.send(message);
    }
}
