package com.optum.pe.sftp;

import org.springframework.util.AntPathMatcher;

import java.util.List;

/**
 * Custom SftpPatternFileListFilter Implementation as default only worked with single regex pattern.
 *
 * @author vivek v58
 */
class CustomSftpPatternFileListFilter {

    private final AntPathMatcher matcher = new AntPathMatcher();
    private List<String> acceptedFilePattern;
    private List<String> ignoredFilePattern;
    private String fileName;

    CustomSftpPatternFileListFilter(List<String> acceptedFilePattern, List<String> ignoredFilePattern,
                                    String fileName){
        this.acceptedFilePattern = acceptedFilePattern;
        this.ignoredFilePattern = ignoredFilePattern;
        this.fileName = fileName;
    }

    boolean accept() {
        return customAcceptBasedOnProperties();
    }

    /**
     * Check if filename matches accepted list or rejected list.
     * @return status
     */
    private boolean customAcceptBasedOnProperties(){
        return matchFromArray(this.acceptedFilePattern, fileName)
                && !matchFromArray(this.ignoredFilePattern, fileName);
    }

    private boolean matchFromArray(List<String> patterns, String fileName){

        if (patterns != null)
            for (String pattern : patterns){
                if (this.matcher.match(pattern, fileName))
                    return true;
            }
        else{
            return true;
        }

        return false;
    }
}
