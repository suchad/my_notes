package com.optum.pe.sftp;

import com.optum.pe.model.FileTransferDetails;
import com.optum.pe.service.FileTransferService;
import com.optum.pe.service.SMTPService;
import org.springframework.integration.file.FileHeaders;
import org.springframework.messaging.MessageHeaders;
import reactor.util.annotation.Nullable;

import java.math.BigInteger;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;

class CompletionHandler {

    private FileTransferService service;
    private String remoteHostName;
    private SMTPService smtpService;

    CompletionHandler(@Nullable FileTransferService service, String remoteHostName,
                 @Nullable SMTPService smtpService){
        this.service = service;
        this.remoteHostName = remoteHostName;
        this.smtpService = smtpService;
    }

    void sendMail(FileTransferDetails fileTransferDetails, List<String> recipients){
        smtpService.sendMail(fileTransferDetails.getFileId(),
                fileTransferDetails.getRemoteDataFileName(),
                fileTransferDetails.getPartnerId(),
                fileTransferDetails.getStatusCode(),
                recipients);
    }

    void updateDatabase(FileTransferDetails fileTransferDetails){
        service.insertOrUpdateFile(fileTransferDetails);
    }

    FileTransferDetails getFileDetails(MessageHeaders headers, char status) {

        FileTransferDetails fileTransferDetails = new FileTransferDetails();

        fileTransferDetails.setFileId(BigInteger.ONE);
        fileTransferDetails.setRemoteHostName(remoteHostName);
        fileTransferDetails.setRemoteDirectoryPath((String) headers.get("remoteDirectory"));
        fileTransferDetails.setRemoteDataFileName(headers.get(FileHeaders.FILENAME) + "");
        fileTransferDetails.setRemoteAuditFileName("");
        fileTransferDetails.setRemoteTriggerFileName("");

        fileTransferDetails.setCreatedByName("");
        fileTransferDetails.setCreatedDateTime(LocalDateTime.now());
        fileTransferDetails.setUpdatedByName("");
        fileTransferDetails.setUpdatedDateTime(
                LocalDateTime.ofInstant(Instant.ofEpochMilli((long) headers.get("modified")),
                        ZoneId.systemDefault()));
        fileTransferDetails.setPartnerId("");
        fileTransferDetails.setTransferTypeCode("INB");
        fileTransferDetails.setAuditFileName("");
        fileTransferDetails.setTransferStartDateTime(LocalDateTime.now());

        fileTransferDetails.setDataFileName(headers.get(FileHeaders.FILENAME) + "");
        fileTransferDetails.setTransferEndDateTime(LocalDateTime.now());
        fileTransferDetails.setStatusCode(status);

        fileTransferDetails.setDataFileSizeInBytes(Integer.parseInt(headers.get("size") + ""));
        fileTransferDetails.setAuditFileSizeInBytes(0);

        return fileTransferDetails;
    }
}
