package com.optum.pe.model;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.math.BigInteger;
import java.time.LocalDateTime;

@Entity
@Data
@Table(name = "ms_file_info")
public class FileInfo {

    @Id
    @Column(name = "file_id")
    private BigInteger fileId;

    @Column(name = "partner_proc_grp_id")
    private String partnerProcGroupId;

    @Column(name = "partner_id")
    private String partnerId;

    @Column(name = "file_pattern")
    private String filePattern;

    @Column(name = "file_ignore_pattern")
    private String fileIgnorePattern;

    @Column(name = "transfer_type")
    private String transferType;

    @Column(name = "hostname")
    private String hostname;

    @Column(name = "connection_type")
    private String connectionType;

    @Column(name = "port_no")
    private String portNumber;

    private String username;

    private String password;

    private String key;

    private String passphrase;

    @Column(name = "known_hosts")
    private String knownHosts;

    @Column(name = "remote_location")
    private String remoteLocation;

    @Column(name = "native_location")
    private String nativeLocation;

    @Column(name = "mail_recipients")
    private String mailRecipients;

    @Column(name = "create_dt")
    private LocalDateTime createDateTime;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "conflict_folder")
    private String conflictFolder;

    @Column(name = "config_active_flag")
    private String configActiveFlag;

    @Column(name = "config_identifier")
    private String configIdentifier;

    @Column(name = "env")
    private String env;
}
