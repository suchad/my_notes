package com.optum.pe.configuration;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Getter
@Configuration
public class DefaultConfiguration {

    @Value("${default.client:false}")
    private boolean isClient;

    @Value("${default.db:false}")
    private boolean isDb;

    @Value("${default.mail:false}")
    private boolean isMail;

    @Value("${default.outbound:false}")
    private boolean isOutbound;

    @Value("${default.inbound:false}")
    private boolean isInbound;

    @Value("${spring.profiles}")
    private String environment;

    @Value("${default.triggerLocation}")
    private String triggerLocation;
}
