package com.optum.pe.service;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import com.optum.pe.model.FileInfo;
import com.optum.pe.model.FileTransferDetails;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FilenameUtils;
import org.springframework.mail.MailException;
import org.springframework.stereotype.Service;
import org.springframework.util.AntPathMatcher;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@Slf4j
@Service
public class JSchService {

    private final AntPathMatcher matcher = new AntPathMatcher();
    private final FileTransferService fileTransferService;
    private final SMTPService smtpService;

    JSchService(FileTransferService fileTransferService, SMTPService smtpService) {
        this.fileTransferService = fileTransferService;
        this.smtpService = smtpService;
    }

    private Session getJschSessionWithKeys(String username, String remoteHost, String keyPath, String passphrase)
            throws JSchException {
        JSch jsch = getJSch();

        jsch.addIdentity(keyPath, passphrase);
        JSch.setConfig("StrictHostKeyChecking", "no");

        Session jschSession = jsch.getSession(username, remoteHost);

        jschSession.setHost(remoteHost);

        log.debug("got session");
        jschSession.connect();

        log.debug("Connected through session");
        return jschSession;
    }

    JSch getJSch() {
        return new JSch();
    }

    private Session getJschSessionWithPassword(String username, String remoteHost,
                                               String password) throws JSchException {
        JSch jsch = getJSch();

        JSch.setConfig("StrictHostKeyChecking", "no");

        Session jschSession = jsch.getSession(username, remoteHost);
        jschSession.setPassword(password);
        jschSession.setHost(remoteHost);

        log.debug("got session");
        jschSession.connect();

        log.debug("Connected through session");
        return jschSession;
    }

    private ChannelSftp openChannel(Session jschSession) throws JSchException {
        return (ChannelSftp) jschSession.openChannel("sftp");
    }

    public boolean uploadFile(FileInfo fileInfo) {

        boolean status = false;

        try {

            Session jschSession = null;

            if (fileInfo.getConnectionType().equals("USERPASS")) {
                jschSession = getJschSessionWithPassword(fileInfo.getUsername(),
                        fileInfo.getHostname(), fileInfo.getPassword());
            } else {
                jschSession = getJschSessionWithKeys(fileInfo.getUsername(),
                        fileInfo.getHostname(), fileInfo.getKey(), fileInfo.getPassphrase());
            }

            ChannelSftp channelSftp = openChannel(jschSession);

            channelSftp.connect();
            log.debug("Channel Status connected(true)/closed(false) - " + channelSftp.isConnected());

            String localDirectory = fileInfo.getNativeLocation();

            Path localPath = Paths.get(localDirectory);
            status = walkFiles(fileInfo, channelSftp, localPath);

            log.debug("successfully sent files to " + fileInfo.getHostname() + " @ " + fileInfo.getRemoteLocation());
            channelSftp.exit();

            jschSession.disconnect();

            log.debug("channel exited and session disconnected");
        } catch (JSchException ex) {
            log.debug("Error setting up Jsch.");
            log.debug(ex.getMessage());
            log.error("", ex);
        }

        return status;
    }

    private boolean walkFiles(FileInfo fileInfo, ChannelSftp channelSftp, Path localPath) {

        boolean status = false;
        List<String> successfulTransferFiles = new ArrayList<>();

        try (Stream<Path> pathStream = Files.walk(localPath, 1)) {

            List<Path> paths = pathStream
                    .filter(path -> path.toFile().isFile())
                    .filter(path -> fileNameFilter(path, fileInfo))
                    .collect(Collectors.toList());

            paths.stream()
                    .sorted(new FileNameComparator())
                    .forEach(path -> {
                        if (sendFile(channelSftp, fileInfo.getRemoteLocation(),
                                (Path) path, fileInfo.getConflictFolder())) {
                            successfulTransferFiles.add(path + "");
                            generateFileTransferDetails(fileInfo, (Path) path, 'S');
                            try {
                                sendEmail(fileInfo, (Path) path, 'S', fileInfo.getMailRecipients());
                            } catch (MailException ex) {
                                log.debug("Error while sending mail");
                                log.error("", ex);
                            }
                        } else {
                            generateFileTransferDetails(fileInfo, (Path) path, 'F');
                            try {
                                sendEmail(fileInfo, (Path) path, 'F', fileInfo.getMailRecipients());
                            } catch (MailException ex) {
                                log.debug("Error while sending mail");
                                log.error("", ex);
                            }
                        }
                    });

            if (paths.size() == successfulTransferFiles.size()) {
                status = true;
            }

        } catch (IOException ex) {
            log.debug("Error while listing files from local system");
            log.debug(ex.getMessage());
            log.error("", ex);
        }

        return status;
    }

    void sendEmail(FileInfo fileInfo, Path path, char statusCd, String recipientsString) {

        List<String> recipients = Arrays.stream(recipientsString.split(","))
                .collect(Collectors.toList());

        smtpService.sendMail(fileInfo.getFileId(), FilenameUtils.getName(path.toString()),
                fileInfo.getPartnerId(), statusCd, recipients);
    }

    void generateFileTransferDetails(FileInfo fileInfo, Path path, char statusCd) {
        FileTransferDetails fileTransferDetails = getTransferDetailsFrom(fileInfo, path, statusCd);

        fileTransferService.insertOrUpdateFile(fileTransferDetails);
    }

    private FileTransferDetails getTransferDetailsFrom(FileInfo fileInfo, Path path, char statusCd) {

        File file = path.toFile();

        BasicFileAttributes attr = null;

        try {
            attr = Files.readAttributes(path, BasicFileAttributes.class);
        } catch (IOException ex) {
            log.debug("file not found for attributes");
        }

        FileTransferDetails fileTransferDetails = new FileTransferDetails();
        fileTransferDetails.setPartnerProcGroupId(fileInfo.getPartnerProcGroupId());
        fileTransferDetails.setDataFileName(FilenameUtils.getName(path + ""));
        fileTransferDetails.setPartnerId(fileInfo.getPartnerId());
        fileTransferDetails.setTransferTypeCode("OUT");
        fileTransferDetails.setAuditFileName("");
        fileTransferDetails.setFileId(fileInfo.getFileId());
        fileTransferDetails.setRemoteHostName(fileInfo.getHostname());
        fileTransferDetails.setTransferStartDateTime(LocalDateTime.now());
        fileTransferDetails.setTransferEndDateTime(LocalDateTime.now());
        fileTransferDetails.setStatusCode(statusCd);
        fileTransferDetails.setDataFileSizeInBytes(Math.toIntExact(file.length()));
        fileTransferDetails.setAuditFileSizeInBytes(0);
        fileTransferDetails.setCreatedByName("");
        fileTransferDetails.setUpdatedByName("");
        fileTransferDetails.setRemoteDirectoryPath(fileInfo.getRemoteLocation());
        fileTransferDetails.setRemoteDataFileName(FilenameUtils.getName(path + ""));
        fileTransferDetails.setRemoteAuditFileName("");
        fileTransferDetails.setRemoteTriggerFileName("");

        if (attr != null) {
            fileTransferDetails.setCreatedDateTime(LocalDateTime.ofInstant(attr.creationTime().toInstant(),
                    ZoneId.systemDefault()));

            fileTransferDetails.setUpdatedDateTime(
                    LocalDateTime.ofInstant(attr.lastModifiedTime().toInstant(),
                            ZoneId.systemDefault()));
        } else {
            fileTransferDetails.setCreatedDateTime(LocalDateTime.now());
            fileTransferDetails.setUpdatedDateTime(LocalDateTime.now());
        }

        return fileTransferDetails;
    }

    boolean fileNameFilter(Path path, FileInfo fileInfo) {
        return matchAcceptedPattern(fileInfo.getFilePattern(), path.getFileName().toString())
                && !matchRejectedPattern(fileInfo.getFileIgnorePattern(), path.getFileName().toString());
    }

    boolean sendFile(ChannelSftp channelSftp, String remoteLocation, Path path, String conflictFolder) {

        boolean status = false;

        try {
            channelSftp.put(path.toString(), remoteLocation + path.getFileName().toString());

            status = moveFilesToArchiveFolder(path, conflictFolder);

            log.info("File Successfully Transferred and Archived - " + path.getFileName().toString());
        } catch (SftpException ex) {
            log.debug("Error while uploading file " + path.getFileName().toString());
            log.debug(ex.getMessage());
            log.error("", ex);
        } catch (IOException ex) {
            log.debug("Error while archiving file " + path.getFileName().toString());
            log.debug(ex.getMessage());
            log.error("", ex);
        }

        return status;
    }

    private boolean matchAcceptedPattern(String pattern, String fileName) {

        return pattern == null || pattern.isEmpty() || this.matcher.match(pattern, fileName);
    }

    private boolean matchRejectedPattern(String pattern, String fileName) {

        if (pattern == null || pattern.isEmpty())
            return false;
        else
            return this.matcher.match(pattern, fileName);
    }

    private boolean moveFilesToArchiveFolder(Path path, String conflictFolder) throws IOException {

        String conflictPath = path.getParent().toString() + File.separator + conflictFolder;

        File directory = getFileFrom(conflictPath, conflictPath);
        boolean success = true;

        if (!directory.exists()) {
            success = directory.mkdir();
        }

        if (!success) {
            log.error("Directory was not created");
        }

        return zipAndMoveFile(path, conflictPath);
    }

    boolean zipAndMoveFile(Path path, String conflictPath) throws IOException {

        boolean status = false;

        File fileToZip = path.toFile();

        String zipFileName = path.getFileName() + "-"
                + LocalDateTime.now().format(DateTimeFormatter.ofPattern("ddMMyyyy-HHmmss"))
                + ".zip";

        File file = getFileFrom(conflictPath, zipFileName);
        log.debug(file.getPath());

        if (file.createNewFile()) {
            log.debug("successfully created empty zip file");
        }

        FileOutputStream fos = new FileOutputStream(file);

        try (ZipOutputStream zipOut = new ZipOutputStream(fos)) {

            write(fileToZip, zipOut);

            status = true;
        } catch (IOException ex) {
            log.error("Not Able to create the output file in archive folder.");
            log.error("", ex);
        }

        fos.close();
        Files.delete(path);

        return status;
    }

    private void write(File fileToZip, ZipOutputStream zipOut) {
        try (FileInputStream fis = new FileInputStream(fileToZip)) {

            putZipEntry(fileToZip, zipOut);

            writeBytesToZipFile(zipOut, fis);

        } catch (FileNotFoundException ex) {
            log.error("Not Able to read the file " + fileToZip.getName());
            log.error("", ex);
        } catch (IOException ex) {
            log.error("IOException thrown: " + ex);
        }
    }

    private void putZipEntry(File fileToZip, ZipOutputStream zipOut) throws IOException {
        ZipEntry zipEntry = new ZipEntry(fileToZip.getName());

        zipOut.putNextEntry(zipEntry);
    }

    private void writeBytesToZipFile(ZipOutputStream zipOut, FileInputStream fis) throws IOException {
        byte[] bytes = new byte[1024];
        int length;
        while ((length = fis.read(bytes)) >= 0) {
            zipOut.write(bytes, 0, length);
        }
    }

    private File getFileFrom(String path, String name) {
        return new File(FilenameUtils.getFullPath(path), FilenameUtils.getName(name));
    }
}
