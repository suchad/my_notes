package com.optum.pe.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.math.BigInteger;

/**
 * POJO to hold file details and acts as entity to database table 'ms_file_info'
 *
 * @author vivek v58
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "ms_file_info")
class FileStatus {

    @Id
    @Column(name = "file_id")
    private BigInteger fileId;

    @Column(name = "partner_name")
    private String partnerName;

    @Column(name = "partner_id")
    private String partnerId;

    @Column(name = "file_name")
    private String fileName;

    @Column(name = "status")
    private String status;
}
