package com.optum.pe.repository;

import com.optum.pe.model.FileInfo;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;
import java.util.List;

@Repository
public interface FileInfoRepository extends CrudRepository<FileInfo, BigInteger> {

    @Query(value = "select * from ms_file_info where config_active_flag = 'X'", nativeQuery = true)
    List<FileInfo> findAll();

    @Query(value = "select * from ms_file_info where transfer_type = 'OUTBOUND' " +
            "and partner_proc_grp_id = ?1 and config_identifier = ?2 " +
            "and env = ?3 and config_active_flag = 'Y'", nativeQuery = true)
    List<FileInfo> findByPartnerNameAndPartnerId(String ppid, String identifier, String env);

    @Query(value = "select * from ms_file_info where transfer_type = 'INBOUND' and config_active_flag = 'Y'", nativeQuery = true)
    List<FileInfo> findByTransferType();
}
