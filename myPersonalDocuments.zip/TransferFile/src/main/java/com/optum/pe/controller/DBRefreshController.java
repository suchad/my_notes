package com.optum.pe.controller;

import com.optum.pe.PeSftpServiceApplication;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeansException;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin
@Slf4j
@RestController
@RequestMapping("/database")
public class DBRefreshController {

    @GetMapping("/refresh_mapping")
    public boolean refreshMapping() {

        boolean status = true;

        try {
            PeSftpServiceApplication.restart();
        } catch (BeansException ex) {
            log.debug(ex.getMessage());
            log.error("", ex);
            status = false;
        }

        return status;
    }
}
