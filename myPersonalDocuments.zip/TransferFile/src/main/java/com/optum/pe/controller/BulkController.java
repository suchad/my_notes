package com.optum.pe.controller;

import com.optum.pe.model.FileInfo;
import com.optum.pe.service.FileGetterService;
import com.optum.pe.service.FileInfoService;
import com.optum.pe.service.JSchAsyncService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;
import java.util.Optional;

@Slf4j
@RestController
@RequestMapping("/sftp")
class BulkController {

    private final FileInfoService fileInfoService;
    private final FileGetterService fileGetterService;
    private final JSchAsyncService jSchAsyncService;

    BulkController(FileInfoService fileInfoService, FileGetterService fileGetterService,
                   JSchAsyncService jSchAsyncService) {
        this.fileInfoService = fileInfoService;
        this.fileGetterService = fileGetterService;
        this.jSchAsyncService = jSchAsyncService;
    }

    @GetMapping("/upload/bulk/{ppid}/{identifier}/{env}")
    public String uploadBulk(@PathVariable("ppid") String ppid,
                             @PathVariable("identifier") String identifier,
                             @PathVariable("env") String env) throws IOException {

        Optional<Path> triggerFileOptional = fileGetterService.createTriggerFile();

        if (triggerFileOptional.isPresent()) {

            List<FileInfo> fileInfoList = fileInfoService.getFileInfoFor(ppid, identifier, env);

            if (fileInfoList.isEmpty()) {
                return null;
            } else {
                jSchAsyncService.bulkUpload(fileInfoList.get(0), triggerFileOptional.get());

                return triggerFileOptional.get().toString();
            }

        }

        return null;
    }
}
