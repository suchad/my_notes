package com.optum.pe.service;

import com.optum.pe.model.FileTransferDetails;
import com.optum.pe.repository.FileTransferRepository;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

/**
 * Service for FileTransferRepository.
 *
 * @author vivek v58
 */
@ConditionalOnProperty(
        value="default.db",
        havingValue = "true",
        matchIfMissing = false)
@Service
public class FileTransferService {

    private FileTransferRepository repository;

    FileTransferService(FileTransferRepository repository){
        this.repository = repository;
    }

    /**
     * Insert FileTransferDetails or if exists update it.
     *
     * @param fileTransferDetails FileTransferDetails
     * @return FileTransferDetails
     */
    public FileTransferDetails insertOrUpdateFile(FileTransferDetails fileTransferDetails){

        return repository.save(fileTransferDetails);
    }
}
