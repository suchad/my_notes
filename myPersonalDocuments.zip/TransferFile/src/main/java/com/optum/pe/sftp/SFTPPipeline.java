package com.optum.pe.sftp;

import com.jcraft.jsch.ChannelSftp;
import com.optum.pe.model.SFTPServer;
import com.optum.pe.model.SFTPServerWrapper;
import com.optum.pe.util.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.integration.file.remote.session.DelegatingSessionFactory;
import org.springframework.integration.file.remote.session.SessionFactory;
import org.springframework.integration.sftp.session.DefaultSftpSessionFactory;
import org.springframework.integration.sftp.session.SftpRemoteFileTemplate;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.IntStream;

@Component
class SFTPPipeline {

    private SFTPServerWrapper sftpServerWrapper;

    SFTPPipeline(SFTPServerWrapper sftpServerWrapper) {
        this.sftpServerWrapper = sftpServerWrapper;
    }

    /**
     * Creating session for Source SFTP server Folder
     *
     * @return SessionFactory
     */
    @DependsOn({"SFTPServerWrapper"})
    @Bean
    DelegatingSessionFactory<ChannelSftp.LsEntry> delegatingSessionFactory() {

        Map<String, SessionFactory<ChannelSftp.LsEntry>> sftpSessionFactoryMap = new HashMap<>();

        if (sftpServerWrapper.getSftpServer() != null) {

            IntStream.range(0, sftpServerWrapper.getSftpServer().size())
                    .forEach(index -> {

                        DefaultSftpSessionFactory defaultSftpSessionFactory =
                                new DefaultSftpSessionFactory(false);

                        SFTPServer sftpServer = sftpServerWrapper.getSftpServer().get(index);
                        defaultSftpSessionFactory.setHost(sftpServer.getHostname());
                        defaultSftpSessionFactory.setPort(sftpServer.getPort());
                        defaultSftpSessionFactory.setUser(sftpServer.getUsername());

                        if (sftpServer.getConnectionType().equals(Constants.AUTH_TYPE_PASS)) {
                            defaultSftpSessionFactory.setPassword(sftpServer.getPassword());
                        } else {
                            Resource resource = new ByteArrayResource(sftpServer.getKey().getBytes());
                            defaultSftpSessionFactory.setPrivateKey(resource);

                            defaultSftpSessionFactory.setPrivateKeyPassphrase(sftpServer.getPassphrase());
                            defaultSftpSessionFactory.setKnownHosts(sftpServer.getKnownHosts());
                        }

                        defaultSftpSessionFactory.setAllowUnknownKeys(true);

                        sftpSessionFactoryMap.put(sftpServer.getHostname(), defaultSftpSessionFactory);
                    });
        }

        SessionFactory defaultFactory = null;

        if (sftpSessionFactoryMap.values().iterator().hasNext()) {
            defaultFactory = sftpSessionFactoryMap.values().iterator().next();
        }

        return new DelegatingSessionFactory(sftpSessionFactoryMap, defaultFactory);
    }

    /**
     * Suggested streaming File Template.
     *
     * @return SftpRemoteFileTemplate
     */
    @Autowired
    @Bean
    SftpRemoteFileTemplate template(@Lazy DelegatingSessionFactory sessionFactory) {
        return new SftpRemoteFileTemplate(sessionFactory);
    }
}
