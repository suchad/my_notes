package com.optum.pe.sftp;

import com.jcraft.jsch.ChannelSftp;
import com.optum.pe.util.Constants;
import org.springframework.integration.file.filters.FileListFilter;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class CustomFileNameFilter implements FileListFilter<ChannelSftp.LsEntry> {

    @Override
    public List<ChannelSftp.LsEntry> filterFiles(ChannelSftp.LsEntry[] files) {
        return Arrays.stream(files)
                .filter(file -> !file.getFilename().contains(Constants.TEMP_FILE_SUFFIX))
                .collect(Collectors.toList());
    }
}
