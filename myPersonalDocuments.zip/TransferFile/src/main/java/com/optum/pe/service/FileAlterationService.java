package com.optum.pe.service;

import org.apache.commons.io.monitor.FileAlterationListener;
import org.apache.commons.io.monitor.FileAlterationObserver;

import java.nio.file.Path;

public class FileAlterationService {

    private FileAlterationObserver observer;

    public FileAlterationService(Path path, FileAlterationListener listener){
        observer = new FileAlterationObserver(path.toFile());

        observer.addListener(listener);
    }

    public FileAlterationObserver getObserver() {
        return observer;
    }

}
