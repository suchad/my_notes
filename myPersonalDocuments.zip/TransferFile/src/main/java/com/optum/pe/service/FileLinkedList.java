package com.optum.pe.service;

import lombok.Getter;
import lombok.Setter;

import java.io.File;
import java.util.LinkedList;

@Setter @Getter
public class FileLinkedList {

    private LinkedList<File> fileList = new LinkedList<>();
    private String localDir;
    private String remoteDir;
    private String hostname;

    void addFileToQueue(File file){
        fileList.add(file);
    }

    public File popFileFromQueue(){
        return fileList.pop();
    }

    public int getQueueSize(){
        return fileList.size();
    }
}
