package com.optum.pe.sftp;

import com.optum.pe.model.FileTransferDetails;
import com.optum.pe.service.FileTransferService;
import com.optum.pe.service.SMTPService;
import com.optum.pe.util.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.integration.message.AdviceMessage;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHandler;
import org.springframework.messaging.MessageHeaders;
import org.springframework.stereotype.Component;
import reactor.util.annotation.Nullable;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

@Slf4j
@Component
public class SuccessHandler implements MessageHandler {

    private FileTransferService service;
    private SMTPService smtpService;

    SuccessHandler(@Nullable FileTransferService service, @Nullable SMTPService smtpService){
        this.service = service;
        this.smtpService = smtpService;
    }

    @Override
    public void handleMessage(Message<?> message) {

        MessageHeaders header = ((AdviceMessage) message).getInputMessage().getHeaders();

        CompletionHandler completionHandler = new CompletionHandler(service,
                header.get("hostname")+"", smtpService);

        FileTransferDetails fileTransferDetails = getFileTransferDetails(header,
                completionHandler);

        updateDatabase(completionHandler, fileTransferDetails);

        sendMail(completionHandler, fileTransferDetails,
                (List<String>) header.get(Constants.RECIPIENTS));

        LocalStreamingMessageSource.fileNameMap
                .get(header.get(Constants.LOCAL_DIRECTORY)+"")
                .remove(fileTransferDetails.getDataFileName());

        tryClosingInputStream((AdviceMessage) message);

        tryRemovingLocalFile(header.get("localDirectory") + fileTransferDetails.getDataFileName());
    }

    private FileTransferDetails getFileTransferDetails(MessageHeaders headers, CompletionHandler completionHandler) {
        return completionHandler.getFileDetails(headers, 'S');
    }

    private void tryRemovingLocalFile(String filePath) {
        try {
            removeLocalFile(filePath);
        } catch (IOException ex){
            log.debug("Error while removing local file.");
            log.debug(ex.getMessage());
            log.error("", ex);
        }
    }

    private void tryClosingInputStream(AdviceMessage message) {
        try {
            ((FileInputStream) message.getInputMessage().getPayload()).close();
        } catch (IOException ex){
            log.debug("Error while closing Input Stream.");
            log.debug(ex.getMessage());
            log.error("", ex);
        }
    }

    private void removeLocalFile(String filePath) throws IOException {
        log.debug("Removing file - " + filePath);
        Files.delete(Paths.get(filePath));
    }

    private void sendMail(CompletionHandler completionHandler, FileTransferDetails fileTransferDetails,
                          List<String> recipients) {
        if (smtpService != null)
            completionHandler.sendMail(fileTransferDetails, recipients);
    }

    private void updateDatabase(CompletionHandler completionHandler, FileTransferDetails fileTransferDetails) {
        if (service != null)
            completionHandler.updateDatabase(fileTransferDetails);
    }
}
