package com.optum.pe.swaggerservice.util;

public class Constant {

    public static final String LOCAL_API_DOC_URL = "http://pe-swagger-service-test-route-payment-engine-ctc.ocp-ctc-core-nonprod.optum.com/v2/api-docs";
}
