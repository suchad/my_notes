package com.optum.pe.swaggerservice.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Primary;
import springfox.documentation.swagger.web.InMemorySwaggerResourcesProvider;
import springfox.documentation.swagger.web.SwaggerResource;
import springfox.documentation.swagger.web.SwaggerResourcesProvider;

import java.util.ArrayList;
import java.util.List;

@Configuration
public class SwaggerUIConfiguration {

    @Autowired
    private SwaggerDefinitionContext swaggerDefinitionContext;

    @Primary
    @Bean
    @Lazy
    public SwaggerResourcesProvider swaggerResourcesProvider(
            InMemorySwaggerResourcesProvider defaultResourcesProvider) {

        return () -> {
            List<SwaggerResource> resources = new ArrayList<>(defaultResourcesProvider.get());

            resources.clear();
            resources.add(swaggerDefinitionContext.getDefaultResource());
            resources.addAll(swaggerDefinitionContext.getSwaggerDefinitions());

            return resources;
        };
    }
}
