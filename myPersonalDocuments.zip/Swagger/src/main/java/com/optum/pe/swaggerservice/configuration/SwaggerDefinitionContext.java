package com.optum.pe.swaggerservice.configuration;

import com.netflix.appinfo.InstanceInfo;
import com.netflix.eureka.EurekaServerContextHolder;
import com.netflix.eureka.registry.PeerAwareInstanceRegistry;
import com.optum.pe.swaggerservice.util.Constant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import springfox.documentation.swagger.web.SwaggerResource;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Component
@Scope(scopeName = ConfigurableBeanFactory.SCOPE_SINGLETON)
public class SwaggerDefinitionContext {

    @Autowired
    private RestTemplate restTemplate;

    List<SwaggerResource> getSwaggerDefinitions() {

        PeerAwareInstanceRegistry registry = EurekaServerContextHolder.getInstance()
                .getServerContext().getRegistry();

        return registry.getApplications().getRegisteredApplications().stream()
                .map(application -> {

                    SwaggerResource resource = new SwaggerResource();
                    resource.setUrl("/service/" + application.getName());
                    resource.setName(application.getName());
                    resource.setSwaggerVersion("2.0");
                    return resource;
                }).collect(Collectors.toList());
    }

    SwaggerResource getDefaultResource() {

        SwaggerResource resource = new SwaggerResource();
        resource.setUrl(Constant.LOCAL_API_DOC_URL);
        resource.setName("default");
        resource.setSwaggerVersion("2.0");

        return resource;
    }

    public String getSwaggerDefinition(String serviceName) {
        PeerAwareInstanceRegistry registry = EurekaServerContextHolder.getInstance()
                .getServerContext().getRegistry();

        InstanceInfo instanceInfo = registry.getApplication(serviceName)
                .getInstances().get(0);

        return restTemplate.getForObject("http://" + instanceInfo.getIPAddr() + ":"
                + instanceInfo.getPort() + "/v2/api-docs", String.class);
    }
}
