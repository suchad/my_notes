package com.optum.pe.swaggerservice.controller;

import com.optum.pe.swaggerservice.configuration.SwaggerDefinitionContext;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.Silent.class)
public class ResourceControllerTest {

    @InjectMocks
    private ResourceController resourceController;

    @Mock
    private SwaggerDefinitionContext swaggerDefinitionContext;

    @Test
    public void testGetServiceDefinition(){
        Mockito.when(swaggerDefinitionContext.getSwaggerDefinition(Mockito.anyString())).thenReturn(Mockito.anyString());

        assertEquals("",resourceController.getServiceDefinition("testServiceName"));
    }
}
