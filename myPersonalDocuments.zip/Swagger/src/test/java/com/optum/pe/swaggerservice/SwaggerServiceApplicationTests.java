package com.optum.pe.swaggerservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SwaggerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
