#!/bin/sh -ex
mvn clean install
oc start-build spring --from-dir=. --follow=true
