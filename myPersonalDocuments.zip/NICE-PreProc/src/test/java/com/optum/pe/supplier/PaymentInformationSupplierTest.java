package com.optum.pe.supplier;

import com.optum.pe.beans.parsing.CheckRecord;
import com.optum.pe.models.LookupData;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
public class PaymentInformationSupplierTest {

    @InjectMocks
    private PaymentInformationSupplier paymentInformationSupplier;

    @Test
    public void supply() {

        assertNotNull(paymentInformationSupplier.supply(getCheckRecord(), "", "P",
                getLookupData(), getLookupData()));
    }

    private CheckRecord getCheckRecord() {

        return CheckRecord.builder().checkDate("12/12/2020").vendorId("CML223762376237").bankCode("").checkAmount("").taxId("").build();
    }

    private LookupData getLookupData() {

        return new LookupData();
    }
}