package com.optum.pe.parsers;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertNull;

@RunWith(MockitoJUnitRunner.class)
public class LineParserSupplierTest {

    @InjectMocks
    private LineParserSupplier lineParserSupplier;

    @Test
    public void getLineParser() {

        assertNull(lineParserSupplier.getLineParser("10"));
    }
}