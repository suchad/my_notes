package com.optum.pe.nice;

import com.optum.pe.onepay.avro.ClaimHeader;
import com.optum.pe.onepay.avro.ClaimServiceLine;
import com.optum.pe.onepay.avro.OnePayClaimCOR;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;

import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
public class OnePayClaimCORStringTest {

    @InjectMocks
    private OnePayClaimCORString onePayClaimCORString;

    @Test
    public void getString() {

        assertNotNull(onePayClaimCORString.getString(getOnePayClaimCOR()));
    }

    private OnePayClaimCOR getOnePayClaimCOR() {

        return OnePayClaimCOR.newBuilder()
                .setPaymentInformation("")
                .setClaimHeaderList(Arrays.asList(getClaimHeader()))
                .build();
    }

    private ClaimHeader getClaimHeader() {

        return ClaimHeader.newBuilder()
                .setClaimHeaderInformation("")
                .setServiceCenter("")
                .setPolicyPlan("")
                .setClaimServiceLineList(Arrays.asList(getClaimServiceLine()))
                .build();
    }

    private ClaimServiceLine getClaimServiceLine() {

        return ClaimServiceLine.newBuilder().setServiceLineInformation("").build();
    }
}