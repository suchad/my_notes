package com.optum.pe.nice.runnable;

import com.optum.pe.parsers.FileParserFactory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.nio.file.Path;
import java.nio.file.Paths;

import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class PathConsumerRunnableTest {

    @Mock
    private Path path;

    @Mock
    private FileParserFactory fileParserFactory;

    @Test
    public void run() {

        PathConsumerRunnable pathConsumerRunnable = new PathConsumerRunnable(path, fileParserFactory);

        Mockito.when(path.getFileName()).thenReturn(Paths.get(""));
        Mockito.when(fileParserFactory.getFileParser(path)).thenReturn(null);

        pathConsumerRunnable.run();

        assertTrue(true);
    }
}