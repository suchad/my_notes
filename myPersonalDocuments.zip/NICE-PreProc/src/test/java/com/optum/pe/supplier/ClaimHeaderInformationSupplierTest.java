package com.optum.pe.supplier;

import com.optum.pe.beans.parsing.*;
import com.optum.pe.service.ParameterConfigService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
public class ClaimHeaderInformationSupplierTest {

    @InjectMocks
    private ClaimHeaderInformationSupplier claimHeaderInformationSupplier;

    @Mock
    private ParameterConfigService parameterConfigService;

    @Test
    public void supply() {
        Mockito.when(parameterConfigService.isNiceDeployedCode())
                .thenReturn(true);
        assertNotNull(claimHeaderInformationSupplier.supply(1, getClaimHeaderRecord(), getCheckRecord()));
    }

    private ClaimHeaderRecord getClaimHeaderRecord() {

        return ClaimHeaderRecord.builder()
                .claimTotalRecord(ClaimTotalRecord.builder().totalCharges("").totalPay("").totalProvisionalPay("").totalAdjusted("").build())
                .claimDetailRecordList(getClaimDetailRecordList())
                .fDos("")
                .lDos("")
                .pcn("")
                .build();
    }

    private List<ClaimDetailRecord> getClaimDetailRecordList() {

        return Arrays.asList(ClaimDetailRecord.builder().adjustedAmount("").payAmount("").chargeAmount("").qpa("100.10").serviceLineList(getServiceLine()).build());
    }

    private CheckRecord getCheckRecord() {

        return CheckRecord.builder().vendorId("CLM1238778").checkAmount("").build();
    }

    private List<ServiceLine> getServiceLine() {

        return  Arrays.asList(ServiceLine.builder()
                .recordType("")
                .serviceCode("")
                .serviceDate("")
                .chargeAmount("")
                .adjustedAmount("")
                .adjustedSign('-')
                .adjustedReason("")
                .payAmount("")
                .paySign('-')
                .remarkAdjustmentReasonCode("")
                .adjustmentGroupCode("")
                .claimAdjustmentReasonCode("")
                .qpa("100.10")
                .build());
    }
}