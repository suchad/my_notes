package com.optum.pe.nice;

import com.optum.pe.utils.Constants;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import java.nio.file.Paths;

import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.class)
public class FileNameComparatorTest {

    @InjectMocks
    private FileNameComparator fileNameComparator;

    @Test
    public void compare() {
        assertEquals(0, fileNameComparator.compare(Paths.get("."), Paths.get("..")));
    }

    @Test
    public void compare1() {
        assertEquals(-1, fileNameComparator.compare(null, Paths.get("..")));
    }

    @Test
    public void compare2() {
        assertEquals(1, fileNameComparator.compare(Paths.get(".."), null));
    }

    @Test
    public void compare3() {
        assertEquals(1, fileNameComparator.compare(Paths.get("./some" + Constants.TRIGGER_FILE_EXTENSION), Paths.get("..")));
    }

    @Test
    public void compare4() {
        assertEquals(-1, fileNameComparator.compare(Paths.get("."), Paths.get("./some" + Constants.TRIGGER_FILE_EXTENSION)));
    }
}