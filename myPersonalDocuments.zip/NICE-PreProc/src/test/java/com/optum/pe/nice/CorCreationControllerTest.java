package com.optum.pe.nice;

import com.optum.pe.service.ParameterService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.io.File;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import static org.junit.Assert.assertTrue;

@Slf4j
@RunWith(MockitoJUnitRunner.Silent.class)
public class CorCreationControllerTest {

    @Mock
    private FileWritingService fileWritingService;

    @InjectMocks
    private CorCreationController corCreationController;

    @Mock
    ParameterService parameterService;

    @Mock
    PathGetterService pathGetterService;

    @Rule
    public TemporaryFolder folder = new TemporaryFolder();

    @Before
    public void setUp() {
        try {
            File file = folder.newFile("FILE_PROCESS_COMPLETE_AP2030_20200101.success");
            String value = StringUtils.substringBeforeLast(file.getPath(), "/");
            List<Path> list = new ArrayList<>();
            list.add(file.toPath());
            Stream<Path> filePaths = list.stream();
            Mockito.when(pathGetterService.getSuccessFilePath()).thenReturn(filePaths);
        } catch (Exception e) {
            log.info("Exception thrown: " + e);
        }
    }

    @Test
    public void startFileCreation() {

        Mockito.doNothing().when(fileWritingService).write();

        assertTrue(corCreationController.startFileCreation());
    }

    @Test
    public void startFileCreationException() {
        try {
            Mockito.doThrow(new RuntimeException()).when(parameterService).updateServiceEndpointFlag(Mockito.anyString());
            corCreationController.startFileCreation();
        } catch (Exception e) {
            log.info("Exception thrown: " + e);
        }

        assertTrue(true);
    }

    @Test
    public void isTriggerFileTest() {
        try {
            File file = folder.newFile("FILE_PROCESS_COMPLETE_AP2030_20200102.success");
            corCreationController.isTriggerFile(file.toPath());
        } catch (Exception e) {
            log.info("Exception thrown: " + e);
        }

        assertTrue(true);
    }

    @Test
    public void deleteFileTest() {
        try {
            File file = folder.newFile("FILE_PROCESS_COMPLETE_AP2030_20200103.success");
            corCreationController.deleteFile(file.toPath());
        } catch (Exception e) {
            log.info("Exception thrown: " + e);
        }

        assertTrue(true);
    }
}