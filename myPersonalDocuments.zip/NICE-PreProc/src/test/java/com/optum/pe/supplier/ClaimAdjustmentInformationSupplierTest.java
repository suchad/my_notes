package com.optum.pe.supplier;

import com.optum.pe.beans.parsing.Adjustment;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
public class ClaimAdjustmentInformationSupplierTest {

    @InjectMocks
    private ClaimAdjustmentInformationSupplier claimAdjustmentInformationSupplier;

    @Test
    public void supply() {

        assertNotNull(claimAdjustmentInformationSupplier
                .supply("", "", 1, getAdjustment()));
    }

    private Adjustment getAdjustment() {

        return Adjustment.builder().build();
    }
}