package com.optum.pe.supplier;

import com.optum.pe.beans.parsing.ClaimDetailRecord;
import com.optum.pe.beans.parsing.ClaimHeaderRecord;
import com.optum.pe.utils.Constants;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;

import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
public class ClaimMessageInformationSupplierTest {

    @InjectMocks
    private ClaimMessageInformationSupplier claimMessageInformationSupplier;

    @Test
    public void supply() {

        assertNotNull(claimMessageInformationSupplier.supply("", "",
                "CLM172637", 1, 1,
                "", 1, "MSG",
                "1", "1", getClaimHeaderRecord()));
    }

    @Test
    public void supplyNonMsg() {

        assertNotNull(claimMessageInformationSupplier.supply("", "",
                "CLM172637", 1, 1,
                "", 1, "OVR",
                "1", "1", getClaimHeaderRecord()));
    }

    private ClaimHeaderRecord getClaimHeaderRecord() {

        return ClaimHeaderRecord.builder()
                .claimDetailRecordList(Arrays.asList(ClaimDetailRecord.builder().serviceCode(Constants.RECOVERY_SERVICE_CODE).build()))
                .build();
    }
}