package com.optum.pe.supplier;

import com.optum.pe.beans.mapping.ClaimHeaderInformation;
import com.optum.pe.beans.mapping.ClaimSupplementalInformation;
import com.optum.pe.beans.mapping.PatientInformation;
import com.optum.pe.beans.mapping.PolicyPlanInformation;
import com.optum.pe.beans.mapping.ProviderInformation;
import com.optum.pe.beans.mapping.ServiceCenterInformation;
import com.optum.pe.beans.mapping.SubscriberInformation;
import com.optum.pe.beans.parsing.CheckRecord;
import com.optum.pe.beans.parsing.ClaimDetailRecord;
import com.optum.pe.beans.parsing.ClaimHeaderRecord;
import com.optum.pe.beans.parsing.ClaimTotalRecord;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;

@RunWith(MockitoJUnitRunner.class)
public class ClaimHeaderSupplierTest {

    @InjectMocks
    private ClaimHeaderSupplier claimHeaderSupplier;

    @Mock
    private ClaimHeaderInformationSupplier claimHeaderInformationSupplier;

    @Mock
    private ClaimPolicyPlanInformationSupplier claimPolicyPlanInformationSupplier;

    @Mock
    private ClaimServiceCenterInformationSupplier claimServiceCenterInformationSupplier;
    private ClaimInterestInformationSupplier claimInterestInformationSupplier;

    @Mock
    private PatientInformationSupplier patientInformationSupplier;

    @Mock
    private ProviderInformationSupplier providerInformationSupplier;

    @Mock
    private SubscriberInformationSupplier subscriberInformationSupplier;

    @Mock
    private ClaimSupplementalInformationSupplier claimSupplementalInformationSupplier;

    @Test
    public void supply() {

        Mockito.when(claimHeaderInformationSupplier.supply(anyInt(), any(), any()))
                .thenReturn(ClaimHeaderInformation.builder().build());

        Mockito.when(claimPolicyPlanInformationSupplier.supply(anyString(), anyString(), anyInt(),
                any(), any()))
                .thenReturn(PolicyPlanInformation.builder().build());

        Mockito.when(claimServiceCenterInformationSupplier.supply(anyString(), anyInt(), any(), any(), any()))
                .thenReturn(ServiceCenterInformation.builder().build());

        Mockito.when(patientInformationSupplier.supply(anyString(), anyInt(), any()))
                .thenReturn(PatientInformation.builder().build());

        Mockito.when(providerInformationSupplier.supply(anyInt(), anyInt(), any(), any(), anyString()))
                .thenReturn(ProviderInformation.builder().build());

        Mockito.when(subscriberInformationSupplier.supply(anyString(), anyInt(), anyString(), any()))
                .thenReturn(SubscriberInformation.builder().build());

        Mockito.when(claimSupplementalInformationSupplier.supply(anyString(), anyString(), anyInt(), anyInt(),
                any(), any(), anyString())).thenReturn(ClaimSupplementalInformation.builder().build());

       assertNotNull(claimHeaderSupplier.supply(1, getClaimHeaderRecord(),
                getCheckRecord(), null, null,
                null, null,
                null, null));
    }

    private ClaimHeaderRecord getClaimHeaderRecord() {

        return ClaimHeaderRecord.builder().claimNumber("1234")
                .claimDetailRecordList(getClaimDetailRecordList()).claimTotalRecord(getClaimTotalRecord()).medGroup("1").build();
    }

    private List<ClaimDetailRecord> getClaimDetailRecordList() {

        return Arrays.asList(ClaimDetailRecord.builder().serviceCode("").build());
    }

    private CheckRecord getCheckRecord() {

        return CheckRecord.builder().checkNumber("1234").vendorId("CLM3").bankCode("").build();
    }

    private ClaimTotalRecord getClaimTotalRecord(){
        return ClaimTotalRecord.builder().totalPriorPay("1").totalPriorSign('Y').build();
    }
}