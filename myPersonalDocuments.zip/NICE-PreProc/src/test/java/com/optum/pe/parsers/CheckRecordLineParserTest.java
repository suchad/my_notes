package com.optum.pe.parsers;

import com.optum.pe.beans.parsing.AP2030File;
import com.optum.pe.beans.parsing.CheckRecord;
import com.optum.pe.beans.parsing.ClaimDetailRecord;
import com.optum.pe.beans.parsing.ClaimHeaderRecord;
import com.optum.pe.beans.parsing.ServiceLine;
import com.optum.pe.nice.CORProducerService;
import com.optum.pe.nice.ProcessState;
import com.optum.pe.nice.ProcessStateFactory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.StringJoiner;
import java.util.stream.IntStream;

import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class CheckRecordLineParserTest {

    @InjectMocks
    private CheckRecordLineParser checkRecordLineParser;

    @Mock
    private ProcessStateFactory processStateFactory;

    @Mock
    private CORProducerService corProducerService;

    @Test
    public void parse() {

        AP2030File ap2030File = new AP2030File();

        ProcessState processState = new ProcessState();
        processState.setAp2030File(new AP2030File());
        processState.setCheckRecord(CheckRecord.builder().build());

        Mockito.when(processStateFactory.getProcessStateFor("")).thenReturn(processState);

        Mockito.doNothing().when(corProducerService).sendCurrentCheckRecordToDB("", Boolean.FALSE);

        assertTrue(checkRecordLineParser.parse("", getLine()));
    }

    @Test
    public void parseServiceLine() {

        AP2030File ap2030File = new AP2030File();

        ProcessState processState = new ProcessState();
        processState.setAp2030File(new AP2030File());
        processState.setCheckRecord(CheckRecord.builder().build());
        processState.setServiceLine(ServiceLine.builder().build());

        Mockito.when(processStateFactory.getProcessStateFor("")).thenReturn(processState);

        Mockito.doNothing().when(corProducerService).sendCurrentCheckRecordToDB("", Boolean.FALSE);

        assertTrue(checkRecordLineParser.parse("", getLine()));
    }

    @Test
    public void parseClaimDetail() {

        AP2030File ap2030File = new AP2030File();

        ProcessState processState = new ProcessState();
        processState.setAp2030File(new AP2030File());
        processState.setCheckRecord(CheckRecord.builder().build());
        processState.setClaimDetailRecord(ClaimDetailRecord.builder().build());
        processState.setClaimHeaderRecord(ClaimHeaderRecord.builder().build());

        Mockito.when(processStateFactory.getProcessStateFor("")).thenReturn(processState);

        Mockito.doNothing().when(corProducerService).sendCurrentCheckRecordToDB("", Boolean.FALSE);

        assertTrue(checkRecordLineParser.parse("", getLine()));
    }

    @Test
    public void parseClaimHeader() {

        AP2030File ap2030File = new AP2030File();

        ProcessState processState = new ProcessState();
        processState.setAp2030File(new AP2030File());
        processState.setCheckRecord(CheckRecord.builder().build());
        processState.setClaimDetailRecord(ClaimDetailRecord.builder().build());
        processState.setClaimHeaderRecord(ClaimHeaderRecord.builder().build());

        Mockito.when(processStateFactory.getProcessStateFor("")).thenReturn(processState);

        Mockito.doNothing().when(corProducerService).sendCurrentCheckRecordToDB("", Boolean.FALSE);

        assertTrue(checkRecordLineParser.parse("", getLine()));
    }

    @Test
    public void updateState() {

        assertTrue(true);
    }

    private String getLine() {
        StringJoiner joiner = new StringJoiner("");

        IntStream.range(0, 250).forEach(count -> joiner.add(count + ""));

        return joiner.toString();
    }
}