package com.optum.pe.service;

import com.optum.pe.configuration.DefaultConfiguration;
import com.optum.pe.models.ServiceEndpoints;
import com.optum.pe.models.ServiceParameters;
import com.optum.pe.repositories.ServiceEndpointsRepository;
import com.optum.pe.repositories.ServiceParametersRepository;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertTrue;

@Slf4j
@RunWith(MockitoJUnitRunner.Silent.class)
public class ParameterServiceTest {
    @InjectMocks
    ParameterService parameterService;
    @Mock
    ServiceEndpointsRepository serviceEndpointsRepository;

    @Mock
    DefaultConfiguration defaultConfiguration;

    @Mock
    ServiceParametersRepository serviceParamRepository;

    @Before
    public void setupTest() {
        List<ServiceEndpoints> serviceEndpointsList = new java.util.ArrayList<>();
        ServiceEndpoints serviceEndpoints = new ServiceEndpoints();
        serviceEndpoints.setStatusFlag("N");
        serviceEndpointsList.add(serviceEndpoints);
        Mockito.when(parameterService.getServiceEndpointsList("pe-nice-preproc", "NICE-COR-FILE-CREATION")).thenReturn(serviceEndpointsList);
        Mockito.when(serviceEndpointsRepository.findByPartnerProcGrpIdAndServiceNameAndEndpointName("NICE", "pe-nice-preproc", "NICE-COR-FILE-CREATION")).thenReturn(serviceEndpointsList);
        Mockito.when(defaultConfiguration.getPartnerProcGroupId()).thenReturn("NICE");
    }

    @Test
    public void getServiceEndpointListTest() {
        parameterService.getServiceEndpointsList("1", "NICEService");

        assertTrue(true);
    }

    @Test
    public void updateServiceEndpointFlagTest() {
        try {
            parameterService.updateServiceEndpointFlag("Y");
        } catch (Exception e) {
            log.info("Exception thrown: " + e);
        }

        assertTrue(true);
    }

    @Test
    public void jobTriggerServiceEndpointExceptionTest() {
        try {
            Mockito.when(parameterService.getServiceEndpointsList("pe-nice-preproc", "NICE-COR-FILE-CREATION"))
                    .thenThrow(new RuntimeException());
            parameterService.updateServiceEndpointFlag("Y");
        } catch (Exception e) {
            log.info("Exception thrown: " + e);
        }

        assertTrue(true);
    }

    @Test
    public void updateServiceParameterFlagTest() {
        try {
            List<ServiceParameters> serviceParametersList = new ArrayList<>();
            ServiceParameters serviceParameters = new ServiceParameters();
            serviceParameters.setCurrentValue("Y");
            serviceParametersList.add(serviceParameters);
            Mockito.when(serviceParamRepository.findByParamNameAndPartnerProcGrpId("PREPROC_2030_FLAG", "NICE"))
                    .thenReturn(serviceParametersList);
            parameterService.updateServiceParameterFlag("Y");
        } catch (Exception e) {
            log.info("Exception thrown: " + e);
        }

        assertTrue(true);
    }

    @Test
    public void updateServiceParameterFlagExceptionTest() {
        try {
            Mockito.when(serviceParamRepository.findByParamNameAndPartnerProcGrpId("PREPROC_2030_FLAG", "NICE"))
                    .thenThrow(new RuntimeException());
            parameterService.updateServiceParameterFlag("Y");
        } catch (Exception e) {
            log.info("Exception thrown: " + e);
        }

        assertTrue(true);
    }

    @Test
    public void getServiceParameter() {
        try {
            List<ServiceParameters> serviceParametersList = new ArrayList<>();
            ServiceParameters serviceParameters = new ServiceParameters();
            serviceParameters.setCurrentValue("Y");
            serviceParametersList.add(serviceParameters);
            Mockito.when(serviceParamRepository.findByParamNameAndPartnerProcGrpId("PREPROC_2030_FLAG", "NICE"))
                    .thenReturn(serviceParametersList);
            parameterService.getServiceParameter();
        } catch (Exception e) {
            log.info("Exception thrown: " + e);
        }

        assertTrue(true);
    }

    @Test
    public void getServiceParameterException() {
        try {
            List<ServiceParameters> serviceParametersList = new ArrayList<>();
            ServiceParameters serviceParameters = new ServiceParameters();
            serviceParameters.setCurrentValue("Y");
            serviceParametersList.add(serviceParameters);
            Mockito.when(serviceParamRepository.findByParamNameAndPartnerProcGrpId("PREPROC_2030_FLAG", "NICE"))
                    .thenThrow(new RuntimeException());
            parameterService.getServiceParameter();
        } catch (Exception e) {
            log.info("Exception thrown: " + e);
        }

        assertTrue(true);
    }
}
