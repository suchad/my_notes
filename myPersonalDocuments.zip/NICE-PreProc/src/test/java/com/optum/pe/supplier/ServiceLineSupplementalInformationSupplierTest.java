package com.optum.pe.supplier;

import com.optum.pe.beans.parsing.Adjustment;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
public class ServiceLineSupplementalInformationSupplierTest {

    @InjectMocks
    private ServiceLineSupplementalInformationSupplier serviceLineSupplementalInformationSupplier;

    @Test
    public void supply() {

        assertNotNull(serviceLineSupplementalInformationSupplier.supply("", "",
                1, 1, 1, getAdjustment()));
    }

    private Adjustment getAdjustment() {

        return Adjustment.builder().payAmount("").build();
    }
}