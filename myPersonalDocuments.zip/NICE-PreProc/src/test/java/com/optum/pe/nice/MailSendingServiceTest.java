package com.optum.pe.nice;

import com.optum.pe.beans.parsing.FileCountAndAmountInformation;
import com.optum.pe.beans.parsing.FileMetaData;
import com.optum.pe.beans.parsing.Trailer;
import com.optum.pe.service.SMTPService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.concurrent.Executors;

import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.Silent.class)
public class MailSendingServiceTest {

    @InjectMocks
    private MailSendingService mailSendingService;

    @Mock
    private ExecutorStore executorStore;

    @Mock
    private SMTPService smtpService;

    @Before
    public void setUp() {
        Mockito.when(executorStore.getMailExecutorService())
                .thenReturn(Executors.newSingleThreadExecutor());
    }

    @Test
    public void missingTrailerMail() {
        Mockito.doNothing().when(smtpService).sendMailForMissingTrailer("", "");

        mailSendingService.missingTrailerMail("", "");

        assertTrue(true);
    }

    @Test
    public void countAndAmountMisMatchMail() {

        Mockito.doNothing().when(smtpService).sendMailForCountAmountMisMatch(getFileCountAndAmountInformation(), "");

        mailSendingService.countAndAmountMisMatchMail(getFileCountAndAmountInformation(), "");

        assertTrue(true);
    }

    @Test
    public void missingDatFileMail() {

        Mockito.doNothing().when(smtpService).sendMailForMissingDatFile("", "");

        mailSendingService.missingDatFileMail("", "");

        assertTrue(true);
    }

    private FileCountAndAmountInformation getFileCountAndAmountInformation() {

        FileCountAndAmountInformation fileCountAndAmountInformation
                = new FileCountAndAmountInformation();

        fileCountAndAmountInformation.setFileMetaData(FileMetaData.builder().build());
        fileCountAndAmountInformation.setTrailerRecord(Trailer.builder().build());

        return fileCountAndAmountInformation;
    }
}