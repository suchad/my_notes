package com.optum.pe.supplier;

import com.optum.pe.beans.parsing.ClaimDetailRecord;
import com.optum.pe.beans.parsing.ClaimHeaderRecord;
import com.optum.pe.models.LookupData;
import com.optum.pe.utils.Constants;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;

import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
public class ClaimPolicyPlanInformationSupplierTest {

    @InjectMocks
    private ClaimPolicyPlanInformationSupplier claimPolicyPlanInformationSupplier;

    @Test
    public void supply() {

        assertNotNull(claimPolicyPlanInformationSupplier.supply("", "", 1,
                getClaimHeaderRecord(), getLookupData()));
    }

    private ClaimHeaderRecord getClaimHeaderRecord() {

        return ClaimHeaderRecord.builder()
                .claimDetailRecordList(Arrays.asList(ClaimDetailRecord.builder().serviceCode(Constants.RECOVERY_SERVICE_CODE).build()))
                .build();
    }

    private LookupData getLookupData() {

        return new LookupData();
    }
}