package com.optum.pe.parsers;

import com.optum.pe.beans.parsing.CheckRecord;
import com.optum.pe.nice.ProcessState;
import com.optum.pe.nice.ProcessStateFactory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class ProviderSubTotalRecordLineParserTest {

    @InjectMocks
    private ProviderSubTotalRecordLineParser providerSubTotalRecordLineParser;

    @Mock
    private ProcessStateFactory processStateFactory;

    @Test
    public void parse() {

        ProcessState processState = new ProcessState();
        processState.setCheckRecord(CheckRecord.builder().build());

        Mockito.when(processStateFactory.getProcessStateFor("")).thenReturn(processState);

        assertTrue(providerSubTotalRecordLineParser.parse("", getLine()));
    }

    private String getLine() {
        return "43DAR, SAIRA M                           72.68                                    ";
    }
}