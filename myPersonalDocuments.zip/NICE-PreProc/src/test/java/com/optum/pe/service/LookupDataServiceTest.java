package com.optum.pe.service;

import com.optum.pe.dao.LookupDataDao;
import com.optum.pe.exception.DAOException;
import com.optum.pe.utils.Constants;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.time.LocalDate;
import java.util.Collections;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;

@RunWith(MockitoJUnitRunner.class)
public class LookupDataServiceTest {

    @InjectMocks
    private LookupDataService lookupDataService;

    @Mock
    private LookupDataDao lookupDataDao;

    @Test
    public void getLookupData() throws DAOException {

        Mockito.when(lookupDataDao.getAllLookupInfo(any(), anyString()))
                .thenReturn(Collections.emptyList());

        assertEquals(Collections.emptyList(), lookupDataService.getLookupData(LocalDate.now(), Constants.LOOKUP_PARTNER_PROC_GRP_ID));
    }

    @Test
    public void getLookupDataWithException() throws DAOException {

        Mockito.doThrow(new DAOException("", new Exception()))
                .when(lookupDataDao).getAllLookupInfo(any(), anyString());

        assertEquals(Collections.emptyList(), lookupDataService.getLookupData(LocalDate.now(), Constants.LOOKUP_PARTNER_PROC_GRP_ID));
    }
}