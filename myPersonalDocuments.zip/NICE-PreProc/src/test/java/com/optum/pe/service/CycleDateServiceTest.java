package com.optum.pe.service;

import com.optum.pe.repositories.CycleDateRepository;
import com.optum.pe.utils.Constants;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import static junit.framework.TestCase.assertEquals;

@RunWith(MockitoJUnitRunner.class)
public class CycleDateServiceTest {

    @InjectMocks
    private CycleDateService cycleDateService;

    @Mock
    private CycleDateRepository cycleDateRepository;

    @Test
    public void getCycleDate() {

        Mockito.when(cycleDateRepository.getCycleDateForPartner(Constants.LOOKUP_PARTNER_PROC_GRP_ID))
                .thenReturn("");

        assertEquals("", cycleDateService.getCycleDate());
    }
}