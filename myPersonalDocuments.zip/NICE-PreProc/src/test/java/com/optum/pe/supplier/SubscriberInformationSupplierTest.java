package com.optum.pe.supplier;

import com.optum.pe.beans.parsing.ClaimHeaderRecord;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
public class SubscriberInformationSupplierTest {

    @InjectMocks
    private SubscriberInformationSupplier subscriberInformationSupplier;

    @Test
    public void supply() {

        assertNotNull(subscriberInformationSupplier.supply("", 1,
                "CLM1374673", getClaimHeaderRecord()));
    }

    private ClaimHeaderRecord getClaimHeaderRecord() {

        return ClaimHeaderRecord.builder().build();
    }
}