package com.optum.pe.supplier;

import com.optum.pe.beans.parsing.ClaimDetailRecord;
import com.optum.pe.beans.parsing.ClaimHeaderRecord;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
public class OverPaymentInformationSupplierTest {

    @InjectMocks
    private OverPaymentInformationSupplier overPaymentInformationSupplier;

    @Test
    public void supply() {

        assertNotNull(overPaymentInformationSupplier.supply("", "CLM128378",
                1, getClaimDetailRecord(), getClaimHeaderRecord(), ""));
    }

    private ClaimDetailRecord getClaimDetailRecord() {

        return ClaimDetailRecord.builder().adjustedAmount("").build();
    }

    private ClaimHeaderRecord getClaimHeaderRecord() {

        return ClaimHeaderRecord.builder()
                .fDos("")
                .lDos("")
                .build();
    }
}