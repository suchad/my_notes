package com.optum.pe.nice;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.stream.Stream;

import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class ConcreteMediatorTest {

    @InjectMocks
    private ConcreteMediator concreteMediator;

    @Mock
    private PathGetterService pathGetterService;

    @Mock
    private FileNameComparator fileNameComparator;

    @Mock
    private PathConsumerService pathConsumerService;

    @Test
    public void mediate() throws IOException {

        Mockito.when(pathGetterService.getFilePaths()).thenReturn(Stream.of(Paths.get(".")));

        assertTrue(concreteMediator.mediate());
    }
}