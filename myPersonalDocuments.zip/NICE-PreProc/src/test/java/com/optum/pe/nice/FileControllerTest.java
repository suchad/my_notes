package com.optum.pe.nice;

import com.optum.pe.utils.Constants;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;

import java.util.concurrent.Callable;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class FileControllerTest {

    @InjectMocks
    private FileController fileController;

    @Mock
    private ConcreteMediator concreteMediator;

    @Mock
    private ProcessStateFactory processStateFactory;

    @Mock
    private CacheManager cacheManager;

    @Test
    public void ingestFiles() {

        Mockito.when(concreteMediator.mediate()).thenReturn(Boolean.TRUE);

        assertTrue(fileController.ingestFiles());
    }

    @Test
    public void clearState() {

        Mockito.doNothing().when(processStateFactory).removeAllStates();

        assertTrue(fileController.clearState());
    }

    @Test
    public void clearCache() {

        Mockito.when(cacheManager.getCache(Constants.LOOKUP_CACHE_NAME)).thenReturn(new Cache() {
            @Override
            public String getName() {
                return null;
            }

            @Override
            public Object getNativeCache() {
                return null;
            }

            @Override
            public ValueWrapper get(Object key) {
                return null;
            }

            @Override
            public <T> T get(Object key, Class<T> type) {
                return null;
            }

            @Override
            public <T> T get(Object key, Callable<T> valueLoader) {
                return null;
            }

            @Override
            public void put(Object key, Object value) {

            }

            @Override
            public void evict(Object key) {

            }

            @Override
            public void clear() {

            }
        });

        assertTrue(fileController.clearCache());
    }

    @Test
    public void clearCacheElse() {

        Mockito.when(cacheManager.getCache(Constants.LOOKUP_CACHE_NAME)).thenReturn(null);

        assertFalse(fileController.clearCache());
    }
}