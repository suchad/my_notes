package com.optum.pe.parsers;

import com.optum.pe.beans.parsing.AP2030File;
import com.optum.pe.beans.parsing.CheckRecord;
import com.optum.pe.nice.ProcessState;
import com.optum.pe.nice.ProcessStateFactory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class CompanyHeaderRecordLineParserTest {

    @InjectMocks
    private CompanyHeaderRecordLineParser companyHeaderRecordLineParser;

    @Mock
    private ProcessStateFactory processStateFactory;

    @Test
    public void parse() {

        ProcessState processState = new ProcessState();
        processState.setCheckRecord(CheckRecord.builder().build());
        processState.setAp2030File(new AP2030File());

        Mockito.when(processStateFactory.getProcessStateFor("")).thenReturn(processState);

        assertTrue(companyHeaderRecordLineParser.parse("", getLine()));
    }

    private String getLine() {
        return "004599TXCLMCHK99                                                      ";
    }
}