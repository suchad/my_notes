package com.optum.pe.nice.poller;

import com.optum.pe.service.CycleDateService;
import com.optum.pe.service.FileEventStore;
import com.optum.pe.service.ParameterService;
import com.optum.pe.service.SMTPService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;

import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;

@Slf4j
@RunWith(MockitoJUnitRunner.class)
public class FileProcessedValidationPollerTest {

    @InjectMocks
    private FileProcessedValidationPoller fileProcessedValidationPoller;

    @Mock
    private SMTPService smtpService;

    @Mock
    private FileEventStore fileEventStore;

    @Mock
    private CycleDateService cycleDateService;

    @Mock
    private ParameterService parameterService;

    @Test
    public void poll() {
        try {

            Mockito.when(fileEventStore.getMissingFileNames()).thenReturn(Arrays.asList("", ""));

            Mockito.when(cycleDateService.getCycleDate()).thenReturn("");

            Mockito.doNothing().when(smtpService).sendMailForMissingFiles(any(), anyString());

            Mockito.when(parameterService.getServiceParameter()).thenReturn("Y");

            fileProcessedValidationPoller.poll();

            assertTrue(true);
        } catch (Exception e) {
            log.info("Exception thrown: " + e);
        }
    }
}