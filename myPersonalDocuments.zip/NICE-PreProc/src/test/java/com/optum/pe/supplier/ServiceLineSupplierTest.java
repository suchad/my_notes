package com.optum.pe.supplier;

import com.optum.pe.beans.mapping.ClaimServiceLineAdjustmentInformation;
import com.optum.pe.beans.mapping.ClaimServiceLineInformation;
import com.optum.pe.beans.mapping.ServiceLineSupplementalInformation;
import com.optum.pe.beans.parsing.ServiceLine;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;

@RunWith(MockitoJUnitRunner.Silent.class)
public class ServiceLineSupplierTest {

    @InjectMocks
    private ServiceLineSupplier serviceLineSupplier;

    @Mock
    private ClaimServiceLineInformationSupplier claimServiceLineInformationSupplier;

    @Mock
    private ClaimServiceLineAdjustmentInformationSupplier claimServiceLineAdjustmentInformationSupplier;

    @Mock
    private ServiceLineSupplementalInformationSupplier serviceLineSupplementalInformationSupplier;

    @Test
    public void supply() {

        Mockito.when(claimServiceLineInformationSupplier.supply(anyString(), anyString(), anyInt(), anyString(), anyInt(), any()))
                .thenReturn(ClaimServiceLineInformation.builder().build());

        Mockito.when(claimServiceLineAdjustmentInformationSupplier.supply(anyString(), anyString(), anyInt(), anyInt(), anyInt(), any()))
                .thenReturn(ClaimServiceLineAdjustmentInformation.builder().build());

        Mockito.when(serviceLineSupplementalInformationSupplier.supply(anyString(), anyString(), anyInt(), anyInt(), anyInt(), any()))
                .thenReturn(ServiceLineSupplementalInformation.builder().build());

        assertNotNull(serviceLineSupplier.supply("", "",
                1, "CLM1738272", 1, getServiceLine()));
    }

    private ServiceLine getServiceLine() {

        return ServiceLine.builder()
                .recordType("")
                .serviceCode("")
                .serviceDate("")
                .chargeAmount("")
                .adjustedAmount("")
                .adjustedSign('-')
                .adjustedReason("")
                .payAmount("")
                .paySign('-')
                .remarkAdjustmentReasonCode("")
                .adjustmentGroupCode("")
                .claimAdjustmentReasonCode("")
                .qpa("100.10")
                .build();
    }
}