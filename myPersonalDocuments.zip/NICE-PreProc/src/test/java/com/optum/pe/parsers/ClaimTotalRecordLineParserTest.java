package com.optum.pe.parsers;

import com.optum.pe.beans.parsing.CheckRecord;
import com.optum.pe.beans.parsing.ClaimHeaderRecord;
import com.optum.pe.nice.ProcessState;
import com.optum.pe.nice.ProcessStateFactory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class ClaimTotalRecordLineParserTest {

    @InjectMocks
    private ClaimTotalRecordLineParser claimTotalRecordLineParser;

    @Mock
    private ProcessStateFactory processStateFactory;

    @Test
    public void parse() {

        ProcessState processState = new ProcessState();
        processState.setCheckRecord(CheckRecord.builder().build());
        processState.setClaimHeaderRecord(ClaimHeaderRecord.builder().build());

        Mockito.when(processStateFactory.getProcessStateFor("")).thenReturn(processState);

        assertTrue(claimTotalRecordLineParser.parse("", getLine()));
    }

    private String getLine() {
        return "40      750.00      425.19       324.81         0.00       324.81                                                                                                                                                                                         ";
    }
}