package com.optum.pe.service;

import com.optum.pe.beans.parsing.FileCountAndAmountInformation;
import com.optum.pe.beans.parsing.FileMetaData;
import com.optum.pe.beans.parsing.Trailer;
import com.optum.pe.configuration.DefaultConfiguration;
import com.optum.pe.configuration.SMTPConfiguration;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.mail.javamail.JavaMailSender;

import javax.mail.internet.MimeMessage;
import java.util.Collections;

import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class SMTPServiceTest {

    @InjectMocks
    private SMTPService smtpService;

    @Mock
    private JavaMailSender javaMailSender;

    @Mock
    private MimeMessage mimeMessage;

    @Mock
    private SMTPConfiguration smtpConfiguration;

    @Mock
    private DefaultConfiguration defaultConfiguration;

    @Before
    public void setUp() {
        Mockito.when(javaMailSender.createMimeMessage()).thenReturn(mimeMessage);
        Mockito.when(smtpConfiguration.getRecipients()).thenReturn(getRecipientsArray());
        Mockito.when(defaultConfiguration.getEnvironment()).thenReturn("testEnv");

    }

    @Test
    public void sendMailForCountAmountMisMatch() {

        smtpService.sendMailForCountAmountMisMatch(getFileCountAndAmountInformation(), "");

        assertTrue(true);
    }

    private FileCountAndAmountInformation getFileCountAndAmountInformation() {

        FileCountAndAmountInformation fileCountAndAmountInformation
                = new FileCountAndAmountInformation();

        fileCountAndAmountInformation.setFileMetaData(FileMetaData.builder().build());
        fileCountAndAmountInformation.setTrailerRecord(Trailer.builder().build());

        return fileCountAndAmountInformation;
    }

    @Test
    public void sendMailForMissingTrailer() {

        smtpService.sendMailForMissingTrailer("", "");

        assertTrue(true);
    }

    @Test
    public void sendMailForMissingFiles() {

        smtpService.sendMailForMissingFiles(Collections.emptyList(), "");

        assertTrue(true);
    }

    @Test
    public void sendMailForMissingDatFile() {

        smtpService.sendMailForMissingDatFile("", "");

        assertTrue(true);
    }

    private String[] getRecipientsArray() {
        String[] recipients = new String[2];
        recipients[0] = "optum";
        recipients[1] = "uhg";

        return recipients;
    }
}