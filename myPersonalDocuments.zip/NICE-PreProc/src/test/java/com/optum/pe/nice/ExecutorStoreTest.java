package com.optum.pe.nice;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
public class ExecutorStoreTest {

    @InjectMocks
    private ExecutorStore executorStore;

    @Test
    public void getMailExecutorService() {
        assertNotNull(executorStore.getMailExecutorService());
    }
}