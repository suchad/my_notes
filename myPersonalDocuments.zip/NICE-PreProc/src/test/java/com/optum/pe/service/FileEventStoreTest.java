package com.optum.pe.service;

import com.optum.pe.configuration.DefaultConfiguration;
import com.optum.pe.models.FileEvent;
import com.optum.pe.nice.SuccessFileWritingService;
import com.optum.pe.repositories.FileEventStoreRepository;
import com.optum.pe.utils.Constants;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.dao.DataRetrievalFailureException;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;

@RunWith(MockitoJUnitRunner.class)
public class FileEventStoreTest {

    @InjectMocks
    private FileEventStore fileEventStore;

    @Mock
    private FileEventStoreRepository fileEventStoreRepository;

    @Mock
    private SuccessFileWritingService successFileWritingService;

    @Mock
    private DefaultConfiguration defaultConfiguration;

    @Before
    public void setUp() throws Exception {

        Mockito.when(fileEventStoreRepository.findMissingFileNames(Constants.APPLICATION_NAME,
                Constants.LOOKUP_PARTNER_PROC_GRP_ID)).thenReturn(Collections.emptyList());

        Mockito.when(fileEventStoreRepository.save(Mockito.any()))
                .thenReturn(FileEvent.builder().build());

        Mockito.when(defaultConfiguration.getPartnerProcGroupId())
                .thenReturn(Constants.LOOKUP_PARTNER_PROC_GRP_ID);
    }

    @Test
    public void getMissingFileNames() {

        assertEquals(Collections.emptyList(), fileEventStore.getMissingFileNames());
    }

    @Test
    public void getMissingFileNamesWithException() {

        Mockito.doThrow(new DataRetrievalFailureException(""))
                .when(fileEventStoreRepository).findMissingFileNames(Constants.APPLICATION_NAME,
                Constants.LOOKUP_PARTNER_PROC_GRP_ID);

        assertEquals(Collections.emptyList(), fileEventStore.getMissingFileNames());
    }

    @Test
    public void addEvent() {

        Mockito.when(successFileWritingService.write()).thenReturn(Boolean.TRUE);

        fileEventStore.addEvent(FileEvent.builder().build());

        assertTrue(true);
    }

    @Test
    public void addEventFalse() {

        Mockito.when(successFileWritingService.write()).thenReturn(Boolean.FALSE);

        fileEventStore.addEvent(FileEvent.builder().build());

        assertTrue(true);
    }

    @Test
    public void getFileEventFrom() {
        assertNotNull(fileEventStore.getFileEventFrom("filename_123.dat", LocalDate.now(), "0"));
    }

    @Test
    public void getFileEventFromWithException() {
        assertNotNull(fileEventStore.getFileEventFrom("filename_s.dat", LocalDate.now(),"0"));
    }

    @Test
    public void getFileEventFlagAndCount() {

        Map<String, Object> resultSet = new HashMap<>(3);
        resultSet.put("active_flag", 'Y');
        resultSet.put("file_count", BigDecimal.ONE);

        Mockito.when(fileEventStoreRepository.getFileEventFlagAndCountMap(anyString(), anyString(), anyString()))
                .thenReturn(resultSet);

        assertNotNull(fileEventStore.getFileEventFlagAndCount("", ""));
    }
}