package com.optum.pe.parsers;

import com.optum.pe.beans.parsing.CheckRecord;
import com.optum.pe.nice.ProcessState;
import com.optum.pe.nice.ProcessStateFactory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class ClaimDetailRecordLineParserTest {

    @InjectMocks
    private ClaimDetailRecordLineParser claimDetailRecordLineParser;

    @Mock
    private ProcessStateFactory processStateFactory;

    @Test
    public void parse() {

        ProcessState processState = new ProcessState();
        processState.setCheckRecord(CheckRecord.builder().build());

        Mockito.when(processStateFactory.getProcessStateFor("")).thenReturn(processState);

        assertTrue(claimDetailRecordLineParser.parse("", getLineBlankLine()));
    }

    @Test
    public void parseClaimServiceCode() {

        ProcessState processState = new ProcessState();
        processState.setCheckRecord(CheckRecord.builder().build());

        Mockito.when(processStateFactory.getProcessStateFor("")).thenReturn(processState);

        assertTrue(claimDetailRecordLineParser.parse("", getLineClaim()));
    }

    private String getLineBlankLine() {
        return "30                                 25.00 Outpt Service Copay/Coinsu                                       25.00-                                                                                                                                          ";
    }

    private String getLineClaim() {
        return "30CLAIM-  12/20/2019      0.00      0.00                                                                   0.00                                                                                                                                           ";
    }
}