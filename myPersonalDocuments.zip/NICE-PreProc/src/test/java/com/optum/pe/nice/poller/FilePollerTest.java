package com.optum.pe.nice.poller;

import com.optum.pe.nice.ConcreteMediator;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class FilePollerTest {

    @InjectMocks
    private FilePoller filePoller;

    @Mock
    private ConcreteMediator concreteMediator;

    @Test
    public void poll() {

        Mockito.when(concreteMediator.mediate()).thenReturn(Boolean.TRUE);

        filePoller.poll();

        assertTrue(true);
    }
}