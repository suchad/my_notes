package com.optum.pe.nice;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class ProcessStateFactoryTest {

    @InjectMocks
    private ProcessStateFactory processStateFactory;

    @Test
    public void createProcessStateFor() {

        assertNotNull(processStateFactory.createProcessStateFor(""));
    }

    @Test
    public void getProcessStateFor() {

        processStateFactory.createProcessStateFor("");
        assertNotNull(processStateFactory.getProcessStateFor(""));
    }

    @Test
    public void removeProcessStateFor() {

        processStateFactory.removeProcessStateFor("");

        assertTrue(true);
    }

    @Test
    public void removeAllStates() {

        processStateFactory.removeAllStates();

        assertTrue(true);
    }
}