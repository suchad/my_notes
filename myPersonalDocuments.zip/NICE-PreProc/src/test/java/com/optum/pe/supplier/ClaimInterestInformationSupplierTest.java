package com.optum.pe.supplier;

import com.optum.pe.beans.parsing.ClaimDetailRecord;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
public class ClaimInterestInformationSupplierTest {

    @InjectMocks
    private ClaimInterestInformationSupplier claimInterestInformationSupplier;

    @Test
    public void supply() {

        assertNotNull(claimInterestInformationSupplier.supply("",
                "", 1, "CLM1263726",
                "", 1, getClaimDetailRecord()));
    }

    private ClaimDetailRecord getClaimDetailRecord() {

        return ClaimDetailRecord.builder().payAmount("").paySign('-').build();
    }
}