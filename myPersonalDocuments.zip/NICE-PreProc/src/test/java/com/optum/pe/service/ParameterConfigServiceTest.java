package com.optum.pe.service;

import com.optum.pe.models.ParameterConfigEntity;
import com.optum.pe.repositories.ParameterConfigRepository;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import static org.mockito.ArgumentMatchers.any;

@RunWith(MockitoJUnitRunner.class)
public class ParameterConfigServiceTest {

    private static final String partnerProdGrpId = "NICECLM";
    private static final String parameterNameNice = "IsNiceCodeDeployed";
    private static final String parameterNameCdc = "IsCdcCodeDeployed";

    @InjectMocks
    private ParameterConfigService parameterConfigService;

    @Mock
    private ParameterConfigRepository parameterConfigRepository;

    @Test
    public void isNiceDeployedCode() {

        Mockito.when(parameterConfigRepository.findByPartnerProcGrpIdAndParameterNm(any(String.class), any(String.class)))
                .thenReturn(getParameterConfigEntityY());

        Assert.assertEquals(Boolean.TRUE, parameterConfigService.isNiceDeployedCode());

    }

    @Test
    public void isCdcDeployedCode() {

        Mockito.when(parameterConfigRepository.findByPartnerProcGrpIdAndParameterNm(any(String.class), any(String.class)))
                .thenReturn(getParameterConfigEntityN());

        Assert.assertEquals(Boolean.FALSE, parameterConfigService.isCdcCodeDeployed());
    }

    public ParameterConfigEntity getParameterConfigEntityY() {
        ParameterConfigEntity pce = new ParameterConfigEntity();
        pce.setParameterNm(partnerProdGrpId);
        pce.setParameterVal(parameterNameNice);
        pce.setParameterVal("Y");
        return pce;
    }

    public ParameterConfigEntity getParameterConfigEntityN() {
        ParameterConfigEntity pce = new ParameterConfigEntity();
        pce.setParameterNm(partnerProdGrpId);
        pce.setParameterVal(parameterNameCdc);
        pce.setParameterVal("N");
        return pce;
    }

}