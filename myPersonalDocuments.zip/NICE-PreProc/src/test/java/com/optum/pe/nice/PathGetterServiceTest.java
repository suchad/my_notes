package com.optum.pe.nice;

import com.optum.pe.configuration.DefaultConfiguration;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.io.IOException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
public class PathGetterServiceTest {

    @InjectMocks
    private PathGetterService pathGetterService;

    @Mock
    private DefaultConfiguration defaultConfiguration;

    @Test
    public void getFilePaths() throws IOException {

        Mockito.when(defaultConfiguration.getFileLocation()).thenReturn(".");

        assertNotNull(pathGetterService.getFilePaths());
    }

    @Test
    public void getOutputPath() {

        Mockito.when(defaultConfiguration.getOutputPath()).thenReturn(".");

        assertEquals(".", pathGetterService.getOutputPath());
    }

    @Test
    public void getArchivePath() {

        Mockito.when(defaultConfiguration.getArchivePath()).thenReturn(".");

        assertEquals(".", pathGetterService.getArchivePath());
    }

    @Test
    public void getSuccessFilePath() throws IOException{
        Mockito.when(defaultConfiguration.getOutputPath()).thenReturn(".");
        assertNotNull(pathGetterService.getSuccessFilePath());
    }
}