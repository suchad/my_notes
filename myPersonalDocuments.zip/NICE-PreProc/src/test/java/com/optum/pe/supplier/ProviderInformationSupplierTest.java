package com.optum.pe.supplier;

import com.optum.pe.beans.parsing.CheckRecord;
import com.optum.pe.beans.parsing.ClaimHeaderRecord;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.HashMap;

import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
public class ProviderInformationSupplierTest {

    @InjectMocks
    private ProviderInformationSupplier providerInformationSupplier;

    @Test
    public void supply() {

        assertNotNull(providerInformationSupplier.supply(1, 1, getClaimHeaderRecord(), getCheckRecord(), ""));
    }

    private ClaimHeaderRecord getClaimHeaderRecord() {

        return ClaimHeaderRecord.builder().build();
    }

    private CheckRecord getCheckRecord() {

        return CheckRecord.builder().vendorId("627367267627367").highestId(1).serviceProviderIdMap(new HashMap<>()).build();
    }
}