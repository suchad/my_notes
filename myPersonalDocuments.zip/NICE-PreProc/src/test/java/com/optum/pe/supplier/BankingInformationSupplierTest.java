package com.optum.pe.supplier;

import com.optum.pe.beans.parsing.CheckRecord;
import com.optum.pe.models.LookupData;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
public class BankingInformationSupplierTest {

    @InjectMocks
    private BankingInformationSupplier bankingInformationSupplier;

    @Test
    public void supply() {

        assertNotNull(bankingInformationSupplier.supply(getCheckRecord(), getLookupData(), getLookupData()));
    }

    private CheckRecord getCheckRecord() {

        return CheckRecord.builder()
                .checkNumber("")
                .build();
    }

    private LookupData getLookupData() {

        return new LookupData();
    }
}