package com.optum.pe.supplier;

import com.optum.pe.beans.parsing.Adjustment;
import com.optum.pe.beans.parsing.ClaimTotalRecord;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
public class ClaimSupplementalInformationSupplierTest {

    @InjectMocks
    private ClaimSupplementalInformationSupplier claimSupplementalInformationSupplier;

    @Test
    public void supply() {

        assertNotNull(claimSupplementalInformationSupplier.supply("", "",
                1, 1, getAdjustment(), getClaimTotalRecord(), ""));
    }

    private Adjustment getAdjustment() {

        return Adjustment.builder().adjustedAmount("").payAmount("").build();
    }

    private ClaimTotalRecord getClaimTotalRecord() {

        return ClaimTotalRecord.builder().totalPriorPay("").build();
    }
}