package com.optum.pe.nice;

import com.optum.pe.beans.parsing.CheckRecord;
import com.optum.pe.exception.LookupDataNotFoundException;
import com.optum.pe.onepay.avro.ClaimHeader;
import com.optum.pe.onepay.avro.OnePayClaimCOR;
import com.optum.pe.service.CorDataStoreService;
import com.optum.pe.supplier.OnePayClaimCORSupplier;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.time.LocalDate;
import java.util.Arrays;

import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;

@RunWith(MockitoJUnitRunner.class)
public class CORProducerServiceTest {

    @InjectMocks
    private CORProducerService corProducerService;

    @Mock
    private ProcessStateFactory processStateFactory;

    @Mock
    private OnePayClaimCORSupplier onePayClaimCORSupplier;

    @Mock
    private CorDataStoreService corDataStoreService;

    @Test
    public void sendCurrentCheckRecordToKafka() throws LookupDataNotFoundException {

        ProcessState processState = new ProcessState();
        processState.setCheckRecord(CheckRecord.builder().build());
        processState.setCycleDate(LocalDate.now());

        Mockito.when(processStateFactory.getProcessStateFor(""))
                .thenReturn(processState);

        Mockito.when(onePayClaimCORSupplier.supply(processState.getCheckRecord(), "", LocalDate.now()))
                .thenReturn(getOnePayClaimCOR());

        Mockito.doNothing().when(corDataStoreService).save(any());

        corProducerService.sendCurrentCheckRecordToDB("", Boolean.FALSE);

        assertTrue(true);
    }

    private OnePayClaimCOR getOnePayClaimCOR() {

        return OnePayClaimCOR.newBuilder()
                .setPaymentInformation("")
                .setClaimHeaderList(Arrays.asList(getClaimHeader()))
                .build();
    }

    private ClaimHeader getClaimHeader() {

        return ClaimHeader.newBuilder()
                .setClaimHeaderInformation("")
                .setServiceCenter("")
                .setPolicyPlan("")
                .build();
    }
}