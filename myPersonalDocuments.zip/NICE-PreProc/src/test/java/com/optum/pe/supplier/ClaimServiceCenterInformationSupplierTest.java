package com.optum.pe.supplier;

import com.optum.pe.beans.parsing.ClaimDetailRecord;
import com.optum.pe.beans.parsing.ClaimHeaderRecord;
import com.optum.pe.models.LookupData;
import com.optum.pe.utils.Constants;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;

import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
public class ClaimServiceCenterInformationSupplierTest {

    @InjectMocks
    private ClaimServiceCenterInformationSupplier claimServiceCenterInformationSupplier;

    @Test
    public void supply() {

        assertNotNull(claimServiceCenterInformationSupplier.supply("", 1, getClaimHeaderRecord(), getLookupData(), getLookupData()));
    }

    private ClaimHeaderRecord getClaimHeaderRecord() {

        return ClaimHeaderRecord.builder()
                .claimDetailRecordList(Arrays.asList(ClaimDetailRecord.builder().serviceCode(Constants.RECOVERY_SERVICE_CODE).build()))
                .build();
    }

    private LookupData getLookupData() {

        return new LookupData();
    }
}