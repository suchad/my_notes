package com.optum.pe.supplier;

import com.optum.pe.beans.parsing.CheckRecord;
import com.optum.pe.exception.LookupDataNotFoundException;
import com.optum.pe.models.LookupData;
import com.optum.pe.service.LookupDataService;
import com.optum.pe.utils.Constants;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
public class OnePayClaimCORSupplierTest {

    @InjectMocks
    private OnePayClaimCORSupplier onePayClaimCORSupplier;

    @Mock
    private LookupDataService lookupDataService;

    @Test(expected = LookupDataNotFoundException.class)
    public void supply() throws LookupDataNotFoundException {

        Mockito.when(lookupDataService.getLookupData(LocalDate.now(), Constants.LOOKUP_PARTNER_PROC_GRP_ID))
                .thenReturn(getLookupData());

        assertNotNull(onePayClaimCORSupplier.supply(getCheckRecord(), "", LocalDate.now()));
    }

    private CheckRecord getCheckRecord() {

        return CheckRecord.builder()
                .bankCode("bankCode")
                .build();
    }

    private List<LookupData> getLookupData() {

        List<LookupData> lookupDataList = new ArrayList<>();

        LookupData lookupData = new LookupData();
        lookupData.setLookupSetCode("bankCode");

        lookupDataList.add(lookupData);

        return lookupDataList;
    }
}
