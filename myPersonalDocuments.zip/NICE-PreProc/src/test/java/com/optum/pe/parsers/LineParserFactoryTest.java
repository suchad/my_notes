package com.optum.pe.parsers;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Optional;

import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
public class LineParserFactoryTest {

    @InjectMocks
    private LineParserFactory lineParserFactory;

    @Mock
    private LineParserSupplier lineParserSupplier;

    @Mock
    private CheckRecordLineParser checkRecordLineParser;

    @Test
    public void getLineParser() {

        Mockito.when(lineParserSupplier.getLineParser("10"))
                .thenReturn(checkRecordLineParser);

        Optional<LineParser> lineParserOptional = lineParserFactory.getLineParser("10");

        assertNotNull(lineParserOptional.get());
    }
}