package com.optum.pe.supplier;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
public class PaymentSupplementalInformationSupplierTest {

    @InjectMocks
    private PaymentSupplementalInformationSupplier paymentSupplementalInformationSupplier;

    @Test
    public void supply() {

        assertNotNull(paymentSupplementalInformationSupplier.supply("", "", "", ""));
    }
}