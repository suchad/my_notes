package com.optum.pe.supplier;

import com.optum.pe.beans.parsing.ServiceLine;
import com.optum.pe.service.ParameterConfigService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
public class ClaimServiceLineInformationSupplierTest {

    @InjectMocks
    private ClaimServiceLineInformationSupplier claimServiceLineInformationSupplier;

    @Mock
    private ParameterConfigService parameterConfigService;

    @Test
    public void supply() {
        Mockito.when(parameterConfigService.isNiceDeployedCode())
                .thenReturn(true);
        assertNotNull(claimServiceLineInformationSupplier.supply("", "",
                1, "CLM13728", 1, getServiceLine()));
    }

    private ServiceLine getServiceLine() {

        return ServiceLine.builder().serviceCode("62736237").serviceDate("12/12/2020").payAmount("123").chargeAmount("").adjustedAmount("").qpa("100.10").build();
    }
}