package com.optum.pe.service;

import com.optum.pe.configuration.DefaultConfiguration;
import com.optum.pe.exception.ServiceException;
import com.optum.pe.models.ServiceEndpoints;
import com.optum.pe.models.ServiceParameters;
import com.optum.pe.repositories.ServiceEndpointsRepository;
import com.optum.pe.repositories.ServiceParametersRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

import static com.optum.pe.utils.Constants.APP_NAME;
import static com.optum.pe.utils.Constants.ENDPOINT_NAME;
import static com.optum.pe.utils.Constants.FLAG_N;
import static com.optum.pe.utils.Constants.FLAG_X;
import static com.optum.pe.utils.Constants.FLAG_Y;
import static com.optum.pe.utils.Constants.SERVICE_NAME;
import static com.optum.pe.utils.Constants.SERVICE_PARAMETER_VALUE;

@Slf4j
@Service
public class ParameterService {

    private final ServiceEndpointsRepository serviceEndpointsRepository;
    private ServiceParametersRepository serviceParamRepository;
    private final DefaultConfiguration defaultConfiguration;

    public ParameterService(DefaultConfiguration defaultConfiguration, ServiceEndpointsRepository serviceEndpointsRepository, ServiceParametersRepository serviceParamRepository) {
        this.defaultConfiguration = defaultConfiguration;
        this.serviceEndpointsRepository = serviceEndpointsRepository;
        this.serviceParamRepository = serviceParamRepository;
    }

    public List<ServiceEndpoints> getServiceEndpointsList(String serviceName, String endpointName) {
        return serviceEndpointsRepository.findByPartnerProcGrpIdAndServiceNameAndEndpointName(defaultConfiguration.getPartnerProcGroupId(), serviceName, endpointName);
    }

    private void updateServiceEndpoints(ServiceEndpoints serviceEndpoints){
        serviceEndpointsRepository.save(serviceEndpoints);
    }

    private void updateServiceParameters(ServiceParameters serviceParameters){
        serviceParamRepository.save(serviceParameters);
    }

    public void updateServiceEndpointFlag(String flag) throws ServiceException {
        try {
            List<ServiceEndpoints> serviceEndpointsList = getServiceEndpointsList(SERVICE_NAME, ENDPOINT_NAME);

            if(!serviceEndpointsList.isEmpty()) {
                ServiceEndpoints serviceEndpoints = serviceEndpointsList.get(0);
                if(!(FLAG_Y.equals(flag)
                        && FLAG_X.equals(serviceEndpoints.getStatusFlag()))) {
                    serviceEndpoints.setStatusFlag(flag);
                    serviceEndpoints.setLastUpdatedBy(APP_NAME);
                    serviceEndpoints.setLastUpdateDt(LocalDateTime.now());
                    updateServiceEndpoints(serviceEndpoints);
                }
            }
        } catch (Exception e) {
            throw new ServiceException(e);
        }
    }

    public String getServiceParameter() throws ServiceException {
        String preProcFlag = FLAG_N;
        try {
            List<ServiceParameters> serviceParametersList = serviceParamRepository.findByParamNameAndPartnerProcGrpId(
                    SERVICE_PARAMETER_VALUE, defaultConfiguration.getPartnerProcGroupId());
            if (!serviceParametersList.isEmpty()) {
                preProcFlag = serviceParametersList.get(0).getCurrentValue();
            }
        } catch (Exception e) {
            throw new ServiceException(e);
        }
        return preProcFlag;
    }

    public void updateServiceParameterFlag(String flag) throws ServiceException {
        try{
            List<ServiceParameters> serviceParametersList = serviceParamRepository.findByParamNameAndPartnerProcGrpId(
                    SERVICE_PARAMETER_VALUE, defaultConfiguration.getPartnerProcGroupId());
            if (!serviceParametersList.isEmpty()) {
                ServiceParameters serviceParameters = serviceParametersList.get(0);
                serviceParameters.setCurrentValue(flag);
                serviceParameters.setUpdatedBy(APP_NAME);
                serviceParameters.setUpdatedDate(LocalDateTime.now());
                updateServiceParameters(serviceParameters);
            }
        } catch (Exception e) {
            throw new ServiceException(e);
        }
    }
}
