package com.optum.pe.beans.parsing;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class CompanyHeaderRecord implements Record {

    private String recordType;
    private String coDiv;
    private String bankCode;
}
