package com.optum.pe.beans.parsing;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class ProviderSubTotalRecord implements Record {

    private String recordType;
    private String providerName;

    private String subTotal;
    private char subTotalSign;
}
