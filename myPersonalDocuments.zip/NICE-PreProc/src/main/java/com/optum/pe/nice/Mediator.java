package com.optum.pe.nice;

public interface Mediator {

    boolean mediate();
}
