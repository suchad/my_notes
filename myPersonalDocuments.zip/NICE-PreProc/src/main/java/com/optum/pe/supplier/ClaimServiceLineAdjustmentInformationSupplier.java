package com.optum.pe.supplier;

import com.optum.pe.beans.mapping.ClaimServiceLineAdjustmentInformation;
import com.optum.pe.beans.parsing.Adjustment;
import com.optum.pe.utils.Constants;
import com.optum.pe.utils.RecordType;
import org.springframework.stereotype.Service;

@Service
class ClaimServiceLineAdjustmentInformationSupplier {

    ClaimServiceLineAdjustmentInformation supply(String checkNumber, String claimNumber,
                                                 int transactionSequenceNumber, int recordSequenceNumber,
                                                 int adjudicationSystemNumber,
                                                 Adjustment adjustment) {

        ClaimServiceLineAdjustmentInformation.ClaimServiceLineAdjustmentInformationBuilder
                claimServiceLineAdjustmentInformation
                = ClaimServiceLineAdjustmentInformation.builder();

        claimServiceLineAdjustmentInformation.recordType(RecordType.SERVICE_LINE_ADJUSTMENT.getLabel());
        claimServiceLineAdjustmentInformation.partnerId(Constants.NICE_PARTNER_ID);
        claimServiceLineAdjustmentInformation.consolidationId(checkNumber);
        claimServiceLineAdjustmentInformation.adjudicationSystemId(Constants.ADJUDICATION_SYSTEM_ID);
        claimServiceLineAdjustmentInformation.adjudicationSystemUniqueClaimNumber(claimNumber);
        claimServiceLineAdjustmentInformation.adjudicationSystemUniqueClaimNumberTransactionSequenceNumber(transactionSequenceNumber + "");
        claimServiceLineAdjustmentInformation.recordSequenceNumber(recordSequenceNumber + "");

        claimServiceLineAdjustmentInformation.serviceLineAdjudicationSystemNumber(
                adjudicationSystemNumber + "");

        claimServiceLineAdjustmentInformation.adjustedAmount(
                HelperSupplier.getAmount(adjustment.getAdjustedSign(), HelperSupplier.removeComma(adjustment.getAdjustedAmount())));
        claimServiceLineAdjustmentInformation.groupCode(adjustment.getAdjustmentGroupCode());
        claimServiceLineAdjustmentInformation.adjustmentReasonCode(adjustment.getClaimAdjustmentReasonCode());
        claimServiceLineAdjustmentInformation.adjustedUnitsOfService("");
        claimServiceLineAdjustmentInformation.serviceLineRemarkCode("");
        claimServiceLineAdjustmentInformation.remarkTextVersionKeyCode("");
        claimServiceLineAdjustmentInformation.remarkAdditionalTextVersionKeyCode("");
        claimServiceLineAdjustmentInformation.remarkQualifierCode("");
        claimServiceLineAdjustmentInformation.remarkCodeReferenceKey("");

        return claimServiceLineAdjustmentInformation.build();
    }
}
