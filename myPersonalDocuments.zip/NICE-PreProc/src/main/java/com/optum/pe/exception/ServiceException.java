package com.optum.pe.exception;

public class ServiceException extends Exception{
    public ServiceException(Exception ex){super(ex);}
}
