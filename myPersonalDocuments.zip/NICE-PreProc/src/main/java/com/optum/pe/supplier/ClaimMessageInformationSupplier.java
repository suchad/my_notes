package com.optum.pe.supplier;

import com.optum.pe.beans.mapping.ClaimMessageInformation;
import com.optum.pe.beans.parsing.ClaimDetailRecord;
import com.optum.pe.beans.parsing.ClaimHeaderRecord;
import com.optum.pe.utils.Constants;
import com.optum.pe.utils.RecordType;
import org.springframework.stereotype.Service;

@Service
class ClaimMessageInformationSupplier {

    ClaimMessageInformation supply(String checkNumber, String claimNumber, String vendorId,
                                   int transactionSequenceNumber, int recordSequenceNumber,
                                   String messageText, int serviceLineNumber, String messageCode,
                                   String messageSequenceNumber, String messagePlacementCode,
                                   ClaimHeaderRecord claimHeaderRecord) {

        ClaimMessageInformation.ClaimMessageInformationBuilder claimMessageInformation
                = ClaimMessageInformation.builder();

        claimMessageInformation.recordType(RecordType.CLAIM_MESSAGE.getLabel());
        claimMessageInformation.partnerId(Constants.NICE_PARTNER_ID);
        claimMessageInformation.consolidationId(checkNumber);
        claimMessageInformation.adjudicationSystemId(Constants.ADJUDICATION_SYSTEM_ID);
        claimMessageInformation.adjudicationSystemUniqueClaimNumber(claimNumber);
        claimMessageInformation.adjudicationSystemUniqueClaimNumberTransactionSequenceNumber(transactionSequenceNumber + "");
        claimMessageInformation.recordSequenceNumber(recordSequenceNumber + "");
        claimMessageInformation.documentTypeCode(getDocumentTypeCode(vendorId));
        claimMessageInformation.messageCode(messageCode);
        claimMessageInformation.messageText(getMessageText(messagePlacementCode, messageText, claimHeaderRecord));
        claimMessageInformation.messagePlacementCode(messagePlacementCode);
        claimMessageInformation.messageSequenceNumber(messageSequenceNumber);
        claimMessageInformation.messageServiceLineNumber(getServiceLineNumber(serviceLineNumber));

        return claimMessageInformation.build();
    }

    private String getServiceLineNumber(int serviceLineNumber) {

        if (serviceLineNumber == 0) {
            return "";
        }

        return serviceLineNumber + "";
    }

    private String getMessageText(String messagePlacementCode, String messageText,
                                  ClaimHeaderRecord claimHeaderRecord) {

        if (Constants.CLAIM_MESSAGE_PLACEMENT_CODE.equals(messagePlacementCode) ||
                Constants.SERVICE_MESSAGE_PLACEMENT_CODE.equals(messagePlacementCode)) {

            return messageText;
        } else if (Constants.OVER_MESSAGE_PLACEMENT_CODE.equals(messagePlacementCode)) {

            ClaimDetailRecord claimDetailRecord =
                    claimHeaderRecord.getClaimDetailRecordList().get(0);

            return claimDetailRecord.getRemarkAdjustmentReasonCode() +
                    claimDetailRecord.getAdjustedReason();
        }

        return "";
    }

    private String getDocumentTypeCode(String vendorId) {

        if (Constants.SUBSCRIBER_CODE.equals(HelperSupplier.getPayeeType(vendorId))) {
            return "E";
        }

        return Constants.PROVIDER_CODE;
    }
}
