package com.optum.pe.beans.parsing;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
public class ClaimTotalRecord implements Record {

    private String recordType;

    private String totalCharges;
    private String totalAdjusted;

    private char totalAdjustedSign;

    private String totalPay;
    private char totalPaySign;

    private String totalPriorPay;
    private char totalPriorSign;

    private String totalProvisionalPay;
    private char totalProvisionalSign;

    private ProviderSubTotalRecord providerSubTotalRecord;
}
