package com.optum.pe.beans.mapping;

import lombok.Builder;
import lombok.Getter;

import java.util.StringJoiner;

@Builder
@Getter
public class ProviderInformation {

    private String recordType;
    private String partnerId;
    private String consolidationId;
    private String adjudicationSystemId;
    private String adjudicationSystemUniqueClaimNumber;
    private String adjudicationSystemUniqueClaimNumberTransactionSequenceNumber;
    private String recordSequenceNumber;
    private String qualifierCode;
    private String tinNumber;
    private String adjudicationSystemAssignedIdNumber;
    private String payorAssignedIdNumber;
    private String npiNumber;
    private String type;
    private String firstName;
    private String middleName;
    private String lastName;
    private String suffix;
    private String degree;
    private String entityName;
    private String placeOfServiceStateCode;
    private String inNetworkCode;
    private String streetAddress1;
    private String streetAddress2;
    private String streetAddress3;
    private String streetAddress4;
    private String streetAddress5;
    private String streetAddress6;
    private String streetAddress7;
    private String city;
    private String addressState;
    private String zipCode;
    private String countryCode;
    private String primaryPhoneNumber;
    private String taxonomyCode;
    private String prefix;
    private String idQualifier;
    private String id;
    private String specialPayeeIndicator;
    private String tinNumberQualifier;

    @Override
    public String toString() {
        return new StringJoiner("|", "", "|")
                .add(recordType)
                .add(partnerId)
                .add(consolidationId)
                .add(adjudicationSystemId)
                .add(adjudicationSystemUniqueClaimNumber)
                .add(adjudicationSystemUniqueClaimNumberTransactionSequenceNumber)
                .add(recordSequenceNumber)
                .add(qualifierCode)
                .add(tinNumber)
                .add(adjudicationSystemAssignedIdNumber)
                .add(payorAssignedIdNumber)
                .add(npiNumber)
                .add(type)
                .add(firstName)
                .add(middleName)
                .add(lastName)
                .add(suffix)
                .add(degree)
                .add(entityName)
                .add(placeOfServiceStateCode)
                .add(inNetworkCode)
                .add(streetAddress1)
                .add(streetAddress2)
                .add(streetAddress3)
                .add(streetAddress4)
                .add(streetAddress5)
                .add(streetAddress6)
                .add(streetAddress7)
                .add(city)
                .add(addressState)
                .add(zipCode)
                .add(countryCode)
                .add(primaryPhoneNumber)
                .add(taxonomyCode)
                .add(prefix)
                .add(idQualifier)
                .add(id)
                .add(specialPayeeIndicator)
                .add(tinNumberQualifier)
                .toString();
    }
}
