package com.optum.pe.beans.parsing;

import lombok.Builder;
import lombok.Getter;

import java.math.BigDecimal;

@Getter
@Builder
public class FileMetaData {

    private String fileName;
    private int numberOfPayments;
    private BigDecimal totalAmount;
    private int numberOfLines;
    private int invalidLines;

    public void incrementPaymentCount() {
        this.numberOfPayments++;
    }

    public void incrementTotalAmountBy(BigDecimal amount) {
        this.totalAmount = this.totalAmount.add(amount);
    }

    public void incrementNumberOfLines() {
        this.numberOfLines++;
    }

    public void reduceTotalAmountBy(BigDecimal amount) {
        this.totalAmount = this.totalAmount.subtract(amount);
    }

    public void incrementInvalidLines() {
        this.invalidLines++;
    }
}