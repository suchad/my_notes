package com.optum.pe.nice.runnable;

import com.optum.pe.parsers.FileParser;
import com.optum.pe.parsers.FileParserFactory;
import lombok.extern.slf4j.Slf4j;

import java.nio.file.Path;
import java.util.Optional;

@Slf4j
public class PathConsumerRunnable implements Runnable {

    private final Path path;
    private final FileParserFactory fileParserFactory;

    public PathConsumerRunnable(Path path, FileParserFactory fileParserFactory) {
        this.path = path;
        this.fileParserFactory = fileParserFactory;
    }

    @Override
    public void run() {
        log.info("Got File - " + path.getFileName()
                + ", Executing Thread - " + Thread.currentThread().getName());

        try {
            Optional<FileParser> fileParserOptional = fileParserFactory.getFileParser(path);

            fileParserOptional.ifPresent(fileParser -> fileParser.parse(path));
        } catch (Exception ex) {
            log.error("File - " + path.getFileName() + " ", ex);
        }
    }
}
