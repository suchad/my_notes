package com.optum.pe.models;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import java.io.Serializable;

@Data
@NoArgsConstructor
public class ServiceEndpointsPk implements Serializable {

    private static final long serialVersionUID = 1L;

    @Column(name = "PARTNER_PROC_GRP_ID")
    private String partnerProcGrpId;

    @Column(name = "SERVICE_NAME")
    private String serviceName;

    @Column(name = "ENDPOINT_NAME")
    private String endpointName;
}
