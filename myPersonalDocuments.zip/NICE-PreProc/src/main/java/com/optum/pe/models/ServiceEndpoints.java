package com.optum.pe.models;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import java.io.Serializable;
import java.time.LocalDateTime;

@Entity
@IdClass(ServiceEndpointsPk.class)
@Table(name = "SERVICE_ENDPOINTS", schema = "PE01")
@Data
public class ServiceEndpoints implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "PARTNER_PROC_GRP_ID")
    private String partnerProcGrpId;

    @Id
    @Column(name = "SERVICE_NAME")
    private String serviceName;

    @Id
    @Column(name = "ENDPOINT_NAME")
    private String endpointName;

    @Column(name = "OS_ENDPOINT")
    private String osEndpoint;

    @Column(name = "SERVICE_ENDPOINT")
    private String serviceEndpoint;

    @Column(name = "PARAMETERS")
    private String parameters;

    @Column(name = "LOG_NAME")
    private String logName;

    @Column(name = "ENV")
    private String env;

    @Column(name = "STATUS_FLAG")
    private String statusFlag;

    @Column(name = "ACTV_IND")
    private String actvInd;

    @Column(name = "FL_CHK_IND")
    private String flChkInd;

    @Column(name = "AUTH_TYPE")
    private String authType;

    @Column(name = "OAUTH_URL")
    private String oauthUrl;

    @Column(name = "CREATION_DT")
    private LocalDateTime creationDt;

    @Column(name = "LAST_UPDATE_DT")
    private LocalDateTime lastUpdateDt;

    @Column(name = "LAST_UPDATED_BY")
    private String lastUpdatedBy;

}
