package com.optum.pe.beans.mapping;

import lombok.Builder;
import lombok.Getter;

import java.util.StringJoiner;

@Builder
@Getter
public class OverPaymentInformation {

    private String recordType;
    private String partnerId;
    private String consolidationId;
    private String recordSequenceNumber;
    private String recoverySourceIndicator;
    private String originalSubscriberIdNumberQualifier;
    private String originalSubscriberIdentificationNumber;
    private String originalPatientNamePrefix;
    private String originalPatientFirstName;
    private String originalPatientMiddleName;
    private String originalPatientLastName;
    private String originalPatientNameSuffix;
    private String originalPatientDependentSequenceNumber;
    private String originalRelationshipToSubscriber;
    private String originalPatientIdentificationNumber;
    private String originalPolicyGroupNumber;
    private String originalClaimNumber;
    private String originalClaimEarliestServiceStartDate;
    private String originalClaimLatestServiceEndDate;
    private String originalClaimTotalOverPaymentAmount;
    private String originalClaimOverPaymentAmountPreviouslyDeducted;
    private String originalClaimOverPaymentAmountCurrentlyDeducted;
    private String originalClaimOverPaymentAmountRemaining;
    private String providerIdQualifier;
    private String providerId;
    private String previousCheckNumber;
    private String remarkMessageCode;
    private String remarkMessageText;
    private String dateOverPaymentEstablished;

    @Override
    public String toString() {
        return new StringJoiner("|", "", "|")
                .add(recordType)
                .add(partnerId)
                .add(consolidationId)
                .add(recordSequenceNumber)
                .add(recoverySourceIndicator)
                .add(originalSubscriberIdNumberQualifier)
                .add(originalSubscriberIdentificationNumber)
                .add(originalPatientNamePrefix)
                .add(originalPatientFirstName)
                .add(originalPatientMiddleName)
                .add(originalPatientLastName)
                .add(originalPatientNameSuffix)
                .add(originalPatientDependentSequenceNumber)
                .add(originalRelationshipToSubscriber)
                .add(originalPatientIdentificationNumber)
                .add(originalPolicyGroupNumber)
                .add(originalClaimNumber)
                .add(originalClaimEarliestServiceStartDate)
                .add(originalClaimLatestServiceEndDate)
                .add(originalClaimTotalOverPaymentAmount)
                .add(originalClaimOverPaymentAmountPreviouslyDeducted)
                .add(originalClaimOverPaymentAmountCurrentlyDeducted)
                .add(originalClaimOverPaymentAmountRemaining)
                .add(providerIdQualifier)
                .add(providerId)
                .add(previousCheckNumber)
                .add(remarkMessageCode)
                .add(remarkMessageText)
                .add(dateOverPaymentEstablished)
                .toString();
    }
}
