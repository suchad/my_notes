package com.optum.pe.nice;

import com.optum.pe.onepay.avro.OnePayClaimCOR;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.StringJoiner;

@Service
public
class OnePayClaimCORString {

    public String getString(OnePayClaimCOR onePayClaimCOR) {

        StringJoiner stringJoiner = new StringJoiner(System.lineSeparator());
        stringJoiner.add(onePayClaimCOR.getPaymentInformation());

        if (onePayClaimCOR.getClaimHeaderList() != null) {
            onePayClaimCOR.getClaimHeaderList()
                    .forEach(claimHeader -> {
                        stringJoiner.add(claimHeader.getClaimHeaderInformation());
                        stringifyList(claimHeader.getClaimAdjustmentList(), stringJoiner);
                        stringifyList(claimHeader.getClaimInterestList(), stringJoiner);
                        stringifyList(claimHeader.getClaimSurchargeList(), stringJoiner);
                        stringifyList(claimHeader.getClaimQuantityList(), stringJoiner);
                        stringifyList(claimHeader.getClaimReferenceList(), stringJoiner);
                        stringifyList(claimHeader.getClaimAmountList(), stringJoiner);
                        stringifyList(claimHeader.getClaimMessageList(), stringJoiner);
                        stringifyList(claimHeader.getOtherNameList(), stringJoiner);
                        stringifyString(claimHeader.getPrescriptionClaim(), stringJoiner);
                        stringJoiner.add(claimHeader.getPolicyPlan());
                        stringifyList(claimHeader.getSupplementalPolicyList(), stringJoiner);
                        stringJoiner.add(claimHeader.getServiceCenter());
                        stringifyList(claimHeader.getOtherAddressList(), stringJoiner);
                        stringifyString(claimHeader.getSubscriber(), stringJoiner);
                        stringifyString(claimHeader.getPatient(), stringJoiner);
                        stringifyList(claimHeader.getProviderList(), stringJoiner);
                        stringifyList(claimHeader.getFinancialAccumulatorList(), stringJoiner);
                        stringifyList(claimHeader.getSupplementalInformationList(), stringJoiner);
                        stringifyList(claimHeader.getDiagnosesCodeList(), stringJoiner);

                        if (claimHeader.getClaimServiceLineList() != null) {

                            claimHeader.getClaimServiceLineList().forEach(claimServiceLine -> {

                                stringJoiner.add(claimServiceLine.getServiceLineInformation());
                                stringifyList(claimServiceLine.getServiceLineAdjustmentList(), stringJoiner);
                                stringifyList(claimServiceLine.getServiceLineQuantityList(), stringJoiner);
                                stringifyList(claimServiceLine.getServiceLineReferenceList(), stringJoiner);
                                stringifyList(claimServiceLine.getServiceLineAmountList(), stringJoiner);
                                stringifyList(claimServiceLine.getServiceLineRemarkList(), stringJoiner);
                                stringifyList(claimServiceLine.getServiceLineSupplementalList(), stringJoiner);
                            });
                        }

                        stringifyString(claimHeader.getClaimLifeTracking(), stringJoiner);
                    });
        }

        stringifyList(onePayClaimCOR.getPaymentAdjustmentList(), stringJoiner);
        stringifyList(onePayClaimCOR.getPaymentSupplementalInformationList(), stringJoiner);
        stringifyList(onePayClaimCOR.getOverPaymentRecoveryList(), stringJoiner);
        stringifyString(onePayClaimCOR.getBankInfo(), stringJoiner);
        stringifyString(onePayClaimCOR.getPaymentLedger(), stringJoiner);

        return stringJoiner.toString();
    }

    private void stringifyList(List<String> list, StringJoiner stringJoiner) {

        if (list != null) {
            list.forEach(stringJoiner::add);
        }
    }

    private void stringifyString(String string, StringJoiner stringJoiner) {

        if (string != null) {
            stringJoiner.add(string);
        }
    }
}
