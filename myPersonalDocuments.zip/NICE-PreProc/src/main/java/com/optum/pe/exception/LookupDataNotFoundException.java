package com.optum.pe.exception;

public class LookupDataNotFoundException extends Exception {

    public LookupDataNotFoundException(String message) {
        super(message);
    }
}
