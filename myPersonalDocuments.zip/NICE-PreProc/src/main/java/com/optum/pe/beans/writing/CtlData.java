package com.optum.pe.beans.writing;

import lombok.Builder;

import java.util.StringJoiner;

@Builder
public class CtlData {

    private String fileName;
    private String creationTimeStamp;
    private String processDate;
    private String numberOfLines;
    private String transferComplete;

    @Override
    public String toString() {
        return new StringJoiner("|", "", "|")
                .add(fileName)
                .add(creationTimeStamp)
                .add(processDate)
                .add(numberOfLines)
                .add(transferComplete)
                .toString();
    }
}
