package com.optum.pe.nice;

import com.optum.pe.utils.Constants;
import org.springframework.stereotype.Service;

import java.nio.file.Path;
import java.util.Comparator;

@Service
public class FileNameComparator implements Comparator<Path> {

    @Override
    public int compare(Path o1, Path o2) {

        if (o1 == null) {
            return -1;
        } else if (o2 == null) {
            return 1;
        }

        if (o1.getFileName().toString().contains(Constants.TRIGGER_FILE_EXTENSION)) {
            return 1;
        } else if (o2.getFileName().toString().contains(Constants.TRIGGER_FILE_EXTENSION)) {
            return -1;
        }

        return 0;
    }
}
