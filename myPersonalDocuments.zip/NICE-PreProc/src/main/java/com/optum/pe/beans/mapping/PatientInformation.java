package com.optum.pe.beans.mapping;

import lombok.Builder;
import lombok.Getter;

import java.util.StringJoiner;

@Builder
@Getter
public class PatientInformation {

    private String recordType;
    private String partnerId;
    private String consolidationId;
    private String adjudicationSystemId;
    private String adjudicationSystemUniqueClaimNumber;
    private String adjudicationSystemUniqueClaimNumberTransactionSequenceNumber;
    private String universalId;
    private String adjudicationSystemIdNumberSubmitted;
    private String idNumberQualifierSubmitted;
    private String firstName;
    private String middleName;
    private String lastName;
    private String suffix;
    private String adjudicationSystemIdNumberAdjudicated;
    private String idNumberQualifierAdjudicated;
    private String firstNameAdjudicated;
    private String middleNameAdjudicated;
    private String lastNameAdjudicated;
    private String suffixAdjudicated;
    private String age;
    private String relationshipToSubscriber;
    private String mailingAddressStreet1;
    private String mailingAddressStreet2;
    private String mailingAddressStreet3;
    private String mailingAddressStreet4;
    private String mailingAddressStreet5;
    private String mailingAddressStreet6;
    private String mailingAddressStreet7;
    private String mailingAddressCity;
    private String mailingAddressState;
    private String mailingAddressZipCode;
    private String mailingCountryCode;
    private String coverageMemberIdXRef;
    private String namePrefix;
    private String namePrefixAdjudicated;
    private String dependentSequenceNumber;
    private String dateOfBirth;

    @Override
    public String toString() {
        return new StringJoiner("|", "", "|")
                .add(recordType)
                .add(partnerId)
                .add(consolidationId)
                .add(adjudicationSystemId)
                .add(adjudicationSystemUniqueClaimNumber)
                .add(adjudicationSystemUniqueClaimNumberTransactionSequenceNumber)
                .add(universalId)
                .add(adjudicationSystemIdNumberSubmitted)
                .add(idNumberQualifierSubmitted)
                .add(firstName)
                .add(middleName)
                .add(lastName)
                .add(suffix)
                .add(adjudicationSystemIdNumberAdjudicated)
                .add(idNumberQualifierAdjudicated)
                .add(firstNameAdjudicated)
                .add(middleNameAdjudicated)
                .add(lastNameAdjudicated)
                .add(suffixAdjudicated)
                .add(age)
                .add(relationshipToSubscriber)
                .add(mailingAddressStreet1)
                .add(mailingAddressStreet2)
                .add(mailingAddressStreet3)
                .add(mailingAddressStreet4)
                .add(mailingAddressStreet5)
                .add(mailingAddressStreet6)
                .add(mailingAddressStreet7)
                .add(mailingAddressCity)
                .add(mailingAddressState)
                .add(mailingAddressZipCode)
                .add(mailingCountryCode)
                .add(coverageMemberIdXRef)
                .add(namePrefix)
                .add(namePrefixAdjudicated)
                .add(dependentSequenceNumber)
                .add(dateOfBirth)
                .toString();
    }
}
