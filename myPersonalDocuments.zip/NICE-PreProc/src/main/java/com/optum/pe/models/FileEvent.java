package com.optum.pe.models;

import lombok.Builder;
import lombok.Getter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Builder
@Getter
@Entity
@Table(name = "FILE_EVENT_STORE", schema = "PE01")
public class FileEvent implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "file_name")
    private String fileName;

    @Column(name = "cycle_date")
    private LocalDate cycleDate;

    @Column(name = "ppid")
    private String ppid;

    @Column(name = "file_id")
    private int fileId;

    @Column(name = "active_flag")
    private char activeFlag;

    @Column(name = "creation_date")
    private LocalDateTime creationDate;

    @Column(name = "updation_date")
    private LocalDateTime updationDate;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "pay_count")
    private int payCount;

}
