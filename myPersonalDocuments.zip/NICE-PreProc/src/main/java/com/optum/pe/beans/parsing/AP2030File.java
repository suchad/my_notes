package com.optum.pe.beans.parsing;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class AP2030File {

    private CompanyHeaderRecord companyHeaderRecord;
    private List<CheckRecord> checkRecordList;
    private TrailerRecord trailerRecord;
    private int processedLineCount;
}
