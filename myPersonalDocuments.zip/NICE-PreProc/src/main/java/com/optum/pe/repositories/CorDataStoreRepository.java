package com.optum.pe.repositories;

import com.optum.pe.models.CorDataStore;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Clob;
import java.util.List;

@Repository
public interface CorDataStoreRepository extends CrudRepository<CorDataStore, Long> {

    @Query(value = "SELECT COR_DATA FROM PE01.COR_2030_DATA_STORE WHERE " +
            "CREATED_BY = 'NICE-PREPROC' AND PARTNER_ID = '1223-1' AND " +
            "CYCLE_DATE = (SELECT to_date(max(cd.CYC_DT_NM), 'yyyymmdd') " +
            "   FROM PE01.CYCLE_DATE cd WHERE cd.PARTNER_PROC_GRP_ID = 'NICECLM' " +
            "   AND cd.CYC_DT_USED_IND = 'Y')", nativeQuery = true)
    List<Clob> findCurrentPayments();

    @Transactional
    @Modifying(flushAutomatically = true)
    @Query(value = "DELETE FROM PE01.COR_2030_DATA_STORE WHERE " +
            "CREATED_BY = 'NICE-PREPROC' AND PARTNER_ID = '1223-1' AND " +
            "CYCLE_DATE = (SELECT to_date(max(cd.CYC_DT_NM), 'yyyymmdd') " +
            "   FROM PE01.CYCLE_DATE cd WHERE cd.PARTNER_PROC_GRP_ID = 'NICECLM' " +
            "   AND cd.CYC_DT_USED_IND = 'Y')", nativeQuery = true)
    void deleteCurrentPayments();
}
