package com.optum.pe.supplier;

import com.optum.pe.beans.parsing.Adjustment;
import com.optum.pe.beans.parsing.ServiceLine;
import com.optum.pe.onepay.avro.ClaimServiceLine;
import com.optum.pe.utils.Constants;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

@Service
class ServiceLineSupplier {

    private final ClaimServiceLineInformationSupplier claimServiceLineInformationSupplier;
    private final ClaimServiceLineAdjustmentInformationSupplier claimServiceLineAdjustmentInformationSupplier;
    private final ServiceLineSupplementalInformationSupplier serviceLineSupplementalInformationSupplier;

    ServiceLineSupplier(ClaimServiceLineInformationSupplier claimServiceLineInformationSupplier, ClaimServiceLineAdjustmentInformationSupplier claimServiceLineAdjustmentInformationSupplier, ServiceLineSupplementalInformationSupplier serviceLineSupplementalInformationSupplier) {
        this.claimServiceLineInformationSupplier = claimServiceLineInformationSupplier;
        this.claimServiceLineAdjustmentInformationSupplier = claimServiceLineAdjustmentInformationSupplier;
        this.serviceLineSupplementalInformationSupplier = serviceLineSupplementalInformationSupplier;
    }

    ClaimServiceLine supply(String checkNumber, String claimNumber, int transactionSequenceNumber, String vendorId,
                            int adjudicationSystemNumber, ServiceLine serviceLine) {

        ClaimServiceLine.Builder claimServiceLineBuilder = ClaimServiceLine.newBuilder()
                .setServiceLineInformation(
                        claimServiceLineInformationSupplier.supply(checkNumber, claimNumber,
                                transactionSequenceNumber, vendorId, adjudicationSystemNumber, serviceLine).toString());

        addAdjustments(checkNumber, claimNumber, transactionSequenceNumber, adjudicationSystemNumber, serviceLine, claimServiceLineBuilder);

        addSupplementals(checkNumber, claimNumber, transactionSequenceNumber, adjudicationSystemNumber, serviceLine, claimServiceLineBuilder);

        return claimServiceLineBuilder.build();
    }

    private void addSupplementals(String checkNumber, String claimNumber, int transactionSequenceNumber, int adjudicationSystemNumber, ServiceLine serviceLine, ClaimServiceLine.Builder claimServiceLineBuilder) {
        List<String> supplementalList = getSupplementalList(checkNumber, claimNumber, transactionSequenceNumber, adjudicationSystemNumber, serviceLine);

        if (!supplementalList.isEmpty()) {
            claimServiceLineBuilder.setServiceLineSupplementalList(supplementalList);
        }
    }

    private void addAdjustments(String checkNumber, String claimNumber, int transactionSequenceNumber, int adjudicationSystemNumber, ServiceLine serviceLine, ClaimServiceLine.Builder claimServiceLineBuilder) {
        List<String> adjustmentList = getAdjustmentList(checkNumber, claimNumber, transactionSequenceNumber, adjudicationSystemNumber, serviceLine);

        if (!adjustmentList.isEmpty()) {
            claimServiceLineBuilder.setServiceLineAdjustmentList(adjustmentList);
        }
    }

    private List<String> getAdjustmentList(String checkNumber, String claimNumber,
                                           int transactionSequenceNumber, int adjudicationSystemNumber, ServiceLine serviceLine) {

        List<String> adjustmentList = new ArrayList<>();

        AtomicInteger recordSequenceNumber = new AtomicInteger(1);

        if (!Constants.ZERO_AMOUNT.equals(serviceLine.getAdjustedAmount())) {
            adjustmentList.add(claimServiceLineAdjustmentInformationSupplier.supply(checkNumber,
                    claimNumber, transactionSequenceNumber, recordSequenceNumber.getAndAdd(1),
                    adjudicationSystemNumber, getAdjustmentFrom(serviceLine)).toString());
        }

        if (serviceLine.getAdjustmentList() != null) {

            adjustmentList.addAll(serviceLine.getAdjustmentList().stream()
                    .filter(this::isServiceLineAdjustment)
                    .map(adjustment ->
                            claimServiceLineAdjustmentInformationSupplier.supply(checkNumber,
                                    claimNumber, transactionSequenceNumber, recordSequenceNumber.getAndAdd(1),
                                    adjudicationSystemNumber, adjustment).toString()
                    ).collect(Collectors.toList()));
        }

        return adjustmentList;
    }

    private Adjustment getAdjustmentFrom(ServiceLine serviceLine) {

        return Adjustment.builder()
                .recordType(serviceLine.getRecordType())
                .serviceCode(serviceLine.getServiceCode())
                .serviceDate(serviceLine.getServiceDate())
                .chargeAmount(serviceLine.getChargeAmount())
                .adjustedAmount(serviceLine.getAdjustedAmount())
                .adjustedSign(serviceLine.getAdjustedSign())
                .adjustedReason(serviceLine.getAdjustedReason())
                .payAmount(serviceLine.getPayAmount())
                .paySign(serviceLine.getPaySign())
                .remarkAdjustmentReasonCode(serviceLine.getRemarkAdjustmentReasonCode())
                .adjustmentGroupCode(serviceLine.getAdjustmentGroupCode())
                .claimAdjustmentReasonCode(serviceLine.getClaimAdjustmentReasonCode())
                .build();
    }

    private boolean isServiceLineAdjustment(Adjustment adjustment) {
        return Constants.EMPTY_SERVICE_CODE.equals(adjustment.getServiceCode()) &&
                !Constants.ZERO_AMOUNT.equals(adjustment.getAdjustedAmount());
    }

    private List<String> getSupplementalList(String checkNumber, String claimNumber,
                                             int transactionSequenceNumber, int adjudicationSystemNumber, ServiceLine serviceLine) {

        List<String> adjustmentList = new ArrayList<>();

        AtomicInteger recordSequenceNumber = new AtomicInteger(1);

        if (!Constants.ZERO_AMOUNT.equals(serviceLine.getAdjustedAmount())) {
            adjustmentList.add(serviceLineSupplementalInformationSupplier.supply(checkNumber,
                    claimNumber, transactionSequenceNumber, recordSequenceNumber.getAndAdd(1),
                    adjudicationSystemNumber, getAdjustmentFrom(serviceLine)).toString());
        }

        if (serviceLine.getAdjustmentList() != null) {

            adjustmentList.addAll(serviceLine.getAdjustmentList().stream()
                    .filter(this::isServiceLineSupplemental)
                    .map(adjustment ->
                            serviceLineSupplementalInformationSupplier.supply(checkNumber,
                                    claimNumber, transactionSequenceNumber, recordSequenceNumber.getAndAdd(1),
                                    adjudicationSystemNumber, adjustment).toString()
                    ).collect(Collectors.toList()));
        }

        return adjustmentList;
    }

    private boolean isServiceLineSupplemental(Adjustment adjustment) {

        return Constants.EMPTY_SERVICE_CODE.equals(adjustment.getServiceCode()) &&
                !Constants.ZERO_AMOUNT.equals(adjustment.getAdjustedAmount());
    }
}
