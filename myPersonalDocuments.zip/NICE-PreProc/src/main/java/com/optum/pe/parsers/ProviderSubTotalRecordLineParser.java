package com.optum.pe.parsers;

import com.optum.pe.beans.parsing.ProviderSubTotalRecord;
import com.optum.pe.beans.parsing.Record;
import com.optum.pe.nice.ProcessState;
import com.optum.pe.nice.ProcessStateFactory;
import org.springframework.stereotype.Service;

@Service
public class ProviderSubTotalRecordLineParser implements AP2030LineParser {

    private final ProcessStateFactory processStateFactory;

    public ProviderSubTotalRecordLineParser(ProcessStateFactory processStateFactory) {
        this.processStateFactory = processStateFactory;
    }

    @Override
    public boolean parse(String fileName, String line) {

        ProviderSubTotalRecord providerSubTotalRecord = ProviderSubTotalRecord.builder()
                .recordType(line.substring(0, 2).trim())
                .providerName(line.substring(2, 32).trim())
                .subTotal(line.substring(32, 46).trim())
                .subTotalSign(line.charAt(46)).build();

        updateState(fileName, providerSubTotalRecord);

        return true;
    }

    @Override
    public void updateState(String fileName, Record record) {

        ProcessState processState = processStateFactory.getProcessStateFor(fileName);

        if (processState.getClaimHeaderRecord() != null) {
            processState.getClaimHeaderRecord().getClaimTotalRecord()
                    .setProviderSubTotalRecord((ProviderSubTotalRecord) record);

            processState.incrementCheckRecordLines();
        }
    }
}
