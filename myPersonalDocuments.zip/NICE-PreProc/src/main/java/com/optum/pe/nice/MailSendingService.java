package com.optum.pe.nice;

import com.optum.pe.beans.parsing.FileCountAndAmountInformation;
import com.optum.pe.nice.runnable.CountAndAmountMisMatchRunnable;
import com.optum.pe.nice.runnable.DuplicateDatFileRunnable;
import com.optum.pe.nice.runnable.MissingDatFileRunnable;
import com.optum.pe.nice.runnable.MissingTrailerRunnable;
import com.optum.pe.service.SMTPService;
import org.springframework.stereotype.Service;

@Service
public class MailSendingService {

    private final ExecutorStore executorStore;
    private final SMTPService smtpService;

    public MailSendingService(ExecutorStore executorStore, SMTPService smtpService) {
        this.executorStore = executorStore;
        this.smtpService = smtpService;
    }

    public void missingTrailerMail(String fileName, String cycleDate) {
        executorStore.getMailExecutorService()
                .submit(new MissingTrailerRunnable(fileName, cycleDate, smtpService));
    }

    public void countAndAmountMisMatchMail(FileCountAndAmountInformation fileCountAndAmountInformation, String cycleDate) {
        executorStore.getMailExecutorService()
                .submit(new CountAndAmountMisMatchRunnable(fileCountAndAmountInformation, cycleDate, smtpService));
    }

    public void missingDatFileMail(String fileName, String cycleDate) {
        executorStore.getMailExecutorService()
                .submit(new MissingDatFileRunnable(fileName, cycleDate, smtpService));
    }

    public void duplicateDatFileMail(String fileName, String cycleDate) {
        executorStore.getMailExecutorService()
                .submit(new DuplicateDatFileRunnable(fileName, cycleDate, smtpService));
    }
}
