package com.optum.pe.beans.parsing;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

@Setter
@Getter
@Builder
public class ServiceLine {

    private String recordType;
    private String serviceCode;

    private String serviceDate;
    private String chargeAmount;

    private String adjustedAmount;
    private char adjustedSign;
    private String adjustedReason;

    private String payAmount;
    private char paySign;

    private String remarkAdjustmentReasonCode;
    private String adjustmentGroupCode;
    private String claimAdjustmentReasonCode;
    private String qpa;

    private List<Adjustment> adjustmentList;

    private List<ClaimNoteRecord> claimNoteRecords;
}
