package com.optum.pe.models;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name="SERVICE_PARAMETERS", schema = "PE01")
@Data
public class ServiceParameters implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "PARM_NM")
    private String paramName;

    @Column(name = "PARTNER_PROC_GRP_ID")
    private String partnerProcGrpId;

    @Column(name = "CATGY_CD")
    private String categoryCode;

    @Column(name = "PARM_DESC")
    private String paramDesc;

    @Column(name = "CURR_VAL")
    private String currentValue;

    @Column(name = "UPDT_BY_NM")
    private String updatedBy;

    @Column(name = "UPDT_DTTM")
    private LocalDateTime updatedDate;

    @Column(name = "CREAT_BY_NM")
    private String createdBy;

    @Column(name = "CREAT_DTTM")
    private LocalDateTime createdDate;
}
