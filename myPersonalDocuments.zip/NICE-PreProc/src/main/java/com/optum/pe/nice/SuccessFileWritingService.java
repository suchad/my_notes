package com.optum.pe.nice;

import com.optum.pe.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Slf4j
@Service
public class SuccessFileWritingService {

    private final PathGetterService pathGetterService;

    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");

    public SuccessFileWritingService(PathGetterService pathGetterService) {
        this.pathGetterService = pathGetterService;
    }

    public boolean write() {

        boolean status = false;

        Path filePath = Paths.get(pathGetterService.getOutputPath() +
                Constants.COMPLETE_SUCCESS_FILE + LocalDateTime.now().format(formatter) +
                Constants.TRIGGER_FILE_EXTENSION.toLowerCase());

        try {
            Files.createFile(filePath);

            status = true;
        } catch (IOException e) {
            log.error("", e);
        }

        return status;
    }
}
