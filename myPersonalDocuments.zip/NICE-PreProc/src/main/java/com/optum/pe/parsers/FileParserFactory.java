package com.optum.pe.parsers;

import com.optum.pe.configuration.FileType;
import org.springframework.stereotype.Service;

import java.nio.file.Path;
import java.util.Optional;

@Service
public class FileParserFactory {

    private final AP2030FileParser ap2030FileParser;

    FileParserFactory(AP2030FileParser ap2030FileParser) {
        this.ap2030FileParser = ap2030FileParser;
    }

    public Optional<FileParser> getFileParser(Path path) {

        if ((path.getFileName() + "").contains(FileType.NICE_PE_EOP.toString())) {
            return Optional.of(ap2030FileParser);
        }

        return Optional.empty();
    }
}
