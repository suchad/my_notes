package com.optum.pe.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.optum.pe.models.ServiceParameters;

@Repository
public interface ServiceParametersRepository extends CrudRepository<ServiceParameters, String> {
    List<ServiceParameters> findByParamNameAndPartnerProcGrpId(String id, String partnerProcGrpId);
}
