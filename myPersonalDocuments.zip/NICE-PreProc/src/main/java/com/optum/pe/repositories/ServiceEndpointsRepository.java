package com.optum.pe.repositories;

import com.optum.pe.models.ServiceEndpoints;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ServiceEndpointsRepository extends CrudRepository<ServiceEndpoints, String> {
    List<ServiceEndpoints> findByPartnerProcGrpIdAndServiceNameAndEndpointName(String partnerProcGrpId, String serviceName, String endpointName);
}
