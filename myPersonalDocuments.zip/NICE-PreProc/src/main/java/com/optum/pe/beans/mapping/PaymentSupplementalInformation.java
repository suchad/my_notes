package com.optum.pe.beans.mapping;

import lombok.Builder;
import lombok.Getter;

import java.util.StringJoiner;

@Builder
@Getter
public class PaymentSupplementalInformation {

    private String recordType;
    private String partnerId;
    private String consolidationId;
    private String recordSequenceNumber;
    private String userDefinedField1;
    private String userDefinedField2;
    private String userDefinedField3;
    private String userDefinedField4;
    private String userDefinedField5;
    private String userDefinedField6;
    private String userDefinedField7;
    private String userDefinedField8;
    private String userDefinedField9;
    private String userDefinedField10;

    @Override
    public String toString() {
        return new StringJoiner("|", "", "|")
                .add(recordType)
                .add(partnerId)
                .add(consolidationId)
                .add(recordSequenceNumber)
                .add(userDefinedField1)
                .add(userDefinedField2)
                .add(userDefinedField3)
                .add(userDefinedField4)
                .add(userDefinedField5)
                .add(userDefinedField6)
                .add(userDefinedField7)
                .add(userDefinedField8)
                .add(userDefinedField9)
                .add(userDefinedField10)
                .toString();
    }
}