package com.optum.pe.service;

import com.optum.pe.models.ParameterConfigEntity;
import com.optum.pe.repositories.ParameterConfigRepository;
import com.optum.pe.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class ParameterConfigService {


    private ParameterConfigRepository parameterConfigRepository;

    public ParameterConfigService(ParameterConfigRepository parameterConfigRepository) {
        this.parameterConfigRepository = parameterConfigRepository;
    }

    public boolean isNiceDeployedCode() {
        ParameterConfigEntity pce = parameterConfigRepository.findByPartnerProcGrpIdAndParameterNm(Constants.PARTNER_PROC_GRP_ID, Constants.PARAMETER_NAME_NICE);
        if ("Y".equals(pce.getParameterVal())) {
            return true;
        }
        return false;
    }

    public boolean isCdcCodeDeployed() {
        ParameterConfigEntity pce = parameterConfigRepository.findByPartnerProcGrpIdAndParameterNm(Constants.PARTNER_PROC_GRP_ID, Constants.PARAMETER_NAME_CDC);
        if ("Y".equals(pce.getParameterVal())) {
            return true;
        }
        return false;
    }

}
