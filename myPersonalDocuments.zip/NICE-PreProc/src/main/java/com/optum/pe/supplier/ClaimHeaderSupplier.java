package com.optum.pe.supplier;

import com.optum.pe.beans.parsing.*;
import com.optum.pe.models.LookupData;
import com.optum.pe.onepay.avro.ClaimHeader;
import com.optum.pe.onepay.avro.ClaimServiceLine;
import com.optum.pe.service.ParameterConfigService;
import com.optum.pe.utils.Constants;
import io.micrometer.core.instrument.util.StringUtils;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import static com.optum.pe.utils.Constants.ZERO_AMOUNT;

@Service
class ClaimHeaderSupplier {

    private final ClaimHeaderInformationSupplier claimHeaderInformationSupplier;
    private final ClaimMessageInformationSupplier claimMessageInformationSupplier;
    private final ClaimPolicyPlanInformationSupplier claimPolicyPlanInformationSupplier;
    private final ClaimServiceCenterInformationSupplier claimServiceCenterInformationSupplier;
    private final PatientInformationSupplier patientInformationSupplier;
    private final ProviderInformationSupplier providerInformationSupplier;
    private final SubscriberInformationSupplier subscriberInformationSupplier;
    private final ClaimSupplementalInformationSupplier claimSupplementalInformationSupplier;
    private final ServiceLineSupplier serviceLineSupplier;
    private final ParameterConfigService parameterConfigService;

    ClaimHeaderSupplier(ClaimHeaderInformationSupplier claimHeaderInformationSupplier,
                        ClaimMessageInformationSupplier claimMessageInformationSupplier,
                        ClaimPolicyPlanInformationSupplier claimPolicyPlanInformationSupplier,
                        ClaimServiceCenterInformationSupplier claimServiceCenterInformationSupplier,
                        PatientInformationSupplier patientInformationSupplier,
                        ProviderInformationSupplier providerInformationSupplier,
                        SubscriberInformationSupplier subscriberInformationSupplier,
                        ClaimSupplementalInformationSupplier claimSupplementalInformationSupplier,
                        ServiceLineSupplier serviceLineSupplier, ParameterConfigService parameterConfigService) {
        this.claimHeaderInformationSupplier = claimHeaderInformationSupplier;
        this.claimMessageInformationSupplier = claimMessageInformationSupplier;
        this.claimPolicyPlanInformationSupplier = claimPolicyPlanInformationSupplier;
        this.claimServiceCenterInformationSupplier = claimServiceCenterInformationSupplier;
        this.patientInformationSupplier = patientInformationSupplier;
        this.providerInformationSupplier = providerInformationSupplier;
        this.subscriberInformationSupplier = subscriberInformationSupplier;
        this.claimSupplementalInformationSupplier = claimSupplementalInformationSupplier;
        this.serviceLineSupplier = serviceLineSupplier;
        this.parameterConfigService = parameterConfigService;
    }

    ClaimHeader supply(int transactionSequenceNumber, ClaimHeaderRecord claimHeaderRecord,
                       CheckRecord payment,
                       LookupData payerInfoLookupData,
                       LookupData payerServiceCenterLookupData,
                       LookupData payerReturnAddressLookupData,
                       LookupData memberMessageGenericLookupData,
                       LookupData providerMessageStateLookupData,
                       LookupData providerMessageAppealsLookupData) {

        ClaimHeader.Builder claimHeaderBuilder = ClaimHeader.newBuilder()
                .setClaimHeaderInformation(claimHeaderInformationSupplier.supply(transactionSequenceNumber, claimHeaderRecord, payment).toString())
                .setPolicyPlan(claimPolicyPlanInformationSupplier.supply(payment.getCheckNumber(), payment.getBankCode(), transactionSequenceNumber, claimHeaderRecord, payerInfoLookupData).toString())
                .setServiceCenter(claimServiceCenterInformationSupplier.supply(
                        payment.getCheckNumber(), transactionSequenceNumber, claimHeaderRecord,
                        payerServiceCenterLookupData, payerReturnAddressLookupData).toString());

        addMessages(transactionSequenceNumber, claimHeaderRecord, payment, memberMessageGenericLookupData, providerMessageStateLookupData, providerMessageAppealsLookupData, claimHeaderBuilder);

        addPatient(transactionSequenceNumber, claimHeaderRecord, payment, claimHeaderBuilder);

        addProviders(transactionSequenceNumber, claimHeaderRecord, payment, claimHeaderBuilder);

        addSubscriber(transactionSequenceNumber, claimHeaderRecord, payment, claimHeaderBuilder);

        addSupplementals(transactionSequenceNumber, claimHeaderRecord, payment, claimHeaderBuilder);

        addServiceLines(transactionSequenceNumber, claimHeaderRecord, payment, claimHeaderBuilder);

        return claimHeaderBuilder.build();
    }

    private void addServiceLines(int transactionSequenceNumber, ClaimHeaderRecord claimHeaderRecord, CheckRecord payment, ClaimHeader.Builder claimHeaderBuilder) {
        List<ClaimServiceLine> claimServiceLineList = getClaimServiceLineList(payment.getCheckNumber(), transactionSequenceNumber, payment.getVendorId(), claimHeaderRecord);

        if (!claimServiceLineList.isEmpty()) {
            claimHeaderBuilder.setClaimServiceLineList(claimServiceLineList);
        }
    }

    private void addSupplementals(int transactionSequenceNumber, ClaimHeaderRecord claimHeaderRecord, CheckRecord payment, ClaimHeader.Builder claimHeaderBuilder) {
        List<String> claimSupplementalList = getClaimSupplementalList(payment.getCheckNumber(), transactionSequenceNumber, claimHeaderRecord);

        if (claimSupplementalList != null) {
            claimHeaderBuilder.setSupplementalInformationList(claimSupplementalList);
        }
    }

    private void addSubscriber(int transactionSequenceNumber, ClaimHeaderRecord claimHeaderRecord, CheckRecord payment, ClaimHeader.Builder claimHeaderBuilder) {
        String claimSubscriberString = getClaimSubscriberString(payment.getCheckNumber(), transactionSequenceNumber, payment.getVendorId(), claimHeaderRecord);

        if (!claimSubscriberString.isEmpty()) {
            claimHeaderBuilder.setSubscriber(claimSubscriberString);
        }
    }

    private void addProviders(int transactionSequenceNumber, ClaimHeaderRecord claimHeaderRecord, CheckRecord payment, ClaimHeader.Builder claimHeaderBuilder) {
        List<String> claimProviderList = getProviderList(transactionSequenceNumber, claimHeaderRecord, payment);

        if (!claimProviderList.isEmpty()) {
            claimHeaderBuilder.setProviderList(claimProviderList);
        }
    }

    private void addPatient(int transactionSequenceNumber, ClaimHeaderRecord claimHeaderRecord, CheckRecord payment, ClaimHeader.Builder claimHeaderBuilder) {
        String patientString = getPatientString(transactionSequenceNumber, payment.getCheckNumber(), claimHeaderRecord);

        if (!patientString.isEmpty()) {
            claimHeaderBuilder.setPatient(patientString);
        }
    }

    private void addMessages(int transactionSequenceNumber, ClaimHeaderRecord claimHeaderRecord, CheckRecord payment, LookupData memberMessageGenericLookupData, LookupData providerMessageStateLookupData, LookupData providerMessageAppealsLookupData, ClaimHeader.Builder claimHeaderBuilder) {
        List<String> claimMessageList = getClaimMessageListFrom(transactionSequenceNumber, claimHeaderRecord, payment,
                memberMessageGenericLookupData, providerMessageStateLookupData, providerMessageAppealsLookupData, claimHeaderBuilder);

        if (!claimMessageList.isEmpty()) {
            claimHeaderBuilder.setClaimMessageList(claimMessageList);
        }
    }

    private List<ClaimServiceLine> getClaimServiceLineList(String checkNumber, int transactionSequenceNumber, String vendorId,
                                                           ClaimHeaderRecord claimHeaderRecord) {

        List<ClaimServiceLine> claimServiceLineList = new ArrayList<>();

        if (claimHeaderRecord.getClaimDetailRecordList() != null) {

            for (ClaimDetailRecord claimDetailRecord : claimHeaderRecord.getClaimDetailRecordList()) {

                int adjudicationSystemNumber = 1;

                if (claimDetailRecord.getServiceLineList() != null) {
                    for (ServiceLine serviceLine : claimDetailRecord.getServiceLineList()) {
                        claimServiceLineList.add(serviceLineSupplier.supply(checkNumber,
                                claimHeaderRecord.getClaimNumber(), transactionSequenceNumber, vendorId,
                                adjudicationSystemNumber, serviceLine));

                        adjudicationSystemNumber++;
                    }
                }
            }

        }

        return claimServiceLineList;

    }

    private List<String> getClaimSupplementalList(String checkNumber, int transactionSequenceNumber, ClaimHeaderRecord claimHeaderRecord) {

        List<String> claimSupplementalList = new ArrayList<>();

        AtomicInteger recordSequenceNumber = new AtomicInteger(1);

        if (claimHeaderRecord.getAdjustmentList() != null) {
            claimSupplementalList.addAll(claimHeaderRecord.getAdjustmentList().stream()
                    .map(adjustment ->
                            claimSupplementalInformationSupplier.supply(checkNumber,
                                    claimHeaderRecord.getClaimNumber(),
                                    transactionSequenceNumber,
                                    recordSequenceNumber.getAndAdd(1), adjustment,
                                    claimHeaderRecord.getClaimTotalRecord(),
                                    claimHeaderRecord.getMedGroup()).toString())
                    .collect(Collectors.toList()));
        }

        if (claimHeaderRecord.getClaimDetailRecordList() != null) {

            claimSupplementalList.addAll(
                    claimHeaderRecord.getClaimDetailRecordList().stream()
                            .filter(claimDetailRecord -> Constants.INTEREST_SERVICE_CODE.equals(claimDetailRecord.getServiceCode())
                                    || Constants.PENALTY_SERVICE_CODE.equals(claimDetailRecord.getServiceCode()))
                            .map(claimDetailRecord ->
                                    claimSupplementalInformationSupplier.supply(checkNumber,
                                            claimHeaderRecord.getClaimNumber(),
                                            transactionSequenceNumber,
                                            recordSequenceNumber.getAndAdd(1), getAdjustmentFrom(claimDetailRecord),
                                            claimHeaderRecord.getClaimTotalRecord(),
                                            claimHeaderRecord.getMedGroup()).toString())
                            .collect(Collectors.toList()));
        }

        if (claimSupplementalList.isEmpty()) {
            Adjustment adjustment = Adjustment.builder().adjustmentGroupCode("").claimAdjustmentReasonCode("")
                    .payAmount(ZERO_AMOUNT).remarkAdjustmentReasonCode("").adjustedReason("").adjustedSign(' ')
                    .adjustedAmount(ZERO_AMOUNT).paySign(' ').chargeAmount(ZERO_AMOUNT).build();
            claimSupplementalList.add(claimSupplementalInformationSupplier.supply(checkNumber,
                    claimHeaderRecord.getClaimNumber(),
                    transactionSequenceNumber,
                    recordSequenceNumber.getAndAdd(1), adjustment,
                    claimHeaderRecord.getClaimTotalRecord(),
                    claimHeaderRecord.getMedGroup()).toString());
        }

        return claimSupplementalList;
    }

    private String getClaimSubscriberString(String checkNumber, int transactionSequenceNumber, String vendorId, ClaimHeaderRecord claimHeaderRecord) {

        return subscriberInformationSupplier.supply(checkNumber, transactionSequenceNumber, vendorId, claimHeaderRecord).toString();
    }

    private List<String> getProviderList(int transactionSequenceNumber, ClaimHeaderRecord claimHeaderRecord, CheckRecord payment) {

        List<String> claimProviderList = new ArrayList<>(3);

        int recordSequenceNumber = 1;

        if (!Constants.CLM_2.equals(payment.getVendorId().substring(0, 4))) {
            claimProviderList.add(
                    providerInformationSupplier.supply(transactionSequenceNumber, recordSequenceNumber, claimHeaderRecord, payment, Constants.BILLING_PROVIDER_CODE).toString());

            recordSequenceNumber++;
        }

        claimProviderList.add(
                providerInformationSupplier.supply(transactionSequenceNumber, recordSequenceNumber, claimHeaderRecord, payment, Constants.RENDERING_PROVIDER_CODE).toString());

        return claimProviderList;
    }

    private String getPatientString(int transactionSequenceNumber, String checkNumber, ClaimHeaderRecord claimHeaderRecord) {

        return patientInformationSupplier.supply(checkNumber, transactionSequenceNumber, claimHeaderRecord).toString();
    }

    private List<String> getClaimMessageListFrom(int transactionSequenceNumber,
                                                 ClaimHeaderRecord claimHeaderRecord,
                                                 CheckRecord payment,
                                                 LookupData memberMessageLookupData,
                                                 LookupData providerMessagePdrLookupData,
                                                 LookupData providerMessageNonnLookupData,ClaimHeader.Builder claimHeaderBuilder) {

        List<String> claimMessageList = new ArrayList<>();

        AtomicInteger recordSequenceNumber = new AtomicInteger(1);

        AtomicInteger messageSequenceNumber = new AtomicInteger(1);

        addClaimHeaderNotes(transactionSequenceNumber, claimHeaderRecord, payment, claimMessageList, recordSequenceNumber, messageSequenceNumber, Constants.CLAIM_MESSAGE_PLACEMENT_CODE,claimHeaderBuilder);

        AtomicInteger messageSequenceNumberServiceLine = new AtomicInteger(1);

        addServiceLineNotes(transactionSequenceNumber, claimHeaderRecord, payment, claimMessageList, recordSequenceNumber, messageSequenceNumberServiceLine, Constants.SERVICE_MESSAGE_PLACEMENT_CODE);

        addClaimDetailNotes(transactionSequenceNumber, claimHeaderRecord, payment, claimMessageList, recordSequenceNumber, messageSequenceNumber, Constants.CLAIM_MESSAGE_PLACEMENT_CODE);

        if (memberMessageLookupData != null) {
            claimMessageList.add(claimMessageInformationSupplier.supply(payment.getCheckNumber(),
                    claimHeaderRecord.getClaimNumber(), payment.getVendorId(), transactionSequenceNumber,
                    recordSequenceNumber.getAndAdd(1), "", 0,
                    HelperSupplier.getBlankForAsterisk(memberMessageLookupData.getResultField01()),
                    HelperSupplier.getBlankForAsterisk(memberMessageLookupData.getResultField03()),
                    HelperSupplier.getBlankForAsterisk(memberMessageLookupData.getResultField02()), claimHeaderRecord).toString());
        }

        if (providerMessagePdrLookupData != null) {
            claimMessageList.add(claimMessageInformationSupplier.supply(payment.getCheckNumber(),
                    claimHeaderRecord.getClaimNumber(), payment.getVendorId(),
                    transactionSequenceNumber, recordSequenceNumber.getAndAdd(1), "", 0,
                    HelperSupplier.getBlankForAsterisk(providerMessagePdrLookupData.getResultField01()),
                    HelperSupplier.getBlankForAsterisk(providerMessagePdrLookupData.getResultField03()),
                    HelperSupplier.getBlankForAsterisk(providerMessagePdrLookupData.getResultField02()),
                    claimHeaderRecord).toString());
        }

        if (providerMessageNonnLookupData != null) {
            claimMessageList.add(claimMessageInformationSupplier.supply(payment.getCheckNumber(),
                    claimHeaderRecord.getClaimNumber(), payment.getVendorId(),
                    transactionSequenceNumber, recordSequenceNumber.getAndAdd(1), "", 0,
                    HelperSupplier.getBlankForAsterisk(providerMessageNonnLookupData.getResultField01()),
                    HelperSupplier.getBlankForAsterisk(providerMessageNonnLookupData.getResultField03()),
                    HelperSupplier.getBlankForAsterisk(providerMessageNonnLookupData.getResultField02()), claimHeaderRecord).toString());
        }

        return claimMessageList;
    }

    private void addClaimDetailNotes(int transactionSequenceNumber, ClaimHeaderRecord claimHeaderRecord, CheckRecord payment,
                                     List<String> claimMessageList, AtomicInteger recordSequenceNumber, AtomicInteger messageSequenceNumber, String claimMessagePlacementCode) {

        if (claimHeaderRecord.getClaimDetailRecordList() != null) {
            for (ClaimDetailRecord claimDetailRecord : claimHeaderRecord.getClaimDetailRecordList()) {

                if (!Constants.RECOVERY_SERVICE_CODE.equals(claimDetailRecord.getServiceCode())) {
                    iterateServiceLineNotes(transactionSequenceNumber, claimHeaderRecord, payment, claimMessageList, recordSequenceNumber,
                            0, claimDetailRecord.getClaimNoteRecordList(), messageSequenceNumber, claimMessagePlacementCode);
                }
            }
        }
    }

    private void addClaimHeaderNotes(int transactionSequenceNumber, ClaimHeaderRecord claimHeaderRecord, CheckRecord payment, List<String> claimMessageList, AtomicInteger recordSequenceNumber, AtomicInteger messageSequenceNumber,
                                     String claimMessagePlacementCode, ClaimHeader.Builder claimHeaderBuilder) {
        if (StringUtils.isNotEmpty(claimHeaderBuilder.getClaimHeaderInformation()) &&
                claimHeaderBuilder.getClaimHeaderInformation().contains("|SB|")) {
            claimMessageList.add(claimMessageInformationSupplier
                    .supply(payment.getCheckNumber(), claimHeaderRecord.getClaimNumber(),
                            payment.getVendorId(), transactionSequenceNumber, recordSequenceNumber.getAndAdd(1),
                            Constants.SURPRISE_BILLING_MESSAGE, 0,
                            Constants.MESSAGE_CODE_35, messageSequenceNumber.getAndAdd(1) + "",
                            claimMessagePlacementCode, claimHeaderRecord).toString());
        }
        iterateServiceLineNotes(transactionSequenceNumber, claimHeaderRecord, payment, claimMessageList, recordSequenceNumber, 0, claimHeaderRecord.getClaimNoteRecords(), messageSequenceNumber, claimMessagePlacementCode);
    }

    private void addServiceLineNotes(int transactionSequenceNumber, ClaimHeaderRecord claimHeaderRecord, CheckRecord payment,
                                     List<String> claimMessageList, AtomicInteger recordSequenceNumber, AtomicInteger messageSequenceNumberServiceLine, String claimMessagePlacementCode) {

        if (claimHeaderRecord.getClaimDetailRecordList() != null) {
            for (ClaimDetailRecord claimDetailRecord : claimHeaderRecord.getClaimDetailRecordList()) {

                iterateServiceLineList(transactionSequenceNumber, claimHeaderRecord, payment, claimMessageList, recordSequenceNumber, claimDetailRecord, messageSequenceNumberServiceLine, claimMessagePlacementCode);
            }
        }
    }

    private void iterateServiceLineList(int transactionSequenceNumber, ClaimHeaderRecord claimHeaderRecord, CheckRecord payment, List<String> claimMessageList, AtomicInteger recordSequenceNumber, ClaimDetailRecord claimDetailRecord, AtomicInteger messageSequenceNumberServiceLine, String claimMessagePlacementCode) {

        if (claimDetailRecord.getServiceLineList() != null) {
            int serviceLineNumber = 1;
            for (ServiceLine serviceLine : claimDetailRecord.getServiceLineList()) {
                iterateServiceLineNotes(transactionSequenceNumber, claimHeaderRecord, payment, claimMessageList, recordSequenceNumber,
                        serviceLineNumber, serviceLine.getClaimNoteRecords(), messageSequenceNumberServiceLine, claimMessagePlacementCode);

                if (!parameterConfigService.isCdcCodeDeployed()
                        && parameterConfigService.isNiceDeployedCode()
                        && serviceLine.getQpa() != null 
                        && BigDecimal.ZERO.compareTo(new BigDecimal(serviceLine.getQpa())) != 0) {
                    claimMessageList.add(claimMessageInformationSupplier
                            .supply(payment.getCheckNumber(), claimHeaderRecord.getClaimNumber(),
                                    payment.getVendorId(), transactionSequenceNumber, recordSequenceNumber.getAndAdd(1),
                                    "QPA Amount $" + serviceLine.getQpa(), serviceLineNumber,
                                    Constants.MESSAGE_CODE_S9999, messageSequenceNumberServiceLine.getAndAdd(1) + "",
                                    claimMessagePlacementCode, claimHeaderRecord).toString());
                }

                serviceLineNumber++;
            }
        }
    }


    private void iterateServiceLineNotes(int transactionSequenceNumber, ClaimHeaderRecord claimHeaderRecord, CheckRecord payment,
                                         List<String> claimMessageList, AtomicInteger recordSequenceNumber,
                                         int serviceLineNumber, List<ClaimNoteRecord> claimNoteRecords, AtomicInteger messageSequenceNumber, String claimMessagePlacementCode) {
        if (claimNoteRecords != null) {

            for (ClaimNoteRecord claimNoteRecord : claimNoteRecords) {

                claimMessageList.add(claimMessageInformationSupplier
                        .supply(payment.getCheckNumber(), claimHeaderRecord.getClaimNumber(),
                                payment.getVendorId(), transactionSequenceNumber, recordSequenceNumber.getAndAdd(1),
                                claimNoteRecord.getNoteLine(), serviceLineNumber,
                                Constants.MESSAGE_CODE_35, messageSequenceNumber.getAndAdd(1) + "",
                                claimMessagePlacementCode, claimHeaderRecord).toString());
                
            }
        }
    }

    private Adjustment getAdjustmentFrom(ClaimDetailRecord claimDetailRecord) {

        return Adjustment.builder()
                .recordType(claimDetailRecord.getRecordType())
                .serviceCode(claimDetailRecord.getServiceCode())
                .serviceDate(claimDetailRecord.getServiceDate())
                .chargeAmount(claimDetailRecord.getChargeAmount())
                .adjustedAmount(claimDetailRecord.getAdjustedAmount())
                .adjustedSign(claimDetailRecord.getAdjustedSign())
                .adjustedReason(claimDetailRecord.getAdjustedReason())
                .payAmount(claimDetailRecord.getPayAmount())
                .paySign(claimDetailRecord.getPaySign())
                .remarkAdjustmentReasonCode(claimDetailRecord.getRemarkAdjustmentReasonCode())
                .adjustmentGroupCode(claimDetailRecord.getAdjustmentGroupCode())
                .claimAdjustmentReasonCode(claimDetailRecord.getClaimAdjustmentReasonCode())
                .build();
    }
}
