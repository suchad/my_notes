package com.optum.pe.service;

import com.optum.pe.beans.parsing.FileCountAndAmountInformation;
import com.optum.pe.beans.parsing.FileMetaData;
import com.optum.pe.beans.parsing.Trailer;
import com.optum.pe.configuration.DefaultConfiguration;
import com.optum.pe.configuration.SMTPConfiguration;
import com.optum.pe.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.util.List;

/**
 * Service to compose and send mails.
 *
 * @author vivek
 */
@Service
@Slf4j
public class SMTPService {

    private static final String FILE_NAME = "File Name: ";
    private static final String BR = "<br>";
    private static final String BR_BR = "<br><br>";
    private static final String CYCLE_DATE = "Cycle Date: ";

    private JavaMailSender mailSender;
    private SMTPConfiguration smtpConfiguration;
    private DefaultConfiguration defaultConfiguration;

    SMTPService(JavaMailSender mailSender, SMTPConfiguration smtpConfiguration,
                DefaultConfiguration defaultConfiguration) {
        this.mailSender = mailSender;
        this.smtpConfiguration = smtpConfiguration;
        this.defaultConfiguration = defaultConfiguration;
    }

    /**
     * to send mail to the recipients mentioned in configuration.
     */
    public void sendMailForCountAmountMisMatch(
            FileCountAndAmountInformation fileCountAndAmountInformation, String cycleDate) {

        FileMetaData fileMetaData = fileCountAndAmountInformation.getFileMetaData();
        Trailer trailer = fileCountAndAmountInformation.getTrailerRecord();

        MimeMessage message = mailSender.createMimeMessage();

        try {
            MimeMessageHelper messageHelper = new MimeMessageHelper(message, true);

            messageHelper.setTo(smtpConfiguration.getRecipients());

            messageHelper.setSubject(defaultConfiguration.getEnvironment().toUpperCase()
                    + Constants.SEPARATOR
                    + defaultConfiguration.getPartnerProcGroupId()
                    + Constants.SEPARATOR
                    + Constants.APPLICATION_NAME + Constants.SEPARATOR
                    + "ALERT: AP2030 File Rejected – Data File-Trailer Record mismatch / File with Invalid Length"
                    + Constants.SEPARATOR + CYCLE_DATE + cycleDate);

            messageHelper.setFrom(getMailFromProperty());

            messageHelper.setText("This mail is generated for ER200 in NICE Pre-Processor AI SPEC." + BR_BR +
                    "One or more of the following mismatches have occurred:" + BR_BR +
                    "1 - The Total Payment Count (W17_TOTAL_CHECKS) on the AP2030 Trailer record is not equal to the total number of Payments (W13_CHECK_NO) in the file." + BR_BR +
                    "&nbsp;&nbsp;&nbsp;&nbsp; - AP2030 File - Total Payment Count: " + fileMetaData.getNumberOfPayments() + BR +
                    "&nbsp;&nbsp;&nbsp;&nbsp; - AP2030 Trailer Record – Total Payment Count: " + trailer.getTotalChecks() + BR_BR +
                    "2 - The Total Payment Amount (W17_TOTAL_PAYMENT_AMT) on the AP2030 Trailer record is not equal to the sum of the total Payment Amounts (W16_TOTAL_PAY) in the file." + BR_BR +
                    "&nbsp;&nbsp;&nbsp;&nbsp; - AP2030 File - Total Payment Amount: " + fileMetaData.getTotalAmount() + BR +
                    "&nbsp;&nbsp;&nbsp;&nbsp; - AP2030 Trailer Record – Total Payment Amount: " + trailer.getTotalPaymentAmount() + BR_BR +
                    "3 - The Total record count (W17_TOTAL_RECORD_CNT) on the AP2030 Trailer record is not equal to the total number of records in the file." + BR_BR +
                    "&nbsp;&nbsp;&nbsp;&nbsp; - AP2030 File - Total Record Count: " + fileMetaData.getNumberOfLines() + BR +
                    "&nbsp;&nbsp;&nbsp;&nbsp; - AP2030 Trailer Record – Total Record Count: " + trailer.getTotalRecordCount() + BR_BR +
                    "4 - The Total number of lines with invalid Line Length(<> " + Constants.LINE_LENGTH + ") on the AP2030 File is greater than 0." + BR_BR +
                    "&nbsp;&nbsp;&nbsp;&nbsp; - AP2030 File - Invalid Line Length Count: " + fileMetaData.getInvalidLines() + BR_BR +
                    FILE_NAME + fileMetaData.getFileName(), true);

            mailSender.send(message);
        } catch (MailException | MessagingException ex) {
            log.error("", ex);
        }
    }

    public void sendMailForMissingTrailer(String fileName, String cycleDate) {

        MimeMessage message = mailSender.createMimeMessage();

        try {
            MimeMessageHelper messageHelper = new MimeMessageHelper(message, true);

            messageHelper.setTo(smtpConfiguration.getRecipients());

            messageHelper.setSubject(defaultConfiguration.getEnvironment().toUpperCase()
                    + Constants.SEPARATOR
                    + defaultConfiguration.getPartnerProcGroupId()
                    + Constants.SEPARATOR
                    + Constants.APPLICATION_NAME + Constants.SEPARATOR
                    + "ALERT: AP2030 File Rejected – Trailer Record Missing"
                    + Constants.SEPARATOR + CYCLE_DATE + cycleDate);

            messageHelper.setFrom(getMailFromProperty());

            messageHelper.setText("This mail is generated for ER150 in NICE Pre-Processor AI SPEC."
                    + BR_BR + "Trailer Record Missing." + BR_BR + FILE_NAME + fileName, true);

            mailSender.send(message);
        } catch (MailException | MessagingException ex) {
            log.error("", ex);
        }
    }

    public void sendMailForMissingFiles(List<String> fileNames, String cycleDate) {

        MimeMessage message = mailSender.createMimeMessage();

        try {
            MimeMessageHelper messageHelper = new MimeMessageHelper(message, true);

            messageHelper.setTo(smtpConfiguration.getRecipients());

            messageHelper.setSubject(defaultConfiguration.getEnvironment().toUpperCase()
                    + Constants.SEPARATOR
                    + defaultConfiguration.getPartnerProcGroupId()
                    + Constants.SEPARATOR
                    + Constants.APPLICATION_NAME + Constants.SEPARATOR
                    + "ALERT: AP2030 File(s) not received" + Constants.SEPARATOR +
                    CYCLE_DATE + cycleDate);

            messageHelper.setFrom(getMailFromProperty());

            messageHelper.setText("This mail is generated for ER101 in NICE Pre-Processor AI SPEC."
                    + BR_BR + "Below mentioned files are yet to be received: " + BR_BR
                    + String.join("<br>", fileNames), true);

            mailSender.send(message);
        } catch (MailException | MessagingException ex) {
            log.error("", ex);
        }
    }

    public void sendMailForMissingDatFile(String fileName, String cycleDate) {

        MimeMessage message = mailSender.createMimeMessage();

        try {
            MimeMessageHelper messageHelper = new MimeMessageHelper(message, true);

            messageHelper.setTo(smtpConfiguration.getRecipients());

            messageHelper.setSubject(defaultConfiguration.getEnvironment().toUpperCase()
                    + Constants.SEPARATOR
                    + defaultConfiguration.getPartnerProcGroupId()
                    + Constants.SEPARATOR
                    + Constants.APPLICATION_NAME + Constants.SEPARATOR
                    + "ALERT: AP2030 Dat File Not Found" + Constants.SEPARATOR
                    + CYCLE_DATE + cycleDate);

            messageHelper.setFrom(getMailFromProperty());

            messageHelper.setText("This mail is generated for ER100 in NICE Pre-Processor AI SPEC."
                    + BR_BR + "Process has waited for " + defaultConfiguration.getDatWaitAge()
                    + " minutes but the dat file is missing for the below trigger file: " + BR_BR
                    + FILE_NAME + fileName, true);

            mailSender.send(message);
        } catch (MailException | MessagingException ex) {
            log.error("", ex);
        }
    }

    public void sendMailForDuplicateDatFile(String fileName, String cycleDate) {

        MimeMessage message = mailSender.createMimeMessage();

        try {
            MimeMessageHelper messageHelper = new MimeMessageHelper(message, true);

            messageHelper.setTo(smtpConfiguration.getRecipients());

            messageHelper.setSubject(defaultConfiguration.getEnvironment().toUpperCase()
                    + Constants.SEPARATOR
                    + defaultConfiguration.getPartnerProcGroupId()
                    + Constants.SEPARATOR
                    + Constants.APPLICATION_NAME + Constants.SEPARATOR
                    + "ALERT: Duplicate AP2030 File Received" + Constants.SEPARATOR
                    + CYCLE_DATE + cycleDate);

            messageHelper.setFrom(getMailFromProperty());

            messageHelper.setText("This mail is generated for ER102 in NICE Pre-Processor AI SPEC."
                    + BR_BR + "NICE Pre-Processor has encountered a file which has already been processed for the current cycle date: " + BR_BR
                    + FILE_NAME + fileName, true);

            mailSender.send(message);
        } catch (MailException | MessagingException ex) {
            log.error("", ex);
        }
    }

    private String getMailFromProperty() {
        return "admin_" + defaultConfiguration.getEnvironment() + "@optum.com";
    }

	public void sendMailForPayCountMismatch(String cycleDate, int filePayCount, int corPayCount) {

		MimeMessage message = mailSender.createMimeMessage();

		try {
			MimeMessageHelper messageHelper = new MimeMessageHelper(message, true);

			messageHelper.setTo(smtpConfiguration.getRecipients());

			messageHelper.setSubject(defaultConfiguration.getEnvironment().toUpperCase() + Constants.SEPARATOR
					+ defaultConfiguration.getPartnerProcGroupId() + Constants.SEPARATOR + Constants.APPLICATION_NAME
					+ Constants.SEPARATOR + "ALERT: Mismatch (AP2030 to Onramp Control)" + Constants.SEPARATOR
					+ CYCLE_DATE + cycleDate);

			messageHelper.setFrom(getMailFromProperty());

			messageHelper.setText("This mail is generated for ER250 in NICE AP2030 Pre-Processor AI SPEC." + BR_BR
					+ "The total number of payments across all AP2030 files is not equal to the total number of Payments mapped to the AP2030 Common On Ramp."
					+ BR_BR + "  - AP2030 Files – Total Payment Count: " + filePayCount + BR
					+ "  - AP2030 COR  – Total Payment Count: " + corPayCount, true);

			mailSender.send(message);

		} catch (MailException | MessagingException ex) {
			log.error("", ex);
		}
	}
}
