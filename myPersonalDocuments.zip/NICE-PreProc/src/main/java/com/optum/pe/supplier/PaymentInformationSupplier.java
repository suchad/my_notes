package com.optum.pe.supplier;

import com.optum.pe.beans.mapping.PaymentInformation;
import com.optum.pe.beans.parsing.CheckRecord;
import com.optum.pe.models.LookupData;
import com.optum.pe.utils.Constants;
import com.optum.pe.utils.RecordType;
import org.springframework.stereotype.Service;

@Service
class PaymentInformationSupplier {

    PaymentInformation supply(CheckRecord payment, String fileName, String payeeType,
                              LookupData payerInfoLookupData,
                              LookupData payerReturnAddressLookupData) {

        PaymentInformation.PaymentInformationBuilder paymentInformation
                = PaymentInformation.builder();

        paymentInformation.recordType(RecordType.PAYMENT.getLabel());
        paymentInformation.partnerId(Constants.NICE_PARTNER_ID);
        paymentInformation.consolidationId(getConsolidationId(payment));
        paymentInformation.payeeType(payeeType);
        paymentInformation.payeeIdQualifier(getPayeeIdQualifier(payeeType));
        paymentInformation.payeeId(getPayeeId(payment, payeeType));
        paymentInformation.payeeEntityName(payment.getVendorName());
        paymentInformation.payeePrefix("");
        paymentInformation.payeeFirstName("");
        paymentInformation.payeeMiddleName("");
        paymentInformation.payeeLastName("");
        paymentInformation.payeeSuffix("");
        paymentInformation.payeeMailingStreetAddress1(payment.getAddrLine1());
        paymentInformation.payeeMailingStreetAddress2(payment.getAddrLine2());
        paymentInformation.payeeMailingStreetAddress3("");
        paymentInformation.payeeMailingStreetAddress4("");
        paymentInformation.payeeMailingStreetAddress5("");
        paymentInformation.payeeMailingStreetAddress6("");
        paymentInformation.payeeMailingStreetAddress7("");
        paymentInformation.payeeMailingCity(payment.getAddrCity());
        paymentInformation.payeeMailingState(payment.getAddrState());
        paymentInformation.payeeMailingZip(payment.getAddrZipCode());
        paymentInformation.payeeMailingCountryCode("");
        paymentInformation.totalPayAmount(HelperSupplier.removeComma(payment.getCheckAmount()));
        paymentInformation.payMethod(HelperSupplier.getPayMethod(payment.getBankCode()));
        paymentInformation.checkOrTraceNumber(payment.getCheckNumber());
        paymentInformation.payGroupCode(payment.getBankCode());
        paymentInformation.issueDate(HelperSupplier.getFormattedDate(payment.getCheckDate()));
        paymentInformation.payerNameType("E");
        paymentInformation.payerName(
                HelperSupplier.getBlankForAsterisk(payerInfoLookupData.getResultField01()));
        paymentInformation.payerPrefix("");
        paymentInformation.payerFirstName("");
        paymentInformation.payerMiddleName("");
        paymentInformation.payerLastName("");
        paymentInformation.payerSuffix("");

        paymentInformation.payerMailingStreetAddress1(
                HelperSupplier.getBlankForAsterisk(payerReturnAddressLookupData.getResultField01()));
        paymentInformation.payerMailingStreetAddress2(
                HelperSupplier.getBlankForAsterisk(payerReturnAddressLookupData.getResultField02()));
        paymentInformation.payerMailingStreetAddress3(
                HelperSupplier.getBlankForAsterisk(payerReturnAddressLookupData.getResultField03()));
        paymentInformation.payerMailingStreetAddress4(
                HelperSupplier.getBlankForAsterisk(payerReturnAddressLookupData.getResultField04()));
        paymentInformation.payerMailingStreetAddress5(
                HelperSupplier.getBlankForAsterisk(payerReturnAddressLookupData.getResultField05()));
        paymentInformation.payerMailingStreetAddress6(
                HelperSupplier.getBlankForAsterisk(payerReturnAddressLookupData.getResultField06()));
        paymentInformation.payerMailingStreetAddress7(
                HelperSupplier.getBlankForAsterisk(payerReturnAddressLookupData.getResultField07()));
        paymentInformation.payerMailingCity(
                HelperSupplier.getBlankForAsterisk(payerReturnAddressLookupData.getResultField08()));
        paymentInformation.payerMailingState(
                HelperSupplier.getBlankForAsterisk(payerReturnAddressLookupData.getResultField09()));
        paymentInformation.payerMailingZip(
                HelperSupplier.getBlankForAsterisk(payerReturnAddressLookupData.getResultField10()));

        paymentInformation.payerMailingCountryCode("");

        paymentInformation.payerWebsiteUrl(
                HelperSupplier.getBlankForAsterisk(payerInfoLookupData.getResultField06()));
        paymentInformation.payerTechnicalContactUrl("");
        paymentInformation.eraRoutingId("");
        paymentInformation._835TransactionSetControlNumber("");
        paymentInformation.additionalPayerId(
                HelperSupplier.getBlankForAsterisk(payerInfoLookupData.getResultField03()));
        paymentInformation.originalFileNames(fileName);
        paymentInformation.payeeEntitySupplementalName("");
        paymentInformation.adjudicationSystemAssignedPayeeId(payment.getVendorId().trim());
        paymentInformation.payeeNPI(payment.getNpi());
        paymentInformation.payeeNameType("E");
        paymentInformation.remittanceType(HelperSupplier.getRemittanceType(payeeType, payment.getBankCode()));
        paymentInformation.payerId(
                HelperSupplier.getBlankForAsterisk(payerInfoLookupData.getResultField02()));
        paymentInformation.payerTechnicalContactName("");
        paymentInformation.payerTechnicalContactEmailId("");
        paymentInformation.payerTechnicalContactPhoneNumber("");
        paymentInformation.payerTechnicalContactPhoneExtension("");
        paymentInformation.payerTechnicalFaxNumber("");
        paymentInformation.remittanceCopyCode("");
        paymentInformation._835ERACopyRoutingId("");
        paymentInformation.remittanceCopyEntityName("");
        paymentInformation.remittanceCopyMailingStreetAddress1("");
        paymentInformation.remittanceCopyMailingStreetAddress2("");
        paymentInformation.remittanceCopyMailingStreetAddress3("");
        paymentInformation.remittanceCopyMailingStreetAddress4("");
        paymentInformation.remittanceCopyMailingStreetAddress5("");
        paymentInformation.remittanceCopyMailingStreetAddress6("");
        paymentInformation.remittanceCopyMailingStreetAddress7("");
        paymentInformation.remittanceCopyMailingCity("");
        paymentInformation.remittanceCopyMailingState("");
        paymentInformation.remittanceCopyMailingZip("");
        paymentInformation.remittanceCopyMailingCountyCode("");
        paymentInformation.remittanceVcpSeriesDesignator("");

        return paymentInformation.build();
    }

    private boolean isValue(String payeeType, String s) {
        return s.equals(payeeType);
    }

    private String getPayeeId(CheckRecord payment, String payeeType) {

        if (isValue(payeeType, Constants.SUBSCRIBER_CODE) && payment.getClaimHeaderRecordList() != null) {
            return payment.getClaimHeaderRecordList().get(0).getSubscriberId();
        } else if (!payment.getTaxId().isEmpty()) {
            return payment.getTaxId();
        }

        return Constants.ZERO;
    }

    private String getPayeeIdQualifier(String payeeType) {

        if (isValue(payeeType, Constants.SUBSCRIBER_CODE)) {
            return "EMP";
        }

        return "TIN";
    }

    private String getConsolidationId(CheckRecord payment) {
        return payment.getCheckNumber();
    }
}