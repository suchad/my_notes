package com.optum.pe.repositories;

import com.optum.pe.models.CycleDate;
import com.optum.pe.models.CycleDatePK;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CycleDateRepository extends CrudRepository<CycleDate, CycleDatePK> {

    @Query(value = "SELECT max(CYC_DT_NM) FROM PE01.CYCLE_DATE " +
            "WHERE PARTNER_PROC_GRP_ID = ?1 " +
            "AND CYC_DT_USED_IND = 'Y'", nativeQuery = true)
    String getCycleDateForPartner(String partnerProcessingGrpId);
}
