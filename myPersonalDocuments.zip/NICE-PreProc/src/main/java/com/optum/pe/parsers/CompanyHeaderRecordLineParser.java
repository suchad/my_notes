package com.optum.pe.parsers;

import com.optum.pe.beans.parsing.CompanyHeaderRecord;
import com.optum.pe.beans.parsing.Record;
import com.optum.pe.nice.ProcessState;
import com.optum.pe.nice.ProcessStateFactory;
import org.springframework.stereotype.Service;

@Service
public class CompanyHeaderRecordLineParser implements AP2030LineParser {

    private final ProcessStateFactory processStateFactory;

    CompanyHeaderRecordLineParser(ProcessStateFactory processStateFactory) {
        this.processStateFactory = processStateFactory;
    }

    @Override
    public boolean parse(String fileName, String line) {

        CompanyHeaderRecord companyHeaderRecord = CompanyHeaderRecord.builder()
                .recordType(line.substring(0, 2).trim())
                .coDiv(line.substring(2, 6).trim())
                .bankCode(line.substring(6, 31).trim()).build();

        updateState(fileName, companyHeaderRecord);

        return true;
    }

    @Override
    public void updateState(String fileName, Record record) {
        
        ProcessState processState = processStateFactory.getProcessStateFor(fileName);

        processState.getAp2030File().setCompanyHeaderRecord((CompanyHeaderRecord) record);
        processState.incrementProcessedLineCountByOne();
    }
}
