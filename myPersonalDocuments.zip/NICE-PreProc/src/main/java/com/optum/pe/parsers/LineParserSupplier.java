package com.optum.pe.parsers;

import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
class LineParserSupplier {

    private transient Map<String, LineParser> lineParserMap = new HashMap<>(10, 1);

    LineParserSupplier(CompanyHeaderRecordLineParser companyHeaderRecordLineParser,
                       CheckRecordLineParser checkRecordLineParser,
                       ClaimHeaderRecordLineParser claimHeaderRecordLineParser,
                       ClaimTotalRecordLineParser claimTotalRecordLineParser,
                       ProviderSubTotalRecordLineParser providerSubTotalRecordLineParser,
                       TrailerRecordLineParser trailerRecordLineParser,
                       ClaimNoteRecordLineParser claimNoteRecordLineParser,
                       ClaimDetailRecordLineParser claimDetailRecordLineParser) {

        lineParserMap.put("00", companyHeaderRecordLineParser);
        lineParserMap.put("10", checkRecordLineParser);
        lineParserMap.put("20", claimHeaderRecordLineParser);
        lineParserMap.put("30", claimDetailRecordLineParser);
        lineParserMap.put("35", claimNoteRecordLineParser);
        lineParserMap.put("40", claimTotalRecordLineParser);
        lineParserMap.put("43", providerSubTotalRecordLineParser);
        lineParserMap.put("50", trailerRecordLineParser);
    }

    LineParser getLineParser(String code) {
        return lineParserMap.get(code);
    }
}
