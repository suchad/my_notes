package com.optum.pe.supplier;

import com.optum.pe.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.time.DateTimeException;
import java.time.LocalDate;

@Slf4j
class HelperSupplier {

    private HelperSupplier() {
    }

    static String getPayeeType(String vendorId) {

        String payeeType;

        switch (vendorId.charAt(3)) {
            case '2':
                payeeType = "S";
                break;
            default:
                payeeType = "P";
        }

        return payeeType;
    }

    static String getRemittanceType(String payeeType, String bankCode) {

        if (Constants.PROVIDER_CODE.equals(payeeType)) {

            if (bankCode.contains("CHK")) {
                return "RP";
            } else if (bankCode.contains("ACH")) {
                return "RO";
            }
        }

        return "PS";
    }

    static String getPayMethod(String bankCode) {

        if (bankCode != null && bankCode.contains("ACH")) {
            return "E";
        } else if (bankCode != null && bankCode.contains("CHK")) {
            return "P";
        }

        return "";
    }

    static String getBlankForAsterisk(String str) {

        if ("*".equals(str)) {
            return "";
        }

        return str;
    }

    static String getFormattedDate(String serviceDate) {

        try {

            return LocalDate.parse(serviceDate, Constants.AP2030_FILE_DATE_FORMATTER)
                    .format(Constants.COR_DATE_FORMATTER);
        } catch (DateTimeException ex) {
        }

        return "";
    }

    static String getAmount(char sign, String amount) {

        if (amount.isEmpty()) {
            return Constants.ZERO_AMOUNT;
        } else if (' ' == sign) {
            return amount;
        }

        return sign + amount;
    }

    static BigDecimal getBigDecimal(String value) {

        try {
            return new BigDecimal(value);
        } catch (NumberFormatException ex) {
        }

        return new BigDecimal(Constants.ZERO_AMOUNT);
    }

    static String removeComma(String value) {

        if (value != null) {
            return value.replace(",", "");
        }

        return value;
    }

    static String getPaddedAmount(char sign, String amount, int count, String value) {

        if (StringUtils.isBlank(amount)) {
            return sign + StringUtils.leftPad(Constants.ZERO_AMOUNT, count, value);
        } else {
            return sign + StringUtils.leftPad(amount, count, value);
        }

    }
}
