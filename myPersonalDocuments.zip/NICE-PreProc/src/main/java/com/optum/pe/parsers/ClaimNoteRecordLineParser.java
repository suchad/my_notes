package com.optum.pe.parsers;

import com.optum.pe.beans.parsing.ClaimNoteRecord;
import com.optum.pe.beans.parsing.Record;
import com.optum.pe.nice.ProcessState;
import com.optum.pe.nice.ProcessStateFactory;
import com.optum.pe.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
public class ClaimNoteRecordLineParser implements AP2030LineParser {

    private final ProcessStateFactory processStateFactory;

    public ClaimNoteRecordLineParser(ProcessStateFactory processStateFactory) {
        this.processStateFactory = processStateFactory;
    }

    @Override
    public boolean parse(String fileName, String line) {

        ClaimNoteRecord claimNoteRecord = ClaimNoteRecord.builder()
                .recordType(line.substring(0, 2).trim())
                .noteLine(line.substring(2, 82).trim()).build();

        updateState(fileName, claimNoteRecord);

        return true;
    }

    @Override
    public void updateState(String fileName, Record record) {

        ProcessState processState = processStateFactory.getProcessStateFor(fileName);

        if (processState.getServiceLine() != null) {

            addClaimNoteToServiceLine(processState, (ClaimNoteRecord) record);
        } else if (processState.getClaimDetailRecord() != null &&
                !Constants.CLAIM_SERVICE_CODE.equals(processState.getClaimDetailRecord().getServiceCode())) {

            addClaimNoteToClaimDetail(processState, (ClaimNoteRecord) record);
        } else {

            addClaimNoteToClaimHeader(processState, (ClaimNoteRecord) record);
        }

        processState.incrementCheckRecordLines();
    }

    private void addClaimNoteToClaimDetail(ProcessState processState, ClaimNoteRecord record) {

        if (processState.getClaimDetailRecord().getClaimNoteRecordList() == null) {

            processState.getClaimDetailRecord().setClaimNoteRecordList(new ArrayList<>(4));
        }

        processState.getClaimDetailRecord().getClaimNoteRecordList().add(record);
    }

    private void addClaimNoteToClaimHeader(ProcessState processState, ClaimNoteRecord record) {

        if (processState.getClaimHeaderRecord().getClaimNoteRecords() == null) {

            List<ClaimNoteRecord> claimNoteRecords = new ArrayList<>(4);
            claimNoteRecords.add(record);

            processState.getClaimHeaderRecord()
                    .setClaimNoteRecords(claimNoteRecords);
        } else {

            try {
                processState.getClaimHeaderRecord().getClaimNoteRecords()
                        .add(record);
            } catch (UnsupportedOperationException ex) {
                log.warn("Got 35 after 30RECOVERY");
            }
        }
    }

    private void addClaimNoteToServiceLine(ProcessState processState, ClaimNoteRecord record) {
        if (processState.getServiceLine().getClaimNoteRecords() == null) {

            List<ClaimNoteRecord> claimNoteRecords = new ArrayList<>(4);
            claimNoteRecords.add(record);

            processState.getServiceLine()
                    .setClaimNoteRecords(claimNoteRecords);
        } else {
            processState.getServiceLine().getClaimNoteRecords()
                    .add(record);
        }
    }
}
