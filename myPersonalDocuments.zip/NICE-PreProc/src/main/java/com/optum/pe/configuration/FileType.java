package com.optum.pe.configuration;

public enum FileType {
    NICE_PE_EOP
}
