package com.optum.pe.nice;

import com.optum.pe.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@Slf4j
@Service
public class ZipAndMoveService {

    private final PathGetterService pathGetterService;

    public ZipAndMoveService(PathGetterService pathGetterService) {
        this.pathGetterService = pathGetterService;
    }

    public void moveFilesToArchiveFolder(Path dataFilePath, Path triggerFilePath) throws IOException {

        String archiveFilePath = pathGetterService.getArchivePath();

        File directory = Paths.get(archiveFilePath).toFile();

        if (!directory.exists() && directory.mkdir()) {
            log.error("not able to create the archive directory.");

            return;
        }

        if (triggerFilePath != null) {
            zipAndMoveFile(triggerFilePath);
        }

        if (dataFilePath != null) {
            zipAndMoveFile(dataFilePath);
        }
    }

    private void zipAndMoveFile(Path filePath) throws IOException {

        String fileName = getFileName(filePath);

        String zipFileName = fileName + "-"
                + LocalDateTime.now().format(DateTimeFormatter.ofPattern("ddMMyyyy-HHmmss"))
                + ".zip";

        Path zipFilePath = Paths.get(pathGetterService.getArchivePath()).resolve(zipFileName);

        File file = zipFilePath.toFile();

        if (createEmptyZipFile(file)) {
            return;
        }

        try (OutputStream fos = Files.newOutputStream(zipFilePath);
             ZipOutputStream zipOut = new ZipOutputStream(fos)) {
            write(filePath, zipOut);
        } catch (IOException ex) {
            throw new IOException(ex);
        }
        Files.delete(filePath);
    }

    private boolean createEmptyZipFile(File file) {
        try {
            if (!file.createNewFile()) {
                log.error("zip file already exists - " + file.getPath());

                return true;
            }
        } catch (IOException ex) {
            log.error("while creating the zip file - " + file.getPath());
            log.error("", ex);

            return true;
        }
        return false;
    }

    private String getFileName(Path filePath) {

        String fileName;

        if (filePath.getFileName().toString().endsWith(Constants.WIP_FILE_EXTENSION)) {

            fileName = filePath.getFileName().toString()
                    .replace(Constants.WIP_FILE_EXTENSION, "");
        } else {
            fileName = filePath.getFileName().toString();
        }

        return fileName;
    }

    private void write(Path pathToZip, ZipOutputStream zipOut) throws IOException {

        try (InputStream fis = Files.newInputStream(pathToZip)) {
            putZipEntry(pathToZip, zipOut);
            writeBytesToZipFile(zipOut, fis);
        } catch (IOException ex) {
            throw new IOException(ex);
        }
    }

    private void putZipEntry(Path pathToZip, ZipOutputStream zipOut) throws IOException {

        ZipEntry zipEntry = new ZipEntry((pathToZip.getFileName() + "")
                .replace(Constants.WIP_FILE_EXTENSION, ""));

        zipOut.putNextEntry(zipEntry);
    }

    private void writeBytesToZipFile(ZipOutputStream zipOut, InputStream fis) throws IOException {
        byte[] bytes = new byte[1024];
        int length;
        while ((length = fis.read(bytes)) >= 0) {
            zipOut.write(bytes, 0, length);
        }
    }
}
