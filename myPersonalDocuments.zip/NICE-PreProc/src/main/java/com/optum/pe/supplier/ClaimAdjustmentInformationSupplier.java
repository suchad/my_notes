package com.optum.pe.supplier;

import com.optum.pe.beans.mapping.ClaimAdjustmentInformation;
import com.optum.pe.beans.parsing.Adjustment;
import com.optum.pe.utils.Constants;
import com.optum.pe.utils.RecordType;
import org.springframework.stereotype.Service;

@Service
class ClaimAdjustmentInformationSupplier {

    ClaimAdjustmentInformation supply(String claimNumber, String checkNumber,
                                      int recordSequenceNumber, Adjustment adjustment) {

        ClaimAdjustmentInformation.ClaimAdjustmentInformationBuilder claimAdjustmentInformation
                = ClaimAdjustmentInformation.builder();

        claimAdjustmentInformation.recordType(RecordType.CLAIM_ADJUSTMENT.getLabel());
        claimAdjustmentInformation.partnerId(Constants.NICE_PARTNER_ID);
        claimAdjustmentInformation.consolidationId(checkNumber);
        claimAdjustmentInformation.adjudicationSystemId(Constants.ADJUDICATION_SYSTEM_ID);
        claimAdjustmentInformation.adjudicationSystemUniqueClaimNumber(claimNumber);
        claimAdjustmentInformation.adjudicationSystemUniqueClaimNumberTransactionSequenceNumber("");
        claimAdjustmentInformation.recordSequenceNumber(recordSequenceNumber + "");
        claimAdjustmentInformation._835CASClaimAdjustmentGroupCode(adjustment.getAdjustmentGroupCode());
        claimAdjustmentInformation._835CASClaimAdjustmentReasonCode(adjustment.getClaimAdjustmentReasonCode());
        claimAdjustmentInformation._835CASClaimAdjustmentAmount("");
        claimAdjustmentInformation._835CASClaimAdjustmentQuantity("");
        claimAdjustmentInformation.remarkCode("");
        claimAdjustmentInformation.remarkTextVersionKeyCode("");
        claimAdjustmentInformation.remarkAdditionalTextVersionKeyCode("");
        claimAdjustmentInformation.remarkQualifierCode("");
        claimAdjustmentInformation.remarkReferenceKey("");


        return claimAdjustmentInformation.build();
    }
}
