package com.optum.pe.supplier;

import com.optum.pe.beans.mapping.ClaimServiceLineInformation;
import com.optum.pe.beans.parsing.ServiceLine;
import com.optum.pe.service.ParameterConfigService;
import com.optum.pe.utils.Constants;
import com.optum.pe.utils.RecordType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Slf4j
@Service
class ClaimServiceLineInformationSupplier {

    private final ParameterConfigService parameterConfigService;
    
    public ClaimServiceLineInformationSupplier(ParameterConfigService parameterConfigService){
        this.parameterConfigService = parameterConfigService;
    }

    ClaimServiceLineInformation supply(String checkNumber, String claimNumber,
                                       int transactionSequenceNumber, String vendorId, int adjudicationSystemNumber,
                                       ServiceLine serviceLine) {

        ClaimServiceLineInformation.ClaimServiceLineInformationBuilder claimServiceLineInformation
                = ClaimServiceLineInformation.builder();

        claimServiceLineInformation.recordType(RecordType.CLAIM_SERVICE_LINE.getLabel());
        claimServiceLineInformation.partnerId(Constants.NICE_PARTNER_ID);
        claimServiceLineInformation.consolidationId(checkNumber);
        claimServiceLineInformation.adjudicationSystemId(Constants.ADJUDICATION_SYSTEM_ID);
        claimServiceLineInformation.adjudicationSystemUniqueClaimNumber(claimNumber);
        claimServiceLineInformation.adjudicationSystemUniqueClaimNumberTransactionSequenceNumber(transactionSequenceNumber + "");
        claimServiceLineInformation.serviceLineAdjudicationSystemNumber(adjudicationSystemNumber + "");
        claimServiceLineInformation.serviceLineControlNumberReceivedOnTheClaimAsAssignedByTheProvider("");
        claimServiceLineInformation.serviceLineServiceType("");
        claimServiceLineInformation.serviceLineSubmittedCodeQualifier("");
        claimServiceLineInformation.serviceLineSubmittedServiceCode("");
        claimServiceLineInformation.submittedModifierCode1("");
        claimServiceLineInformation.submittedModifierCode2("");
        claimServiceLineInformation.submittedModifierCode3("");
        claimServiceLineInformation.submittedModifierCode4("");
        claimServiceLineInformation.adjudicatedServiceCodeQualifier("");
        claimServiceLineInformation.adjudicatedServiceCode(getAdjudicatedServiceCode(serviceLine.getServiceCode()));
        claimServiceLineInformation.adjudicatedModifierCode1(getAdjudicatedModifierCode1(serviceLine.getServiceCode()));
        claimServiceLineInformation.adjudicatedModifierCode2("");
        claimServiceLineInformation.adjudicatedModifierCode3("");
        claimServiceLineInformation.adjudicatedModifierCode4("");
        claimServiceLineInformation.submittedSupplementalServiceCode("");
        claimServiceLineInformation.adjudicatedSupplementalServiceCode("");
        claimServiceLineInformation.submittedUnitsOfService("");
        claimServiceLineInformation.adjudicatedUnitsOfService("");
        claimServiceLineInformation.serviceCodeShortDescription("");

        claimServiceLineInformation.serviceLineServiceStartDate(
                HelperSupplier.getFormattedDate(serviceLine.getServiceDate()));

        claimServiceLineInformation.serviceLineServiceEndDate(Constants.MAX_DATE);
        claimServiceLineInformation.serviceLineInfoOnlyIndicator("");
        claimServiceLineInformation.serviceLineApprovedOrDeniedIndicator("");
        claimServiceLineInformation.serviceLineAmountBilled(HelperSupplier.removeComma(serviceLine.getChargeAmount()));
        claimServiceLineInformation.serviceLineAmountPended("");

        claimServiceLineInformation.serviceLineAmountApprovedOrAllowedByPlan(
                getAmountApprovedOrAllowedByPlan());
        if (parameterConfigService.isNiceDeployedCode() && serviceLine.getQpa() != null) {
            BigDecimal qpa = new BigDecimal(serviceLine.getQpa().trim());
            if (BigDecimal.ZERO.compareTo(qpa) != 0) {
                claimServiceLineInformation.contractedAmount(serviceLine.getQpa().trim());
            }
        } else {
            claimServiceLineInformation.contractedAmount("");
        }
        claimServiceLineInformation.serviceLinePlanPaidAmount(
                HelperSupplier.getAmount(serviceLine.getPaySign(),
                        HelperSupplier.removeComma(getAmountOnBasisOfPayeeTyp(vendorId, serviceLine))));

        claimServiceLineInformation.totalPatientResponsibilityAmount("");

        claimServiceLineInformation.maxSubscriberPotentialLiabilityAmount("");
        claimServiceLineInformation.coinsurancePercentage("");

        // eob display indicator
        claimServiceLineInformation.displayIndicator(getEOBDisplayIndicator(vendorId));
        claimServiceLineInformation.paidToCode("");
        claimServiceLineInformation.memberResponsibilityTypeIndicator("");
        claimServiceLineInformation.medicareCoveredIndicator("");
        claimServiceLineInformation.serviceAppliesToMOOPIndicator("");
        claimServiceLineInformation.sgaIndicator("");
        claimServiceLineInformation.serviceLineInNetworkIndicator("");
        claimServiceLineInformation.serviceLineReferralStatusCode("");
        claimServiceLineInformation.remarkCode1(serviceLine.getRemarkAdjustmentReasonCode());
        claimServiceLineInformation.remarkCode2("");
        claimServiceLineInformation.remarkCode3("");
        claimServiceLineInformation.remarkCode4("");
        claimServiceLineInformation.remarkCode5("");
        claimServiceLineInformation.ansiCode1("");
        claimServiceLineInformation.ansiCode2("");
        claimServiceLineInformation.ansiCode3("");
        claimServiceLineInformation.ansiCode4("");
        claimServiceLineInformation.ansiCode5("");
        claimServiceLineInformation.apcPricingCode("");
        claimServiceLineInformation.opgGroupCode("");
        claimServiceLineInformation.apcStatusIndicator("");
        claimServiceLineInformation.apcReturnCode("");
        claimServiceLineInformation.oceEditCode("");
        claimServiceLineInformation.preventiveServiceCode("");
        claimServiceLineInformation.capitationIndicator("");
        claimServiceLineInformation.remarkQualifierCode1("");
        claimServiceLineInformation.remarkQualifierCode2("");
        claimServiceLineInformation.remarkQualifierCode3("");
        claimServiceLineInformation.remarkQualifierCode4("");
        claimServiceLineInformation.remarkQualifierCode5("");
        claimServiceLineInformation.renderingProviderTinNumber("");
        claimServiceLineInformation.adjudicationSystemAssignedRenderingProviderIdNumber("");
        claimServiceLineInformation.payorAssignedRenderingProviderIdNumber("");
        claimServiceLineInformation.renderingProviderNPINumber("");
        claimServiceLineInformation.renderingProviderType("");
        claimServiceLineInformation.renderingProviderFirstName("");
        claimServiceLineInformation.renderingProviderMiddleName("");
        claimServiceLineInformation.renderingProviderLastName("");
        claimServiceLineInformation.renderingProviderSuffix("");
        claimServiceLineInformation.renderingProviderEntityName("");
        claimServiceLineInformation.renderingProviderInNetworkCode("");
        claimServiceLineInformation.renderingProviderBillingStreetAddress1("");
        claimServiceLineInformation.renderingProviderBillingStreetAddress2("");
        claimServiceLineInformation.renderingProviderBillingStreetAddress3("");
        claimServiceLineInformation.renderingProviderBillingStreetAddress4("");
        claimServiceLineInformation.renderingProviderBillingStreetAddress5("");
        claimServiceLineInformation.renderingProviderBillingStreetAddress6("");
        claimServiceLineInformation.renderingProviderBillingStreetAddress7("");
        claimServiceLineInformation.renderingProviderBillingCity("");
        claimServiceLineInformation.renderingProviderBillingAddressState("");
        claimServiceLineInformation.renderingProviderBillingZipCode("");
        claimServiceLineInformation.renderingProviderBillingCountryCode("");
        claimServiceLineInformation.renderingProviderPOSStreetAddress1("");
        claimServiceLineInformation.renderingProviderPOSStreetAddress2("");
        claimServiceLineInformation.renderingProviderPOSStreetAddress3("");
        claimServiceLineInformation.renderingProviderPOSStreetAddress4("");
        claimServiceLineInformation.renderingProviderPOSStreetAddress5("");
        claimServiceLineInformation.renderingProviderPOSStreetAddress6("");
        claimServiceLineInformation.renderingProviderPOSStreetAddress7("");
        claimServiceLineInformation.renderingProviderPOSCity("");
        claimServiceLineInformation.renderingProviderPOSAddressState("");
        claimServiceLineInformation.renderingProviderPOSZipCode("");
        claimServiceLineInformation.renderingProviderPOSCountryCode("");
        claimServiceLineInformation.renderingProviderPrimaryPhoneNumber("");
        claimServiceLineInformation.referringProviderTinNumber("");
        claimServiceLineInformation.adjudicationSystemAssignedReferringProviderIdNumber("");
        claimServiceLineInformation.payorAssignedReferringProviderIdNumber("");
        claimServiceLineInformation.referringProviderNPINumber("");
        claimServiceLineInformation.referringProviderType("");
        claimServiceLineInformation.referringProviderFirstName("");
        claimServiceLineInformation.referringProviderMiddleName("");
        claimServiceLineInformation.referringProviderLastName("");
        claimServiceLineInformation.referringProviderSuffix("");
        claimServiceLineInformation.referringProviderEntityName("");
        claimServiceLineInformation.referringProviderInNetworkCode("");
        claimServiceLineInformation.referringProviderBillingStreetAddress1("");
        claimServiceLineInformation.referringProviderBillingStreetAddress2("");
        claimServiceLineInformation.referringProviderBillingStreetAddress3("");
        claimServiceLineInformation.referringProviderBillingStreetAddress4("");
        claimServiceLineInformation.referringProviderBillingStreetAddress5("");
        claimServiceLineInformation.referringProviderBillingStreetAddress6("");
        claimServiceLineInformation.referringProviderBillingStreetAddress7("");
        claimServiceLineInformation.referringProviderBillingCity("");
        claimServiceLineInformation.referringProviderBillingAddressState("");
        claimServiceLineInformation.referringProviderBillingZipCode("");
        claimServiceLineInformation.referringProviderBillingCountryCode("");
        claimServiceLineInformation.referringProviderPOSStreetAddress1("");
        claimServiceLineInformation.referringProviderPOSStreetAddress2("");
        claimServiceLineInformation.referringProviderPOSStreetAddress3("");
        claimServiceLineInformation.referringProviderPOSStreetAddress4("");
        claimServiceLineInformation.referringProviderPOSStreetAddress5("");
        claimServiceLineInformation.referringProviderPOSStreetAddress6("");
        claimServiceLineInformation.referringProviderPOSStreetAddress7("");
        claimServiceLineInformation.referringProviderPOSCity("");
        claimServiceLineInformation.referringProviderPOSAddressState("");
        claimServiceLineInformation.referringProviderPOSZipCode("");
        claimServiceLineInformation.referringProviderPOSCountryCode("");
        claimServiceLineInformation.referringProviderPrimaryPhoneNumber("");
        claimServiceLineInformation.appealCode("");
        claimServiceLineInformation.planCopayAmountForCategory("");
        claimServiceLineInformation.remarkTextVersionKeyCode1("");
        claimServiceLineInformation.remarkTextVersionKeyCode2("");
        claimServiceLineInformation.remarkTextVersionKeyCode3("");
        claimServiceLineInformation.remarkTextVersionKeyCode4("");
        claimServiceLineInformation.remarkTextVersionKeyCode5("");
        claimServiceLineInformation.remarkAdditionalTextVersionKeyCode1("");
        claimServiceLineInformation.remarkAdditionalTextVersionKeyCode2("");
        claimServiceLineInformation.remarkAdditionalTextVersionKeyCode3("");
        claimServiceLineInformation.remarkAdditionalTextVersionKeyCode4("");
        claimServiceLineInformation.remarkAdditionalTextVersionKeyCode5("");
        claimServiceLineInformation.copay("");
        claimServiceLineInformation.coins("");
        claimServiceLineInformation.deductible("");
        claimServiceLineInformation.remarkCode1ReferenceKey("");
        claimServiceLineInformation.remarkCode2ReferenceKey("");
        claimServiceLineInformation.remarkCode3ReferenceKey("");
        claimServiceLineInformation.remarkCode4ReferenceKey("");
        claimServiceLineInformation.remarkCode5ReferenceKey("");
        claimServiceLineInformation.paidByOtherInsurance("");
        claimServiceLineInformation.paidByMedicare("");
        claimServiceLineInformation.providerDiscountAmount("");
        claimServiceLineInformation.notCoveredPatientResponsibilityAmount("");
        claimServiceLineInformation.medicareEstimatedPaymentAmount("");
        claimServiceLineInformation.renderingProviderIdQualifier("");
        claimServiceLineInformation.renderingProviderId("");
        claimServiceLineInformation.capitationFundCode("");
        claimServiceLineInformation.providerPRAServiceLineDisplayIndicator(getPRADisplayIndicator(vendorId));
        claimServiceLineInformation._835ServiceLineDisplayIndicator("N");
        claimServiceLineInformation.freeFormRemarkCode("");
        claimServiceLineInformation.freeFormRemarkText("");
        claimServiceLineInformation.submittedSupplementalServiceCodeQualifier("");
        claimServiceLineInformation.adjudicatedSupplementalServiceCodeQualifier("");

        claimServiceLineInformation.serviceLinePlanPaidAmountToTheProvider(
                getPlanPaidAmountToTheProvider(vendorId, serviceLine));

        claimServiceLineInformation.serviceLinePlanPaidAmountToTheMember(
                HelperSupplier.removeComma(getServiceLinePlanPaidAmountToTheMemberConditionally(vendorId, serviceLine.getPayAmount(), Constants.ZERO_AMOUNT)));

        claimServiceLineInformation.submittedServiceCodeDescription("");
        claimServiceLineInformation.submittedSupplementalServiceCodeDescription("");
        claimServiceLineInformation.adjudicatedServiceCodeDescription("");
        claimServiceLineInformation.adjudicatedSupplementalServiceCodeDescription("");
        claimServiceLineInformation.providerNotCoveredAmount("");
        claimServiceLineInformation.serviceLineReportingPaidAmountToProviderByExternalPayer("");
        claimServiceLineInformation.serviceLineReportingPaidAmountToMemberByExternalPayer("");
        claimServiceLineInformation.serviceLinePaidAmountToProviderByExternalPayer("");
        claimServiceLineInformation.serviceLinePaidAmountToMemberByExternalPayer("");
        claimServiceLineInformation.serviceLineTotalPaidAmountByExternalPayer("");
        if(parameterConfigService.isNiceDeployedCode()) {
            claimServiceLineInformation.serviceLinePharmacyCouponEligibleIndicator("");
            claimServiceLineInformation.serviceLinePharmacyCouponAmount("");
            claimServiceLineInformation.serviceLinePharmacyCouponPatientResponsibleAmount("");
            claimServiceLineInformation.serviceLinePharmacyCouponDeductableAfterCouponAmount("");
            claimServiceLineInformation.serviceLinePharmacyCouponPatientResponsibilityAfterCouponAmount("");
            claimServiceLineInformation.serviceLinePharmacyCouponCoinsuranceAfterCouponAmount("");
            if (serviceLine.getQpa() != null) {
                BigDecimal qpa = new BigDecimal(serviceLine.getQpa().trim());
                if (BigDecimal.ZERO.compareTo(qpa) != 0) {
                    claimServiceLineInformation.serviceLineSurpriseBillCode(Constants.FEDERAL);
                }else {
                    claimServiceLineInformation.serviceLineSurpriseBillCode("");
                } 
            }
        }

        return claimServiceLineInformation.build();
    }

    private String getServiceLinePlanPaidAmountToTheMemberConditionally(String vendorId, String payAmount, String zeroAmount) {
        return Constants.SUBSCRIBER_CODE.equals(HelperSupplier.getPayeeType(vendorId)) ? payAmount : zeroAmount;
    }

    private String getAmountOnBasisOfPayeeTyp(String vendorId, ServiceLine serviceLine) {
        return getServiceLinePlanPaidAmountToTheMemberConditionally(vendorId, getPlanPaidAmountToTheMember(vendorId, serviceLine), serviceLine.getPayAmount());
    }

    private String getPRADisplayIndicator(String vendorId) {

        String payeeType = HelperSupplier.getPayeeType(vendorId);

        if (Constants.PROVIDER_CODE.equals(payeeType)) {
            return "Y";
        }

        return "N";
    }

    private String getEOBDisplayIndicator(String vendorId) {

        String payeeType = HelperSupplier.getPayeeType(vendorId);

        if (Constants.SUBSCRIBER_CODE.equals(payeeType)) {
            return "Y";
        }

        return "N";
    }

    private String getPlanPaidAmountToTheMember(String vendorId, ServiceLine serviceLine) {

        String payeeType = HelperSupplier.getPayeeType(vendorId);

        if (Constants.SUBSCRIBER_CODE.equals(payeeType)) {

            BigDecimal amount = getSumOfAdjustmentAmountsFor(serviceLine);

            return amount.toString();
        }

        return Constants.ZERO_AMOUNT;
    }

    private String getPlanPaidAmountToTheProvider(String vendorId, ServiceLine serviceLine) {

        String payeeType = HelperSupplier.getPayeeType(vendorId);

        if (Constants.PROVIDER_CODE.equals(payeeType)) {

            BigDecimal amount = getSumOfAdjustmentAmountsFor(serviceLine);

            return amount.toString();
        }

        return Constants.ZERO_AMOUNT;
    }

    private BigDecimal getSumOfAdjustmentAmountsFor(ServiceLine serviceLine) {

        BigDecimal amount = new BigDecimal(Constants.ZERO_AMOUNT);

        if (serviceLine.getAdjustmentList() != null) {
            amount = serviceLine.getAdjustmentList().stream()
                    .map(adjustment -> HelperSupplier.getAmount(adjustment.getPaySign(), adjustment.getPayAmount()))
                    .map(HelperSupplier::getBigDecimal)
                    .reduce(new BigDecimal(Constants.ZERO_AMOUNT), BigDecimal::add);
        }

        amount = amount.add(
                HelperSupplier.getBigDecimal(
                        HelperSupplier.getAmount(serviceLine.getPaySign(), HelperSupplier.removeComma(serviceLine.getPayAmount()))));

        return amount;
    }

    private String getAdjudicatedModifierCode1(String serviceCode) {

        if (serviceCode.length() > 7) {
            return serviceCode.substring(6, 8).trim();
        }

        return "";
    }

    private String getAdjudicatedServiceCode(String serviceCode) {

        if (serviceCode.length() > 4) {
            return serviceCode.substring(0, 5).trim();
        }

        return "";
    }

    private String getAmountApprovedOrAllowedByPlan() {

        return Constants.ZERO_AMOUNT;
    }
}
