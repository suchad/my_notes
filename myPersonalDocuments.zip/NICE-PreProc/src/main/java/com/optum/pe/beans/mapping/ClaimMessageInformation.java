package com.optum.pe.beans.mapping;

import lombok.Builder;
import lombok.Getter;

import java.util.StringJoiner;

@Builder
@Getter
public class ClaimMessageInformation {

    private String recordType;
    private String partnerId;
    private String consolidationId;
    private String adjudicationSystemId;
    private String adjudicationSystemUniqueClaimNumber;
    private String adjudicationSystemUniqueClaimNumberTransactionSequenceNumber;
    private String recordSequenceNumber;
    private String documentTypeCode;
    private String messageCode;
    private String messageText;
    private String messagePlacementCode;
    private String messageSequenceNumber;
    private String messageServiceLineNumber;

    @Override
    public String toString() {
        return new StringJoiner("|", "", "|")
                .add(recordType)
                .add(partnerId)
                .add(consolidationId)
                .add(adjudicationSystemId)
                .add(adjudicationSystemUniqueClaimNumber)
                .add(adjudicationSystemUniqueClaimNumberTransactionSequenceNumber)
                .add(recordSequenceNumber)
                .add(documentTypeCode)
                .add(messageCode)
                .add(messageText)
                .add(messagePlacementCode)
                .add(messageSequenceNumber)
                .add(messageServiceLineNumber)
                .toString();
    }
}
