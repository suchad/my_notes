package com.optum.pe.beans.mapping;

import lombok.Builder;
import lombok.Getter;

import java.util.StringJoiner;

@Builder
@Getter
public class ServiceCenterInformation {

    private String recordType;
    private String partnerId;
    private String consolidationId;
    private String adjudicationSystemId;
    private String adjudicationSystemUniqueClaimNumber;
    private String adjudicationSystemUniqueClaimNumberTransactionSequenceNumber;
    private String subscriberServiceCenterName;
    private String subscriberServiceCenterStreetAddress1;
    private String subscriberServiceCenterStreetAddress2;
    private String subscriberServiceCenterCity;
    private String subscriberServiceCenterState;
    private String subscriberServiceCenterZip;
    private String subscriberCustomerServiceContactPersonFirstName;
    private String subscriberCustomerServiceContactPersonLastName;
    private String subscriberServiceCenterWebsiteUrl;
    private String subscriberServiceCenterPhoneNumber;
    private String subscriberServiceCenterTTYOrTDDPhoneNumber;
    private String subscriberServiceCenterForeignLanguagePhoneNumber;
    private String subscriberServiceCenterForeignLanguageNumberQualifier;
    private String subscriberServiceCenterOperatingDays;
    private String subscriberServiceCenterOperatingTimes;
    private String providerServiceCenterName;
    private String providerServiceCenterStreetAddress1;
    private String providerServiceCenterStreetAddress2;
    private String providerServiceCenterCity;
    private String providerServiceCenterState;
    private String providerServiceCenterZip;
    private String providerCustomerServiceContactPersonFirstName;
    private String providerCustomerServiceContactPersonLastName;
    private String providerServiceCenterWebsiteUrl;
    private String providerServiceCenterPhoneNumber;
    private String providerServiceCenterTTYOrTDDPhoneNumber;
    private String subscriberServiceCenterPhoneExtensionNumber;
    private String subscriberServiceCenterFaxNumber;
    private String subscriberServiceCenterEmail;
    private String providerServiceCenterPhoneExtensionNumber;
    private String providerServiceCenterFaxNumber;
    private String providerServiceCenterEmail;
    private String policyHolderServiceCenterName;
    private String policyHolderServiceCenterStreetAddress1;
    private String policyHolderServiceCenterStreetAddress2;
    private String policyHolderServiceCenterCity;
    private String policyHolderServiceCenterState;
    private String policyHolderServiceCenterZip;
    private String policyHolderCustomerServiceContactPersonFirstName;
    private String policyHolderCustomerServiceContactPersonLastName;
    private String policyHolderServiceCenterWebsiteUrl;
    private String policyHolderServiceCenterEmail;
    private String policyHolderServiceCenterTollFreePhoneNumber;
    private String policyHolderServiceCenterTollFreePhoneExtensionNumber;
    private String policyHolderServiceCenterLocalPhoneNumber;
    private String policyHolderServiceCenterLocalPhoneExtensionNumber;
    private String policyHolderServiceCenterFaxNumber;
    private String policyHolderServiceCenterTTYOrTDDPhoneNumber;
    private String subscriberServiceCenterStreetAddress3;
    private String providerServiceCenterStreetAddress3;
    private String policyHolderServiceCenterStreetAddress3;

    @Override
    public String toString() {
        return new StringJoiner("|", "", "|")
                .add(recordType)
                .add(partnerId)
                .add(consolidationId)
                .add(adjudicationSystemId)
                .add(adjudicationSystemUniqueClaimNumber)
                .add(adjudicationSystemUniqueClaimNumberTransactionSequenceNumber)
                .add(subscriberServiceCenterName)
                .add(subscriberServiceCenterStreetAddress1)
                .add(subscriberServiceCenterStreetAddress2)
                .add(subscriberServiceCenterCity)
                .add(subscriberServiceCenterState)
                .add(subscriberServiceCenterZip)
                .add(subscriberCustomerServiceContactPersonFirstName)
                .add(subscriberCustomerServiceContactPersonLastName)
                .add(subscriberServiceCenterWebsiteUrl)
                .add(subscriberServiceCenterPhoneNumber)
                .add(subscriberServiceCenterTTYOrTDDPhoneNumber)
                .add(subscriberServiceCenterForeignLanguagePhoneNumber)
                .add(subscriberServiceCenterForeignLanguageNumberQualifier)
                .add(subscriberServiceCenterOperatingDays)
                .add(subscriberServiceCenterOperatingTimes)
                .add(providerServiceCenterName)
                .add(providerServiceCenterStreetAddress1)
                .add(providerServiceCenterStreetAddress2)
                .add(providerServiceCenterCity)
                .add(providerServiceCenterState)
                .add(providerServiceCenterZip)
                .add(providerCustomerServiceContactPersonFirstName)
                .add(providerCustomerServiceContactPersonLastName)
                .add(providerServiceCenterWebsiteUrl)
                .add(providerServiceCenterPhoneNumber)
                .add(providerServiceCenterTTYOrTDDPhoneNumber)
                .add(subscriberServiceCenterPhoneExtensionNumber)
                .add(subscriberServiceCenterFaxNumber)
                .add(subscriberServiceCenterEmail)
                .add(providerServiceCenterPhoneExtensionNumber)
                .add(providerServiceCenterFaxNumber)
                .add(providerServiceCenterEmail)
                .add(policyHolderServiceCenterName)
                .add(policyHolderServiceCenterStreetAddress1)
                .add(policyHolderServiceCenterStreetAddress2)
                .add(policyHolderServiceCenterCity)
                .add(policyHolderServiceCenterState)
                .add(policyHolderServiceCenterZip)
                .add(policyHolderCustomerServiceContactPersonFirstName)
                .add(policyHolderCustomerServiceContactPersonLastName)
                .add(policyHolderServiceCenterWebsiteUrl)
                .add(policyHolderServiceCenterEmail)
                .add(policyHolderServiceCenterTollFreePhoneNumber)
                .add(policyHolderServiceCenterTollFreePhoneExtensionNumber)
                .add(policyHolderServiceCenterLocalPhoneNumber)
                .add(policyHolderServiceCenterLocalPhoneExtensionNumber)
                .add(policyHolderServiceCenterFaxNumber)
                .add(policyHolderServiceCenterTTYOrTDDPhoneNumber)
                .add(subscriberServiceCenterStreetAddress3)
                .add(providerServiceCenterStreetAddress3)
                .add(policyHolderServiceCenterStreetAddress3)
                .toString();
    }
}
