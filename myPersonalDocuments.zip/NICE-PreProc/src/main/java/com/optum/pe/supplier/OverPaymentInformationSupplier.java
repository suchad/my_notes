package com.optum.pe.supplier;

import com.optum.pe.beans.mapping.OverPaymentInformation;
import com.optum.pe.beans.parsing.ClaimDetailRecord;
import com.optum.pe.beans.parsing.ClaimHeaderRecord;
import com.optum.pe.utils.Constants;
import com.optum.pe.utils.RecordType;
import org.springframework.stereotype.Service;

@Service
class OverPaymentInformationSupplier {

    OverPaymentInformation supply(String consolidationId, String vendorId,
                                  int recordSequenceNumber,
                                  ClaimDetailRecord claimDetailRecord,
                                  ClaimHeaderRecord claimHeaderRecord, String checkDate) {

        OverPaymentInformation.OverPaymentInformationBuilder overPaymentInformation
                = OverPaymentInformation.builder();

        overPaymentInformation.recordType(RecordType.OVER_PAYMENT.getLabel());
        overPaymentInformation.partnerId(Constants.NICE_PARTNER_ID);
        overPaymentInformation.consolidationId(consolidationId);
        overPaymentInformation.recordSequenceNumber(recordSequenceNumber + "");

        overPaymentInformation.recoverySourceIndicator(HelperSupplier.getPayeeType(vendorId));

        overPaymentInformation.originalSubscriberIdNumberQualifier("");

        overPaymentInformation.originalSubscriberIdentificationNumber(claimHeaderRecord.getSubscriberId());

        overPaymentInformation.originalPatientNamePrefix("");

        overPaymentInformation.originalPatientFirstName(claimHeaderRecord.getPatientFirstName());
        overPaymentInformation.originalPatientMiddleName(claimHeaderRecord.getPatientMiddleInitial() + "");
        overPaymentInformation.originalPatientLastName(claimHeaderRecord.getPatientLastName());
        overPaymentInformation.originalPatientNameSuffix("");
        overPaymentInformation.originalPatientDependentSequenceNumber("");
        overPaymentInformation.originalRelationshipToSubscriber("");
        overPaymentInformation.originalPatientIdentificationNumber(claimHeaderRecord.getPcn());
        overPaymentInformation.originalPolicyGroupNumber(claimHeaderRecord.getEmpGroup());
        overPaymentInformation.originalClaimNumber(claimHeaderRecord.getClaimNumber());
        overPaymentInformation.originalClaimEarliestServiceStartDate(HelperSupplier.getFormattedDate(claimHeaderRecord.getFDos()));
        overPaymentInformation.originalClaimLatestServiceEndDate(HelperSupplier.getFormattedDate(claimHeaderRecord.getLDos()));
        overPaymentInformation.originalClaimTotalOverPaymentAmount("");
        overPaymentInformation.originalClaimOverPaymentAmountPreviouslyDeducted("");
        overPaymentInformation.originalClaimOverPaymentAmountCurrentlyDeducted(
                HelperSupplier.getAmount(claimDetailRecord.getAdjustedSign(),
                        HelperSupplier.removeComma(claimDetailRecord.getAdjustedAmount())));
        overPaymentInformation.originalClaimOverPaymentAmountRemaining("");
        overPaymentInformation.providerIdQualifier("");
        overPaymentInformation.providerId(vendorId.trim());
        overPaymentInformation.previousCheckNumber("");
        overPaymentInformation.remarkMessageCode(getRemarkMessageCode(claimDetailRecord));
        overPaymentInformation.remarkMessageText(claimDetailRecord.getAdjustedReason());
        overPaymentInformation.dateOverPaymentEstablished(HelperSupplier.getFormattedDate(checkDate));

        return overPaymentInformation.build();
    }

    private String getRemarkMessageCode(ClaimDetailRecord claimDetailRecord) {

        if (Constants.RECOVERY_SERVICE_CODE.equals(claimDetailRecord.getServiceCode())) {
            return claimDetailRecord.getRemarkAdjustmentReasonCode();
        } else {
            return "IOR";
        }
    }
}
