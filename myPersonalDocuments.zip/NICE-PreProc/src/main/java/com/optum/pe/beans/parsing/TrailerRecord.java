package com.optum.pe.beans.parsing;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class TrailerRecord implements Record {

    private String recordType;
    private String totalChecks;
    private char totalPaymentSign;
    private String totalPaymentAmount;
    private String totalRecordCount;
    private String processDate;
}

