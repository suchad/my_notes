package com.optum.pe.beans.parsing;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.List;
import java.util.Map;

@Builder
@Getter
@Setter
public class CheckRecord implements Record {

    private String recordType;
    private String bankCode;
    private String coDivCode;
    private char eraIndicator;

    private String checkNumber;
    private String checkDate;
    private String checkAmount;

    private String vendorId;
    private String vendorName;
    private String addrLine1;
    private String addrLine2;

    private String addrCity;
    private String addrState;
    private String addrZipCode;

    private char achIndicator;

    private String mPin;
    private String taxId;
    private char tinType;
    private String npi;

    List<ClaimHeaderRecord> claimHeaderRecordList;

    List<Adjustment> adjustmentList;

    private int lines;

    private Integer highestId;
    private Map<String, String> serviceProviderIdMap;
}
