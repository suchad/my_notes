package com.optum.pe.beans.mapping;

import lombok.Builder;
import lombok.Getter;

import java.util.StringJoiner;

@Builder
@Getter
public class SubscriberInformation {

    private String recordType;
    private String partnerId;
    private String consolidationId;
    private String adjudicationSystemId;
    private String adjudicationSystemUniqueClaimNumber;
    private String adjudicationSystemUniqueClaimNumberTransactionSequenceNumber;
    private String universalId;
    private String identificationNumberSubmitted;
    private String identificationNumberQualifierSubmitted;
    private String firstName;
    private String middleName;
    private String lastName;
    private String suffix;
    private String identificationNumberAdjudicated;
    private String identificationNumberQualifierAdjudicated;
    private String firstNameAdjudicated;
    private String middleNameAdjudicated;
    private String lastNameAdjudicated;
    private String suffixAdjudicated;
    private String mailingStreetAddress1;
    private String mailingStreetAddress2;
    private String mailingStreetAddress3;
    private String mailingStreetAddress4;
    private String mailingStreetAddress5;
    private String mailingStreetAddress6;
    private String mailingStreetAddress7;
    private String mailingCity;
    private String mailingState;
    private String mailingZip;
    private String countryCode;
    private String authorizedPartnerIndicator;
    private String coverageIdXRef;
    private String medicareMedicalSourceSystem;
    private String hicn;
    private String dateOfBirth;
    private String traditionalAccumulatorKey;
    private String namePrefix;
    private String namePrefixAdjudicated;

    @Override
    public String toString() {
        return new StringJoiner("|", "", "|")
                .add(recordType)
                .add(partnerId)
                .add(consolidationId)
                .add(adjudicationSystemId)
                .add(adjudicationSystemUniqueClaimNumber)
                .add(adjudicationSystemUniqueClaimNumberTransactionSequenceNumber)
                .add(universalId)
                .add(identificationNumberSubmitted)
                .add(identificationNumberQualifierSubmitted)
                .add(firstName)
                .add(middleName)
                .add(lastName)
                .add(suffix)
                .add(identificationNumberAdjudicated)
                .add(identificationNumberQualifierAdjudicated)
                .add(firstNameAdjudicated)
                .add(middleNameAdjudicated)
                .add(lastNameAdjudicated)
                .add(suffixAdjudicated)
                .add(mailingStreetAddress1)
                .add(mailingStreetAddress2)
                .add(mailingStreetAddress3)
                .add(mailingStreetAddress4)
                .add(mailingStreetAddress5)
                .add(mailingStreetAddress6)
                .add(mailingStreetAddress7)
                .add(mailingCity)
                .add(mailingState)
                .add(mailingZip)
                .add(countryCode)
                .add(authorizedPartnerIndicator)
                .add(coverageIdXRef)
                .add(medicareMedicalSourceSystem)
                .add(hicn)
                .add(dateOfBirth)
                .add(traditionalAccumulatorKey)
                .add(namePrefix)
                .add(namePrefixAdjudicated)
                .toString();
    }
}
