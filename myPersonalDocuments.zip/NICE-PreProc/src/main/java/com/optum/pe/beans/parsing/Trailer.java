package com.optum.pe.beans.parsing;

import lombok.Builder;
import lombok.Getter;

import java.math.BigDecimal;

@Getter
@Builder
public class Trailer implements Record {

    private String recordType;
    private int totalChecks;
    private BigDecimal totalPaymentAmount;
    private int totalRecordCount;
    private String processDate;
}