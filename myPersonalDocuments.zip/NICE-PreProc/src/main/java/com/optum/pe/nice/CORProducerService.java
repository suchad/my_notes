package com.optum.pe.nice;

import com.optum.pe.beans.parsing.CheckRecord;
import com.optum.pe.exception.LookupDataNotFoundException;
import com.optum.pe.models.CorDataStore;
import com.optum.pe.onepay.avro.OnePayClaimCOR;
import com.optum.pe.service.CorDataStoreService;
import com.optum.pe.supplier.OnePayClaimCORSupplier;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Slf4j
@Service
public class CORProducerService {

    private final OnePayClaimCORSupplier onePayClaimCORSupplier;
    private final ProcessStateFactory processStateFactory;
    private final CorDataStoreService corDataStoreService;

    CORProducerService(OnePayClaimCORSupplier onePayClaimCORSupplier,
                       ProcessStateFactory processStateFactory,
                       CorDataStoreService corDataStoreService) {
        this.onePayClaimCORSupplier = onePayClaimCORSupplier;
        this.processStateFactory = processStateFactory;
        this.corDataStoreService = corDataStoreService;
    }

    public void sendCurrentCheckRecordToDB(String fileName, boolean isLastPayment) {

        CheckRecord payment = processStateFactory.getProcessStateFor(fileName).getCheckRecord();
        LocalDate processDate = processStateFactory.getProcessStateFor(fileName).getCycleDate();

        try {
            OnePayClaimCOR onePayClaimCOR = onePayClaimCORSupplier.supply(payment, fileName, processDate);

            CorDataStore corDataStore = corDataStoreService.getCorDataStore(onePayClaimCOR, processDate, fileName, payment.getCheckNumber());

            corDataStoreService.save(corDataStore);

            if (isLastPayment) {
                log.info("last payment done - " + fileName);
            }
        } catch (LookupDataNotFoundException | RuntimeException ex) {
            log.error("", ex);
        }
    }
}
