package com.optum.pe.models;

import lombok.Data;
import lombok.Getter;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Data
@Getter
@Table(name = "PE01.CYCLE_DATE")
public class CycleDate implements Serializable {

    @EmbeddedId
    private CycleDatePK id;

    @Column(name = "CYC_DT_USED_IND")
    private String cycleDateUsedIndicator;

}
