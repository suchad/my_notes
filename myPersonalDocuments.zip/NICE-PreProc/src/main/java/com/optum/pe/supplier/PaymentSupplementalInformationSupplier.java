package com.optum.pe.supplier;

import com.optum.pe.beans.mapping.PaymentSupplementalInformation;
import com.optum.pe.utils.Constants;
import com.optum.pe.utils.RecordType;
import org.springframework.stereotype.Service;

import static com.optum.pe.supplier.HelperSupplier.getBlankForAsterisk;

@Service
class PaymentSupplementalInformationSupplier {

    PaymentSupplementalInformation supply(String checkNumber, String vendorId, String eraIndicator, String bankInfo) {

        PaymentSupplementalInformation.PaymentSupplementalInformationBuilder
                paymentSupplementalInformation
                = PaymentSupplementalInformation.builder();

        paymentSupplementalInformation.recordType(RecordType.PAYMENT_SUPPLEMENTAL.getLabel());
        paymentSupplementalInformation.partnerId(Constants.NICE_PARTNER_ID);
        paymentSupplementalInformation.consolidationId(checkNumber);
        paymentSupplementalInformation.recordSequenceNumber("1");
        paymentSupplementalInformation.userDefinedField1(vendorId.trim());
        paymentSupplementalInformation.userDefinedField2(eraIndicator.trim());
        paymentSupplementalInformation.userDefinedField3(getBlankForAsterisk(bankInfo.trim()));
        paymentSupplementalInformation.userDefinedField4("");
        paymentSupplementalInformation.userDefinedField5("");
        paymentSupplementalInformation.userDefinedField6("");
        paymentSupplementalInformation.userDefinedField7("");
        paymentSupplementalInformation.userDefinedField8("");
        paymentSupplementalInformation.userDefinedField9("");
        paymentSupplementalInformation.userDefinedField10("");

        return paymentSupplementalInformation.build();
    }
}