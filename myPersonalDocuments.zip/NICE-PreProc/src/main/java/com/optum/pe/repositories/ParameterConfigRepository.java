package com.optum.pe.repositories;

import com.optum.pe.models.ParameterConfigEntity;
import com.optum.pe.utils.Constants;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ParameterConfigRepository extends JpaRepository<ParameterConfigEntity, String> {
    
    @Cacheable(Constants.NICE_CDC_CACHE_NAME)
    public ParameterConfigEntity findByPartnerProcGrpIdAndParameterNm(String partnerProcGrpId, String parameterNm);
}