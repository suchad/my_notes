package com.optum.pe.beans.parsing;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class Adjustment implements Record {

    private String recordType;
    private String serviceCode;

    private String serviceDate;
    private String chargeAmount;

    private String adjustedAmount;
    private char adjustedSign;
    private String adjustedReason;

    private String payAmount;
    private char paySign;

    private String remarkAdjustmentReasonCode;
    private String adjustmentGroupCode;
    private String claimAdjustmentReasonCode;
}
