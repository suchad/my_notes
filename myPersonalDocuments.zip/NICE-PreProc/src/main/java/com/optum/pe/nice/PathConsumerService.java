package com.optum.pe.nice;

import com.optum.pe.configuration.DefaultConfiguration;
import com.optum.pe.nice.runnable.PathConsumerRunnable;
import com.optum.pe.parsers.FileParserFactory;
import org.springframework.stereotype.Service;

import java.nio.file.Path;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Service
class PathConsumerService {

    private final ExecutorService executorService;
    private final FileParserFactory fileParserFactory;

    PathConsumerService(DefaultConfiguration defaultConfiguration, FileParserFactory fileParserFactory) {
        this.fileParserFactory = fileParserFactory;

        executorService = Executors.newFixedThreadPool(defaultConfiguration.getThreads());
    }

    void consume(Path path) {
        executorService.submit(new PathConsumerRunnable(path, fileParserFactory));
    }

}
