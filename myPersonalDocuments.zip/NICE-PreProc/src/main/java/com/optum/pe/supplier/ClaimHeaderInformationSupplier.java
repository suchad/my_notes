package com.optum.pe.supplier;

import com.optum.pe.beans.mapping.ClaimHeaderInformation;
import com.optum.pe.beans.parsing.*;
import com.optum.pe.service.ParameterConfigService;
import com.optum.pe.utils.Constants;
import com.optum.pe.utils.RecordType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.util.Objects;

@Slf4j
@Service
class ClaimHeaderInformationSupplier {

    private final ParameterConfigService parameterConfigService;


    public ClaimHeaderInformationSupplier(ParameterConfigService parameterConfigService){
              this.parameterConfigService = parameterConfigService;
    }

    ClaimHeaderInformation supply(int transactionSequenceNumber, ClaimHeaderRecord claimHeaderRecord, CheckRecord payment) {


        ClaimHeaderInformation.ClaimHeaderInformationBuilder claimHeaderInformation
                = ClaimHeaderInformation.builder();

        String payeeType = HelperSupplier.getPayeeType(payment.getVendorId());

        claimHeaderInformation.recordType(RecordType.CLAIM_HEADER.getLabel());
        claimHeaderInformation.partnerId(Constants.NICE_PARTNER_ID);
        claimHeaderInformation.consolidationId(payment.getCheckNumber());
        claimHeaderInformation.adjudicationSystemId(Constants.ADJUDICATION_SYSTEM_ID);
        claimHeaderInformation.adjudicationSystemUniqueClaimNumber(claimHeaderRecord.getClaimNumber());
        claimHeaderInformation.adjudicationSystemUniqueClaimNumberTransactionSequenceNumber(transactionSequenceNumber + "");
        claimHeaderInformation.adjudicationSubSystemId("");
        claimHeaderInformation.claimsRepositoryId("");
        claimHeaderInformation.claimsRepositoryUniqueClaimId("");
        claimHeaderInformation.claimCoverageTypeCode("MD");
        claimHeaderInformation.claimTypeOfTransaction("00");
        claimHeaderInformation.claimCOBStatusCode("P");

        claimHeaderInformation.claimEarliestServiceStartDate(HelperSupplier.getFormattedDate(claimHeaderRecord.getFDos()));
        claimHeaderInformation.claimLatestServiceEndDate(HelperSupplier.getFormattedDate(claimHeaderRecord.getLDos()));

        claimHeaderInformation.claimTotalAmountBilled(
                HelperSupplier.removeComma(claimHeaderRecord.getClaimTotalRecord().getTotalCharges()));

        claimHeaderInformation.claimTotalAmountPended("");

        claimHeaderInformation.claimTotalAmountApproved(getTotalAmountApproved());

        claimHeaderInformation.claimTotalPlanPaidAmount(
                HelperSupplier.getAmount(claimHeaderRecord.getClaimTotalRecord().getTotalPaySign(),
                        HelperSupplier.removeComma(claimHeaderRecord.getClaimTotalRecord().getTotalPay())));

        claimHeaderInformation.claimTotalPlanPaidAmountPaidToTheProvider(
                HelperSupplier.getAmount(claimHeaderRecord.getClaimTotalRecord().getTotalProvisionalSign(),
                        HelperSupplier.removeComma(claimHeaderRecord.getClaimTotalRecord().getTotalProvisionalPay())));

        claimHeaderInformation.claimTotalPlanPaidAmountPaidToTheMember(
                getTotalPlanPaidAmountPaidToTheMember(payment.getVendorId(),
                        HelperSupplier.getAmount(claimHeaderRecord.getClaimTotalRecord().getTotalProvisionalSign(),
                                HelperSupplier.removeComma(claimHeaderRecord.getClaimTotalRecord().getTotalProvisionalPay()))));

        claimHeaderInformation.claimTotalAmountPaidToAnyOtherEntity("");

        claimHeaderInformation.claimTotalPatientResponsibilityAmount(
                getTotalPatientResponsibilityAmount(claimHeaderRecord));

        claimHeaderInformation.claimTotalPatientResponsibilityAmountForApprovedServices("");
        claimHeaderInformation.claimTotalPatientResponsibilityAmountForDeniedServices("");
        claimHeaderInformation.dateClaimWasReceivedByCarrier("");
        claimHeaderInformation.dateClaimWasFullyAdjudicatedByTheAdjudicationSystem("");
        claimHeaderInformation.claimSubmitterTypeCode("");
        claimHeaderInformation.claimSubmissionTypeCode("");
        claimHeaderInformation.remittanceDisplayClaimId(claimHeaderRecord.getClaimNumber());
        claimHeaderInformation.consolidationAdjudicationSystemId("");
        claimHeaderInformation.otherAdjudicationSystemAssociatedClaimNumber("");
        claimHeaderInformation.claimInNetworkIndicator("");
        claimHeaderInformation.eobCopyCode("N");
        claimHeaderInformation.globalHubIndicator("");
        claimHeaderInformation.documentCode("S");

        claimHeaderInformation.claimEOBPrintSuppressionIndicator("N");

        claimHeaderInformation.claimEOBPrintSuppressionReasonCode("");
        claimHeaderInformation.paymentSuppressionIndicator("");
        claimHeaderInformation.immediateReleaseIndicatorMember("");
        claimHeaderInformation.capitationIndicator("");
        claimHeaderInformation.privacyCode("");
        claimHeaderInformation.optOutIndicator("");
        claimHeaderInformation.payTheMemberIndicator("");
        claimHeaderInformation.claimInPatientIndicator("");
        claimHeaderInformation.claimServiceTypeCode(getServiceTypeCode(claimHeaderRecord));
        claimHeaderInformation.memberPaymentMethodCode("P");
        claimHeaderInformation.providerPaymentMethodCode(getPayMethodProvider(payment.getBankCode(), payeeType));
        claimHeaderInformation.preAuthorizationCode("");
        claimHeaderInformation.authorizationNumber("");
        claimHeaderInformation.drgCode("");
        claimHeaderInformation.drgWeight("");
        claimHeaderInformation.claimLevelAdjudicationSystemsOfficeCode("");
        claimHeaderInformation.claimLevelRemarkCode1("");
        claimHeaderInformation.claimLevelRemarkCode2("");
        claimHeaderInformation.claimLevelRemarkCode3("");
        claimHeaderInformation.claimLevelRemarkCode4("");
        claimHeaderInformation.claimLevelRemarkCode5("");
        claimHeaderInformation.ansiRMKCode1("");
        claimHeaderInformation.ansiRMKCode2("");
        claimHeaderInformation.ansiRMKCode3("");
        claimHeaderInformation.ansiRMKCode4("");
        claimHeaderInformation.ansiRMKCode5("");

        claimHeaderInformation.patientIdentificationNumber(
                getPatientIdentificationNumber(payment.getVendorId(),
                        claimHeaderRecord.getPcn()));

        claimHeaderInformation.promptPayState("");
        claimHeaderInformation.promptPayNoLaterThanPenaltyDate("");
        claimHeaderInformation.claimFilingIndicatorCode("");
        claimHeaderInformation.claimFacilityTypeCode("");
        claimHeaderInformation.claimFrequencyCode("");
        claimHeaderInformation.claimDischargeFraction("");
        claimHeaderInformation.claimCoverageEligibilityExpirationDate("");
        claimHeaderInformation.claimOriginalCheckNumber("");
        claimHeaderInformation.languageThresholdIndicator("");
        claimHeaderInformation.preferredLanguageCode("");
        claimHeaderInformation.thresholdLanguageCode1("");
        claimHeaderInformation.thresholdLanguageCode2("");
        claimHeaderInformation.thresholdLanguageCode3("");
        claimHeaderInformation.clapHMOIndicator("");
        claimHeaderInformation.clapIndicator("");
        claimHeaderInformation.clapRMKCode("");
        claimHeaderInformation.optSupplementalCoverageIndicator("");
        claimHeaderInformation.claimAppliesToMOOP("");
        claimHeaderInformation.peGenMonthlyEOB("N");
        claimHeaderInformation.praDocumentCode("S");
        claimHeaderInformation.rmkQualifierCode1("");
        claimHeaderInformation.rmkQualifierCode2("");
        claimHeaderInformation.rmkQualifierCode3("");
        claimHeaderInformation.rmkQualifierCode4("");
        claimHeaderInformation.rmkQualifierCode5("");
        claimHeaderInformation.finalizeDateTime("");
        claimHeaderInformation.coverageHasNetworkIndicator("");
        if (parameterConfigService.isNiceDeployedCode() && isQpaAmountInServiceLineList(claimHeaderRecord)) {
            claimHeaderInformation.claimEventCode(Constants.CLAIM_EVENT_CODE_SURPRISE_BILLING);
        } else {
            claimHeaderInformation.claimEventCode("");
        }
        claimHeaderInformation.rmkTextVersionKeyCode1("");
        claimHeaderInformation.rmkTextVersionKeyCode2("");
        claimHeaderInformation.rmkTextVersionKeyCode3("");
        claimHeaderInformation.rmkTextVersionKeyCode4("");
        claimHeaderInformation.rmkTextVersionKeyCode5("");
        claimHeaderInformation.rmkAdditionalTextVersionKeyCode1("");
        claimHeaderInformation.rmkAdditionalTextVersionKeyCode2("");
        claimHeaderInformation.rmkAdditionalTextVersionKeyCode3("");
        claimHeaderInformation.rmkAdditionalTextVersionKeyCode4("");
        claimHeaderInformation.rmkAdditionalTextVersionKeyCode5("");
        claimHeaderInformation.claimCoPay("");
        claimHeaderInformation.claimCoins("");
        claimHeaderInformation.claimDeductible("");
        claimHeaderInformation.remarkCode1ReferenceKey("");
        claimHeaderInformation.remarkCode2ReferenceKey("");
        claimHeaderInformation.remarkCode3ReferenceKey("");
        claimHeaderInformation.remarkCode4ReferenceKey("");
        claimHeaderInformation.remarkCode5ReferenceKey("");
        claimHeaderInformation.peGenPRA(getGenPRA(payment.getVendorId()));
        claimHeaderInformation.peGen835("N");
        claimHeaderInformation.pseudoClaimIndicator("N");
        claimHeaderInformation.claimStatusCode("");
        claimHeaderInformation.promptPaymentByPassIndicator("");
        claimHeaderInformation.desiredPaymentReleaseDateMemberEOB("");
        claimHeaderInformation.desiredPaymentReleaseDateProvider("");
        claimHeaderInformation.immediateReleaseIndicatorProvider("");
        claimHeaderInformation.erisaIndicator("");
        claimHeaderInformation.otherInsuranceType("");
        claimHeaderInformation.totalPaidByOtherInsurance("");
        claimHeaderInformation.totalPaidByMedicare("");

        claimHeaderInformation.providerDiscountAmount(
                HelperSupplier.getAmount(claimHeaderRecord.getClaimTotalRecord().getTotalAdjustedSign(),
                        HelperSupplier.removeComma(claimHeaderRecord.getClaimTotalRecord().getTotalAdjusted())));

        claimHeaderInformation.notCoveredPatientResponsibility("");
        claimHeaderInformation.medicareEstimatedPaymentAmount("");

        claimHeaderInformation.claimPRAPrintSuppressionIndicator(
                getPrintSuppressionIndicator(payeeType, payment.getEraIndicator(),
                        payment.getBankCode()));

        claimHeaderInformation.reversalCorrectionAssociationId("");
        claimHeaderInformation.resubmitIndicator("");
        claimHeaderInformation.dateOriginalClaimWasReceivedByCarrier("");
        claimHeaderInformation.promptPaymentClaimStoppedDate("");
        claimHeaderInformation.cleanClaimIndicator("");
        claimHeaderInformation.correctionClaimPaymentChangeCode("");
        claimHeaderInformation.sgaIndicator("");
        claimHeaderInformation.patientMedicalRecordNumber("");
        claimHeaderInformation.freeformRemarkCode("");
        claimHeaderInformation.freeformRemarkText("");

        claimHeaderInformation.claimTotalReportingPaidAmountToProvider(
                getTotalReportingPaidAmountToProvider(payeeType,
                        HelperSupplier.getAmount(claimHeaderRecord.getClaimTotalRecord().getTotalPaySign(),
                                HelperSupplier.removeComma(claimHeaderRecord.getClaimTotalRecord().getTotalPay()))));

        claimHeaderInformation.claimTotalReportingPaidAmountToMember(
                getTotalReportingPaidAmountToMember(payeeType,
                        HelperSupplier.getAmount(claimHeaderRecord.getClaimTotalRecord().getTotalPaySign(),
                                HelperSupplier.removeComma(claimHeaderRecord.getClaimTotalRecord().getTotalPay()))));

        claimHeaderInformation.compliance835RejectByPassIndicator("");
        claimHeaderInformation.remittanceAdviceCode1("");
        claimHeaderInformation.remittanceAdviceCode2("");
        claimHeaderInformation.remittanceAdviceCode3("");
        claimHeaderInformation.remittanceAdviceCode4("");
        claimHeaderInformation.remittanceAdviceCode5("");
        claimHeaderInformation.adjudicationSystemUniqueSubmittedClaimNumber("");
        claimHeaderInformation.adjudicationSystemOriginalUniqueClaimNumberTransactionSequenceNumber("");
        claimHeaderInformation.adjudicatedPerManagedCareContractIndicator("");
        claimHeaderInformation.adjudicatedPrePPOContractIndicator("");
        claimHeaderInformation.adjudicationSyatemOriginalClaimControlNumber("");
        claimHeaderInformation.promptPaymentSpecialFacilityCode("");
        claimHeaderInformation.cobCreditSavingsAppliedToPaymentIndicator("");
        claimHeaderInformation.benefitDenialMessageReasonCode("");
        claimHeaderInformation.divertProviderPaymentIndicator("");
        claimHeaderInformation.divertMemberPaymentIndicator("");
        claimHeaderInformation.dedOOPReachedCode("");
        claimHeaderInformation.memberEOBPolicyElectionSuppressionReportingCode("");
        claimHeaderInformation.eobSubscriberElectionSuppressReportingCode("");
        claimHeaderInformation.peGenMemberEOB(getGenMemberEOB(payment.getVendorId()));
        claimHeaderInformation.providerNotCoveredAmount("");
        claimHeaderInformation.divertProviderPRAIndicator("");
        claimHeaderInformation.divertMemberEOBIndicator("");
        claimHeaderInformation.otherAdjudicationSystemAssociatedClaimTransactionSequenceNumber("");
        claimHeaderInformation.otherAdjudicationSystemAssociatedPolicyGroupNumber("");
        claimHeaderInformation.interestOnlyClaimIndicator("");
        claimHeaderInformation.interestClaimAssociationId("");
        claimHeaderInformation.surchargeOnlyClaimIndicator("");
        claimHeaderInformation.providerEOBTierMessageIndicator("");
        claimHeaderInformation.reverseInterestOriginalClaimIndicator("");
        claimHeaderInformation.originalPaidAmount("");
        claimHeaderInformation.benefitLevel("");
        claimHeaderInformation.peORMSInSyncIndicator("");
        claimHeaderInformation.splitClaimAssociationId("");
        claimHeaderInformation.ccClaimNumber("");
        claimHeaderInformation.ccReceiptDate("");
        claimHeaderInformation.ccClosureLetterDate("");
        claimHeaderInformation.ccReasonCode("");
        claimHeaderInformation.externalPayerIndicator("");
        claimHeaderInformation.claimReportingPaidAmountToProviderByExternalPayer("");
        claimHeaderInformation.claimReportingPaidAmountToMemberByExternalPayer("");
        claimHeaderInformation.claimPaidAmountToProviderByExternalPayer("");
        claimHeaderInformation.claimPaidAmountToMemberByExternalPayer("");
        claimHeaderInformation.totalPaidAmountByExternalPayer("");
        claimHeaderInformation.drgAmount("");

        return claimHeaderInformation.build();
    }

    private String getTotalReportingPaidAmountToMember(String payeeType, String totalPay) {

        if (Constants.PROVIDER_CODE.equals(payeeType)) {
            return Constants.ZERO;
        }

        return totalPay;

    }

    private String getTotalReportingPaidAmountToProvider(String payeeType, String totalPay) {

        if (Constants.PROVIDER_CODE.equals(payeeType)) {
            return totalPay;
        }

        return Constants.ZERO;
    }

    private String getTotalPlanPaidAmountPaidToTheMember(String vendorId,
                                                         String provisionalPay) {

        String payeeType = HelperSupplier.getPayeeType(vendorId);

        if (Constants.PROVIDER_CODE.equals(payeeType)) {
            return Constants.ZERO;
        }

        return provisionalPay;
    }

    private String getPatientIdentificationNumber(String vendorId, String pcn) {

        String payeeType = HelperSupplier.getPayeeType(vendorId);

        if (Constants.PROVIDER_CODE.equals(payeeType)) {

            if (!pcn.isEmpty()) {
                return pcn;
            } else {
                return " ";
            }
        }

        return Constants.ZERO;
    }

    private String getServiceTypeCode(ClaimHeaderRecord claimHeaderRecord) {
        return claimHeaderRecord.getInstitutionalIndicator() + "";
    }

    private String getGenPRA(String vendorId) {

        if (Constants.PROVIDER_CODE.equals(HelperSupplier.getPayeeType(vendorId))) {
            return "Y";
        }

        return "N";
    }

    private String getGenMemberEOB(String vendorId) {

        if (Constants.SUBSCRIBER_CODE.equals(HelperSupplier.getPayeeType(vendorId))) {
            return "Y";
        }

        return "N";
    }

    private String getTotalPatientResponsibilityAmount(ClaimHeaderRecord claimHeaderRecord) {

        BigDecimal sum = new BigDecimal(Constants.ZERO_AMOUNT);

        sum = addClaimAdjustment(claimHeaderRecord, sum);

        for (ClaimDetailRecord claimDetailRecord : claimHeaderRecord.getClaimDetailRecordList()) {

            sum = addClaimDetailAdjustment(sum, claimDetailRecord);

            sum = addServiceLineAdjustment(sum, claimDetailRecord);
        }

        return sum.toString();
    }

    private BigDecimal addServiceLineAdjustment(BigDecimal sum, ClaimDetailRecord claimDetailRecord) {
        if (claimDetailRecord.getServiceLineList() != null) {

            for (ServiceLine serviceLine : claimDetailRecord.getServiceLineList()) {

                sum = addAdjustmentAmount(sum, serviceLine.getAdjustmentGroupCode(),
                        serviceLine.getAdjustedSign(), serviceLine.getAdjustedAmount());

                if (serviceLine.getAdjustmentList() != null) {

                    for (Adjustment adjustment : serviceLine.getAdjustmentList()) {

                        sum = addAdjustmentAmount(sum, adjustment.getAdjustmentGroupCode(),
                                adjustment.getAdjustedSign(), HelperSupplier.removeComma(adjustment.getAdjustedAmount()));
                    }
                }
            }
        }
        return sum;
    }

    private BigDecimal addClaimDetailAdjustment(BigDecimal sum, ClaimDetailRecord claimDetailRecord) {
        if (!Constants.RECOVERY_SERVICE_CODE.equals(claimDetailRecord.getServiceCode())) {

            sum = addAdjustmentAmount(sum, claimDetailRecord.getAdjustmentGroupCode(),
                    claimDetailRecord.getAdjustedSign(), HelperSupplier.removeComma(claimDetailRecord.getAdjustedAmount()));
        }
        return sum;
    }

    private BigDecimal addClaimAdjustment(ClaimHeaderRecord claimHeaderRecord, BigDecimal sum) {

        if (claimHeaderRecord.getAdjustmentList() != null) {
            for (Adjustment adjustment : claimHeaderRecord.getAdjustmentList()) {
                sum = addAdjustmentAmount(sum, adjustment.getAdjustmentGroupCode(),
                        adjustment.getAdjustedSign(), HelperSupplier.removeComma(adjustment.getAdjustedAmount()));
            }
        }

        return sum;
    }

    private BigDecimal addAdjustmentAmount(BigDecimal sum, String adjustmentGroupCode,
                                           char adjustedSign, String adjustedAmount) {
        if ("PR".equals(adjustmentGroupCode)) {

            if ('-' == adjustedSign) {
                sum = sum.subtract(getBigDecimal(adjustedAmount));
            } else {
                sum = sum.add(getBigDecimal(adjustedAmount));
            }
        }

        return sum;
    }

    private String getPrintSuppressionIndicator(String payeeType, char eraIndicator, String bankCode) {

        if (eraIndicator == 'E' && Constants.PROVIDER_CODE.equals(payeeType) &&
                "E".equals(getPayMethodProvider(bankCode, payeeType))) {

            return "Y";
        }

        return "N";

    }

    private String getTotalAmountApproved() {

        return Constants.ZERO_AMOUNT;
    }

    private BigDecimal getBigDecimal(String str) {

        BigDecimal num = BigDecimal.ZERO;

        try {
            num = new BigDecimal(str.replace(",", ""));
        } catch (NumberFormatException ex) {
            log.warn("Error while parsing to big decimal - " + str);
        }

        return num;
    }

    private String getPayMethod(String bankCode) {

        if (bankCode != null && bankCode.contains("ACH")) {
            return "E";
        } else if (bankCode != null && bankCode.contains("CHK")) {
            return "P";
        }

        return "";
    }

    private String getPayMethodProvider(String bankCode, String payeeType) {

        if (Constants.PROVIDER_CODE.equals(payeeType)) {

            return getPayMethod(bankCode);
        }

        return "P";
    }


    private boolean isQpaAmountInServiceLineList(ClaimHeaderRecord claimHeaderRecord) {
        if (!Objects.isNull(claimHeaderRecord) && !CollectionUtils.isEmpty(claimHeaderRecord.getClaimDetailRecordList())) {
            for (ClaimDetailRecord claimDetailRecord : claimHeaderRecord.getClaimDetailRecordList()) {
                if (!CollectionUtils.isEmpty(claimDetailRecord.getServiceLineList())) {
                    return claimDetailRecord.getServiceLineList().stream().filter(serviceLine -> serviceLine.getQpa() != null &&
                            BigDecimal.ZERO.compareTo(new BigDecimal(serviceLine.getQpa())) != 0).findAny().isPresent();

                }
            }
        }
        return false;
    }


}
