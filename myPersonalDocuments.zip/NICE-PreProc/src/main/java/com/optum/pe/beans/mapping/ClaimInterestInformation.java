package com.optum.pe.beans.mapping;

import lombok.Builder;
import lombok.Getter;

import java.util.StringJoiner;

@Builder
@Getter
public class ClaimInterestInformation {

    private String recordType;
    private String partnerId;
    private String consolidationId;
    private String adjudicationSystemId;
    private String adjudicationSystemUniqueClaimNumber;
    private String adjudicationSystemUniqueClaimNumberTransactionSequenceNumber;
    private String recordSequenceNumber;
    private String claimLevelInterestIndicator;
    private String claimLevelInterestAmountPaidToMember;
    private String claimLevelInterestAmountPaidToProvider;
    private String claimLevelInterestTypePaidToMember;
    private String claimLevelInterestTypePaidToProvider;

    @Override
    public String toString() {
        return new StringJoiner("|", "", "|")
                .add(recordType)
                .add(partnerId)
                .add(consolidationId)
                .add(adjudicationSystemId)
                .add(adjudicationSystemUniqueClaimNumber)
                .add(adjudicationSystemUniqueClaimNumberTransactionSequenceNumber)
                .add(recordSequenceNumber)
                .add(claimLevelInterestIndicator)
                .add(claimLevelInterestAmountPaidToMember)
                .add(claimLevelInterestAmountPaidToProvider)
                .add(claimLevelInterestTypePaidToMember)
                .add(claimLevelInterestTypePaidToProvider)
                .toString();
    }
}
