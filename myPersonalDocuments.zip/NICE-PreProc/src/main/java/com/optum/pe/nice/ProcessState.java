package com.optum.pe.nice;

import com.optum.pe.beans.parsing.AP2030File;
import com.optum.pe.beans.parsing.CheckRecord;
import com.optum.pe.beans.parsing.ClaimDetailRecord;
import com.optum.pe.beans.parsing.ClaimHeaderRecord;
import com.optum.pe.beans.parsing.ServiceLine;
import com.optum.pe.utils.Constants;
import lombok.Getter;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;

@Getter
public class ProcessState {

    private String fileName = "";

    private LocalDate cycleDate = null;

    private AP2030File ap2030File = null;

    private CheckRecord checkRecord = null;

    private ClaimHeaderRecord claimHeaderRecord = null;

    private ClaimDetailRecord claimDetailRecord = null;

    private ServiceLine serviceLine = null;

    private int processedLineCount = 0;

    public void incrementCheckRecordLines() {
        this.checkRecord.setLines(this.checkRecord.getLines() + 1);
    }

    public void incrementProcessedLineCount() {
        this.processedLineCount += this.checkRecord.getLines();
    }

    public void incrementProcessedLineCountByOne() {
        ++this.processedLineCount;
    }

    public void handleRecovery() {

        if (this.serviceLine != null) {
            this.serviceLine = null;
        }

        if (this.claimHeaderRecord.getAdjustmentList() != null) {
            this.claimHeaderRecord.setAdjustmentList(Collections.emptyList());
        }

        if (this.claimHeaderRecord.getClaimNoteRecords() != null) {
            this.claimHeaderRecord.setClaimNoteRecords(Collections.emptyList());
        }

        this.claimHeaderRecord.setClaimDetailRecordList(new ArrayList<>(4));
    }

    public boolean isRecoveryPresent() {

        if (this.claimHeaderRecord.getClaimDetailRecordList() != null) {
            return this.claimHeaderRecord.getClaimDetailRecordList().stream()
                    .filter(claimDetailRecord1 -> Constants.RECOVERY_SERVICE_CODE.equals(claimDetailRecord1.getServiceCode()))
                    .findAny().orElse(null) != null;
        }

        return false;
    }

    public void addCurrentCheckRecordToAP2030File() {

        if (this.ap2030File.getCheckRecordList() == null) {
            this.ap2030File.setCheckRecordList(new ArrayList<>());
        }

        this.ap2030File.getCheckRecordList().add(this.checkRecord);
        this.checkRecord = null;
    }

    public void addCurrentClaimHeaderRecordToCheckRecord() {

        if (this.checkRecord.getClaimHeaderRecordList() == null) {
            this.checkRecord.setClaimHeaderRecordList(new ArrayList<>());
        }

        this.checkRecord.getClaimHeaderRecordList().add(this.claimHeaderRecord);
        this.claimHeaderRecord = null;
    }

    public void addCurrentClaimDetailRecordToHeaderRecord() {

        if (this.claimHeaderRecord.getClaimDetailRecordList() == null) {
            this.claimHeaderRecord.setClaimDetailRecordList(new ArrayList<>());
        }

        this.claimHeaderRecord.getClaimDetailRecordList().add(this.claimDetailRecord);
        this.claimDetailRecord = null;
    }

    public void addCurrentServiceLineToClaimDetailRecord() {

        if (this.claimDetailRecord != null) {

            if (this.claimDetailRecord.getServiceLineList() == null) {
                this.claimDetailRecord.setServiceLineList(new ArrayList<>());
            }

            this.claimDetailRecord.getServiceLineList().add(this.serviceLine);
        }

        this.serviceLine = null;
    }

    public void setAp2030File(AP2030File ap2030File) {
        this.ap2030File = ap2030File;
    }

    public void setCheckRecord(CheckRecord checkRecord) {
        this.checkRecord = checkRecord;
    }

    public void setClaimHeaderRecord(ClaimHeaderRecord claimHeaderRecord) {
        this.claimHeaderRecord = claimHeaderRecord;
    }

    public void setClaimDetailRecord(ClaimDetailRecord claimDetailRecord) {
        this.claimDetailRecord = claimDetailRecord;
    }

    public void setServiceLine(ServiceLine serviceLine) {
        this.serviceLine = serviceLine;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public void setCycleDate(LocalDate cycleDate) {
        this.cycleDate = cycleDate;
    }
}
