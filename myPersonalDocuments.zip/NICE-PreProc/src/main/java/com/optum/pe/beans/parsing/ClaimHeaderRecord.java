package com.optum.pe.beans.parsing;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Builder
@Getter
@Setter
public class ClaimHeaderRecord implements Record {

    private String recordType;
    private String patientFirstName;
    private String patientLastName;
    private char patientMiddleInitial;
    private String pcn;

    private String claimNumber;
    private String claimAmount;

    private String serviceProvider;

    private String medGroup;
    private String empGroup;

    private String planCode;

    private String fDos;
    private String lDos;

    private char institutionalIndicator;
    private String subscriberId;
    private String subscriberFirstName;
    private String subscriberLastName;
    private char subscriberMiddleInitial;

    private ClaimTotalRecord claimTotalRecord;
    private List<ClaimDetailRecord> claimDetailRecordList;

    private List<ClaimNoteRecord> claimNoteRecords;

    private List<Adjustment> adjustmentList;
}
