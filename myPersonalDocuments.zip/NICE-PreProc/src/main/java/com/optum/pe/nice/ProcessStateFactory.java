package com.optum.pe.nice;

import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class ProcessStateFactory {

    private Map<String, ProcessState> processStateMap = new ConcurrentHashMap<>(11);

    public ProcessState createProcessStateFor(String fileName) {
        processStateMap.put(fileName, new ProcessState());

        return processStateMap.get(fileName);
    }

    public ProcessState getProcessStateFor(String fileName) {
        return processStateMap.get(fileName);
    }

    public void removeProcessStateFor(String fileName) {
        processStateMap.remove(fileName);
    }

    void removeAllStates() {
        processStateMap.clear();
    }
}
