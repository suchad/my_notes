package com.optum.pe.parsers;

import java.nio.file.Path;

public interface FileParser {

    boolean parse(Path path);
}
