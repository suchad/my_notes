package com.optum.pe.parsers;

import antlr.StringUtils;
import com.optum.pe.beans.parsing.CheckRecord;
import com.optum.pe.beans.parsing.Record;
import com.optum.pe.nice.CORProducerService;
import com.optum.pe.nice.ProcessState;
import com.optum.pe.nice.ProcessStateFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.HashMap;

@Slf4j
@Service
public class CheckRecordLineParser implements AP2030LineParser {

    private final ProcessStateFactory processStateFactory;
    private final CORProducerService corProducerService;

    CheckRecordLineParser(ProcessStateFactory processStateFactory,
                          CORProducerService corProducerService) {
        this.processStateFactory = processStateFactory;
        this.corProducerService = corProducerService;
    }

    @Override
    public boolean parse(String fileName, String line) {

        CheckRecord checkRecord = CheckRecord.builder()
                .recordType(line.substring(0, 2).trim())
                .bankCode(line.substring(2, 23).trim())
                .coDivCode(line.substring(23, 27).trim())
                .eraIndicator(line.charAt(27))
                .checkNumber(StringUtils.stripFront(line.substring(28, 38).trim(),"0"))
                .checkDate(line.substring(38, 48).trim())
                .checkAmount(line.substring(48, 62).trim())
                .vendorId(line.substring(62, 77))
                .vendorName(line.substring(77, 117).trim())
                .addrLine1(line.substring(117, 147).trim())
                .addrLine2(line.substring(147, 177).trim())
                .addrCity(line.substring(177, 197).trim())
                .addrState(line.substring(197, 199).trim())
                .addrZipCode(line.substring(199, 208).trim())
                .achIndicator(line.charAt(208))
                .mPin(line.substring(209, 218).trim())
                .taxId(line.substring(218, 227).trim())
                .tinType(line.charAt(227))
                .npi(line.substring(228, 238).trim())
                .highestId(1)
                .serviceProviderIdMap(new HashMap<>())
                .build();

        updateState(fileName, checkRecord);

        return true;
    }

    public void updateState(String fileName, Record record) {

        ProcessState processState = processStateFactory.getProcessStateFor(fileName);

        if (processState.getServiceLine() != null) {
            processState.addCurrentServiceLineToClaimDetailRecord();
        }

        if (processState.getClaimDetailRecord() != null) {
            processState.addCurrentClaimDetailRecordToHeaderRecord();
        }

        if (processState.getClaimHeaderRecord() != null) {
            processState.addCurrentClaimHeaderRecordToCheckRecord();
        }

        if (processState.getCheckRecord() != null) {
            corProducerService.sendCurrentCheckRecordToDB(fileName, Boolean.FALSE);
            processState.incrementProcessedLineCount();
            processState.addCurrentCheckRecordToAP2030File();
        }

        processState.setCheckRecord((CheckRecord) record);
        processState.incrementCheckRecordLines();
    }
}
