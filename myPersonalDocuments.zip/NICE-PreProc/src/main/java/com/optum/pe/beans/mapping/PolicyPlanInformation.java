package com.optum.pe.beans.mapping;

import lombok.Builder;
import lombok.Getter;

import java.util.StringJoiner;

@Builder
@Getter
public class PolicyPlanInformation {

    private String recordType;
    private String partnerId;
    private String consolidationId;
    private String adjudicationSystemId;
    private String adjudicationSystemUniqueClaimNumber;
    private String adjudicationSystemUniqueClaimNumberTransactionSequenceNumber;
    private String policyHolderNameQualifier;
    private String policyHolderFirstName;
    private String policyHolderMiddleName;
    private String policyHolderLastName;
    private String policyHolderNameSuffix;
    private String policyHolderEntityName;
    private String mnrPlanIdentifier; // correct name
    private String policyGroupNumber;
    private String policyContractSuffixCode;
    private String planVariationCode;
    private String reportCode;
    private String obligorIdentifier;
    private String sharedArrangementIdentifier;
    private String legalEntityCode;
    private String legalEntityText;
    private String fundingArrangementCode;
    private String bankCode;
    private String capitationFundCode;
    private String productName;
    private String planTypeCode;
    private String combinedMedicalAndRXDeductibleIndicator;
    private String combinedInAndOutOfNetworkDeductibleIndicator;
    private String combinedInAndOutOfNetworkOutOfPocketIndicator;
    private String accountDivisionCode;
    private String iPlanCDHPIndicator;
    private String providerMarketType;
    private String providerMarketSite;
    private String memberMarketType;
    private String memberMarketSite;
    private String contractSitusState;
    private String customerNumber;
    private String planEffectiveDate;
    private String planEndDate;
    private String balanceBillIndicator;
    private String balanceBillPercentage;
    private String contractNumber;
    private String planBenefitPackage;
    private String groupEffectiveDate;
    private String groupTerminationDate;
    private String policyHolderNamePrefix;
    private String policyTypeQualifier;
    private String lineOfBusiness;
    private String lineOfBusinessQualifier;
    private String combinedMedicalAndRXOOPIndicator;
    private String essentialHealthBenefitPlanIndicator;
    private String combinedMedicalAndMHSADeductibleIndicator;
    private String combinedMedicalAndMHSAOOPIndicator;
    private String combinedMedicalAndVisionDeductibleIndicator;
    private String combinedMedicalAndVisionOOPIndicator;
    private String combinedMedicalAndDentalDeductibleIndicator;
    private String combinedMedicalAndDentalOOPIndicator;
    private String combinedMedicalAndPhysicalMedicineDeductibleIndicator;
    private String combinedMedicalAndPhysicalMedicineOOPIndicator;
    private String leadPartner;
    private String legalEntityImageId;
    private String documentLogoImageId;
    private String payGroupCodeProvider;
    private String payGroupCodeMember;
    private String payGroupPayerId;
    private String payGroupPayerTaxId;
    private String providerIPA;
    private String additionalPayerId;
    private String _835RoutingId;
    private String _835ERACopyRoutingId;
    private String providerRemittanceCopyCode;

    @Override
    public String toString() {
        return new StringJoiner("|", "", "|")
                .add(recordType)
                .add(partnerId)
                .add(consolidationId)
                .add(adjudicationSystemId)
                .add(adjudicationSystemUniqueClaimNumber)
                .add(adjudicationSystemUniqueClaimNumberTransactionSequenceNumber)
                .add(policyHolderNameQualifier)
                .add(policyHolderFirstName)
                .add(policyHolderMiddleName)
                .add(policyHolderLastName)
                .add(policyHolderNameSuffix)
                .add(policyHolderEntityName)
                .add(mnrPlanIdentifier)
                .add(policyGroupNumber)
                .add(policyContractSuffixCode)
                .add(planVariationCode)
                .add(reportCode)
                .add(obligorIdentifier)
                .add(sharedArrangementIdentifier)
                .add(legalEntityCode)
                .add(legalEntityText)
                .add(fundingArrangementCode)
                .add(bankCode)
                .add(capitationFundCode)
                .add(productName)
                .add(planTypeCode)
                .add(combinedMedicalAndRXDeductibleIndicator)
                .add(combinedInAndOutOfNetworkDeductibleIndicator)
                .add(combinedInAndOutOfNetworkOutOfPocketIndicator)
                .add(accountDivisionCode)
                .add(iPlanCDHPIndicator)
                .add(providerMarketType)
                .add(providerMarketSite)
                .add(memberMarketType)
                .add(memberMarketSite)
                .add(contractSitusState)
                .add(customerNumber)
                .add(planEffectiveDate)
                .add(planEndDate)
                .add(balanceBillIndicator)
                .add(balanceBillPercentage)
                .add(contractNumber)
                .add(planBenefitPackage)
                .add(groupEffectiveDate)
                .add(groupTerminationDate)
                .add(policyHolderNamePrefix)
                .add(policyTypeQualifier)
                .add(lineOfBusiness)
                .add(lineOfBusinessQualifier)
                .add(combinedMedicalAndRXOOPIndicator)
                .add(essentialHealthBenefitPlanIndicator)
                .add(combinedMedicalAndMHSADeductibleIndicator)
                .add(combinedMedicalAndMHSAOOPIndicator)
                .add(combinedMedicalAndVisionDeductibleIndicator)
                .add(combinedMedicalAndVisionOOPIndicator)
                .add(combinedMedicalAndDentalDeductibleIndicator)
                .add(combinedMedicalAndDentalOOPIndicator)
                .add(combinedMedicalAndPhysicalMedicineDeductibleIndicator)
                .add(combinedMedicalAndPhysicalMedicineOOPIndicator)
                .add(leadPartner)
                .add(legalEntityImageId)
                .add(documentLogoImageId)
                .add(payGroupCodeProvider)
                .add(payGroupCodeMember)
                .add(payGroupPayerId)
                .add(payGroupPayerTaxId)
                .add(providerIPA)
                .add(additionalPayerId)
                .add(_835RoutingId)
                .add(_835ERACopyRoutingId)
                .add(providerRemittanceCopyCode)
                .toString();
    }
}
