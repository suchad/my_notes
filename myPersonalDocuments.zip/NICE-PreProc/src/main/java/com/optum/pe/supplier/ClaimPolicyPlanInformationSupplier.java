package com.optum.pe.supplier;

import com.optum.pe.beans.mapping.PolicyPlanInformation;
import com.optum.pe.beans.parsing.ClaimHeaderRecord;
import com.optum.pe.models.LookupData;
import com.optum.pe.utils.Constants;
import com.optum.pe.utils.RecordType;
import org.springframework.stereotype.Service;

@Service
class ClaimPolicyPlanInformationSupplier {

    PolicyPlanInformation supply(String checkNumber, String bankCode, int transactionSequenceNumber, ClaimHeaderRecord claimHeaderRecord,
                                 LookupData payerInfoLookupData) {

        PolicyPlanInformation.PolicyPlanInformationBuilder policyPlanInformation
                = PolicyPlanInformation.builder();

        policyPlanInformation.recordType(RecordType.POLICY_PLAN.getLabel());
        policyPlanInformation.partnerId(Constants.NICE_PARTNER_ID);
        policyPlanInformation.consolidationId(checkNumber);
        policyPlanInformation.adjudicationSystemId(Constants.ADJUDICATION_SYSTEM_ID);
        policyPlanInformation.adjudicationSystemUniqueClaimNumber(claimHeaderRecord.getClaimNumber());
        policyPlanInformation.adjudicationSystemUniqueClaimNumberTransactionSequenceNumber(transactionSequenceNumber + "");
        policyPlanInformation.policyHolderNameQualifier("");
        policyPlanInformation.policyHolderFirstName("");
        policyPlanInformation.policyHolderMiddleName("");
        policyPlanInformation.policyHolderLastName("");
        policyPlanInformation.policyHolderNameSuffix("");
        policyPlanInformation.policyHolderEntityName("");
        policyPlanInformation.mnrPlanIdentifier("");
        policyPlanInformation.policyGroupNumber(claimHeaderRecord.getEmpGroup());
        policyPlanInformation.policyContractSuffixCode("");
        policyPlanInformation.planVariationCode("");
        policyPlanInformation.reportCode("");
        policyPlanInformation.obligorIdentifier("");
        policyPlanInformation.sharedArrangementIdentifier("");
        policyPlanInformation.legalEntityCode("");
        policyPlanInformation.legalEntityText("");
        policyPlanInformation.fundingArrangementCode("");
        policyPlanInformation.bankCode("");
        policyPlanInformation.capitationFundCode("");
        policyPlanInformation.productName(claimHeaderRecord.getPlanCode());
        policyPlanInformation.planTypeCode("");
        policyPlanInformation.combinedMedicalAndRXDeductibleIndicator("");
        policyPlanInformation.combinedInAndOutOfNetworkDeductibleIndicator("");
        policyPlanInformation.combinedInAndOutOfNetworkOutOfPocketIndicator("");
        policyPlanInformation.accountDivisionCode("");
        policyPlanInformation.iPlanCDHPIndicator("");
        policyPlanInformation.providerMarketType("");
        policyPlanInformation.providerMarketSite("");
        policyPlanInformation.memberMarketType("");
        policyPlanInformation.memberMarketSite("");

        policyPlanInformation.contractSitusState(
                HelperSupplier.getBlankForAsterisk(payerInfoLookupData.getResultField05()));

        policyPlanInformation.customerNumber("");
        policyPlanInformation.planEffectiveDate("");
        policyPlanInformation.planEndDate("");
        policyPlanInformation.balanceBillIndicator("");
        policyPlanInformation.balanceBillPercentage("");
        policyPlanInformation.contractNumber("");
        policyPlanInformation.planBenefitPackage("");
        policyPlanInformation.groupEffectiveDate("");
        policyPlanInformation.groupTerminationDate("");
        policyPlanInformation.policyHolderNamePrefix("");
        policyPlanInformation.policyTypeQualifier("");
        policyPlanInformation.lineOfBusiness("");
        policyPlanInformation.lineOfBusinessQualifier("");
        policyPlanInformation.combinedMedicalAndRXOOPIndicator("");
        policyPlanInformation.essentialHealthBenefitPlanIndicator("");
        policyPlanInformation.combinedMedicalAndMHSADeductibleIndicator("");
        policyPlanInformation.combinedMedicalAndMHSAOOPIndicator("");
        policyPlanInformation.combinedMedicalAndVisionDeductibleIndicator("");
        policyPlanInformation.combinedMedicalAndVisionOOPIndicator("");
        policyPlanInformation.combinedMedicalAndDentalDeductibleIndicator("");
        policyPlanInformation.combinedMedicalAndDentalOOPIndicator("");
        policyPlanInformation.combinedMedicalAndPhysicalMedicineDeductibleIndicator("");
        policyPlanInformation.combinedMedicalAndPhysicalMedicineOOPIndicator("");
        policyPlanInformation.leadPartner("");
        policyPlanInformation.legalEntityImageId("");

        policyPlanInformation.documentLogoImageId(
                HelperSupplier.getBlankForAsterisk(payerInfoLookupData.getResultField04()));

        policyPlanInformation.payGroupCodeProvider("");
        policyPlanInformation.payGroupCodeMember(bankCode);

        policyPlanInformation.payGroupPayerId(
                HelperSupplier.getBlankForAsterisk(payerInfoLookupData.getResultField02()));

        policyPlanInformation.payGroupPayerTaxId("");
        policyPlanInformation.providerIPA("");
        policyPlanInformation.additionalPayerId("");
        policyPlanInformation._835RoutingId("");
        policyPlanInformation._835ERACopyRoutingId("");
        policyPlanInformation.providerRemittanceCopyCode("");

        return policyPlanInformation.build();
    }
}
