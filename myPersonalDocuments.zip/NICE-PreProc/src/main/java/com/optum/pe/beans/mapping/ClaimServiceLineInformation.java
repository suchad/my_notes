package com.optum.pe.beans.mapping;

import lombok.Builder;
import lombok.Getter;

import java.util.StringJoiner;

@Builder
@Getter
public class ClaimServiceLineInformation {

    private String recordType;
    private String partnerId;
    private String consolidationId;
    private String adjudicationSystemId;
    private String adjudicationSystemUniqueClaimNumber;
    private String adjudicationSystemUniqueClaimNumberTransactionSequenceNumber;
    private String serviceLineAdjudicationSystemNumber;
    private String serviceLineControlNumberReceivedOnTheClaimAsAssignedByTheProvider;
    private String serviceLineServiceType;
    private String serviceLineSubmittedCodeQualifier;
    private String serviceLineSubmittedServiceCode;
    private String submittedModifierCode1;
    private String submittedModifierCode2;
    private String submittedModifierCode3;
    private String submittedModifierCode4;
    private String adjudicatedServiceCodeQualifier;
    private String adjudicatedServiceCode;
    private String adjudicatedModifierCode1;
    private String adjudicatedModifierCode2;
    private String adjudicatedModifierCode3;
    private String adjudicatedModifierCode4;
    private String submittedSupplementalServiceCode;
    private String adjudicatedSupplementalServiceCode;
    private String submittedUnitsOfService;
    private String adjudicatedUnitsOfService;
    private String serviceCodeShortDescription;
    private String serviceLineServiceStartDate;
    private String serviceLineServiceEndDate;
    private String serviceLineInfoOnlyIndicator;
    private String serviceLineApprovedOrDeniedIndicator;
    private String serviceLineAmountBilled;
    private String serviceLineAmountPended;
    private String serviceLineAmountApprovedOrAllowedByPlan;
    private String contractedAmount;
    private String serviceLinePlanPaidAmount;
    private String totalPatientResponsibilityAmount;
    private String maxSubscriberPotentialLiabilityAmount;
    private String coinsurancePercentage;
    private String displayIndicator;
    private String paidToCode;
    private String memberResponsibilityTypeIndicator;
    private String medicareCoveredIndicator;
    private String serviceAppliesToMOOPIndicator;
    private String sgaIndicator;
    private String serviceLineInNetworkIndicator;
    private String serviceLineReferralStatusCode;
    private String remarkCode1;
    private String remarkCode2;
    private String remarkCode3;
    private String remarkCode4;
    private String remarkCode5;
    private String ansiCode1;
    private String ansiCode2;
    private String ansiCode3;
    private String ansiCode4;
    private String ansiCode5;
    private String apcPricingCode;
    private String opgGroupCode;
    private String apcStatusIndicator;
    private String apcReturnCode;
    private String oceEditCode;
    private String preventiveServiceCode;
    private String capitationIndicator;
    private String remarkQualifierCode1;
    private String remarkQualifierCode2;
    private String remarkQualifierCode3;
    private String remarkQualifierCode4;
    private String remarkQualifierCode5;
    private String renderingProviderTinNumber;
    private String adjudicationSystemAssignedRenderingProviderIdNumber;
    private String payorAssignedRenderingProviderIdNumber;
    private String renderingProviderNPINumber;
    private String renderingProviderType;
    private String renderingProviderFirstName;
    private String renderingProviderMiddleName;
    private String renderingProviderLastName;
    private String renderingProviderSuffix;
    private String renderingProviderEntityName;
    private String renderingProviderInNetworkCode;
    private String renderingProviderBillingStreetAddress1;
    private String renderingProviderBillingStreetAddress2;
    private String renderingProviderBillingStreetAddress3;
    private String renderingProviderBillingStreetAddress4;
    private String renderingProviderBillingStreetAddress5;
    private String renderingProviderBillingStreetAddress6;
    private String renderingProviderBillingStreetAddress7;
    private String renderingProviderBillingCity;
    private String renderingProviderBillingAddressState;
    private String renderingProviderBillingZipCode;
    private String renderingProviderBillingCountryCode;
    private String renderingProviderPOSStreetAddress1;
    private String renderingProviderPOSStreetAddress2;
    private String renderingProviderPOSStreetAddress3;
    private String renderingProviderPOSStreetAddress4;
    private String renderingProviderPOSStreetAddress5;
    private String renderingProviderPOSStreetAddress6;
    private String renderingProviderPOSStreetAddress7;
    private String renderingProviderPOSCity;
    private String renderingProviderPOSAddressState;
    private String renderingProviderPOSZipCode;
    private String renderingProviderPOSCountryCode;
    private String renderingProviderPrimaryPhoneNumber;
    private String referringProviderTinNumber;
    private String adjudicationSystemAssignedReferringProviderIdNumber;
    private String payorAssignedReferringProviderIdNumber;
    private String referringProviderNPINumber;
    private String referringProviderType;
    private String referringProviderFirstName;
    private String referringProviderMiddleName;
    private String referringProviderLastName;
    private String referringProviderSuffix;
    private String referringProviderEntityName;
    private String referringProviderInNetworkCode;
    private String referringProviderBillingStreetAddress1;
    private String referringProviderBillingStreetAddress2;
    private String referringProviderBillingStreetAddress3;
    private String referringProviderBillingStreetAddress4;
    private String referringProviderBillingStreetAddress5;
    private String referringProviderBillingStreetAddress6;
    private String referringProviderBillingStreetAddress7;
    private String referringProviderBillingCity;
    private String referringProviderBillingAddressState;
    private String referringProviderBillingZipCode;
    private String referringProviderBillingCountryCode;
    private String referringProviderPOSStreetAddress1;
    private String referringProviderPOSStreetAddress2;
    private String referringProviderPOSStreetAddress3;
    private String referringProviderPOSStreetAddress4;
    private String referringProviderPOSStreetAddress5;
    private String referringProviderPOSStreetAddress6;
    private String referringProviderPOSStreetAddress7;
    private String referringProviderPOSCity;
    private String referringProviderPOSAddressState;
    private String referringProviderPOSZipCode;
    private String referringProviderPOSCountryCode;
    private String referringProviderPrimaryPhoneNumber;
    private String appealCode;
    private String planCopayAmountForCategory;
    private String remarkTextVersionKeyCode1;
    private String remarkTextVersionKeyCode2;
    private String remarkTextVersionKeyCode3;
    private String remarkTextVersionKeyCode4;
    private String remarkTextVersionKeyCode5;
    private String remarkAdditionalTextVersionKeyCode1;
    private String remarkAdditionalTextVersionKeyCode2;
    private String remarkAdditionalTextVersionKeyCode3;
    private String remarkAdditionalTextVersionKeyCode4;
    private String remarkAdditionalTextVersionKeyCode5;
    private String copay;
    private String coins;
    private String deductible;
    private String remarkCode1ReferenceKey;
    private String remarkCode2ReferenceKey;
    private String remarkCode3ReferenceKey;
    private String remarkCode4ReferenceKey;
    private String remarkCode5ReferenceKey;
    private String paidByOtherInsurance;
    private String paidByMedicare;
    private String providerDiscountAmount;
    private String notCoveredPatientResponsibilityAmount;
    private String medicareEstimatedPaymentAmount;
    private String renderingProviderIdQualifier;
    private String renderingProviderId;
    private String capitationFundCode;
    private String providerPRAServiceLineDisplayIndicator;
    private String _835ServiceLineDisplayIndicator;
    private String freeFormRemarkCode;
    private String freeFormRemarkText;
    private String submittedSupplementalServiceCodeQualifier;
    private String adjudicatedSupplementalServiceCodeQualifier;
    private String serviceLinePlanPaidAmountToTheProvider;
    private String serviceLinePlanPaidAmountToTheMember;
    private String submittedServiceCodeDescription;
    private String submittedSupplementalServiceCodeDescription;
    private String adjudicatedServiceCodeDescription;
    private String adjudicatedSupplementalServiceCodeDescription;
    private String providerNotCoveredAmount;
    private String serviceLineReportingPaidAmountToProviderByExternalPayer;
    private String serviceLineReportingPaidAmountToMemberByExternalPayer; // for future use
    private String serviceLinePaidAmountToProviderByExternalPayer; // for future use
    private String serviceLinePaidAmountToMemberByExternalPayer; // for future use
    private String serviceLineTotalPaidAmountByExternalPayer; // for future use
    private String serviceLinePharmacyCouponEligibleIndicator;
    private String serviceLinePharmacyCouponAmount;
    private String serviceLinePharmacyCouponPatientResponsibleAmount;
    private String serviceLinePharmacyCouponDeductableAfterCouponAmount;
    private String serviceLinePharmacyCouponPatientResponsibilityAfterCouponAmount;
    private String serviceLinePharmacyCouponCoinsuranceAfterCouponAmount;
    private String serviceLineSurpriseBillCode;

    @Override
    public String toString() {
        StringJoiner sj = new StringJoiner("|", "", "|")
                .add(recordType)
                .add(partnerId)
                .add(consolidationId)
                .add(adjudicationSystemId)
                .add(adjudicationSystemUniqueClaimNumber)
                .add(adjudicationSystemUniqueClaimNumberTransactionSequenceNumber)
                .add(serviceLineAdjudicationSystemNumber)
                .add(serviceLineControlNumberReceivedOnTheClaimAsAssignedByTheProvider)
                .add(serviceLineServiceType)
                .add(serviceLineSubmittedCodeQualifier)
                .add(serviceLineSubmittedServiceCode)
                .add(submittedModifierCode1)
                .add(submittedModifierCode2)
                .add(submittedModifierCode3)
                .add(submittedModifierCode4)
                .add(adjudicatedServiceCodeQualifier)
                .add(adjudicatedServiceCode)
                .add(adjudicatedModifierCode1)
                .add(adjudicatedModifierCode2)
                .add(adjudicatedModifierCode3)
                .add(adjudicatedModifierCode4)
                .add(submittedSupplementalServiceCode)
                .add(adjudicatedSupplementalServiceCode)
                .add(submittedUnitsOfService)
                .add(adjudicatedUnitsOfService)
                .add(serviceCodeShortDescription)
                .add(serviceLineServiceStartDate)
                .add(serviceLineServiceEndDate)
                .add(serviceLineInfoOnlyIndicator)
                .add(serviceLineApprovedOrDeniedIndicator)
                .add(serviceLineAmountBilled)
                .add(serviceLineAmountPended)
                .add(serviceLineAmountApprovedOrAllowedByPlan)
                .add(contractedAmount)
                .add(serviceLinePlanPaidAmount)
                .add(totalPatientResponsibilityAmount)
                .add(maxSubscriberPotentialLiabilityAmount)
                .add(coinsurancePercentage)
                .add(displayIndicator)
                .add(paidToCode)
                .add(memberResponsibilityTypeIndicator)
                .add(medicareCoveredIndicator)
                .add(serviceAppliesToMOOPIndicator)
                .add(sgaIndicator)
                .add(serviceLineInNetworkIndicator)
                .add(serviceLineReferralStatusCode)
                .add(remarkCode1)
                .add(remarkCode2)
                .add(remarkCode3)
                .add(remarkCode4)
                .add(remarkCode5)
                .add(ansiCode1)
                .add(ansiCode2)
                .add(ansiCode3)
                .add(ansiCode4)
                .add(ansiCode5)
                .add(apcPricingCode)
                .add(opgGroupCode)
                .add(apcStatusIndicator)
                .add(apcReturnCode)
                .add(oceEditCode)
                .add(preventiveServiceCode)
                .add(capitationIndicator)
                .add(remarkQualifierCode1)
                .add(remarkQualifierCode2)
                .add(remarkQualifierCode3)
                .add(remarkQualifierCode4)
                .add(remarkQualifierCode5)
                .add(renderingProviderTinNumber)
                .add(adjudicationSystemAssignedRenderingProviderIdNumber)
                .add(payorAssignedRenderingProviderIdNumber)
                .add(renderingProviderNPINumber)
                .add(renderingProviderType)
                .add(renderingProviderFirstName)
                .add(renderingProviderMiddleName)
                .add(renderingProviderLastName)
                .add(renderingProviderSuffix)
                .add(renderingProviderEntityName)
                .add(renderingProviderInNetworkCode)
                .add(renderingProviderBillingStreetAddress1)
                .add(renderingProviderBillingStreetAddress2)
                .add(renderingProviderBillingStreetAddress3)
                .add(renderingProviderBillingStreetAddress4)
                .add(renderingProviderBillingStreetAddress5)
                .add(renderingProviderBillingStreetAddress6)
                .add(renderingProviderBillingStreetAddress7)
                .add(renderingProviderBillingCity)
                .add(renderingProviderBillingAddressState)
                .add(renderingProviderBillingZipCode)
                .add(renderingProviderBillingCountryCode)
                .add(renderingProviderPOSStreetAddress1)
                .add(renderingProviderPOSStreetAddress2)
                .add(renderingProviderPOSStreetAddress3)
                .add(renderingProviderPOSStreetAddress4)
                .add(renderingProviderPOSStreetAddress5)
                .add(renderingProviderPOSStreetAddress6)
                .add(renderingProviderPOSStreetAddress7)
                .add(renderingProviderPOSCity)
                .add(renderingProviderPOSAddressState)
                .add(renderingProviderPOSZipCode)
                .add(renderingProviderPOSCountryCode)
                .add(renderingProviderPrimaryPhoneNumber)
                .add(referringProviderTinNumber)
                .add(adjudicationSystemAssignedReferringProviderIdNumber)
                .add(payorAssignedReferringProviderIdNumber)
                .add(referringProviderNPINumber)
                .add(referringProviderType)
                .add(referringProviderFirstName)
                .add(referringProviderMiddleName)
                .add(referringProviderLastName)
                .add(referringProviderSuffix)
                .add(referringProviderEntityName)
                .add(referringProviderInNetworkCode)
                .add(referringProviderBillingStreetAddress1)
                .add(referringProviderBillingStreetAddress2)
                .add(referringProviderBillingStreetAddress3)
                .add(referringProviderBillingStreetAddress4)
                .add(referringProviderBillingStreetAddress5)
                .add(referringProviderBillingStreetAddress6)
                .add(referringProviderBillingStreetAddress7)
                .add(referringProviderBillingCity)
                .add(referringProviderBillingAddressState)
                .add(referringProviderBillingZipCode)
                .add(referringProviderBillingCountryCode)
                .add(referringProviderPOSStreetAddress1)
                .add(referringProviderPOSStreetAddress2)
                .add(referringProviderPOSStreetAddress3)
                .add(referringProviderPOSStreetAddress4)
                .add(referringProviderPOSStreetAddress5)
                .add(referringProviderPOSStreetAddress6)
                .add(referringProviderPOSStreetAddress7)
                .add(referringProviderPOSCity)
                .add(referringProviderPOSAddressState)
                .add(referringProviderPOSZipCode)
                .add(referringProviderPOSCountryCode)
                .add(referringProviderPrimaryPhoneNumber)
                .add(appealCode)
                .add(planCopayAmountForCategory)
                .add(remarkTextVersionKeyCode1)
                .add(remarkTextVersionKeyCode2)
                .add(remarkTextVersionKeyCode3)
                .add(remarkTextVersionKeyCode4)
                .add(remarkTextVersionKeyCode5)
                .add(remarkAdditionalTextVersionKeyCode1)
                .add(remarkAdditionalTextVersionKeyCode2)
                .add(remarkAdditionalTextVersionKeyCode3)
                .add(remarkAdditionalTextVersionKeyCode4)
                .add(remarkAdditionalTextVersionKeyCode5)
                .add(copay)
                .add(coins)
                .add(deductible)
                .add(remarkCode1ReferenceKey)
                .add(remarkCode2ReferenceKey)
                .add(remarkCode3ReferenceKey)
                .add(remarkCode4ReferenceKey)
                .add(remarkCode5ReferenceKey)
                .add(paidByOtherInsurance)
                .add(paidByMedicare)
                .add(providerDiscountAmount)
                .add(notCoveredPatientResponsibilityAmount)
                .add(medicareEstimatedPaymentAmount)
                .add(renderingProviderIdQualifier)
                .add(renderingProviderId)
                .add(capitationFundCode)
                .add(providerPRAServiceLineDisplayIndicator)
                .add(_835ServiceLineDisplayIndicator)
                .add(freeFormRemarkCode)
                .add(freeFormRemarkText)
                .add(submittedSupplementalServiceCodeQualifier)
                .add(adjudicatedSupplementalServiceCodeQualifier)
                .add(serviceLinePlanPaidAmountToTheProvider)
                .add(serviceLinePlanPaidAmountToTheMember)
                .add(submittedServiceCodeDescription)
                .add(submittedSupplementalServiceCodeDescription)
                .add(adjudicatedServiceCodeDescription)
                .add(adjudicatedSupplementalServiceCodeDescription)
                .add(providerNotCoveredAmount)
                .add(serviceLineReportingPaidAmountToProviderByExternalPayer)
                .add(serviceLineReportingPaidAmountToMemberByExternalPayer)
                .add(serviceLinePaidAmountToProviderByExternalPayer)
                .add(serviceLinePaidAmountToMemberByExternalPayer)
                .add(serviceLineTotalPaidAmountByExternalPayer);


        if (serviceLineSurpriseBillCode == null) {
            return sj.toString();
        } else {
            return sj.add(serviceLinePharmacyCouponEligibleIndicator)
                    .add(serviceLinePharmacyCouponAmount)
                    .add(serviceLinePharmacyCouponPatientResponsibleAmount)
                    .add(serviceLinePharmacyCouponDeductableAfterCouponAmount)
                    .add(serviceLinePharmacyCouponPatientResponsibilityAfterCouponAmount)
                    .add(serviceLinePharmacyCouponCoinsuranceAfterCouponAmount)
                    .add(serviceLineSurpriseBillCode)
                    .toString();
        }

    }
}