package com.optum.pe.supplier;

import com.optum.pe.beans.mapping.ClaimInterestInformation;
import com.optum.pe.beans.parsing.ClaimDetailRecord;
import com.optum.pe.utils.Constants;
import com.optum.pe.utils.RecordType;
import org.springframework.stereotype.Service;

@Service
class ClaimInterestInformationSupplier {

    ClaimInterestInformation supply(String checkNumber, String claimNumber, int transactionSequenceNumber, String vendorId,
                                    String indicatorIP, int recordSequenceNumber, ClaimDetailRecord claimDetailRecord) {

        ClaimInterestInformation.ClaimInterestInformationBuilder claimHeaderInformation
                = ClaimInterestInformation.builder();

        claimHeaderInformation.recordType(RecordType.CLAIM_INTEREST.getLabel());
        claimHeaderInformation.partnerId(Constants.NICE_PARTNER_ID);
        claimHeaderInformation.consolidationId(checkNumber);
        claimHeaderInformation.adjudicationSystemId(Constants.ADJUDICATION_SYSTEM_ID);
        claimHeaderInformation.adjudicationSystemUniqueClaimNumber(claimNumber);
        claimHeaderInformation.adjudicationSystemUniqueClaimNumberTransactionSequenceNumber(transactionSequenceNumber + "");
        claimHeaderInformation.recordSequenceNumber(recordSequenceNumber + "");

        claimHeaderInformation.claimLevelInterestIndicator(getInterestIndicator(indicatorIP));

        claimHeaderInformation.claimLevelInterestAmountPaidToMember(
                getInterestAmountPaidToMember(vendorId, claimDetailRecord));

        claimHeaderInformation.claimLevelInterestAmountPaidToProvider(
                getInterestAmountPaidToProvider(vendorId, claimDetailRecord));

        claimHeaderInformation.claimLevelInterestTypePaidToMember(
                getInterestTypePaidToMember(vendorId, indicatorIP));

        claimHeaderInformation.claimLevelInterestTypePaidToProvider(
                getInterestTypePaidToProvider(vendorId, indicatorIP));

        return claimHeaderInformation.build();
    }

    private String getInterestIndicator(String indicatorIP) {

        if ("I".equals(indicatorIP)) {
            return "Y";
        }

        return "";
    }

    private String getInterestTypePaidToProvider(String vendorId, String indicatorIP) {

        if (Constants.PROVIDER_CODE.equals(HelperSupplier.getPayeeType(vendorId))) {
            return indicatorIP;
        }

        return "";

    }

    private String getInterestTypePaidToMember(String vendorId, String indicatorIP) {

        if (Constants.SUBSCRIBER_CODE.equals(HelperSupplier.getPayeeType(vendorId))) {
            return indicatorIP;
        }

        return "";

    }

    private String getInterestAmountPaidToMember(String vendorId, ClaimDetailRecord claimDetailRecord) {

        if (Constants.SUBSCRIBER_CODE.equals(HelperSupplier.getPayeeType(vendorId))) {
            return HelperSupplier.getAmount(claimDetailRecord.getPaySign(),
                    HelperSupplier.removeComma(claimDetailRecord.getPayAmount()));
        }

        return "";

    }

    private String getInterestAmountPaidToProvider(String vendorId, ClaimDetailRecord claimDetailRecord) {

        if (Constants.PROVIDER_CODE.equals(HelperSupplier.getPayeeType(vendorId))) {
            return HelperSupplier.getAmount(claimDetailRecord.getPaySign(),
                    HelperSupplier.removeComma(claimDetailRecord.getPayAmount()));
        }

        return "";
    }
}
