package com.optum.pe.nice.runnable;

import com.optum.pe.service.SMTPService;

public class MissingTrailerRunnable implements Runnable {

    private final SMTPService smtpService;
    private final String fileName;
    private final String cycleDate;

    public MissingTrailerRunnable(String fileName, String cycleDate, SMTPService smtpService) {
        this.smtpService = smtpService;
        this.fileName = fileName;
        this.cycleDate = cycleDate;
    }

    @Override
    public void run() {
        smtpService.sendMailForMissingTrailer(fileName, cycleDate);
    }
}
