package com.optum.pe.beans.mapping;

import lombok.Builder;
import lombok.Getter;

import java.util.StringJoiner;

@Builder
@Getter
public class BankingInformation {

    private String recordType;
    private String partnerId;
    private String consolidationId;
    private String bankName;
    private String branchName;
    private String fractionNumberNumerator;
    private String fractionNumberDenominator;
    private String branchAddress1;
    private String branchAddress2;
    private String branchAddress3;
    private String branchAddress4;
    private String branchAddress5;
    private String branchAddress6;
    private String branchAddress7;
    private String branchCity;
    private String branchState;
    private String branchZipCode;
    private String branchCountryCode;
    private String bankRoutingNumber;
    private String bankAccountNumber;
    private String bankAccountName;
    private String bankAccountType;
    private String bankAndSeriesDesignator;
    private String checkLogoImageId;
    private String checkSignatureImageId;
    private String bankOwnerMark;
    private String checkCashPhrase;
    private String checkPayLabel;
    private String checkSignatureLabel;
    private String checkPayToLabel;
    private String bankPhoneNumber;

    @Override
    public String toString() {
        return new StringJoiner("|", "", "|")
                .add(recordType)
                .add(partnerId)
                .add(consolidationId)
                .add(bankName)
                .add(branchName)
                .add(fractionNumberNumerator)
                .add(fractionNumberDenominator)
                .add(branchAddress1)
                .add(branchAddress2)
                .add(branchAddress3)
                .add(branchAddress4)
                .add(branchAddress5)
                .add(branchAddress6)
                .add(branchAddress7)
                .add(branchCity)
                .add(branchState)
                .add(branchZipCode)
                .add(branchCountryCode)
                .add(bankRoutingNumber)
                .add(bankAccountNumber)
                .add(bankAccountName)
                .add(bankAccountType)
                .add(bankAndSeriesDesignator)
                .add(checkLogoImageId)
                .add(checkSignatureImageId)
                .add(bankOwnerMark)
                .add(checkCashPhrase)
                .add(checkPayLabel)
                .add(checkSignatureLabel)
                .add(checkPayToLabel)
                .add(bankPhoneNumber)
                .toString();
    }
}
