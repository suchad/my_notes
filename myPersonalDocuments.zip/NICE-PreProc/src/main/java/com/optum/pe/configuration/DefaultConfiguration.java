package com.optum.pe.configuration;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Getter
@Configuration
public class DefaultConfiguration {

    @Value("${spring.profiles}")
    private String environment;

    @Value("${spring.partner-proc-group-id}")
    private String partnerProcGroupId;

    @Value("${app.file.location}")
    private String fileLocation;

    @Value("${app.file.output}")
    private String outputPath;

    @Value("${app.file.archive}")
    private String archivePath;

    @Value("${app.file.threads}")
    private int threads;

    @Value("${app.file.datWaitAge}")
    private int datWaitAge;
}
