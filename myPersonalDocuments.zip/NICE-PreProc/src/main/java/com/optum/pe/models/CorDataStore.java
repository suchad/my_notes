package com.optum.pe.models;

import lombok.Builder;
import lombok.Getter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Builder
@Getter
@Entity
@Table(name = "COR_2030_DATA_STORE", schema = "PE01")
public class CorDataStore {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "cycle_date")
    private LocalDate cycleDate;

    @Column(name = "ppid")
    private String partnerProcGroupId;

    @Column(name = "partner_id")
    private String partnerId;

    @Column(name = "file_name")
    private String fileName;

    @Column(name = "pay_id")
    private String payId;

    @Column(name = "cor_data")
    @Lob
    private String corData;

    @Column(name = "creation_date")
    private LocalDateTime creationDate;

    @Column(name = "updation_date")
    private LocalDateTime updationDate;

    @Column(name = "created_by")
    private String createdBy;
}
