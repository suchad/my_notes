package com.optum.pe.models;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class FileEventFlagAndCount {

    private char activeFlag;
    private int fileCount;
}
