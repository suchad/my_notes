package com.optum.pe.parsers;

import com.optum.pe.beans.parsing.Record;
import com.optum.pe.beans.parsing.TrailerRecord;
import com.optum.pe.nice.CORProducerService;
import com.optum.pe.nice.ProcessState;
import com.optum.pe.nice.ProcessStateFactory;
import com.optum.pe.service.FileEventStore;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class TrailerRecordLineParser implements AP2030LineParser {

    private final ProcessStateFactory processStateFactory;
    private final CORProducerService corProducerService;
    private final FileEventStore fileEventStore;

    public TrailerRecordLineParser(ProcessStateFactory processStateFactory, CORProducerService corProducerService, FileEventStore fileEventStore) {
        this.processStateFactory = processStateFactory;
        this.corProducerService = corProducerService;
        this.fileEventStore = fileEventStore;
    }

    @Override
    public boolean parse(String fileName, String line) {

        TrailerRecord trailerRecord = TrailerRecord.builder()
                .recordType(line.substring(0, 2).trim())
                .totalChecks(line.substring(2, 10).trim())
                .totalPaymentAmount(line.substring(10, 25).trim())
                .totalRecordCount(line.substring(25, 35).trim())
                .build();

        updateState(fileName, trailerRecord);

        return true;
    }

    @Override
    public void updateState(String fileName, Record record) {

        ProcessState processState = processStateFactory.getProcessStateFor(fileName);

        processState.getAp2030File().setTrailerRecord((TrailerRecord) record);

        if (processState.getServiceLine() != null) {
            processState.addCurrentServiceLineToClaimDetailRecord();
        }

        if (processState.getClaimDetailRecord() != null) {
            processState.addCurrentClaimDetailRecordToHeaderRecord();
        }

        if (processState.getClaimHeaderRecord() != null) {
            processState.addCurrentClaimHeaderRecordToCheckRecord();
        }

        if (processState.getCheckRecord() != null) {

            corProducerService.sendCurrentCheckRecordToDB(fileName, Boolean.TRUE);
            processState.incrementProcessedLineCount();
            processState.incrementProcessedLineCountByOne();
            processState.addCurrentCheckRecordToAP2030File();
        }

        fileEventStore.addEvent(
                fileEventStore.getFileEventFrom(fileName, processState.getCycleDate(), ((TrailerRecord) record).getTotalChecks()));

        processStateFactory.removeProcessStateFor(fileName);
    }
}
