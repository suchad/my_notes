package com.optum.pe.nice;

import com.optum.pe.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping("/nice")
public class FileController {

    private final ConcreteMediator concreteMediator;
    private final ProcessStateFactory processStateFactory;
    private final CacheManager cacheManager;

    FileController(ConcreteMediator concreteMediator, ProcessStateFactory processStateFactory, CacheManager cacheManager) {
        this.concreteMediator = concreteMediator;
        this.processStateFactory = processStateFactory;
        this.cacheManager = cacheManager;
    }

    @GetMapping("/ingest")
    public boolean ingestFiles() {
        return concreteMediator.mediate();
    }

    @GetMapping("/clear/state")
    public boolean clearState() {
        processStateFactory.removeAllStates();

        return true;
    }

    @GetMapping("/clear/cache")
    public boolean clearCache() {

        Cache cache = cacheManager.getCache(Constants.LOOKUP_CACHE_NAME);

        if (cache != null) {
            cache.clear();
            return true;
        } else {
            log.error("Unable to clear the cache");
            return false;
        }
    }


    @GetMapping("/clear/nice/cdc/cache")
    public boolean clearNiceCdcCache() {

        Cache cache = cacheManager.getCache(Constants.NICE_CDC_CACHE_NAME);

        if (cache != null) {
            cache.clear();
            return true;
        } else {
            log.error("Unable to clear the cache");
            return false;
        }
    }
}
