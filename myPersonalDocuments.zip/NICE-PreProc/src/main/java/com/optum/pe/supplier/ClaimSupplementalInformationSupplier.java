package com.optum.pe.supplier;

import com.optum.pe.beans.mapping.ClaimSupplementalInformation;
import com.optum.pe.beans.parsing.Adjustment;
import com.optum.pe.beans.parsing.ClaimTotalRecord;
import com.optum.pe.utils.Constants;
import com.optum.pe.utils.RecordType;
import org.springframework.stereotype.Service;

@Service
class ClaimSupplementalInformationSupplier {

    ClaimSupplementalInformation supply(String checkNumber, String claimNumber,
                                        int transactionSequenceNumber, int recordSequenceNumber, Adjustment adjustment,
                                        ClaimTotalRecord claimTotalRecord, String medGroup) {

        String recordType = "A";

        if (Constants.INTEREST_SERVICE_CODE.equals(adjustment.getServiceCode())) {
            recordType = "I";
        } else if (Constants.PENALTY_SERVICE_CODE.equals(adjustment.getServiceCode())) {
            recordType = "P";
        }

        ClaimSupplementalInformation.ClaimSupplementalInformationBuilder
                claimSupplementalInformation = ClaimSupplementalInformation.builder();

        claimSupplementalInformation.recordType(RecordType.CLAIM_SUPPLEMENTAL.getLabel());
        claimSupplementalInformation.partnerId(Constants.NICE_PARTNER_ID);
        claimSupplementalInformation.consolidationId(checkNumber);
        claimSupplementalInformation.adjudicationSystemId(Constants.ADJUDICATION_SYSTEM_ID);
        claimSupplementalInformation.adjudicationSystemUniqueClaimNumber(claimNumber);
        claimSupplementalInformation.adjudicationSystemUniqueClaimNumberTransactionSequenceNumber(transactionSequenceNumber + "");
        claimSupplementalInformation.recordSequenceNumber(recordSequenceNumber + "");

        claimSupplementalInformation.userDefinedField1(adjustment.getAdjustmentGroupCode());
        claimSupplementalInformation.userDefinedField2(adjustment.getClaimAdjustmentReasonCode());
        claimSupplementalInformation.userDefinedField3(
                HelperSupplier.getAmount(adjustment.getAdjustedSign(), HelperSupplier.removeComma(adjustment.getAdjustedAmount())));

        claimSupplementalInformation.userDefinedField4(adjustment.getRemarkAdjustmentReasonCode());

        claimSupplementalInformation.userDefinedField5(adjustment.getAdjustedReason());
        claimSupplementalInformation.userDefinedField6(
                HelperSupplier.getAmount(adjustment.getPaySign(),
                        HelperSupplier.removeComma(adjustment.getPayAmount())));
        claimSupplementalInformation.userDefinedField7(recordType);
        claimSupplementalInformation.userDefinedField8("");
        claimSupplementalInformation.userDefinedField9("");
        claimSupplementalInformation.userDefinedField10("");

        /*claimSupplementalInformation.userDefinedField11(
                String.format("%1$18s",
                        HelperSupplier.getAmount(claimTotalRecord.getTotalPriorSign(),
                                HelperSupplier.removeComma(claimTotalRecord.getTotalPriorPay()))).replace(' ', '0'));*/

        claimSupplementalInformation.userDefinedField11(
                HelperSupplier.getPaddedAmount(claimTotalRecord.getTotalPriorSign(),
                        HelperSupplier.removeComma(claimTotalRecord.getTotalPriorPay()), 17, "0"));
        claimSupplementalInformation.userDefinedField12(medGroup);

        claimSupplementalInformation.userDefinedField13("");
        claimSupplementalInformation.userDefinedField14("");
        claimSupplementalInformation.userDefinedField15("");
        claimSupplementalInformation.userDefinedField16("");
        claimSupplementalInformation.userDefinedField17("");
        claimSupplementalInformation.userDefinedField18("");
        claimSupplementalInformation.userDefinedField19("");
        claimSupplementalInformation.userDefinedField20("");
        claimSupplementalInformation.userDefinedField21("");
        claimSupplementalInformation.userDefinedField22("");
        claimSupplementalInformation.userDefinedField23("");
        claimSupplementalInformation.userDefinedField24("");
        claimSupplementalInformation.userDefinedField25("");

        return claimSupplementalInformation.build();
    }
}
