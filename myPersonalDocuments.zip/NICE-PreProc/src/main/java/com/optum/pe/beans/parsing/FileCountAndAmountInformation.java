package com.optum.pe.beans.parsing;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FileCountAndAmountInformation {

    private FileMetaData fileMetaData;
    private Trailer trailerRecord;
}
