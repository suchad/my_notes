package com.optum.pe.beans.parsing;

public interface Segment {
}
