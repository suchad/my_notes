package com.optum.pe.parsers;

import com.optum.pe.beans.parsing.ClaimTotalRecord;
import com.optum.pe.beans.parsing.Record;
import com.optum.pe.nice.ProcessState;
import com.optum.pe.nice.ProcessStateFactory;
import org.springframework.stereotype.Service;

@Service
public class ClaimTotalRecordLineParser implements AP2030LineParser {

    private final ProcessStateFactory processStateFactory;

    public ClaimTotalRecordLineParser(ProcessStateFactory processStateFactory) {
        this.processStateFactory = processStateFactory;
    }

    @Override
    public boolean parse(String fileName, String line) {

        ClaimTotalRecord claimTotalRecord = ClaimTotalRecord.builder()
                .recordType(line.substring(0, 2).trim())
                .totalCharges(line.substring(2, 14).trim())
                .totalAdjusted(line.substring(14, 26).trim())
                .totalAdjustedSign(line.charAt(26))
                .totalPay(line.substring(27, 39).trim())
                .totalPaySign(line.charAt(39))
                .totalPriorPay(line.substring(40, 52).trim())
                .totalPriorSign(line.charAt(52))
                .totalProvisionalPay(line.substring(53, 65).trim())
                .totalProvisionalSign(line.charAt(65)).build();

        updateState(fileName, claimTotalRecord);

        return true;
    }

    @Override
    public void updateState(String fileName, Record record) {

        ProcessState processState = processStateFactory.getProcessStateFor(fileName);

        processState.getClaimHeaderRecord().setClaimTotalRecord((ClaimTotalRecord) record);
        processState.incrementCheckRecordLines();
    }
}
