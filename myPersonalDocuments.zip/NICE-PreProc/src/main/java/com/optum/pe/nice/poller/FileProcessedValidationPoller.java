package com.optum.pe.nice.poller;

import com.optum.pe.exception.ServiceException;
import com.optum.pe.service.CycleDateService;
import com.optum.pe.service.FileEventStore;
import com.optum.pe.service.ParameterService;
import com.optum.pe.service.SMTPService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;

import static com.optum.pe.utils.Constants.FLAG_Y;

@Slf4j
@Component
public class FileProcessedValidationPoller {

	private final SMTPService smtpService;
	private final FileEventStore fileEventStore;
	private final CycleDateService cycleDateService;
	private final ParameterService parameterService;

	public FileProcessedValidationPoller(SMTPService smtpService, FileEventStore fileEventStore,
			CycleDateService cycleDateService, ParameterService parameterService) {
		this.smtpService = smtpService;
		this.fileEventStore = fileEventStore;
		this.cycleDateService = cycleDateService;
		this.parameterService = parameterService;
	}

	@Async
	@Scheduled(cron = "${app.file.cron}")
	void poll() {
		try {
			String preProcFlag = parameterService.getServiceParameter();
			if (FLAG_Y.equals(preProcFlag)) {
				List<String> missingFileNames = fileEventStore.getMissingFileNames();

				if (!missingFileNames.isEmpty()) {

					String cycleDate = cycleDateService.getCycleDate();

					smtpService.sendMailForMissingFiles(missingFileNames, cycleDate);
				}
			}
		} catch (ServiceException ex) {
			log.error("", ex);
		}
	}
}