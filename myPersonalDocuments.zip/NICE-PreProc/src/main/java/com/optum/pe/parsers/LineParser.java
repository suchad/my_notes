package com.optum.pe.parsers;

@FunctionalInterface
public interface LineParser {

    boolean parse(String fileName, String line);
}
