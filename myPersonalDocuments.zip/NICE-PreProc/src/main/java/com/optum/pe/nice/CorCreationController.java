package com.optum.pe.nice;

import com.optum.pe.exception.ServiceException;
import com.optum.pe.service.ParameterService;
import com.optum.pe.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Locale;
import java.util.stream.Stream;

import static com.optum.pe.utils.Constants.FLAG_N;
import static com.optum.pe.utils.Constants.FLAG_Y;

@Slf4j
@RestController
@RequestMapping("/nice")
public class CorCreationController {

    private final FileWritingService fileWritingService;

    private final ParameterService parameterService;

    private final PathGetterService pathGetterService;

    public CorCreationController(FileWritingService fileWritingService, ParameterService parameterService, PathGetterService pathGetterService) {
        this.fileWritingService = fileWritingService;
        this.parameterService = parameterService;
        this.pathGetterService = pathGetterService;
    }

    @GetMapping("/cor/createFile")
    public boolean startFileCreation() {
        try {
            log.info("createFile triggered.");
            parameterService.updateServiceParameterFlag(FLAG_N);
            parameterService.updateServiceEndpointFlag(FLAG_N);
            fileWritingService.write();
            parameterService.updateServiceEndpointFlag(FLAG_Y);
            log.info("AP2030 COR file writing is done.");
            deleteSuccessFile();
        } catch (ServiceException | RuntimeException | IOException e) {
            log.error("", e);
        }

        return true;
    }

    private void deleteSuccessFile() throws IOException {
        try (Stream<Path> filePaths = pathGetterService.getSuccessFilePath()) {
            filePaths.filter(this::isTriggerFile).forEach(this::deleteFile);
        } catch (IOException e) {
            log.error("", e);
            throw e;
        }
    }

    public boolean isTriggerFile(Path path) {
        return path.getFileName().toString().toUpperCase(Locale.ENGLISH).startsWith(Constants.COMPLETE_SUCCESS_FILE)
                && path.getFileName().toString().toUpperCase(Locale.ENGLISH).endsWith(Constants.TRIGGER_FILE_EXTENSION);
    }

    public void deleteFile(Path path) {
        try {
            if (path.toFile().exists()) {
                FileUtils.forceDelete(path.toFile());
                log.info("Success file has been deleted.");
            }
        } catch (IOException e) {
            log.error("", e);
        }
    }
}
