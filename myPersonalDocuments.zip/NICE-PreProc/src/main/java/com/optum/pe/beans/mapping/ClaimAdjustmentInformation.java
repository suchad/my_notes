package com.optum.pe.beans.mapping;

import lombok.Builder;
import lombok.Getter;

import java.util.StringJoiner;

@Builder
@Getter
public class ClaimAdjustmentInformation {

    private String recordType;
    private String partnerId;
    private String consolidationId;
    private String adjudicationSystemId;
    private String adjudicationSystemUniqueClaimNumber;
    private String adjudicationSystemUniqueClaimNumberTransactionSequenceNumber;
    private String recordSequenceNumber;
    private String _835CASClaimAdjustmentGroupCode;
    private String _835CASClaimAdjustmentReasonCode;
    private String _835CASClaimAdjustmentAmount;
    private String _835CASClaimAdjustmentQuantity;
    private String remarkCode;
    private String remarkTextVersionKeyCode;
    private String remarkAdditionalTextVersionKeyCode;
    private String remarkQualifierCode;
    private String remarkReferenceKey;

    @Override
    public String toString() {
        return new StringJoiner("|", "", "|")
                .add(recordType)
                .add(partnerId)
                .add(consolidationId)
                .add(adjudicationSystemId)
                .add(adjudicationSystemUniqueClaimNumber)
                .add(adjudicationSystemUniqueClaimNumberTransactionSequenceNumber)
                .add(recordSequenceNumber)
                .add(_835CASClaimAdjustmentGroupCode)
                .add(_835CASClaimAdjustmentReasonCode)
                .add(_835CASClaimAdjustmentAmount)
                .add(_835CASClaimAdjustmentQuantity)
                .add(remarkCode)
                .add(remarkTextVersionKeyCode)
                .add(remarkAdditionalTextVersionKeyCode)
                .add(remarkQualifierCode)
                .add(remarkReferenceKey)
                .toString();
    }
}
