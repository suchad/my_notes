package com.optum.pe.configuration;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * SMTP based configurations.
 *
 * @author vivek v58
 */
@NoArgsConstructor
@Setter
@Getter
@Configuration
@ConfigurationProperties(prefix = "spring.mail")
public class SMTPConfiguration {

    private String host;
    private String username;
    private String password;
    private String[] recipients;

    @Value("${spring.mail.properties.mail.transport.protocol}")
    private String protocol;

    @Value("${spring.mail.properties.mail.smtp.port}")
    private int port;

    @Value("${spring.mail.properties.mail.smtp.auth}")
    private boolean auth;

}
