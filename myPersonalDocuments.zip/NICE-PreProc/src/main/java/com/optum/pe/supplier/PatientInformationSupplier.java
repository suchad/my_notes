package com.optum.pe.supplier;

import com.optum.pe.beans.mapping.PatientInformation;
import com.optum.pe.beans.parsing.ClaimHeaderRecord;
import com.optum.pe.utils.Constants;
import com.optum.pe.utils.RecordType;
import org.springframework.stereotype.Service;

@Service
class PatientInformationSupplier {

    PatientInformation supply(String checkNumber, int transactionSequenceNumber, ClaimHeaderRecord claimHeaderRecord) {

        PatientInformation.PatientInformationBuilder patientInformation
                = PatientInformation.builder();

        patientInformation.recordType(RecordType.PATIENT.getLabel());
        patientInformation.partnerId(Constants.NICE_PARTNER_ID);
        patientInformation.consolidationId(checkNumber);
        patientInformation.adjudicationSystemId(Constants.ADJUDICATION_SYSTEM_ID);
        patientInformation.adjudicationSystemUniqueClaimNumber(claimHeaderRecord.getClaimNumber());
        patientInformation.adjudicationSystemUniqueClaimNumberTransactionSequenceNumber(transactionSequenceNumber + "");
        patientInformation.universalId("");
        patientInformation.adjudicationSystemIdNumberSubmitted(claimHeaderRecord.getPcn());
        patientInformation.idNumberQualifierSubmitted("");
        patientInformation.firstName(claimHeaderRecord.getPatientFirstName());
        patientInformation.middleName(claimHeaderRecord.getPatientMiddleInitial() + "");
        patientInformation.lastName(claimHeaderRecord.getPatientLastName());
        patientInformation.suffix("");
        patientInformation.adjudicationSystemIdNumberAdjudicated(claimHeaderRecord.getPcn());
        patientInformation.idNumberQualifierAdjudicated("");
        patientInformation.firstNameAdjudicated(claimHeaderRecord.getPatientFirstName());
        patientInformation.middleNameAdjudicated(claimHeaderRecord.getPatientMiddleInitial() + "");
        patientInformation.lastNameAdjudicated(claimHeaderRecord.getPatientLastName());
        patientInformation.suffixAdjudicated("");
        patientInformation.age("");
        patientInformation.relationshipToSubscriber("");
        patientInformation.mailingAddressStreet1("");
        patientInformation.mailingAddressStreet2("");
        patientInformation.mailingAddressStreet3("");
        patientInformation.mailingAddressStreet4("");
        patientInformation.mailingAddressStreet5("");
        patientInformation.mailingAddressStreet6("");
        patientInformation.mailingAddressStreet7("");
        patientInformation.mailingAddressCity("");
        patientInformation.mailingAddressState("");
        patientInformation.mailingAddressZipCode("");
        patientInformation.mailingCountryCode("");
        patientInformation.coverageMemberIdXRef("");
        patientInformation.namePrefix("");
        patientInformation.namePrefixAdjudicated("");
        patientInformation.dependentSequenceNumber("");
        patientInformation.dateOfBirth("");

        return patientInformation.build();
    }
}
