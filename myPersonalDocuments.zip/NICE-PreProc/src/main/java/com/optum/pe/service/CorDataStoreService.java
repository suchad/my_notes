package com.optum.pe.service;

import com.optum.pe.models.CorDataStore;
import com.optum.pe.nice.OnePayClaimCORString;
import com.optum.pe.onepay.avro.OnePayClaimCOR;
import com.optum.pe.repositories.CorDataStoreRepository;
import com.optum.pe.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.sql.Clob;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Slf4j
@Service
public class CorDataStoreService {

    private final CorDataStoreRepository corDataStoreRepository;
    private final OnePayClaimCORString onePayClaimCORString;

    public CorDataStoreService(CorDataStoreRepository corDataStoreRepository,
                               OnePayClaimCORString onePayClaimCORString) {
        this.corDataStoreRepository = corDataStoreRepository;
        this.onePayClaimCORString = onePayClaimCORString;
    }

    public List<Clob> getCurrentPaymentsFromDB() {

        return corDataStoreRepository.findCurrentPayments();
    }

    public void save(CorDataStore corDataStore) {
        corDataStoreRepository.save(corDataStore);
    }

    public CorDataStore getCorDataStore(OnePayClaimCOR onePayClaimCOR, LocalDate cycleDate,
                                        String fileName, String checkNumber) {

        String corString = onePayClaimCORString.getString(onePayClaimCOR);

        return CorDataStore.builder()
                .cycleDate(cycleDate)
                .partnerProcGroupId(Constants.LOOKUP_PARTNER_PROC_GRP_ID)
                .partnerId(Constants.NICE_PARTNER_ID)
                .fileName(fileName)
                .payId(checkNumber)
                .corData(corString)
                .creationDate(LocalDateTime.now())
                .updationDate(LocalDateTime.now())
                .createdBy(Constants.APPLICATION_NAME)
                .build();
    }

    public void deleteCurrentPayments() {

        corDataStoreRepository.deleteCurrentPayments();
        log.info("Deleted Current Payments");
    }

    public int getCurrentPaymentsCount() {
        List<Clob> currentPaymentList = corDataStoreRepository.findCurrentPayments();
        if (currentPaymentList != null && !currentPaymentList.isEmpty()) {
            return currentPaymentList.size();
        } else {
            return 0;
        }
    }
}
