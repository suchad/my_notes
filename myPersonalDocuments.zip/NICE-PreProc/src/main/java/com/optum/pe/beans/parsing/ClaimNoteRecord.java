package com.optum.pe.beans.parsing;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class ClaimNoteRecord implements Record {

    private String recordType;
    private String noteLine;
}
