package com.optum.pe.nice.validation;

import com.optum.pe.configuration.DefaultConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneId;

@Slf4j
@Service
public class TriggerFileAgeValidationService {

    private final DefaultConfiguration defaultConfiguration;

    public TriggerFileAgeValidationService(DefaultConfiguration defaultConfiguration) {
        this.defaultConfiguration = defaultConfiguration;
    }

    public boolean isAgeExpired(Path path) {

        boolean status = false;

        try {
            BasicFileAttributes basicFileAttributes
                    = Files.readAttributes(path, BasicFileAttributes.class);

            FileTime fileTime = basicFileAttributes.lastModifiedTime();

            LocalDateTime convertedFileTime
                    = LocalDateTime.ofInstant(fileTime.toInstant(), ZoneId.systemDefault());

            Duration duration = Duration.between(convertedFileTime, LocalDateTime.now());

            status = duration.toMinutes() > defaultConfiguration.getDatWaitAge();
        } catch (IOException ex) {
            log.error("", ex);
        }

        return status;
    }
}
