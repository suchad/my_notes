package com.optum.pe.nice;

import com.optum.pe.exception.ServiceException;
import com.optum.pe.service.ParameterService;
import com.optum.pe.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Path;
import java.util.stream.Stream;

import static com.optum.pe.utils.Constants.FLAG_Y;

@Slf4j
@Service
public class ConcreteMediator implements Mediator {

    private final PathGetterService pathGetterService;
    private final PathConsumerService pathConsumerService;
    private final FileNameComparator fileNameComparator;
    private final ParameterService parameterService;

    ConcreteMediator(PathGetterService pathGetterService, PathConsumerService pathConsumerService, FileNameComparator fileNameComparator, ParameterService parameterService) {
        this.pathGetterService = pathGetterService;
        this.pathConsumerService = pathConsumerService;
        this.fileNameComparator = fileNameComparator;
        this.parameterService = parameterService;
    }

    public boolean mediate() {

        boolean status = false;

        try (Stream<Path> filePaths = pathGetterService.getFilePaths()) {

            filePaths
                    .sorted(fileNameComparator)
                    .filter(this::isFile)
                    .filter(this::isTriggerFile)
                    .filter(this::isNotWriting)
                    .filter(this::isNotWIP)
                    .filter(this::isServiceParameterFlag)
                    .forEach(pathConsumerService::consume);

            status = true;
        } catch (IOException ex) {
            log.error("", ex);
        }

        return status;
    }

    private boolean isFile(Path path) {
        return path.toFile().isFile();
    }

    private boolean isNotWriting(Path path) {
        return !path.getFileName().toString().endsWith(Constants.WRITING_FILE_EXTENSION);
    }

    private boolean isNotWIP(Path path) {
        return !path.getFileName().toString().endsWith(Constants.WIP_FILE_EXTENSION);
    }

    private boolean isTriggerFile(Path path) {
        return path.getFileName().toString().endsWith(Constants.TRIGGER_FILE_EXTENSION);
    }

    private boolean isServiceParameterFlag(Path path){
        boolean flag = false;
        try {
            String preProcFlag = parameterService.getServiceParameter();
            if(FLAG_Y.equals(preProcFlag)){
                flag = true;
            }
        } catch (ServiceException ex) {
            log.error("", ex);
        }
        return flag;
    }
}
