package com.optum.pe.repositories;

import com.optum.pe.models.FileEvent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Repository
public interface FileEventStoreRepository extends JpaRepository<FileEvent, Long> {

    @Query(value = "SELECT FILE_NAME FROM PE01.FILE_EVENT_STORE WHERE FILE_ID IN (" +
            "SELECT FILE_ID " +
            "FROM PE01.FILE_EVENT_STORE " +
            "WHERE CYCLE_DATE = TIMESTAMP '2000-01-01 00:00:00.0' AND ACTIVE_FLAG = 'Y' AND CREATED_BY = ?1 " +
            "MINUS " +
            "SELECT FILE_ID " +
            "FROM PE01.FILE_EVENT_STORE " +
            "WHERE CYCLE_DATE = (SELECT to_date(max(CYC_DT_NM), 'yyyymmdd') FROM PE01.CYCLE_DATE " +
            "WHERE PARTNER_PROC_GRP_ID = ?2 AND CYC_DT_USED_IND = 'Y') " +
            "AND ACTIVE_FLAG = 'Y' AND CREATED_BY = ?1) AND CYCLE_DATE = TIMESTAMP '2000-01-01 00:00:00.0' AND ACTIVE_FLAG = 'Y' AND CREATED_BY = ?1", nativeQuery = true)
    List<String> findMissingFileNames(String applicationName, String partnerProcGroupId);

    @Query(value = "SELECT a.active_flag active_flag, b.count file_count FROM \n" +
            "(SELECT active_flag active_flag FROM PE01.FILE_EVENT_STORE fes\n" +
            "WHERE FILE_ID = ?2 AND CYCLE_DATE = to_date('20000101', 'yyyymmdd')) a,\n" +
            "(SELECT COUNT(*) count FROM PE01.FILE_EVENT_STORE fes\n" +
            "WHERE CYCLE_DATE = to_date(?3, 'yyyymmdd')\n" +
            "AND FILE_ID = ?2 AND CREATED_BY = ?1) b", nativeQuery = true)
    Map<String, Object> getFileEventFlagAndCountMap(String createdBy, String fileId, String cycleDate);

    @Query(value = "SELECT pay_count FROM PE01.FILE_EVENT_STORE WHERE " +
            "CREATED_BY = ?1 AND ACTIVE_FLAG = 'Y' AND " +
            "CYCLE_DATE = (SELECT to_date(max(cd.CYC_DT_NM), 'yyyymmdd') " +
            "   FROM PE01.CYCLE_DATE cd WHERE cd.PARTNER_PROC_GRP_ID = 'NICECLM' " +
            "   AND cd.CYC_DT_USED_IND = 'Y')", nativeQuery = true)
    List<Integer> getCountByCycleDate(String createdBy);
}
