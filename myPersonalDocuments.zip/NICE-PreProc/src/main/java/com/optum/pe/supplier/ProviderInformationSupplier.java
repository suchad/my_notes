package com.optum.pe.supplier;

import com.optum.pe.beans.mapping.ProviderInformation;
import com.optum.pe.beans.parsing.CheckRecord;
import com.optum.pe.beans.parsing.ClaimHeaderRecord;
import com.optum.pe.utils.Constants;
import com.optum.pe.utils.RecordType;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
class ProviderInformationSupplier {

    ProviderInformation supply(int transactionSequenceNumber, int recordSequenceNumber, ClaimHeaderRecord claimHeaderRecord, CheckRecord payment,
                               String providerCode) {

        ProviderInformation.ProviderInformationBuilder providerInformation
                = ProviderInformation.builder();

        providerInformation.recordType(RecordType.PROVIDER.getLabel());
        providerInformation.partnerId(Constants.NICE_PARTNER_ID);
        providerInformation.consolidationId(payment.getCheckNumber());
        providerInformation.adjudicationSystemId(Constants.ADJUDICATION_SYSTEM_ID);
        providerInformation.adjudicationSystemUniqueClaimNumber(claimHeaderRecord.getClaimNumber());
        providerInformation.adjudicationSystemUniqueClaimNumberTransactionSequenceNumber(transactionSequenceNumber + "");
        providerInformation.recordSequenceNumber(recordSequenceNumber + "");
        providerInformation.qualifierCode(getQualifierCode(providerCode));

        providerInformation.tinNumber(getTinNumber(providerCode, payment.getTaxId()));

        providerInformation.adjudicationSystemAssignedIdNumber(
                getAdjudicationSystemAssignedIdNumber(payment.getVendorId(), providerCode, claimHeaderRecord.getServiceProvider(), payment));

        providerInformation.payorAssignedIdNumber(
                getPayorAssignedIdNumber(providerCode, payment.getVendorId()));

        providerInformation.npiNumber(payment.getNpi());
        providerInformation.type("");
        providerInformation.firstName("");
        providerInformation.middleName("");
        providerInformation.lastName("");
        providerInformation.suffix("");
        providerInformation.degree("");

        providerInformation.entityName(getEntityName(providerCode,
                payment.getVendorName(), claimHeaderRecord.getServiceProvider()));

        providerInformation.placeOfServiceStateCode("");
        providerInformation.inNetworkCode("");
        providerInformation.streetAddress1(getStreetAddress(providerCode, payment.getAddrLine1()));
        providerInformation.streetAddress2(getStreetAddress(providerCode, payment.getAddrLine2()));
        providerInformation.streetAddress3("");
        providerInformation.streetAddress4("");
        providerInformation.streetAddress5("");
        providerInformation.streetAddress6("");
        providerInformation.streetAddress7("");
        providerInformation.city(getStreetAddress(providerCode, payment.getAddrCity()));
        providerInformation.addressState(getStreetAddress(providerCode, payment.getAddrState()));
        providerInformation.zipCode(getStreetAddress(providerCode, payment.getAddrZipCode()));
        providerInformation.countryCode("");
        providerInformation.primaryPhoneNumber("");
        providerInformation.taxonomyCode("");
        providerInformation.prefix("");
        providerInformation.idQualifier("");
        providerInformation.id(getId(providerCode, payment.getMPin()));
        providerInformation.specialPayeeIndicator("");

        providerInformation.tinNumberQualifier(
                getTinNumberQualifier(providerCode, payment.getTinType()));

        return providerInformation.build();
    }

    private String getStreetAddress(String providerCode, String addrLine) {

        if (Constants.BILLING_PROVIDER_CODE.equals(providerCode)) {
            return addrLine;
        }

        return "";
    }

    private String getId(String providerCode, String id) {

        if (Constants.BILLING_PROVIDER_CODE.equals(providerCode)) {
            return id;
        }

        return "";
    }

    private String getEntityName(String providerCode, String vendorName, String serviceProvider) {

        if (Constants.BILLING_PROVIDER_CODE.equals(providerCode)) {
            return vendorName;
        }

        return serviceProvider;
    }

    private String getTinNumberQualifier(String providerCode, char tinType) {

        if (Constants.BILLING_PROVIDER_CODE.equals(providerCode)) {

            if ('T' == tinType) {
                return "2";
            } else if ('S' == tinType) {
                return "1";
            }
        }

        return "";

    }

    private String getTinNumber(String providerCode, String taxId) {

        if (Constants.BILLING_PROVIDER_CODE.equals(providerCode)) {
            return taxId;
        }

        return "";
    }

    private String getPayorAssignedIdNumber(String providerCode, String vendorId) {

        if (Constants.BILLING_PROVIDER_CODE.equals(providerCode) && vendorId.length() > 14) {
            return vendorId.substring(10, 14).trim();
        }

        return "";
    }

    private String getAdjudicationSystemAssignedIdNumber(String vendorId, String providerCode,
                                                         String serviceProvider, CheckRecord payment) {

        if (Constants.RENDERING_PROVIDER_CODE.equals(providerCode)) {

            Map<String, String> serviceProviderIdMap = payment.getServiceProviderIdMap();

            String serviceProviderId = serviceProviderIdMap.get(serviceProvider);

            if (serviceProviderId != null) {
                return serviceProviderId;
            } else {

                String value = "PROV" + payment.getHighestId();

                serviceProviderIdMap.put(serviceProvider, value);
                payment.setHighestId(payment.getHighestId() + 1);

                return value;
            }
        }

        return vendorId.substring(4, 10).trim();
    }

    private String getQualifierCode(String providerCode) {

        if (Constants.BILLING_PROVIDER_CODE.equals(providerCode)) {
            return "BI";
        }

        return "82";
    }
}
