package com.optum.pe.models;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.Objects;

@Embeddable
public class CycleDatePK implements Serializable {

    private static final long serialVersionUID = 1L;

    @Column(name = "PARTNER_PROC_GRP_ID")
    private String partnerProcGrpId;

    @Column(name = "CYC_DT_NM")
    private LocalDate cycleDate;

    @Override
    public boolean equals(Object o) {

        if (this == o) {
            return true;
        }

        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        CycleDatePK that = (CycleDatePK) o;

        return partnerProcGrpId.equals(that.partnerProcGrpId) &&
                cycleDate.equals(that.cycleDate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(partnerProcGrpId, cycleDate);
    }
}
