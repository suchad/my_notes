package com.optum.pe.supplier;

import com.optum.pe.beans.parsing.CheckRecord;
import com.optum.pe.beans.parsing.ClaimDetailRecord;
import com.optum.pe.beans.parsing.ClaimHeaderRecord;
import com.optum.pe.exception.LookupDataNotFoundException;
import com.optum.pe.models.LookupData;
import com.optum.pe.onepay.avro.ClaimHeader;
import com.optum.pe.onepay.avro.OnePayClaimCOR;
import com.optum.pe.service.LookupDataService;
import com.optum.pe.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

@Slf4j
@Service
public class OnePayClaimCORSupplier {

    private final PaymentInformationSupplier paymentInformationSupplier;
    private final ClaimHeaderSupplier claimHeaderSupplier;
    private final OverPaymentInformationSupplier overPaymentInformationSupplier;
    private final BankingInformationSupplier bankingInformationSupplier;
    private final LookupDataService lookupDataService;
    private final PaymentSupplementalInformationSupplier paymentSupplementalInformationSupplier;

    public OnePayClaimCORSupplier(PaymentInformationSupplier paymentInformationSupplier,
                                  ClaimHeaderSupplier claimHeaderSupplier,
                                  OverPaymentInformationSupplier overPaymentInformationSupplier,
                                  BankingInformationSupplier bankingInformationSupplier, LookupDataService lookupDataService, PaymentSupplementalInformationSupplier paymentSupplementalInformationSupplier) {
        this.paymentInformationSupplier = paymentInformationSupplier;
        this.claimHeaderSupplier = claimHeaderSupplier;
        this.overPaymentInformationSupplier = overPaymentInformationSupplier;
        this.bankingInformationSupplier = bankingInformationSupplier;
        this.lookupDataService = lookupDataService;
        this.paymentSupplementalInformationSupplier = paymentSupplementalInformationSupplier;
    }

    public OnePayClaimCOR supply(CheckRecord payment, String fileName, LocalDate processDate) throws LookupDataNotFoundException {

        List<LookupData> lookupDataList = lookupDataService.getLookupData(
                processDate, Constants.LOOKUP_PARTNER_PROC_GRP_ID);

        LookupData bankInfoLookupData = getLookupDataListFor(payment.getBankCode(), "*",
                "*", Constants.NICE_CLAIM_BANK_INFORMATION, lookupDataList);

        if (bankInfoLookupData == null) {
            throw new LookupDataNotFoundException("BANK_INFO -> BANK_CODE - " + payment.getBankCode());
        }

        LookupData bankAddressLookupData =
                getLookupDataListFor(bankInfoLookupData.getResultField10(), "*",
                        "*", Constants.NICE_CLAIM_BANK_ADDRESS, lookupDataList);

        if (bankAddressLookupData == null) {
            throw new LookupDataNotFoundException("BANK_ADDRESS -> SERIES_DESIGNATOR - " +
                    bankInfoLookupData.getResultField10());
        }

        LookupData payerInfoLookupData =
                getLookupDataListFor(payment.getBankCode(), "*",
                        "*", Constants.NICE_CLAIM_PAYER_INFORMATION, lookupDataList);

        if (payerInfoLookupData == null) {
            throw new LookupDataNotFoundException("PAYER_INFO -> BANK_CODE - " + payment.getBankCode());
        }

        LookupData payerReturnAddressLookupData =
                getLookupDataListFor(payment.getBankCode(), "*",
                        "*", Constants.NICE_CLAIM_PAYER_RETURN_ADDRESS, lookupDataList);

        if (payerReturnAddressLookupData == null) {
            throw new LookupDataNotFoundException("PAYER_RETURN_ADDRESS -> BANK_CODE - " + payment.getBankCode());
        }

        LookupData payerServiceCenterLookupData =
                getLookupDataListFor(payment.getBankCode(), "*",
                        "*", Constants.NICE_CLAIM_PAYER_SERVICE_CENTER_INFO, lookupDataList);

        if (payerServiceCenterLookupData == null) {
            throw new LookupDataNotFoundException("PAYER_SERVICE_CENTER_INFO -> BANK_CODE - " + payment.getBankCode());
        }

        String payeeType = HelperSupplier.getPayeeType(payment.getVendorId());

        String remittanceType = HelperSupplier.getRemittanceType(payeeType, payment.getBankCode());

        String providerContractedIndicator = getProviderContractedIndicator(payment.getVendorId());

        LookupData memberMessageGenericLookupData = getLookupDataListFor(remittanceType, "*",
                "*", Constants.NICE_MEMBER_MESSAGE_GENERIC, lookupDataList);

        LookupData providerMessageStateLookupData = getLookupDataListFor(remittanceType,
                payment.getBankCode(), payment.getAddrState(), Constants.NICE_PROVIDER_MESSAGE_STATE, lookupDataList);

        LookupData providerMessageAppealsLookupData = getLookupDataListFor(remittanceType,
                providerContractedIndicator, "*",
                Constants.NICE_PROVIDER_MESSAGE_APPEALS, lookupDataList);

        OnePayClaimCOR.Builder onePayClaimCORBuilder = OnePayClaimCOR.newBuilder()
                .setPaymentInformation(paymentInformationSupplier.supply(payment, fileName,
                        payeeType, payerInfoLookupData, payerReturnAddressLookupData).toString());

        addSupplementals(payment, payeeType, onePayClaimCORBuilder, bankInfoLookupData);

        addBankInfo(payment, bankInfoLookupData, bankAddressLookupData, onePayClaimCORBuilder);

        addOverPayments(payment, onePayClaimCORBuilder);

        addClaims(payment, payerInfoLookupData, payerServiceCenterLookupData, payerReturnAddressLookupData, memberMessageGenericLookupData, providerMessageStateLookupData, providerMessageAppealsLookupData, onePayClaimCORBuilder);

        return onePayClaimCORBuilder.build();
    }

    private void addSupplementals(CheckRecord payment, String payeeType, OnePayClaimCOR.Builder onePayClaimCORBuilder, LookupData bankInfoLookupData) {
        List<String> paymentSupplementalList = getPaymentSupplementals(payeeType, payment.getCheckNumber(), payment.getVendorId(), Objects.toString(payment.getEraIndicator(), ""), bankInfoLookupData.getResultField10());

        if (!paymentSupplementalList.isEmpty()) {
            onePayClaimCORBuilder.setPaymentSupplementalInformationList(paymentSupplementalList);
        }
    }

    private List<String> getPaymentSupplementals(String payeeType, String checkNumber, String vendorId, String eraIndicator, String bankCode) {

        List<String> paymentSupplementalList = new ArrayList<>(2);

        paymentSupplementalList.add(paymentSupplementalInformationSupplier.supply(checkNumber, vendorId, eraIndicator, bankCode).toString());

        return paymentSupplementalList;
    }

    private void addClaims(CheckRecord payment, LookupData payerInfoLookupData, LookupData payerServiceCenterLookupData, LookupData payerReturnAddressLookupData, LookupData memberMessageGenericLookupData, LookupData providerMessageStateLookupData, LookupData providerMessageAppealsLookupData, OnePayClaimCOR.Builder onePayClaimCORBuilder) {
        List<ClaimHeader> claimHeaderList = getClaimHeaderListFrom(payment,
                payerInfoLookupData, payerServiceCenterLookupData, payerReturnAddressLookupData,
                memberMessageGenericLookupData, providerMessageStateLookupData,
                providerMessageAppealsLookupData);

        if (claimHeaderList != null) {
            onePayClaimCORBuilder.setClaimHeaderList(claimHeaderList);
        }
    }

    private void addOverPayments(CheckRecord payment, OnePayClaimCOR.Builder onePayClaimCORBuilder) {
        List<String> overPaymentList = getOverPaymentList(payment);

        if (!overPaymentList.isEmpty()) {
            onePayClaimCORBuilder.setOverPaymentRecoveryList(overPaymentList);
        }
    }

    private void addBankInfo(CheckRecord payment, LookupData bankInfoLookupData, LookupData bankAddressLookupData, OnePayClaimCOR.Builder onePayClaimCORBuilder) {
        String bankInfoString = getBankInfoString(payment, bankInfoLookupData, bankAddressLookupData);

        if (bankInfoString != null) {
            onePayClaimCORBuilder.setBankInfo(bankInfoString);
        }
    }

    private String getProviderContractedIndicator(String vendorId) {

        if (vendorId.length() > 9) {
            int paymentGroup = getInt(vendorId.substring(4, 9));

            if (paymentGroup <= 1000) {
                return "N";
            } else {
                return "Y";
            }
        }

        return "*";
    }

    private int getInt(String str) {

        try {
            return Integer.parseInt(str);
        } catch (NumberFormatException ex) {
            log.warn("", ex);
        }

        return 0;
    }

    private LookupData getLookupDataListFor(String key01, String key02, String key03,
                                            String lookupSetCode,
                                            List<LookupData> lookupDataList) {

        return lookupDataList.stream()
                .filter(lookupData -> lookupData.getLookupSetCode().equals(lookupSetCode))
                .filter(lookupData -> key01.matches(getRegex(lookupData.getKeyField01())))
                .filter(lookupData -> key02.matches(getRegex(lookupData.getKeyField02())))
                .filter(lookupData -> key03.matches(getRegex(lookupData.getKeyField03())))
                .findFirst().orElse(null);
    }

    private String getRegex(String str) {

        if (Constants.WILDCARD.equals(str)) {
            return Constants.REGEX_WILDCARD;
        }

        return str;
    }

    private String getBankInfoString(CheckRecord payment, LookupData bankInfoLookupData,
                                     LookupData bankAddressLookupData) {

        return bankingInformationSupplier.supply(payment, bankInfoLookupData,
                bankAddressLookupData).toString();
    }

    private List<String> getOverPaymentList(CheckRecord payment) {

        List<String> overPaymentList = new ArrayList<>();
        AtomicInteger recordSequenceNumber = new AtomicInteger(1);

        if (payment.getClaimHeaderRecordList() != null) {

            payment.getClaimHeaderRecordList().forEach(claimHeaderRecord -> {

                if (claimHeaderRecord.getClaimDetailRecordList() != null) {

                    claimHeaderRecord.getClaimDetailRecordList().forEach(claimDetailRecord -> {

                        if (isOverPayment(claimDetailRecord)) {

                            overPaymentList.add(overPaymentInformationSupplier.supply(
                                    payment.getCheckNumber(), payment.getVendorId(),
                                    recordSequenceNumber.getAndAdd(1),
                                    claimDetailRecord, claimHeaderRecord, payment.getCheckDate()).toString());
                        }
                    });
                }
            });
        }

        return overPaymentList;
    }

    private boolean isOverPayment(ClaimDetailRecord claimDetailRecord) {
        return Constants.RECOVERY_SERVICE_CODE.equals(claimDetailRecord.getServiceCode()) ||
                Constants.INTEREST_RECOVERY_SERVICE_CODE.equals(claimDetailRecord.getServiceCode());
    }

    private List<ClaimHeader> getClaimHeaderListFrom(CheckRecord payment,
                                                     LookupData payerInfoLookupData,
                                                     LookupData payerServiceCenterLookupData,
                                                     LookupData payerReturnAddressLookupData,
                                                     LookupData memberMessageLookupData,
                                                     LookupData providerMessagePdrLookupData,
                                                     LookupData providerMessageNonnLookupData) {

        List<ClaimHeader> claimHeaderList = null;

        AtomicInteger transactionSequenceNumber = new AtomicInteger(1);

        if (payment.getClaimHeaderRecordList() != null) {
            claimHeaderList = payment.getClaimHeaderRecordList().stream()
                    .filter(this::isNotRecovery)
                    .map(claimHeaderRecord ->
                            claimHeaderSupplier
                                    .supply(transactionSequenceNumber.getAndAdd(1), claimHeaderRecord, payment, payerInfoLookupData,
                                            payerServiceCenterLookupData, payerReturnAddressLookupData,
                                            memberMessageLookupData, providerMessagePdrLookupData,
                                            providerMessageNonnLookupData))
                    .collect(Collectors.toList());
        }

        return claimHeaderList;
    }

    private boolean isNotRecovery(ClaimHeaderRecord claimHeaderRecord) {

        if (claimHeaderRecord.getClaimDetailRecordList() != null) {

            Optional<ClaimDetailRecord> claimDetailRecordOptional = claimHeaderRecord.getClaimDetailRecordList().stream()
                    .filter(claimDetailRecord -> Constants.RECOVERY_SERVICE_CODE.equals(claimDetailRecord.getServiceCode()) ||
                            Constants.INTEREST_RECOVERY_SERVICE_CODE.equals(claimDetailRecord.getServiceCode()))
                    .findAny();

            return !claimDetailRecordOptional.isPresent();
        }

        return true;
    }
}
