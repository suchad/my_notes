package com.optum.pe.supplier;

import com.optum.pe.beans.mapping.SubscriberInformation;
import com.optum.pe.beans.parsing.ClaimHeaderRecord;
import com.optum.pe.utils.Constants;
import com.optum.pe.utils.RecordType;
import org.springframework.stereotype.Service;

@Service
class SubscriberInformationSupplier {

    SubscriberInformation supply(String checkNumber, int transactionSequenceNumber, String vendorId, ClaimHeaderRecord claimHeaderRecord) {

        SubscriberInformation.SubscriberInformationBuilder subscriberInformation
                = SubscriberInformation.builder();

        subscriberInformation.recordType(RecordType.SUBSCRIBER.getLabel());
        subscriberInformation.partnerId(Constants.NICE_PARTNER_ID);
        subscriberInformation.consolidationId(checkNumber);
        subscriberInformation.adjudicationSystemId(Constants.ADJUDICATION_SYSTEM_ID);
        subscriberInformation.adjudicationSystemUniqueClaimNumber(claimHeaderRecord.getClaimNumber());
        subscriberInformation.adjudicationSystemUniqueClaimNumberTransactionSequenceNumber(transactionSequenceNumber + "");
        subscriberInformation.universalId("");
        subscriberInformation.identificationNumberSubmitted(getNumberSubmitted(vendorId, claimHeaderRecord.getSubscriberId()));
        subscriberInformation.identificationNumberQualifierSubmitted("");
        subscriberInformation.firstName(claimHeaderRecord.getSubscriberFirstName());
        subscriberInformation.middleName(claimHeaderRecord.getSubscriberMiddleInitial() + "");
        subscriberInformation.lastName(claimHeaderRecord.getSubscriberLastName());
        subscriberInformation.suffix("");
        subscriberInformation.identificationNumberAdjudicated(claimHeaderRecord.getSubscriberId());
        subscriberInformation.identificationNumberQualifierAdjudicated("E");
        subscriberInformation.firstNameAdjudicated(claimHeaderRecord.getSubscriberFirstName());
        subscriberInformation.middleNameAdjudicated(claimHeaderRecord.getSubscriberMiddleInitial() + "");
        subscriberInformation.lastNameAdjudicated(claimHeaderRecord.getSubscriberLastName());
        subscriberInformation.suffixAdjudicated("");
        subscriberInformation.mailingStreetAddress1("");
        subscriberInformation.mailingStreetAddress2("");
        subscriberInformation.mailingStreetAddress3("");
        subscriberInformation.mailingStreetAddress4("");
        subscriberInformation.mailingStreetAddress5("");
        subscriberInformation.mailingStreetAddress6("");
        subscriberInformation.mailingStreetAddress7("");
        subscriberInformation.mailingCity("");
        subscriberInformation.mailingState("");
        subscriberInformation.mailingZip("");
        subscriberInformation.countryCode("");
        subscriberInformation.authorizedPartnerIndicator("");
        subscriberInformation.coverageIdXRef("");
        subscriberInformation.medicareMedicalSourceSystem("");
        subscriberInformation.hicn("");
        subscriberInformation.dateOfBirth("");
        subscriberInformation.traditionalAccumulatorKey("");
        subscriberInformation.namePrefix("");
        subscriberInformation.namePrefixAdjudicated("");

        return subscriberInformation.build();
    }

    private String getNumberSubmitted(String vendorId, String subscriberId) {

        String payeeType = HelperSupplier.getPayeeType(vendorId);

        if (Constants.SUBSCRIBER_CODE.equals(payeeType)) {
            return subscriberId;
        }

        return "";
    }
}
