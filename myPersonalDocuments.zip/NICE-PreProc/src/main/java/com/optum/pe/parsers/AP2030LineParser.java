package com.optum.pe.parsers;

import com.optum.pe.beans.parsing.Record;

public interface AP2030LineParser extends LineParser {

    void updateState(String fileName, Record record);
}
