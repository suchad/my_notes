package com.optum.pe.beans.mapping;

import lombok.Builder;
import lombok.Getter;

import java.util.StringJoiner;

@Builder
@Getter
public class ClaimHeaderInformation {

    private String recordType;
    private String partnerId;
    private String consolidationId;
    private String adjudicationSystemId;
    private String adjudicationSystemUniqueClaimNumber;
    private String adjudicationSystemUniqueClaimNumberTransactionSequenceNumber;
    private String adjudicationSubSystemId;
    private String claimsRepositoryId;
    private String claimsRepositoryUniqueClaimId;
    private String claimCoverageTypeCode;
    private String claimTypeOfTransaction;
    private String claimCOBStatusCode;
    private String claimEarliestServiceStartDate;
    private String claimLatestServiceEndDate;
    private String claimTotalAmountBilled;
    private String claimTotalAmountPended;
    private String claimTotalAmountApproved;
    private String claimTotalPlanPaidAmount;
    private String claimTotalPlanPaidAmountPaidToTheProvider;
    private String claimTotalPlanPaidAmountPaidToTheMember;
    private String claimTotalAmountPaidToAnyOtherEntity;
    private String claimTotalPatientResponsibilityAmount;
    private String claimTotalPatientResponsibilityAmountForApprovedServices;
    private String claimTotalPatientResponsibilityAmountForDeniedServices;
    private String dateClaimWasReceivedByCarrier;
    private String dateClaimWasFullyAdjudicatedByTheAdjudicationSystem;
    private String claimSubmitterTypeCode;
    private String claimSubmissionTypeCode;
    private String remittanceDisplayClaimId;
    private String consolidationAdjudicationSystemId;
    private String otherAdjudicationSystemAssociatedClaimNumber;
    private String claimInNetworkIndicator;
    private String eobCopyCode;
    private String globalHubIndicator;
    private String documentCode;
    private String claimEOBPrintSuppressionIndicator;
    private String claimEOBPrintSuppressionReasonCode;
    private String paymentSuppressionIndicator;
    private String immediateReleaseIndicatorMember;
    private String capitationIndicator;
    private String privacyCode;
    private String optOutIndicator;
    private String payTheMemberIndicator;
    private String claimInPatientIndicator;
    private String claimServiceTypeCode;
    private String memberPaymentMethodCode;
    private String providerPaymentMethodCode;
    private String preAuthorizationCode;
    private String authorizationNumber;
    private String drgCode;
    private String drgWeight;
    private String claimLevelAdjudicationSystemsOfficeCode;
    private String claimLevelRemarkCode1;
    private String claimLevelRemarkCode2;
    private String claimLevelRemarkCode3;
    private String claimLevelRemarkCode4;
    private String claimLevelRemarkCode5;
    private String ansiRMKCode1;
    private String ansiRMKCode2;
    private String ansiRMKCode3;
    private String ansiRMKCode4;
    private String ansiRMKCode5;
    private String patientIdentificationNumber;
    private String promptPayState;
    private String promptPayNoLaterThanPenaltyDate;
    private String claimFilingIndicatorCode;
    private String claimFacilityTypeCode;
    private String claimFrequencyCode;
    private String claimDischargeFraction;
    private String claimCoverageEligibilityExpirationDate;
    private String claimOriginalCheckNumber;
    private String languageThresholdIndicator;
    private String preferredLanguageCode;
    private String thresholdLanguageCode1;
    private String thresholdLanguageCode2;
    private String thresholdLanguageCode3;
    private String clapHMOIndicator;
    private String clapIndicator;
    private String clapRMKCode;
    private String optSupplementalCoverageIndicator;
    private String claimAppliesToMOOP;
    private String peGenMonthlyEOB;
    private String praDocumentCode;
    private String rmkQualifierCode1;
    private String rmkQualifierCode2;
    private String rmkQualifierCode3;
    private String rmkQualifierCode4;
    private String rmkQualifierCode5;
    private String finalizeDateTime;
    private String coverageHasNetworkIndicator;
    private String claimEventCode;
    private String rmkTextVersionKeyCode1;
    private String rmkTextVersionKeyCode2;
    private String rmkTextVersionKeyCode3;
    private String rmkTextVersionKeyCode4;
    private String rmkTextVersionKeyCode5;
    private String rmkAdditionalTextVersionKeyCode1;
    private String rmkAdditionalTextVersionKeyCode2;
    private String rmkAdditionalTextVersionKeyCode3;
    private String rmkAdditionalTextVersionKeyCode4;
    private String rmkAdditionalTextVersionKeyCode5;
    private String claimCoPay;
    private String claimCoins;
    private String claimDeductible;
    private String remarkCode1ReferenceKey;
    private String remarkCode2ReferenceKey;
    private String remarkCode3ReferenceKey;
    private String remarkCode4ReferenceKey;
    private String remarkCode5ReferenceKey;
    private String peGenPRA;
    private String peGen835;
    private String pseudoClaimIndicator;
    private String claimStatusCode;
    private String promptPaymentByPassIndicator;
    private String desiredPaymentReleaseDateMemberEOB;
    private String desiredPaymentReleaseDateProvider;
    private String immediateReleaseIndicatorProvider;
    private String erisaIndicator;
    private String otherInsuranceType;
    private String totalPaidByOtherInsurance;
    private String totalPaidByMedicare;
    private String providerDiscountAmount;
    private String notCoveredPatientResponsibility;
    private String medicareEstimatedPaymentAmount;
    private String claimPRAPrintSuppressionIndicator;
    private String reversalCorrectionAssociationId;
    private String resubmitIndicator;
    private String dateOriginalClaimWasReceivedByCarrier;
    private String promptPaymentClaimStoppedDate;
    private String cleanClaimIndicator;
    private String correctionClaimPaymentChangeCode;
    private String sgaIndicator;
    private String patientMedicalRecordNumber;
    private String freeformRemarkCode;
    private String freeformRemarkText;
    private String claimTotalReportingPaidAmountToProvider;
    private String claimTotalReportingPaidAmountToMember;
    private String compliance835RejectByPassIndicator;
    private String remittanceAdviceCode1;
    private String remittanceAdviceCode2;
    private String remittanceAdviceCode3;
    private String remittanceAdviceCode4;
    private String remittanceAdviceCode5;
    private String adjudicationSystemUniqueSubmittedClaimNumber;
    private String adjudicationSystemOriginalUniqueClaimNumberTransactionSequenceNumber;
    private String adjudicatedPerManagedCareContractIndicator;
    private String adjudicatedPrePPOContractIndicator;
    private String adjudicationSyatemOriginalClaimControlNumber;
    private String promptPaymentSpecialFacilityCode;
    private String cobCreditSavingsAppliedToPaymentIndicator;
    private String benefitDenialMessageReasonCode;
    private String divertProviderPaymentIndicator;
    private String divertMemberPaymentIndicator;
    private String dedOOPReachedCode;
    private String memberEOBPolicyElectionSuppressionReportingCode;
    private String eobSubscriberElectionSuppressReportingCode;
    private String peGenMemberEOB;
    private String providerNotCoveredAmount;
    private String divertProviderPRAIndicator;
    private String divertMemberEOBIndicator;
    private String otherAdjudicationSystemAssociatedClaimTransactionSequenceNumber;
    private String otherAdjudicationSystemAssociatedPolicyGroupNumber;
    private String interestOnlyClaimIndicator;
    private String interestClaimAssociationId;
    private String surchargeOnlyClaimIndicator;
    private String providerEOBTierMessageIndicator;
    private String reverseInterestOriginalClaimIndicator;
    private String originalPaidAmount;
    private String benefitLevel;
    private String peORMSInSyncIndicator;
    private String splitClaimAssociationId;
    private String ccClaimNumber;
    private String ccReceiptDate;
    private String ccClosureLetterDate;
    private String ccReasonCode;
    private String externalPayerIndicator;
    private String claimReportingPaidAmountToProviderByExternalPayer;
    private String claimReportingPaidAmountToMemberByExternalPayer;
    private String claimPaidAmountToProviderByExternalPayer;
    private String claimPaidAmountToMemberByExternalPayer;
    private String totalPaidAmountByExternalPayer;
    private String drgAmount;

    @Override
    public String toString() {
        return new StringJoiner("|", "", "|")
                .add(recordType)
                .add(partnerId)
                .add(consolidationId)
                .add(adjudicationSystemId)
                .add(adjudicationSystemUniqueClaimNumber)
                .add(adjudicationSystemUniqueClaimNumberTransactionSequenceNumber)
                .add(adjudicationSubSystemId)
                .add(claimsRepositoryId)
                .add(claimsRepositoryUniqueClaimId)
                .add(claimCoverageTypeCode)
                .add(claimTypeOfTransaction)
                .add(claimCOBStatusCode)
                .add(claimEarliestServiceStartDate)
                .add(claimLatestServiceEndDate)
                .add(claimTotalAmountBilled)
                .add(claimTotalAmountPended)
                .add(claimTotalAmountApproved)
                .add(claimTotalPlanPaidAmount)
                .add(claimTotalPlanPaidAmountPaidToTheProvider)
                .add(claimTotalPlanPaidAmountPaidToTheMember)
                .add(claimTotalAmountPaidToAnyOtherEntity)
                .add(claimTotalPatientResponsibilityAmount)
                .add(claimTotalPatientResponsibilityAmountForApprovedServices)
                .add(claimTotalPatientResponsibilityAmountForDeniedServices)
                .add(dateClaimWasReceivedByCarrier)
                .add(dateClaimWasFullyAdjudicatedByTheAdjudicationSystem)
                .add(claimSubmitterTypeCode)
                .add(claimSubmissionTypeCode)
                .add(remittanceDisplayClaimId)
                .add(consolidationAdjudicationSystemId)
                .add(otherAdjudicationSystemAssociatedClaimNumber)
                .add(claimInNetworkIndicator)
                .add(eobCopyCode)
                .add(globalHubIndicator)
                .add(documentCode)
                .add(claimEOBPrintSuppressionIndicator)
                .add(claimEOBPrintSuppressionReasonCode)
                .add(paymentSuppressionIndicator)
                .add(immediateReleaseIndicatorMember)
                .add(capitationIndicator)
                .add(privacyCode)
                .add(optOutIndicator)
                .add(payTheMemberIndicator)
                .add(claimInPatientIndicator)
                .add(claimServiceTypeCode)
                .add(memberPaymentMethodCode)
                .add(providerPaymentMethodCode)
                .add(preAuthorizationCode)
                .add(authorizationNumber)
                .add(drgCode)
                .add(drgWeight)
                .add(claimLevelAdjudicationSystemsOfficeCode)
                .add(claimLevelRemarkCode1)
                .add(claimLevelRemarkCode2)
                .add(claimLevelRemarkCode3)
                .add(claimLevelRemarkCode4)
                .add(claimLevelRemarkCode5)
                .add(ansiRMKCode1)
                .add(ansiRMKCode2)
                .add(ansiRMKCode3)
                .add(ansiRMKCode4)
                .add(ansiRMKCode5)
                .add(patientIdentificationNumber)
                .add(promptPayState)
                .add(promptPayNoLaterThanPenaltyDate)
                .add(claimFilingIndicatorCode)
                .add(claimFacilityTypeCode)
                .add(claimFrequencyCode)
                .add(claimDischargeFraction)
                .add(claimCoverageEligibilityExpirationDate)
                .add(claimOriginalCheckNumber)
                .add(languageThresholdIndicator)
                .add(preferredLanguageCode)
                .add(thresholdLanguageCode1)
                .add(thresholdLanguageCode2)
                .add(thresholdLanguageCode3)
                .add(clapHMOIndicator)
                .add(clapIndicator)
                .add(clapRMKCode)
                .add(optSupplementalCoverageIndicator)
                .add(claimAppliesToMOOP)
                .add(peGenMonthlyEOB)
                .add(praDocumentCode)
                .add(rmkQualifierCode1)
                .add(rmkQualifierCode2)
                .add(rmkQualifierCode3)
                .add(rmkQualifierCode4)
                .add(rmkQualifierCode5)
                .add(finalizeDateTime)
                .add(coverageHasNetworkIndicator)
                .add(claimEventCode)
                .add(rmkTextVersionKeyCode1)
                .add(rmkTextVersionKeyCode2)
                .add(rmkTextVersionKeyCode3)
                .add(rmkTextVersionKeyCode4)
                .add(rmkTextVersionKeyCode5)
                .add(rmkAdditionalTextVersionKeyCode1)
                .add(rmkAdditionalTextVersionKeyCode2)
                .add(rmkAdditionalTextVersionKeyCode3)
                .add(rmkAdditionalTextVersionKeyCode4)
                .add(rmkAdditionalTextVersionKeyCode5)
                .add(claimCoPay)
                .add(claimCoins)
                .add(claimDeductible)
                .add(remarkCode1ReferenceKey)
                .add(remarkCode2ReferenceKey)
                .add(remarkCode3ReferenceKey)
                .add(remarkCode4ReferenceKey)
                .add(remarkCode5ReferenceKey)
                .add(peGenPRA)
                .add(peGen835)
                .add(pseudoClaimIndicator)
                .add(claimStatusCode)
                .add(promptPaymentByPassIndicator)
                .add(desiredPaymentReleaseDateMemberEOB)
                .add(desiredPaymentReleaseDateProvider)
                .add(immediateReleaseIndicatorProvider)
                .add(erisaIndicator)
                .add(otherInsuranceType)
                .add(totalPaidByOtherInsurance)
                .add(totalPaidByMedicare)
                .add(providerDiscountAmount)
                .add(notCoveredPatientResponsibility)
                .add(medicareEstimatedPaymentAmount)
                .add(claimPRAPrintSuppressionIndicator)
                .add(reversalCorrectionAssociationId)
                .add(resubmitIndicator)
                .add(dateOriginalClaimWasReceivedByCarrier)
                .add(promptPaymentClaimStoppedDate)
                .add(cleanClaimIndicator)
                .add(correctionClaimPaymentChangeCode)
                .add(sgaIndicator)
                .add(patientMedicalRecordNumber)
                .add(freeformRemarkCode)
                .add(freeformRemarkText)
                .add(claimTotalReportingPaidAmountToProvider)
                .add(claimTotalReportingPaidAmountToMember)
                .add(compliance835RejectByPassIndicator)
                .add(remittanceAdviceCode1)
                .add(remittanceAdviceCode2)
                .add(remittanceAdviceCode3)
                .add(remittanceAdviceCode4)
                .add(remittanceAdviceCode5)
                .add(adjudicationSystemUniqueSubmittedClaimNumber)
                .add(adjudicationSystemOriginalUniqueClaimNumberTransactionSequenceNumber)
                .add(adjudicatedPerManagedCareContractIndicator)
                .add(adjudicatedPrePPOContractIndicator)
                .add(adjudicationSyatemOriginalClaimControlNumber)
                .add(promptPaymentSpecialFacilityCode)
                .add(cobCreditSavingsAppliedToPaymentIndicator)
                .add(benefitDenialMessageReasonCode)
                .add(divertProviderPaymentIndicator)
                .add(divertMemberPaymentIndicator)
                .add(dedOOPReachedCode)
                .add(memberEOBPolicyElectionSuppressionReportingCode)
                .add(eobSubscriberElectionSuppressReportingCode)
                .add(peGenMemberEOB)
                .add(providerNotCoveredAmount)
                .add(divertProviderPRAIndicator)
                .add(divertMemberEOBIndicator)
                .add(otherAdjudicationSystemAssociatedClaimTransactionSequenceNumber)
                .add(otherAdjudicationSystemAssociatedPolicyGroupNumber)
                .add(interestOnlyClaimIndicator)
                .add(interestClaimAssociationId)
                .add(surchargeOnlyClaimIndicator)
                .add(providerEOBTierMessageIndicator)
                .add(reverseInterestOriginalClaimIndicator)
                .add(originalPaidAmount)
                .add(benefitLevel)
                .add(peORMSInSyncIndicator)
                .add(splitClaimAssociationId)
                .add(ccClaimNumber)
                .add(ccReceiptDate)
                .add(ccClosureLetterDate)
                .add(ccReasonCode)
                .add(externalPayerIndicator)
                .add(claimReportingPaidAmountToProviderByExternalPayer)
                .add(claimReportingPaidAmountToMemberByExternalPayer)
                .add(claimPaidAmountToProviderByExternalPayer)
                .add(claimPaidAmountToMemberByExternalPayer)
                .add(totalPaidAmountByExternalPayer)
                .add(drgAmount)
                .toString();
    }
}
