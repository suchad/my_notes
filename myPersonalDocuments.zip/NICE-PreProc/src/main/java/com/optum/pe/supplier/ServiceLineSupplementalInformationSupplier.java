package com.optum.pe.supplier;

import com.optum.pe.beans.mapping.ServiceLineSupplementalInformation;
import com.optum.pe.beans.parsing.Adjustment;
import com.optum.pe.utils.Constants;
import com.optum.pe.utils.RecordType;
import org.springframework.stereotype.Service;

@Service
class ServiceLineSupplementalInformationSupplier {

    ServiceLineSupplementalInformation supply(String checkNumber, String claimNumber,
                                              int transactionSequenceNumber, int recordSequenceNumber,
                                              int adjudicationSystemNumber, Adjustment adjustment) {

        ServiceLineSupplementalInformation.ServiceLineSupplementalInformationBuilder
                serviceLineSupplementalInformation
                = ServiceLineSupplementalInformation.builder();

        serviceLineSupplementalInformation.recordType(RecordType.SERVICE_LINE_SUPPLEMENTAL.getLabel());
        serviceLineSupplementalInformation.partnerId(Constants.NICE_PARTNER_ID);
        serviceLineSupplementalInformation.consolidationId(checkNumber);
        serviceLineSupplementalInformation.adjudicationSystemId(Constants.ADJUDICATION_SYSTEM_ID);
        serviceLineSupplementalInformation.adjudicationSystemUniqueClaimNumber(claimNumber);
        serviceLineSupplementalInformation.adjudicationSystemUniqueClaimNumberTransactionSequenceNumber(transactionSequenceNumber + "");

        serviceLineSupplementalInformation.serviceLineAdjudicationSystemNumber(
                adjudicationSystemNumber + "");

        serviceLineSupplementalInformation.recordSequenceNumber(recordSequenceNumber + "");
        serviceLineSupplementalInformation.userDefinedField1(adjustment.getAdjustedReason());
        serviceLineSupplementalInformation.userDefinedField2(adjustment.getRemarkAdjustmentReasonCode());
        serviceLineSupplementalInformation.userDefinedField3(
                HelperSupplier.getAmount(adjustment.getPaySign(), HelperSupplier.removeComma(adjustment.getPayAmount())));

        serviceLineSupplementalInformation.userDefinedField4("");
        serviceLineSupplementalInformation.userDefinedField5("");
        serviceLineSupplementalInformation.userDefinedField6("");
        serviceLineSupplementalInformation.userDefinedField7("");
        serviceLineSupplementalInformation.userDefinedField8("");
        serviceLineSupplementalInformation.userDefinedField9("");
        serviceLineSupplementalInformation.userDefinedField10("");

        return serviceLineSupplementalInformation.build();
    }
}
