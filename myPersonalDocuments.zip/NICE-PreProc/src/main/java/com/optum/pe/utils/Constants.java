package com.optum.pe.utils;

import java.time.format.DateTimeFormatter;

public class Constants {

    public static final String CONSUME_CONTAINER_ID = "pe-ctc-onepay_nice_preproc-1";
    public static final String ADJUDICATION_SYSTEM_ID = "1223";
    public static final String NICE_PARTNER_ID = "1223-1";
    public static final String TRIGGER_FILE_EXTENSION = ".SUCCESS";
    public static final String DATA_FILE_EXTENSION = ".DAT";
    public static final String WIP_FILE_EXTENSION = ".wip";
    public static final String OUTPUT_FILE_NAME = "NICECLM_PE_ONRAMP_";
    public static final String WRITING_FILE_EXTENSION = ".writing";
    public static final int LINE_LENGTH = 250;
    public static final Object SEPARATOR = " - ";
    public static final String APPLICATION_NAME = "NICE-PREPROC";
    public static final String LOOKUP_CACHE_NAME = "NICE";
    public static final String BILLING_PROVIDER_CODE = "PROVBI";
    public static final String RENDERING_PROVIDER_CODE = "PROV82";
    public static final String ZERO_AMOUNT = "0.00";
    public static final String PENALTY_SERVICE_CODE = "PENALTY ";
    public static final String INTEREST_SERVICE_CODE = "INTEREST";
    public static final String CLAIM_SERVICE_CODE = "CLAIM-  ";
    public static final String RECOVERY_SERVICE_CODE = "RECOVERY";
    public static final String INTEREST_RECOVERY_SERVICE_CODE = "IOPRCVRY";
    public static final String EMPTY_SERVICE_CODE = "        ";
    public static final String CLM_2 = "CLM2";
    public static final String SUBSCRIBER_CODE = "S";
    public static final String PROVIDER_CODE = "P";
    public static final String OVER_MESSAGE_PLACEMENT_CODE = "OVR";
    public static final String SERVICE_MESSAGE_PLACEMENT_CODE = "SVC";
    public static final String CLAIM_MESSAGE_PLACEMENT_CODE = "CLM";
    public static final String LOOKUP_PARTNER_PROC_GRP_ID = "NICECLM";
    public static final String NICE_CLAIM_BANK_INFORMATION = "NICECLM Bank Information";
    public static final String NICE_CLAIM_BANK_ADDRESS = "NICECLM Bank Address";

    public static final DateTimeFormatter COR_DATE_FORMATTER = DateTimeFormatter.ofPattern(Constants.CTL_CYCLE_DATE_FORMAT);
    public static final DateTimeFormatter AP2030_FILE_DATE_FORMATTER = DateTimeFormatter.ofPattern("MM/dd/yyyy");
    public static final String NICE_CLAIM_PAYER_INFORMATION = "NICECLM Claim Payer Information";
    public static final String NICE_CLAIM_PAYER_RETURN_ADDRESS = "NICECLM Payer Return Address";
    public static final String NICE_CLAIM_PAYER_SERVICE_CENTER_INFO = "NICECLM Payer Service Center Info";
    public static final String NICE_MEMBER_MESSAGE_GENERIC = "NICE Member Message - Generic";
    public static final String NICE_PROVIDER_MESSAGE_STATE = "NICE Provider Message - State";
    public static final String NICE_PROVIDER_MESSAGE_APPEALS = "NICE Provider Message - Appeals";
    public static final String MESSAGE_CODE_35 = "REC35";
    public static final String CTL_CYCLE_DATE_FORMAT = "yyyyMMdd";
    public static final String WILDCARD = "*";
    public static final String REGEX_WILDCARD = ".*";
    public static final String COMPLETE_SUCCESS_FILE = "FILE_PROCESS_COMPLETE_AP2030_";
    public static final String ZERO = "0";
    public static final String MAX_DATE = "99991231";
    public static final String FLAG_Y = "Y";
    public static final String FLAG_N = "N";
    public static final String FLAG_X = "X";
    public static final String APP_NAME = "NICE_PREPROC_APP";
    public static final String SERVICE_NAME = "pe-nice-preproc";
    public static final String ENDPOINT_NAME = "NICE-COR-FILE-CREATION";
    public static final String SERVICE_PARAMETER_VALUE = "PREPROC_2030_FLAG";
    public static final String CLAIM_EVENT_CODE_SURPRISE_BILLING = "SB";
    public static final String FEDERAL = "F";
    public static final String MESSAGE_CODE_S9999 = "S9999";
    public static final String  PARTNER_PROC_GRP_ID = "NICECLM";
    public static final String PARAMETER_NAME_NICE = "IsNiceCodeDeployed";
    public static final String PARAMETER_NAME_CDC = "IsCdcCodeDeployed";
    public static final String NICE_CDC_CACHE_NAME = "NICE_CDC_TOGGLE";
    public static final String MESSAGE_CODE_N0007 = "N0007";
    public static final String SURPRISE_BILLING_MESSAGE = "This claim has been identified as a surprise bill. Additional information is at the end of this statement.";
    private Constants() {
    }
}
