package com.optum.pe.nice;

import com.optum.pe.configuration.DefaultConfiguration;
import org.apache.commons.io.FilenameUtils;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Stream;

@Service
class PathGetterService {

    private final DefaultConfiguration defaultConfiguration;

    PathGetterService(DefaultConfiguration defaultConfiguration) {
        this.defaultConfiguration = defaultConfiguration;
    }

    Stream<Path> getFilePaths() throws IOException {
        String filePath = FilenameUtils.getFullPath(defaultConfiguration.getFileLocation());

        Path path = Paths.get(filePath);

        return Files.walk(path, 1);
    }

    String getOutputPath() {
        return defaultConfiguration.getOutputPath();
    }

    String getArchivePath() {
        return defaultConfiguration.getArchivePath();
    }

    Stream<Path> getSuccessFilePath() throws IOException{
        String filePath = FilenameUtils.getFullPath(getOutputPath());
        Path path = Paths.get(filePath);
        return Files.walk(path, 1);
    }
}
