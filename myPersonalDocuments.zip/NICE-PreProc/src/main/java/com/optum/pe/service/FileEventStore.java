package com.optum.pe.service;

import com.optum.pe.configuration.DefaultConfiguration;
import com.optum.pe.models.FileEvent;
import com.optum.pe.models.FileEventFlagAndCount;
import com.optum.pe.nice.SuccessFileWritingService;
import com.optum.pe.repositories.FileEventStoreRepository;
import com.optum.pe.utils.Constants;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataAccessException;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
@Service
public class FileEventStore {

    private final FileEventStoreRepository fileEventStoreRepository;
    private final DefaultConfiguration defaultConfiguration;
    private final SuccessFileWritingService successFileWritingService;

    public FileEventStore(FileEventStoreRepository fileEventStoreRepository,
                          DefaultConfiguration defaultConfiguration, SuccessFileWritingService successFileWritingService) {
        this.fileEventStoreRepository = fileEventStoreRepository;
        this.defaultConfiguration = defaultConfiguration;
        this.successFileWritingService = successFileWritingService;
    }

    public List<String> getMissingFileNames() {
        try {
            return fileEventStoreRepository.findMissingFileNames(Constants.APPLICATION_NAME, Constants.LOOKUP_PARTNER_PROC_GRP_ID);
        } catch (DataAccessException ex) {
            log.error("", ex);
        }

        return Collections.emptyList();
    }

    @Async
    public void addEvent(FileEvent fileEvent) {
        fileEventStoreRepository.save(fileEvent);

        List<String> missingFileNames =
                fileEventStoreRepository.findMissingFileNames(Constants.APPLICATION_NAME, Constants.LOOKUP_PARTNER_PROC_GRP_ID);

        if (missingFileNames.isEmpty()) {

            boolean isFileCreated = successFileWritingService.write();

            if (isFileCreated) {
                log.info("success file successfully created.");
            } else {
                log.error("not able to create the success file.");
            }
        }
    }

    public FileEventFlagAndCount getFileEventFlagAndCount(String fileId, String cycleDate) {
        return getFileEventFlagAndCountFromMap(fileEventStoreRepository.getFileEventFlagAndCountMap(Constants.APPLICATION_NAME, fileId, cycleDate));
    }

    private FileEventFlagAndCount getFileEventFlagAndCountFromMap(Map<String, Object> resultSet) {

        if (resultSet.containsKey("active_flag") && resultSet.containsKey("file_count")) {
            return new FileEventFlagAndCount((char) resultSet.get("active_flag"), ((BigDecimal) resultSet.get("file_count")).intValue());
        }

        log.warn("not able to find the flag and count values from FILE_EVENT_STORE");

        return new FileEventFlagAndCount('N', 0);
    }

    public FileEvent getFileEventFrom(String fileName, LocalDate cycleDate, String payCount) {
        return FileEvent.builder()
                .fileName(fileName)
                .cycleDate(cycleDate)
                .ppid(defaultConfiguration.getPartnerProcGroupId())
                .fileId(getFileIdFrom(fileName))
                .activeFlag('Y')
                .creationDate(LocalDateTime.now())
                .updationDate(LocalDateTime.now())
                .createdBy(Constants.APPLICATION_NAME)
                .payCount(StringUtils.isNotBlank(payCount) ? Integer.parseInt(payCount) : 0)
                .build();
    }

    public static int getFileIdFrom(String fileName) {

        Pattern pattern = Pattern.compile("\\d+");

        Matcher matcher = pattern.matcher(fileName);

        if (matcher.find()) {
            return getIntFrom(matcher.group());
        }

        return -1;
    }

    private static int getIntFrom(String str) {
        try {
            return Integer.parseInt(str);
        } catch (NumberFormatException ex) {
            log.error("", ex);
        }

        return -1;
    }

    public List<Integer> getFileEventData(String appName){
        return  fileEventStoreRepository.getCountByCycleDate(appName);
    }
}