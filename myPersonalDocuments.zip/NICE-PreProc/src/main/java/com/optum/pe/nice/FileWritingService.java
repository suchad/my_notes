package com.optum.pe.nice;

import com.optum.pe.beans.writing.CtlData;
import com.optum.pe.service.CorDataStoreService;
import com.optum.pe.service.CycleDateService;
import com.optum.pe.service.FileEventStore;
import com.optum.pe.service.SMTPService;
import com.optum.pe.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.sql.Clob;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Stream;
import java.util.zip.GZIPOutputStream;

import static com.optum.pe.utils.Constants.APPLICATION_NAME;

@Slf4j
@Service
public class FileWritingService {

    private final PathGetterService pathGetterService;
    private final CycleDateService cycleDateService;
    private final CorDataStoreService corDataStoreService;
    private final FileEventStore fileEventStore;
    private final SMTPService smtpService;

    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
    private final DateTimeFormatter ctlFormatter = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss");

    public FileWritingService(PathGetterService pathGetterService, CycleDateService cycleDateService, CorDataStoreService corDataStoreService, FileEventStore fileEventStore, SMTPService smtpService) {
        this.pathGetterService = pathGetterService;
        this.cycleDateService = cycleDateService;
        this.corDataStoreService = corDataStoreService;
        this.fileEventStore = fileEventStore;
        this.smtpService = smtpService;
    }

    void write() {

        if (isPayCountMatch()) {

            Path path = getFilePath(pathGetterService.getOutputPath());

            List<Clob> paymentClobList = corDataStoreService.getCurrentPaymentsFromDB();

            if (paymentClobList != null && !paymentClobList.isEmpty()) {
                paymentClobList.stream().map(paymentClob -> {

                    StringBuilder sb = new StringBuilder();

                    try {
                        Reader reader = paymentClob.getCharacterStream();

                        appendRecords(sb, reader);
                    } catch (SQLException e) {
                        log.info("sql exception", e);
                    }

                    return sb.toString();

                }).forEach(paymentString -> writeToFile(path, paymentString));

                String numberOfLines = getFileLineCount(path) + "";

                Path renamedPath = renameDataFile(path);

                if (renamedPath != null) {
                    createCtlFile(renamedPath, numberOfLines);
                    createTriggerFile(renamedPath);
                }

                corDataStoreService.deleteCurrentPayments();
            }
        } else {
            smtpService.sendMailForPayCountMismatch(cycleDateService.getCycleDate(), getFilePayCount(), getCorPayCount());
        }
    }

    private void appendRecords(StringBuilder sb, Reader reader) {

        try (BufferedReader br = new BufferedReader(reader)) {

            String line;
            while (null != (line = br.readLine())) {
                sb.append(line);
                sb.append(System.lineSeparator());
            }

        } catch (IOException e) {
            log.info("io exception", e);
        }
    }

    private void createTriggerFile(Path path) {

        String triggerFileName = path.getFileName().toString()
                .replace(".dat.gz", Constants.TRIGGER_FILE_EXTENSION.toLowerCase());

        Path triggerFilePath = path.resolveSibling(triggerFileName);

        try {
            Files.createFile(triggerFilePath);
        } catch (IOException e) {
            log.error("", e);
        }
    }

    private void createCtlFile(Path path, String numberOfLines) {

        String ctlFileName = path.getFileName().toString().replace(".dat.gz", ".ctl");

        Path ctlFilePath = path.resolveSibling(ctlFileName);

        CtlData ctlData = CtlData.builder()
                .fileName(path.getFileName().toString())
                .creationTimeStamp(LocalDateTime.now().format(ctlFormatter))
                .processDate(cycleDateService.getCycleDate())
                .numberOfLines(numberOfLines)
                .transferComplete("")
                .build();

        try {
            Files.write(ctlFilePath, (ctlData.toString()
                            + System.lineSeparator()).getBytes(StandardCharsets.UTF_8),
                    StandardOpenOption.CREATE);
        } catch (IOException e) {
            log.error("", e);
        }
    }

    private void writeToFile(Path path, String onePayClaimCORString) {
        try {

            if (path.toFile().exists()) {
                Files.write(path, onePayClaimCORString.getBytes(StandardCharsets.UTF_8),
                        StandardOpenOption.APPEND);
            } else {
                Files.write(path, onePayClaimCORString.getBytes(StandardCharsets.UTF_8),
                        StandardOpenOption.CREATE);
            }
        } catch (IOException ex) {
            log.debug(ex.getMessage());
            log.error("", ex);
        }
    }

    private Path renameDataFile(Path path) {

        String newFileName = path.getFileName().toString()
                .replace(Constants.WRITING_FILE_EXTENSION, ".gz");

        Path newFilePath = path.resolveSibling(newFileName);

        try (GZIPOutputStream gos = new GZIPOutputStream(
                Files.newOutputStream(newFilePath))) {

            Files.copy(path, gos);

            Files.delete(path);

            return newFilePath;
        } catch (IOException ex) {
            log.debug(ex.getMessage());
            log.error("", ex);
        }

        return null;
    }

    private Path getFilePath(String location) {
        return Paths.get(location + Constants.OUTPUT_FILE_NAME +
                LocalDateTime.now().format(formatter)
                + ".dat" + Constants.WRITING_FILE_EXTENSION);
    }

    private long getFileLineCount(Path path) {

        try (Stream<String> lines = Files.lines(path)) {

            return lines.count();
        } catch (IOException ex) {
            log.error("", ex);
        }

        return 0;
    }

    private boolean isPayCountMatch() {
        return (getFilePayCount() == getCorPayCount());
    }

    private int getFilePayCount() {
        int filePayCount = 0;
        List<Integer> fileEventList = fileEventStore.getFileEventData(APPLICATION_NAME);
        if (fileEventList != null && !fileEventList.isEmpty()) {
            for (Integer payCount : fileEventList) {
                if (payCount != null) {
                    filePayCount = filePayCount + payCount;
                }
            }
        }
        return filePayCount;
    }

    private int getCorPayCount() {
        return corDataStoreService.getCurrentPaymentsCount();
    }
}
