package com.optum.pe.parsers;

import com.optum.pe.beans.parsing.Adjustment;
import com.optum.pe.beans.parsing.ClaimDetailRecord;
import com.optum.pe.beans.parsing.Record;
import com.optum.pe.beans.parsing.ServiceLine;
import com.optum.pe.nice.ProcessState;
import com.optum.pe.nice.ProcessStateFactory;
import com.optum.pe.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.ArrayList;

@Slf4j
@Service
public class ClaimDetailRecordLineParser implements AP2030LineParser {

    private final ProcessStateFactory processStateFactory;

    ClaimDetailRecordLineParser(ProcessStateFactory processStateFactory) {
        this.processStateFactory = processStateFactory;
    }

    @Override
    public boolean parse(String fileName, String line) {

        ClaimDetailRecord claimDetailRecord = ClaimDetailRecord.builder()
                .recordType(line.substring(0, 2).trim())
                .serviceCode(line.substring(2, 10))
                .serviceDate(line.substring(10, 20).trim())
                .chargeAmount(line.substring(20, 30).trim())
                .adjustedAmount(line.substring(30, 40).trim())
                .adjustedSign(line.charAt(40))
                .adjustedReason(line.substring(41, 101).trim())
                .payAmount(line.substring(101, 111).trim())
                .paySign(line.charAt(111))
                .remarkAdjustmentReasonCode(line.substring(112, 114).trim())
                .adjustmentGroupCode(line.substring(114, 116).trim())
                .claimAdjustmentReasonCode(line.substring(116, 119).trim())
                .qpa(getQpaAmount(line))
                .build();

        if (Constants.CLAIM_SERVICE_CODE.equals(claimDetailRecord.getServiceCode())) {

            if (!Constants.ZERO_AMOUNT.equals(claimDetailRecord.getAdjustedAmount())) {
                Adjustment adjustment = getAdjustmentFrom(claimDetailRecord);

                updateStateWithAdjustment(fileName, adjustment);
            } else {
                updateState(fileName, claimDetailRecord);
            }
        } else if (Constants.INTEREST_SERVICE_CODE.equals(claimDetailRecord.getServiceCode()) ||
                Constants.PENALTY_SERVICE_CODE.equals(claimDetailRecord.getServiceCode())) {

            updateState(fileName, claimDetailRecord);
        } else if (Constants.RECOVERY_SERVICE_CODE.equals(claimDetailRecord.getServiceCode())) {
            updateStateWithRecovery(fileName, claimDetailRecord);
        } else if (Constants.INTEREST_RECOVERY_SERVICE_CODE.equals(claimDetailRecord.getServiceCode())) {
            updateStateWithIOPRecovery(fileName, claimDetailRecord);
        } else if (Constants.EMPTY_SERVICE_CODE.equals(claimDetailRecord.getServiceCode())) {
            Adjustment adjustment = getAdjustmentFrom(claimDetailRecord);

            updateStateWithAdjustment(fileName, adjustment);
        } else {
            ServiceLine serviceLine = getServiceLineFrom(claimDetailRecord);

            updateStateWithServiceLine(fileName, serviceLine);
        }

        processStateFactory.getProcessStateFor(fileName).incrementCheckRecordLines();

        return true;
    }

    private void updateStateWithIOPRecovery(String fileName, Record record) {

        ProcessState processState = processStateFactory.getProcessStateFor(fileName);

        if (processState.getClaimDetailRecord() != null) {
            processState.addCurrentClaimDetailRecordToHeaderRecord();
        }

        if (!processState.isRecoveryPresent()) {

            processState.handleRecovery();
            processState.setClaimDetailRecord((ClaimDetailRecord) record);
        }
    }

    private void updateStateWithRecovery(String fileName, Record record) {

        ProcessState processState = processStateFactory.getProcessStateFor(fileName);

        processState.handleRecovery();

        processState.setClaimDetailRecord((ClaimDetailRecord) record);
    }

    private void updateStateWithServiceLine(String fileName, ServiceLine serviceLine) {

        ProcessState processState = processStateFactory.getProcessStateFor(fileName);

        if (processState.getServiceLine() != null) {
            processState.addCurrentServiceLineToClaimDetailRecord();
        }

        if (processState.getClaimDetailRecord() == null) {
            processState.setClaimDetailRecord(ClaimDetailRecord.builder().build());
        }

        processState.setServiceLine(serviceLine);
    }

    private void updateStateWithAdjustment(String fileName, Adjustment adjustment) {

        ProcessState processState = processStateFactory.getProcessStateFor(fileName);

        if (processState.getServiceLine() != null) {
            if (processState.getServiceLine().getAdjustmentList() == null) {
                processState.getServiceLine().setAdjustmentList(new ArrayList<>());
            }

            processState.getServiceLine().getAdjustmentList().add(adjustment);
        } else if (processState.getClaimHeaderRecord() != null) {
            if (processState.getClaimHeaderRecord().getAdjustmentList() == null) {
                processState.getClaimHeaderRecord().setAdjustmentList(new ArrayList<>());
            }

            try {
                processState.getClaimHeaderRecord().getAdjustmentList().add(adjustment);
            } catch (UnsupportedOperationException ex) {
                log.debug("Got 30 after RECOVERY");
            }
        } else if (processState.getCheckRecord().getAdjustmentList() == null) {
            processState.getCheckRecord().setAdjustmentList(new ArrayList<>());
            processState.getCheckRecord().getAdjustmentList().add(adjustment);
        }
    }

    @Override
    public void updateState(String fileName, Record record) {

        ProcessState processState = processStateFactory.getProcessStateFor(fileName);

        if (processState.getServiceLine() != null) {
            processState.addCurrentServiceLineToClaimDetailRecord();
        }

        if (processState.getClaimDetailRecord() != null) {
            processState.addCurrentClaimDetailRecordToHeaderRecord();
        }

        processState.setClaimDetailRecord((ClaimDetailRecord) record);
    }

    private ServiceLine getServiceLineFrom(ClaimDetailRecord claimDetailRecord) {
        String  qpa=null;
            if(!Constants.ZERO_AMOUNT.equals(claimDetailRecord.getQpa())){
                qpa = claimDetailRecord.getQpa();
             }
        return ServiceLine.builder()
                .recordType(claimDetailRecord.getRecordType())
                .serviceCode(claimDetailRecord.getServiceCode())
                .serviceDate(claimDetailRecord.getServiceDate())
                .chargeAmount(claimDetailRecord.getChargeAmount())
                .adjustedAmount(claimDetailRecord.getAdjustedAmount())
                .adjustedSign(claimDetailRecord.getAdjustedSign())
                .adjustedReason(claimDetailRecord.getAdjustedReason())
                .payAmount(claimDetailRecord.getPayAmount())
                .paySign(claimDetailRecord.getPaySign())
                .remarkAdjustmentReasonCode(claimDetailRecord.getRemarkAdjustmentReasonCode())
                .adjustmentGroupCode(claimDetailRecord.getAdjustmentGroupCode())
                .claimAdjustmentReasonCode(claimDetailRecord.getClaimAdjustmentReasonCode())
                .qpa(qpa)
                .build();
    }

    private Adjustment getAdjustmentFrom(ClaimDetailRecord claimDetailRecord) {

        return Adjustment.builder()
                .recordType(claimDetailRecord.getRecordType())
                .serviceCode(claimDetailRecord.getServiceCode())
                .serviceDate(claimDetailRecord.getServiceDate())
                .chargeAmount(claimDetailRecord.getChargeAmount())
                .adjustedAmount(claimDetailRecord.getAdjustedAmount())
                .adjustedSign(claimDetailRecord.getAdjustedSign())
                .adjustedReason(claimDetailRecord.getAdjustedReason())
                .payAmount(claimDetailRecord.getPayAmount())
                .paySign(claimDetailRecord.getPaySign())
                .remarkAdjustmentReasonCode(claimDetailRecord.getRemarkAdjustmentReasonCode())
                .adjustmentGroupCode(claimDetailRecord.getAdjustmentGroupCode())
                .claimAdjustmentReasonCode(claimDetailRecord.getClaimAdjustmentReasonCode())
                .build();
    }

    private String getQpaAmount(String line) {
        BigDecimal qpaAmt = BigDecimal.ZERO;
        DecimalFormat decimFormat = new DecimalFormat("0.00");
        try {
            if (line.substring(0, 2).trim().equals("30")
                    &&
                    !(Constants.CLAIM_SERVICE_CODE.equals(line.substring(2, 10))
                            || Constants.PENALTY_SERVICE_CODE.equals(line.substring(2, 10))
                            || Constants.INTEREST_SERVICE_CODE.equals(line.substring(2, 10))
                            || Constants.RECOVERY_SERVICE_CODE.equals(line.substring(2, 10))
                            || Constants.EMPTY_SERVICE_CODE.equals(line.substring(2, 10))
                            || Constants.INTEREST_RECOVERY_SERVICE_CODE.equals(line.substring(2, 10))
                    )
                    && line.length() >= 132
                    && line.substring(119, 132).trim().length() > 0
            ) {
                qpaAmt = new BigDecimal(line.substring(119, 132).trim().replace(",", ""));
            }
        } catch (NumberFormatException nfe) {
            log.error("ClaimDetailRecordLineParser::getQpaAmount ", nfe);
        }
        return decimFormat.format(qpaAmt);
    }


}
