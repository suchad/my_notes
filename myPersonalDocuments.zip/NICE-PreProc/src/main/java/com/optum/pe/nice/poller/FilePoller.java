package com.optum.pe.nice.poller;

import com.optum.pe.nice.ConcreteMediator;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class FilePoller {

    private final ConcreteMediator concreteMediator;

    public FilePoller(ConcreteMediator concreteMediator) {
        this.concreteMediator = concreteMediator;
    }

    @Async
    @Scheduled(initialDelay = 5000, fixedRate = 60000)
    void poll() {
        concreteMediator.mediate();
    }
}
