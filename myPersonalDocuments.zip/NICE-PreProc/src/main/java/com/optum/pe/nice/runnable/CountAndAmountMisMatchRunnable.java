package com.optum.pe.nice.runnable;

import com.optum.pe.beans.parsing.FileCountAndAmountInformation;
import com.optum.pe.service.SMTPService;

public class CountAndAmountMisMatchRunnable implements Runnable {

    private final FileCountAndAmountInformation fileCountAndAmountInformation;
    private final String cycleDate;
    private final SMTPService smtpService;

    public CountAndAmountMisMatchRunnable(FileCountAndAmountInformation fileCountAndAmountInformation, String cycleDate, SMTPService smtpService) {
        this.fileCountAndAmountInformation = fileCountAndAmountInformation;
        this.cycleDate = cycleDate;
        this.smtpService = smtpService;
    }

    @Override
    public void run() {
        smtpService.sendMailForCountAmountMisMatch(fileCountAndAmountInformation, cycleDate);
    }
}
