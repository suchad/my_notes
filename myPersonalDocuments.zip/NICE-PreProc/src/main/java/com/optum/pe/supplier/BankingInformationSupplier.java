package com.optum.pe.supplier;

import com.optum.pe.beans.mapping.BankingInformation;
import com.optum.pe.beans.parsing.CheckRecord;
import com.optum.pe.models.LookupData;
import com.optum.pe.utils.Constants;
import com.optum.pe.utils.RecordType;
import org.springframework.stereotype.Service;

@Service
class BankingInformationSupplier {

    BankingInformation supply(CheckRecord payment, LookupData bankInfoLookupData,
                              LookupData bankAddressLookupData) {

        BankingInformation.BankingInformationBuilder bankingInformation = BankingInformation.builder();

        bankingInformation.recordType(RecordType.BANK_INFO.getLabel());
        bankingInformation.partnerId(Constants.NICE_PARTNER_ID);
        bankingInformation.consolidationId(payment.getCheckNumber());

        bankingInformation.bankName(
                HelperSupplier.getBlankForAsterisk(bankInfoLookupData.getResultField01()));
        bankingInformation.branchName(
                HelperSupplier.getBlankForAsterisk(bankInfoLookupData.getResultField08()));
        bankingInformation.fractionNumberNumerator(
                HelperSupplier.getBlankForAsterisk(bankInfoLookupData.getResultField04()));
        bankingInformation.fractionNumberDenominator(
                HelperSupplier.getBlankForAsterisk(bankInfoLookupData.getResultField05()));

        bankingInformation.branchAddress1(
                HelperSupplier.getBlankForAsterisk(bankAddressLookupData.getResultField01()));
        bankingInformation.branchAddress2(
                HelperSupplier.getBlankForAsterisk(bankAddressLookupData.getResultField02()));
        bankingInformation.branchAddress3(
                HelperSupplier.getBlankForAsterisk(bankAddressLookupData.getResultField03()));
        bankingInformation.branchAddress4(
                HelperSupplier.getBlankForAsterisk(bankAddressLookupData.getResultField04()));
        bankingInformation.branchAddress5(
                HelperSupplier.getBlankForAsterisk(bankAddressLookupData.getResultField05()));
        bankingInformation.branchAddress6(
                HelperSupplier.getBlankForAsterisk(bankAddressLookupData.getResultField06()));
        bankingInformation.branchAddress7(
                HelperSupplier.getBlankForAsterisk(bankAddressLookupData.getResultField07()));
        bankingInformation.branchCity(
                HelperSupplier.getBlankForAsterisk(bankAddressLookupData.getResultField08()));
        bankingInformation.branchState(
                HelperSupplier.getBlankForAsterisk(bankAddressLookupData.getResultField09()));
        bankingInformation.branchZipCode(
                HelperSupplier.getBlankForAsterisk(bankAddressLookupData.getResultField10()));
        bankingInformation.branchCountryCode(
                HelperSupplier.getBlankForAsterisk(bankAddressLookupData.getResultField11()));

        bankingInformation.bankRoutingNumber(
                HelperSupplier.getBlankForAsterisk(bankInfoLookupData.getResultField02()));
        bankingInformation.bankAccountNumber(
                HelperSupplier.getBlankForAsterisk(bankInfoLookupData.getResultField03()));
        bankingInformation.bankAccountName(
                HelperSupplier.getBlankForAsterisk(bankInfoLookupData.getResultField09()));
        bankingInformation.bankAccountType("CHK");
        bankingInformation.bankAndSeriesDesignator("");
        bankingInformation.checkLogoImageId(
                HelperSupplier.getBlankForAsterisk(bankInfoLookupData.getResultField11()));
        bankingInformation.checkSignatureImageId(
                HelperSupplier.getBlankForAsterisk(bankInfoLookupData.getResultField06()));
        bankingInformation.bankOwnerMark(
                HelperSupplier.getBlankForAsterisk(bankInfoLookupData.getResultField12()));
        bankingInformation.checkCashPhrase(
                HelperSupplier.getBlankForAsterisk(bankInfoLookupData.getResultField07()));
        bankingInformation.checkPayLabel("");
        bankingInformation.checkSignatureLabel("");
        bankingInformation.checkPayToLabel("");
        bankingInformation.bankPhoneNumber(
                HelperSupplier.getBlankForAsterisk(bankAddressLookupData.getResultField12()));

        return bankingInformation.build();
    }
}
