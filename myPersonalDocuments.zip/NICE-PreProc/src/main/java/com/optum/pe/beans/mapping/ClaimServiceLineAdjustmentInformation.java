package com.optum.pe.beans.mapping;

import lombok.Builder;
import lombok.Getter;

import java.util.StringJoiner;

@Builder
@Getter
public class ClaimServiceLineAdjustmentInformation {

    private String recordType;
    private String partnerId;
    private String consolidationId;
    private String adjudicationSystemId;
    private String adjudicationSystemUniqueClaimNumber;
    private String adjudicationSystemUniqueClaimNumberTransactionSequenceNumber;
    private String recordSequenceNumber;
    private String serviceLineAdjudicationSystemNumber;
    private String adjustedAmount;
    private String groupCode;
    private String adjustmentReasonCode;
    private String adjustedUnitsOfService;
    private String serviceLineRemarkCode;
    private String remarkTextVersionKeyCode;
    private String remarkAdditionalTextVersionKeyCode;
    private String remarkQualifierCode;
    private String remarkCodeReferenceKey;

    @Override
    public String toString() {
        return new StringJoiner("|", "", "|")
                .add(recordType)
                .add(partnerId)
                .add(consolidationId)
                .add(adjudicationSystemId)
                .add(adjudicationSystemUniqueClaimNumber)
                .add(adjudicationSystemUniqueClaimNumberTransactionSequenceNumber)
                .add(recordSequenceNumber)
                .add(serviceLineAdjudicationSystemNumber)
                .add(adjustedAmount)
                .add(groupCode)
                .add(adjustmentReasonCode)
                .add(adjustedUnitsOfService)
                .add(serviceLineRemarkCode)
                .add(remarkTextVersionKeyCode)
                .add(remarkAdditionalTextVersionKeyCode)
                .add(remarkQualifierCode)
                .add(remarkCodeReferenceKey)
                .toString();
    }
}
