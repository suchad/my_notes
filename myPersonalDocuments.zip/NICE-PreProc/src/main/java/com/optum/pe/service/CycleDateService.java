package com.optum.pe.service;

import com.optum.pe.repositories.CycleDateRepository;
import com.optum.pe.utils.Constants;
import org.springframework.stereotype.Service;

@Service
public class CycleDateService {

    private final CycleDateRepository cycleDateRepository;

    public CycleDateService(CycleDateRepository cycleDateRepository) {
        this.cycleDateRepository = cycleDateRepository;
    }

    public String getCycleDate() {
        return cycleDateRepository.getCycleDateForPartner(Constants.LOOKUP_PARTNER_PROC_GRP_ID);
    }
}
