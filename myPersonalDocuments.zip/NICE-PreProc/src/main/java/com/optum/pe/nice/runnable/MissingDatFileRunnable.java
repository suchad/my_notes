package com.optum.pe.nice.runnable;

import com.optum.pe.service.SMTPService;

public class MissingDatFileRunnable implements Runnable {

    private final SMTPService smtpService;
    private final String fileName;
    private final String cycleDate;

    public MissingDatFileRunnable(String fileName, String cycleDate, SMTPService smtpService) {
        this.fileName = fileName;
        this.cycleDate = cycleDate;
        this.smtpService = smtpService;
    }

    @Override
    public void run() {
        smtpService.sendMailForMissingDatFile(fileName, cycleDate);
    }
}
