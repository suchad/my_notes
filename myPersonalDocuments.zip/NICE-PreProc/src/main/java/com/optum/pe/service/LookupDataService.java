package com.optum.pe.service;

import com.optum.pe.dao.LookupDataDao;
import com.optum.pe.exception.DAOException;
import com.optum.pe.models.LookupData;
import com.optum.pe.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
public class LookupDataService {

    private final LookupDataDao lookupDataDao;

    public LookupDataService(LookupDataDao lookupDataDao) {
        this.lookupDataDao = lookupDataDao;
    }

    @Cacheable(Constants.LOOKUP_CACHE_NAME)
    public List<LookupData> getLookupData(LocalDate cycleDate, String partnerProcGrpId) {

        List<LookupData> lookupDataList = new ArrayList<>(1);

        try {

            lookupDataList = lookupDataDao.getAllLookupInfo(cycleDate, partnerProcGrpId);

            log.debug("Got " + lookupDataList.size() + " lookup entries from database.");
        } catch (DAOException e) {
            log.error("", e);
        }

        return lookupDataList;
    }
}
