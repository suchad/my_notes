package com.optum.pe.parsers;

import com.optum.pe.beans.parsing.AP2030File;
import com.optum.pe.models.FileEventFlagAndCount;
import com.optum.pe.nice.MailSendingService;
import com.optum.pe.nice.ProcessState;
import com.optum.pe.nice.ProcessStateFactory;
import com.optum.pe.nice.ZipAndMoveService;
import com.optum.pe.nice.validation.CountAndAmountValidationService;
import com.optum.pe.nice.validation.TriggerFileAgeValidationService;
import com.optum.pe.service.CycleDateService;
import com.optum.pe.service.FileEventStore;
import com.optum.pe.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import java.util.stream.Stream;

@Slf4j
@Service
class AP2030FileParser implements FileParser {

    private final LineParserFactory lineParserFactory;
    private final ProcessStateFactory processStateFactory;
    private final ZipAndMoveService zipAndMoveService;
    private final CountAndAmountValidationService countAndAmountValidationService;
    private final TriggerFileAgeValidationService triggerFileAgeValidationService;
    private final MailSendingService mailSendingService;
    private final CycleDateService cycleDateService;
    private final FileEventStore fileEventStore;

    AP2030FileParser(LineParserFactory lineParserFactory,
                     ProcessStateFactory processStateFactory,
                     ZipAndMoveService zipAndMoveService,
                     CountAndAmountValidationService countAndAmountValidationService,
                     TriggerFileAgeValidationService triggerFileAgeValidationService,
                     MailSendingService mailSendingService, CycleDateService cycleDateService, FileEventStore fileEventStore) {
        this.lineParserFactory = lineParserFactory;
        this.processStateFactory = processStateFactory;
        this.zipAndMoveService = zipAndMoveService;
        this.countAndAmountValidationService = countAndAmountValidationService;
        this.triggerFileAgeValidationService = triggerFileAgeValidationService;
        this.mailSendingService = mailSendingService;
        this.cycleDateService = cycleDateService;
        this.fileEventStore = fileEventStore;
    }

    @Override
    public boolean parse(Path path) {

        boolean status = false;
        LocalDateTime startTime = LocalDateTime.now();

        String fileName = path.getFileName().toString();

        Path parentPath = path.getParent();

        Path datFilePath = getDatFilePath(parentPath, fileName);

        String cycleDate = cycleDateService.getCycleDate();

        if (datFilePath.toFile().exists()) {

            Path wipFilePath = getWipFilePath(parentPath, fileName);

            Path renamedPath = renameTriggerPath(path, wipFilePath);

            if (renamedPath == null) {
                return false;
            }

            FileEventFlagAndCount fileEventFlagAndCount = fileEventStore
                    .getFileEventFlagAndCount(FileEventStore.getFileIdFrom(fileName) + "", cycleDate);

            if ('Y' == fileEventFlagAndCount.getActiveFlag()) {

                if (fileEventFlagAndCount.getFileCount() == 0) {
                    status = handle(datFilePath, cycleDate);
                } else {
                    log.warn("file_id already processed for the cycle_date - " + cycleDate);

                    mailSendingService.duplicateDatFileMail(fileName, cycleDate);
                }
            }

            archiveFiles(renamedPath, fileName, datFilePath);
        } else {
            log.warn("Data file not found - " + datFilePath);

            if (triggerFileAgeValidationService.isAgeExpired(path)) {
                archiveFiles(path, fileName, null);

                mailSendingService.missingDatFileMail(fileName, cycleDate);
            }
        }

        log.info("Ending process for - " + fileName + ", time - "
                + Duration.between(startTime, LocalDateTime.now())
                + ", thread - " + Thread.currentThread().getName());

        return status;
    }

    private Path renameTriggerPath(Path path, Path wipFilePath) {
        Path renamedPath = null;

        try {
            renamedPath = Files.move(path, wipFilePath);
        } catch (IOException ex) {
            log.error("while renaming trigger file " + path);
            log.error("", ex);
        }

        return renamedPath;
    }

    private void archiveFiles(Path path, String fileName, Path datFilePath) {
        try {
            zipAndMoveService.moveFilesToArchiveFolder(datFilePath, path);
        } catch (IOException ex) {
            log.error("while archiving files - "
                    + (datFilePath != null ? datFilePath.getFileName() : "") + " & " + fileName);
            log.error("", ex);
        }
    }

    private Path getDatFilePath(Path path, String fileName) {

        return path.resolve(
                fileName.replace(Constants.TRIGGER_FILE_EXTENSION, Constants.DATA_FILE_EXTENSION));
    }

    private Path getWipFilePath(Path path, String fileName) {
        return path.resolve(fileName + Constants.WIP_FILE_EXTENSION);
    }

    private boolean handle(Path path, String cycleDate) {

        boolean status = false;

        String fileName = path.getFileName().toString();
        log.info("Handling - " + fileName);

        if (countAndAmountValidationService.validateCountAndAmountAndEmptiness(path, cycleDate)) {
            ProcessState processState = processStateFactory.createProcessStateFor(fileName);

            try (Stream<String> lines = Files.lines(path)) {

                // since we are able to read the file add it to state.
                processState.setAp2030File(new AP2030File());
                processState.setFileName(fileName);
                processState.setCycleDate(getLocalDateFrom(cycleDate));

                lines.forEach(line -> this.parseLine(fileName, line));

                status = true;
            } catch (IOException ex) {
                log.debug("", ex);
            }
        }

        return status;
    }

    private void parseLine(String fileName, String line) {

        if (line.length() == Constants.LINE_LENGTH) {
            String code = line.substring(0, 2);

            Optional<LineParser> lineParserOptional = lineParserFactory.getLineParser(code);

            lineParserOptional.ifPresent(lineParser -> lineParser.parse(fileName, line));
        }
    }

    private LocalDate getLocalDateFrom(String processDate) {
        return LocalDate.parse(processDate,
                DateTimeFormatter.ofPattern(Constants.CTL_CYCLE_DATE_FORMAT));
    }
}
