package com.optum.pe.supplier;

import com.optum.pe.beans.mapping.ServiceCenterInformation;
import com.optum.pe.beans.parsing.ClaimHeaderRecord;
import com.optum.pe.models.LookupData;
import com.optum.pe.utils.Constants;
import com.optum.pe.utils.RecordType;
import org.springframework.stereotype.Service;

@Service
class ClaimServiceCenterInformationSupplier {

    ServiceCenterInformation supply(String checkNumber, int transactionSequenceNumber, ClaimHeaderRecord claimHeaderRecord,
                                    LookupData payerServiceCenterLookupData, LookupData payerReturnAddressLookupData) {

        ServiceCenterInformation.ServiceCenterInformationBuilder serviceCenterInformation
                = ServiceCenterInformation.builder();

        serviceCenterInformation.recordType(RecordType.CLAIM_SERVICE_CENTER.getLabel());
        serviceCenterInformation.partnerId(Constants.NICE_PARTNER_ID);
        serviceCenterInformation.consolidationId(checkNumber);
        serviceCenterInformation.adjudicationSystemId(Constants.ADJUDICATION_SYSTEM_ID);
        serviceCenterInformation.adjudicationSystemUniqueClaimNumber(claimHeaderRecord.getClaimNumber());
        serviceCenterInformation.adjudicationSystemUniqueClaimNumberTransactionSequenceNumber(transactionSequenceNumber + "");

        serviceCenterInformation.subscriberServiceCenterName(
                HelperSupplier.getBlankForAsterisk(payerServiceCenterLookupData.getResultField01()));

        serviceCenterInformation.subscriberServiceCenterStreetAddress1(
                HelperSupplier.getBlankForAsterisk(payerReturnAddressLookupData.getResultField01()));
        serviceCenterInformation.subscriberServiceCenterStreetAddress2(
                HelperSupplier.getBlankForAsterisk(payerReturnAddressLookupData.getResultField02()));
        serviceCenterInformation.subscriberServiceCenterCity(
                HelperSupplier.getBlankForAsterisk(payerReturnAddressLookupData.getResultField08()));
        serviceCenterInformation.subscriberServiceCenterState(
                HelperSupplier.getBlankForAsterisk(payerReturnAddressLookupData.getResultField09()));
        serviceCenterInformation.subscriberServiceCenterZip(
                HelperSupplier.getBlankForAsterisk(payerReturnAddressLookupData.getResultField10()));

        serviceCenterInformation.subscriberCustomerServiceContactPersonFirstName(
                HelperSupplier.getBlankForAsterisk(payerServiceCenterLookupData.getResultField02()));
        serviceCenterInformation.subscriberCustomerServiceContactPersonLastName(
                HelperSupplier.getBlankForAsterisk(payerServiceCenterLookupData.getResultField03()));
        serviceCenterInformation.subscriberServiceCenterWebsiteUrl(
                HelperSupplier.getBlankForAsterisk(payerServiceCenterLookupData.getResultField04()));
        serviceCenterInformation.subscriberServiceCenterPhoneNumber(
                HelperSupplier.getBlankForAsterisk(payerServiceCenterLookupData.getResultField05()));

        serviceCenterInformation.subscriberServiceCenterTTYOrTDDPhoneNumber("");
        serviceCenterInformation.subscriberServiceCenterForeignLanguagePhoneNumber("");
        serviceCenterInformation.subscriberServiceCenterForeignLanguageNumberQualifier("");
        serviceCenterInformation.subscriberServiceCenterOperatingDays("");
        serviceCenterInformation.subscriberServiceCenterOperatingTimes("");

        serviceCenterInformation.providerServiceCenterName(
                HelperSupplier.getBlankForAsterisk(payerServiceCenterLookupData.getResultField06()));

        serviceCenterInformation.providerServiceCenterStreetAddress1(
                HelperSupplier.getBlankForAsterisk(payerReturnAddressLookupData.getResultField01()));
        serviceCenterInformation.providerServiceCenterStreetAddress2(
                HelperSupplier.getBlankForAsterisk(payerReturnAddressLookupData.getResultField02()));
        serviceCenterInformation.providerServiceCenterCity(
                HelperSupplier.getBlankForAsterisk(payerReturnAddressLookupData.getResultField08()));
        serviceCenterInformation.providerServiceCenterState(
                HelperSupplier.getBlankForAsterisk(payerReturnAddressLookupData.getResultField09()));
        serviceCenterInformation.providerServiceCenterZip(
                HelperSupplier.getBlankForAsterisk(payerReturnAddressLookupData.getResultField10()));

        serviceCenterInformation.providerCustomerServiceContactPersonFirstName(
                HelperSupplier.getBlankForAsterisk(payerServiceCenterLookupData.getResultField07()));
        serviceCenterInformation.providerCustomerServiceContactPersonLastName(
                HelperSupplier.getBlankForAsterisk(payerServiceCenterLookupData.getResultField08()));
        serviceCenterInformation.providerServiceCenterWebsiteUrl(
                HelperSupplier.getBlankForAsterisk(payerServiceCenterLookupData.getResultField09()));
        serviceCenterInformation.providerServiceCenterPhoneNumber(
                HelperSupplier.getBlankForAsterisk(payerServiceCenterLookupData.getResultField10()));

        serviceCenterInformation.providerServiceCenterTTYOrTDDPhoneNumber("");
        serviceCenterInformation.subscriberServiceCenterPhoneExtensionNumber("");
        serviceCenterInformation.subscriberServiceCenterFaxNumber("");
        serviceCenterInformation.subscriberServiceCenterEmail("");
        serviceCenterInformation.providerServiceCenterPhoneExtensionNumber("");
        serviceCenterInformation.providerServiceCenterFaxNumber("");
        serviceCenterInformation.providerServiceCenterEmail("");
        serviceCenterInformation.policyHolderServiceCenterName("");
        serviceCenterInformation.policyHolderServiceCenterStreetAddress1("");
        serviceCenterInformation.policyHolderServiceCenterStreetAddress2("");
        serviceCenterInformation.policyHolderServiceCenterCity("");
        serviceCenterInformation.policyHolderServiceCenterState("");
        serviceCenterInformation.policyHolderServiceCenterZip("");
        serviceCenterInformation.policyHolderCustomerServiceContactPersonFirstName("");
        serviceCenterInformation.policyHolderCustomerServiceContactPersonLastName("");
        serviceCenterInformation.policyHolderServiceCenterWebsiteUrl("");
        serviceCenterInformation.policyHolderServiceCenterEmail("");
        serviceCenterInformation.policyHolderServiceCenterTollFreePhoneNumber("");
        serviceCenterInformation.policyHolderServiceCenterTollFreePhoneExtensionNumber("");
        serviceCenterInformation.policyHolderServiceCenterLocalPhoneNumber("");
        serviceCenterInformation.policyHolderServiceCenterLocalPhoneExtensionNumber("");
        serviceCenterInformation.policyHolderServiceCenterFaxNumber("");
        serviceCenterInformation.policyHolderServiceCenterTTYOrTDDPhoneNumber("");
        serviceCenterInformation.subscriberServiceCenterStreetAddress3("");
        serviceCenterInformation.providerServiceCenterStreetAddress3("");
        serviceCenterInformation.policyHolderServiceCenterStreetAddress3("");

        return serviceCenterInformation.build();
    }
}
