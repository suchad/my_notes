package com.optum.pe.utils;

public enum RecordType {
    CLAIM_HEADER("CLAIMHDR"),
    POLICY_PLAN("POLICYPL"),
    CLAIM_SERVICE_CENTER("SERVCNTR"),
    SUBSCRIBER("SUBSCBR"),
    PATIENT("PATIENT"),
    PROVIDER("PROVIDER"),
    CLAIM_INTEREST("CLAIMINT"),
    CLAIM_ADJUSTMENT("CLAIMADJ"),
    CLAIM_SERVICE_LINE("CLMSRVLN"),
    SERVICE_LINE_ADJUSTMENT("CLMSVADJ"),
    PAYMENT("PAYMENT"),
    CLAIM_SUPPLEMENTAL("SUPPLMTL"),
    BANK_INFO("BANKINFO"),
    OVER_PAYMENT("OVERPMNT"),
    CLAIM_MESSAGE("CLMMSG"),
    SERVICE_LINE_SUPPLEMENTAL("CLMSVSUP"),
    PAYMENT_SUPPLEMENTAL("PAYSUPPL");

    private final String label;

    RecordType(String label) {
        this.label = label;
    }

    public String getLabel() {
        return this.label;
    }
}
