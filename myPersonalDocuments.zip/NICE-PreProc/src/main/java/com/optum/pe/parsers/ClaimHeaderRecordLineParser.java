package com.optum.pe.parsers;

import com.optum.pe.beans.parsing.ClaimHeaderRecord;
import com.optum.pe.beans.parsing.Record;
import com.optum.pe.nice.ProcessState;
import com.optum.pe.nice.ProcessStateFactory;
import org.springframework.stereotype.Service;

@Service
public class ClaimHeaderRecordLineParser implements AP2030LineParser {

    private final ProcessStateFactory processStateFactory;

    ClaimHeaderRecordLineParser(ProcessStateFactory processStateFactory) {
        this.processStateFactory = processStateFactory;
    }

    @Override
    public boolean parse(String fileName, String line) {

        ClaimHeaderRecord claimHeaderRecord = ClaimHeaderRecord.builder()
                .recordType(line.substring(0, 2).trim())
                .patientFirstName(line.substring(2, 17).trim())
                .patientLastName(line.substring(17, 37).trim())
                .patientMiddleInitial(line.charAt(37))
                .pcn(line.substring(38, 63).trim())
                .claimNumber(line.substring(63, 79).trim())
                .claimAmount(line.substring(79, 89).trim())
                .serviceProvider(line.substring(89, 119).trim())
                .medGroup(line.substring(119, 149).trim())
                .empGroup(line.substring(149, 156).trim())
                .planCode(line.substring(156, 159).trim())
                .fDos(line.substring(159, 169).trim())
                .lDos(line.substring(169, 179).trim())
                .institutionalIndicator(line.charAt(179))
                .subscriberId(line.substring(180, 190).trim())
                .subscriberFirstName(line.substring(190, 205).trim())
                .subscriberLastName(line.substring(205, 225).trim())
                .subscriberMiddleInitial(line.charAt(225))
                .build();

        updateState(fileName, claimHeaderRecord);

        return true;
    }

    @Override
    public void updateState(String fileName, Record record) {

        ProcessState processState = processStateFactory.getProcessStateFor(fileName);

        if (processState.getServiceLine() != null) {
            processState.addCurrentServiceLineToClaimDetailRecord();
        }

        if (processState.getClaimDetailRecord() != null) {
            processState.addCurrentClaimDetailRecordToHeaderRecord();
        }

        if (processState.getClaimHeaderRecord() != null) {
            processState.addCurrentClaimHeaderRecordToCheckRecord();
        }

        processState.setClaimHeaderRecord((ClaimHeaderRecord) record);
        processState.incrementCheckRecordLines();
    }
}
