package com.optum.pe.beans.mapping;

import lombok.Builder;
import lombok.Getter;

import java.util.StringJoiner;

@Builder
@Getter
public class PaymentInformation {

    private String recordType;
    private String partnerId;
    private String consolidationId;
    private String payeeType;
    private String payeeIdQualifier;
    private String payeeId;
    private String payeeEntityName;
    private String payeePrefix;
    private String payeeFirstName;
    private String payeeMiddleName;
    private String payeeLastName;
    private String payeeSuffix;
    private String payeeMailingStreetAddress1;
    private String payeeMailingStreetAddress2;
    private String payeeMailingStreetAddress3;
    private String payeeMailingStreetAddress4;
    private String payeeMailingStreetAddress5;
    private String payeeMailingStreetAddress6;
    private String payeeMailingStreetAddress7;
    private String payeeMailingCity;
    private String payeeMailingState;
    private String payeeMailingZip;
    private String payeeMailingCountryCode;
    private String totalPayAmount;
    private String payMethod;
    private String checkOrTraceNumber;
    private String payGroupCode;
    private String issueDate;
    private String payerNameType;
    private String payerName;
    private String payerPrefix;
    private String payerFirstName;
    private String payerMiddleName;
    private String payerLastName;
    private String payerSuffix;
    private String payerMailingStreetAddress1;
    private String payerMailingStreetAddress2;
    private String payerMailingStreetAddress3;
    private String payerMailingStreetAddress4;
    private String payerMailingStreetAddress5;
    private String payerMailingStreetAddress6;
    private String payerMailingStreetAddress7;
    private String payerMailingCity;
    private String payerMailingState;
    private String payerMailingZip;
    private String payerMailingCountryCode;
    private String payerWebsiteUrl;
    private String payerTechnicalContactUrl;
    private String eraRoutingId;
    private String _835TransactionSetControlNumber;
    private String additionalPayerId;
    private String originalFileNames;
    private String payeeEntitySupplementalName;
    private String adjudicationSystemAssignedPayeeId;
    private String payeeNPI;
    private String payeeNameType;
    private String remittanceType;
    private String payerId;
    private String payerTechnicalContactName;
    private String payerTechnicalContactEmailId;
    private String payerTechnicalContactPhoneNumber;
    private String payerTechnicalContactPhoneExtension;
    private String payerTechnicalFaxNumber;
    private String remittanceCopyCode;
    private String _835ERACopyRoutingId;
    private String remittanceCopyEntityName;
    private String remittanceCopyMailingStreetAddress1;
    private String remittanceCopyMailingStreetAddress2;
    private String remittanceCopyMailingStreetAddress3;
    private String remittanceCopyMailingStreetAddress4;
    private String remittanceCopyMailingStreetAddress5;
    private String remittanceCopyMailingStreetAddress6;
    private String remittanceCopyMailingStreetAddress7;
    private String remittanceCopyMailingCity;
    private String remittanceCopyMailingState;
    private String remittanceCopyMailingZip;
    private String remittanceCopyMailingCountyCode;
    private String remittanceVcpSeriesDesignator;

    @Override
    public String toString() {
        return new StringJoiner("|", "", "|")
                .add(recordType)
                .add(partnerId)
                .add(consolidationId)
                .add(payeeType)
                .add(payeeIdQualifier)
                .add(payeeId)
                .add(payeeEntityName)
                .add(payeePrefix)
                .add(payeeFirstName)
                .add(payeeMiddleName)
                .add(payeeLastName)
                .add(payeeSuffix)
                .add(payeeMailingStreetAddress1)
                .add(payeeMailingStreetAddress2)
                .add(payeeMailingStreetAddress3)
                .add(payeeMailingStreetAddress4)
                .add(payeeMailingStreetAddress5)
                .add(payeeMailingStreetAddress6)
                .add(payeeMailingStreetAddress7)
                .add(payeeMailingCity)
                .add(payeeMailingState)
                .add(payeeMailingZip)
                .add(payeeMailingCountryCode)
                .add(totalPayAmount)
                .add(payMethod)
                .add(checkOrTraceNumber)
                .add(payGroupCode)
                .add(issueDate)
                .add(payerNameType)
                .add(payerName)
                .add(payerPrefix)
                .add(payerFirstName)
                .add(payerMiddleName)
                .add(payerLastName)
                .add(payerSuffix)
                .add(payerMailingStreetAddress1)
                .add(payerMailingStreetAddress2)
                .add(payerMailingStreetAddress3)
                .add(payerMailingStreetAddress4)
                .add(payerMailingStreetAddress5)
                .add(payerMailingStreetAddress6)
                .add(payerMailingStreetAddress7)
                .add(payerMailingCity)
                .add(payerMailingState)
                .add(payerMailingZip)
                .add(payerMailingCountryCode)
                .add(payerWebsiteUrl)
                .add(payerTechnicalContactUrl)
                .add(eraRoutingId)
                .add(_835TransactionSetControlNumber)
                .add(additionalPayerId)
                .add(originalFileNames)
                .add(payeeEntitySupplementalName)
                .add(adjudicationSystemAssignedPayeeId)
                .add(payeeNPI)
                .add(payeeNameType)
                .add(remittanceType)
                .add(payerId)
                .add(payerTechnicalContactName)
                .add(payerTechnicalContactEmailId)
                .add(payerTechnicalContactPhoneNumber)
                .add(payerTechnicalContactPhoneExtension)
                .add(payerTechnicalFaxNumber)
                .add(remittanceCopyCode)
                .add(_835ERACopyRoutingId)
                .add(remittanceCopyEntityName)
                .add(remittanceCopyMailingStreetAddress1)
                .add(remittanceCopyMailingStreetAddress2)
                .add(remittanceCopyMailingStreetAddress3)
                .add(remittanceCopyMailingStreetAddress4)
                .add(remittanceCopyMailingStreetAddress5)
                .add(remittanceCopyMailingStreetAddress6)
                .add(remittanceCopyMailingStreetAddress7)
                .add(remittanceCopyMailingCity)
                .add(remittanceCopyMailingState)
                .add(remittanceCopyMailingZip)
                .add(remittanceCopyMailingCountyCode)
                .add(remittanceVcpSeriesDesignator)
                .toString();
    }
}
