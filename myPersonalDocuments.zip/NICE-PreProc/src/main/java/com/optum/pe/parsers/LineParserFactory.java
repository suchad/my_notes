package com.optum.pe.parsers;

import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
class LineParserFactory {

    private final LineParserSupplier lineParserSupplier;

    LineParserFactory(LineParserSupplier lineParserSupplier) {
        this.lineParserSupplier = lineParserSupplier;
    }

    Optional<LineParser> getLineParser(String code) {

        LineParser lineParser = lineParserSupplier.getLineParser(code);

        return lineParser != null ? Optional.of(lineParser) : Optional.empty();
    }
}
