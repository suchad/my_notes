package com.optum.pe.nice.validation;

import com.optum.pe.beans.parsing.FileCountAndAmountInformation;
import com.optum.pe.beans.parsing.FileMetaData;
import com.optum.pe.beans.parsing.Trailer;
import com.optum.pe.nice.MailSendingService;
import com.optum.pe.service.FileEventStore;
import com.optum.pe.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.stream.Stream;

import static com.optum.pe.utils.Constants.CTL_CYCLE_DATE_FORMAT;

@Slf4j
@Service
public class CountAndAmountValidationService {

    private final MailSendingService mailSendingService;
    private final FileEventStore fileEventStore;

    public CountAndAmountValidationService(MailSendingService mailSendingService, FileEventStore fileEventStore) {
        this.mailSendingService = mailSendingService;
        this.fileEventStore = fileEventStore;
    }

    DateTimeFormatter formatter = DateTimeFormatter.ofPattern(CTL_CYCLE_DATE_FORMAT);

    public boolean validateCountAndAmountAndEmptiness(Path path, String cycleDate) {

        boolean status = false;

        FileCountAndAmountInformation fileCountAndAmountInformation
                = new FileCountAndAmountInformation();

        fileCountAndAmountInformation.setFileMetaData(FileMetaData.builder()
                .fileName(path.getFileName().toString())
                .totalAmount(new BigDecimal(0))
                .invalidLines(0)
                .build());

        try (Stream<String> lines = Files.lines(path)) {

            lines.forEach(line -> parse(line, fileCountAndAmountInformation));

        } catch (IOException ex) {
            log.debug("Enable to parse file for meta data.");
            log.error("", ex);
        }

        if (isEmptyFile(fileCountAndAmountInformation.getFileMetaData())) {

            String fileName = fileCountAndAmountInformation.getFileMetaData().getFileName();

            int numberOfPayments = fileCountAndAmountInformation.getFileMetaData().getNumberOfPayments();

            log.info("Empty file - " + fileName);

			fileEventStore.addEvent(fileEventStore.getFileEventFrom(fileName, LocalDate.parse(cycleDate, formatter),
					String.valueOf(numberOfPayments)));

        } else if (!isTrailerPresent(fileCountAndAmountInformation)) {

            log.info("Trailer Record Missing - "
                    + fileCountAndAmountInformation.getFileMetaData().getFileName());

            mailSendingService
                    .missingTrailerMail(fileCountAndAmountInformation.getFileMetaData().getFileName(), cycleDate);

        } else if (!areCountAndAmountValid(fileCountAndAmountInformation)) {

            log.info("Count and Amount doesn't match - "
                    + fileCountAndAmountInformation.getFileMetaData().getFileName());

            mailSendingService.countAndAmountMisMatchMail(fileCountAndAmountInformation, cycleDate);
        } else {
            status = true;
        }

        return status;
    }

    private boolean isTrailerPresent(FileCountAndAmountInformation fileCountAndAmountInformation) {
        return fileCountAndAmountInformation.getTrailerRecord() != null;
    }

    private boolean isEmptyFile(FileMetaData fileMetaData) {
        return fileMetaData.getNumberOfPayments() == 0;
    }

    private boolean areCountAndAmountValid(FileCountAndAmountInformation fileCountAndAmountInformation) {

        FileMetaData fileMetaData = fileCountAndAmountInformation.getFileMetaData();
        Trailer trailer = fileCountAndAmountInformation.getTrailerRecord();

        return fileMetaData.getNumberOfLines() == trailer.getTotalRecordCount()
                && fileMetaData.getNumberOfPayments() == trailer.getTotalChecks()
                && fileMetaData.getTotalAmount().compareTo(trailer.getTotalPaymentAmount()) == 0
                && fileMetaData.getInvalidLines() == 0;
    }

    private BigDecimal getTrailerTotalPayBigDecimal(String totalPaymentAmount) {

        totalPaymentAmount = totalPaymentAmount.replace(",", "");

        try {
            return new BigDecimal(totalPaymentAmount);
        } catch (NumberFormatException ex) {
            log.error("", ex);
        }

        return BigDecimal.ZERO;
    }

    private void parse(String line, FileCountAndAmountInformation fileCountAndAmountInformation) {

        FileMetaData fileMetaData = fileCountAndAmountInformation.getFileMetaData();

        fileMetaData.incrementNumberOfLines();

        if (isValidLength(line)) {

            switch (line.substring(0, 2)) {
                case "10":
                    fileMetaData.incrementPaymentCount();
                    break;
                case "40":
                    String totalPay = line.substring(27, 39).trim();
                    char totalPaySign = line.charAt(39);

                    BigDecimal totalPayBigDecimal = getTotalPayBigDecimal(totalPay);

                    if (totalPaySign == '-') {
                        fileMetaData.reduceTotalAmountBy(totalPayBigDecimal);
                    } else {
                        fileMetaData.incrementTotalAmountBy(totalPayBigDecimal);
                    }

                    break;
                case "50":
                    fileCountAndAmountInformation.setTrailerRecord(getTrailerRecord(line));
                    break;
                default:
                    break;
            }
        } else {
            fileMetaData.incrementInvalidLines();
        }
    }

    private BigDecimal getTotalPayBigDecimal(String totalPay) {

        try {
            return new BigDecimal(totalPay.replace(",", ""));
        } catch (NumberFormatException ex) {
            log.error("", ex);
        }

        return BigDecimal.ZERO;
    }

    private boolean isValidLength(String line) {
        return line.length() == Constants.LINE_LENGTH;
    }

    private Trailer getTrailerRecord(String line) {

        BigDecimal trailerAmount = getTrailerTotalPayBigDecimal(line.charAt(10) + line.substring(11, 25).trim());
        int totalChecks = getIntFrom(line.substring(2, 10).trim());
        int totalRecordCount = getIntFrom(line.substring(25, 35).trim());

        return Trailer.builder()
                .recordType(line.substring(0, 2).trim())
                .totalChecks(totalChecks)
                .totalPaymentAmount(trailerAmount)
                .totalRecordCount(totalRecordCount)
                .processDate(line.substring(35, 43).trim())
                .build();
    }

    private int getIntFrom(String value) {

        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException ex) {
            log.error("", ex);
        }

        return 0;
    }
}
