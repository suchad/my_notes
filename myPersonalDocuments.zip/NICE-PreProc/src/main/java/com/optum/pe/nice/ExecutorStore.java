package com.optum.pe.nice;

import lombok.Getter;
import org.springframework.stereotype.Service;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Getter
@Service
class ExecutorStore {

    private ExecutorService mailExecutorService = Executors.newFixedThreadPool(2);
}
