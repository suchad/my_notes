package com.optum.pe.models;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import lombok.Data;

@Data
@Entity
@IdClass(ParameterConfigEntityKey.class)
@Table(schema = "PE01", name = "PARAMETER_CONFIG")
public class ParameterConfigEntity {

    @Id
    @Column(name = "PARTNER_PROC_GRP_ID")
    private String partnerProcGrpId;

    @Id
    @Column(name = "PARAMETER_NM")
    private String parameterNm;

    @Column(name = "PARAMETER_VAL")
    private String parameterVal;

    @Column(name = "PARAMETER_DESC")
    private String parameterDesc;

    @Column(name = "CREATION_DT")
    private Date creationDt;

    @Column(name = "LAST_UPDATE_DT")
    private Date lastUpdateDt;

    @Column(name = "LAST_UPDATE_BY_FST_NM")
    private String lastUpdateByFstNm;

    @Column(name = "LAST_UPDATE_BY_LST_NM")
    private String lastUpdateByLstNm;

}


class ParameterConfigEntityKey implements Serializable {

    private String partnerProcGrpId;

    private String parameterNm;
}
