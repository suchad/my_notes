package com.optum.pe.dao;

import com.optum.pe.exception.DAOException;
import com.optum.pe.models.LookupData;
import com.optum.pe.models.LookupData_;
import com.optum.pe.utils.Constants;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

@Repository
public class LookupDataDao {

    @PersistenceContext
    private EntityManager entityManager;

    private final List<String> lookupSetCdList =
            Arrays.asList(Constants.NICE_CLAIM_BANK_INFORMATION,
                    Constants.NICE_CLAIM_BANK_ADDRESS,
                    Constants.NICE_CLAIM_PAYER_INFORMATION,
                    Constants.NICE_CLAIM_PAYER_RETURN_ADDRESS,
                    Constants.NICE_CLAIM_PAYER_SERVICE_CENTER_INFO,
                    Constants.NICE_MEMBER_MESSAGE_GENERIC,
                    Constants.NICE_PROVIDER_MESSAGE_STATE,
                    Constants.NICE_PROVIDER_MESSAGE_APPEALS);

    public List<LookupData> getAllLookupInfo(LocalDate date, String partnerProcGrpId) throws DAOException {
        try {

            CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();

            CriteriaQuery<LookupData> criteriaQuery = criteriaBuilder.createQuery(LookupData.class);
            Root<LookupData> lookupDataRoot = criteriaQuery.from(LookupData.class);

            Predicate partnerProcGrpIdPredicate = criteriaBuilder.equal(lookupDataRoot.get(LookupData_.partnerDataOwnerGrpId),
                    partnerProcGrpId);

            Predicate effectiveDatePredicate = criteriaBuilder.lessThanOrEqualTo(lookupDataRoot.get(LookupData_.effectiveDate), date);
            Predicate endDatePredicate = criteriaBuilder.greaterThanOrEqualTo(lookupDataRoot.get(LookupData_.endDate), date);

            Expression<String> lookupSetCdExpression = lookupDataRoot.get(LookupData_.LOOKUP_SET_CODE);

            Predicate lookupSetCdPredicate = lookupSetCdExpression.in(lookupSetCdList);

            Predicate lookupPredicate = criteriaBuilder.and(
                    partnerProcGrpIdPredicate, effectiveDatePredicate, endDatePredicate, lookupSetCdPredicate);

            criteriaQuery.where(lookupPredicate);

            return entityManager.createQuery(criteriaQuery).getResultList();
        } catch (Exception e) {
            throw new DAOException("JPA error in LookupDataDao getLookupInfo ", e);
        }
    }
}
