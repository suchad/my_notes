package com.optum.pe.peservicespeconsolidation.consolidation;

public class QueryNotFoundException extends Exception {

    public QueryNotFoundException(String message) {
        super(message);
    }
}
