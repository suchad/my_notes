package com.optum.pe.peservicespeconsolidation.consolidation.service_consolidation;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Objects;

class ServiceConsolidationPK implements Serializable {

    private String partnerId;
    private LocalDate cycleDate;
    private String consolidationKey;

    @Override
    public boolean equals(Object o) {

        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        ServiceConsolidationPK that = (ServiceConsolidationPK) o;

        return Objects.equals(partnerId, that.partnerId) &&
                Objects.equals(cycleDate, that.cycleDate) &&
                Objects.equals(consolidationKey, that.consolidationKey);
    }

    @Override
    public int hashCode() {
        return Objects.hash(partnerId, cycleDate, consolidationKey);
    }
}
