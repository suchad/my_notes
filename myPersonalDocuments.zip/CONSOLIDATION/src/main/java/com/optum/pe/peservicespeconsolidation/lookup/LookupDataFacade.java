package com.optum.pe.peservicespeconsolidation.lookup;

import com.optum.pe.peservicespeconsolidation.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Slf4j
@Service
public class LookupDataFacade {

    private final LookupDataCache lookupDataCache;

    public LookupDataFacade(LookupDataCache lookupDataCache) {
        this.lookupDataCache = lookupDataCache;
    }

    public LookupData findOne(LocalDate cycleDate, String payeeAssignmentKey, String payeeType,
                              String paymentType, String covTypeCode, String partnerProcGroupId) throws LookUpDataNotFoundException {

        return lookupDataCache.findAll(cycleDate).stream()
                .filter(lookupData -> lookupData.getKeyField01().equals(payeeAssignmentKey.trim()))
                .filter(lookupData -> lookupData.getKeyField02().equals(payeeType.trim()))
                .filter(lookupData -> lookupData.getKeyField03().equals(paymentType.trim()))
                .filter(lookupData -> covTypeCode.trim().matches(getRegex(lookupData.getKeyField04())))
                .findFirst()
                .orElseThrow(() -> new LookUpDataNotFoundException(Constants.ER_503 + partnerProcGroupId));
    }

    private String getRegex(String str) {

        if (Constants.WILDCARD.equals(str)) {
            return Constants.REGEX_WILDCARD;
        }

        return str;
    }
}
