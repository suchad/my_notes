package com.optum.pe.peservicespeconsolidation.claim;

import com.optum.pe.peservicespeconsolidation.claim.other_entity.ClaimOtherEntity;
import com.optum.pe.peservicespeconsolidation.claim.other_entity.ClaimOtherEntityFacade;
import com.optum.pe.peservicespeconsolidation.claim.other_entity.ClaimOtherEntityNotFoundException;
import com.optum.pe.peservicespeconsolidation.configuration.ConsolidationQuery;
import com.optum.pe.peservicespeconsolidation.configuration.ConsolidationQueryStore;
import com.optum.pe.peservicespeconsolidation.configuration.Key;
import com.optum.pe.peservicespeconsolidation.consolidation.ConsolidationKeyFacade;
import com.optum.pe.peservicespeconsolidation.consolidation.DerivedColumnNotMappedException;
import com.optum.pe.peservicespeconsolidation.consolidation.QueryNotFoundException;
import com.optum.pe.peservicespeconsolidation.lookup.LookUpDataNotFoundException;
import com.optum.pe.peservicespeconsolidation.lookup.LookupData;
import com.optum.pe.peservicespeconsolidation.lookup.LookupDataFacade;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class ClaimFacade {

    private final LookupDataFacade lookupDataFacade;
    private final ConsolidationKeyFacade consolidationKeyFacade;
    private final ClaimOtherEntityFacade claimOtherEntityFacade;

    public ClaimFacade(LookupDataFacade lookupDataFacade, ConsolidationKeyFacade consolidationKeyFacade, ClaimOtherEntityFacade claimOtherEntityFacade) {
        this.lookupDataFacade = lookupDataFacade;
        this.consolidationKeyFacade = consolidationKeyFacade;
        this.claimOtherEntityFacade = claimOtherEntityFacade;
    }

    public void derivePayeeAssignmentKey(Claim claim, ConsolidationQueryStore consolidationQueryStore) throws QueryNotFoundException, LookUpDataNotFoundException {

        Optional<LookupData> lookupDataOptional = getLookupData(claim);

        if (lookupDataOptional.isPresent()) {
            addToQueryStore(claim, lookupDataOptional.get(), consolidationQueryStore);
        }
    }

    private Optional<LookupData> getLookupData(Claim claim) throws LookUpDataNotFoundException {

        return Optional.ofNullable(lookupDataFacade.findOne(
                claim.getMemberFinalReleaseDate().toLocalDate(),
                claim.getPartnerConfig().getConsolidationPayeeAssignmentKeyId(),
                claim.getPayeeTypeCode(), claim.getMemberPayMethodCode(),
                claim.getCoverageTypeCode(), claim.getPartnerProcGroupId()));
    }

    private void addToQueryStore(Claim claim,
                                 LookupData lookupData,
                                 ConsolidationQueryStore consolidationQueryStore) throws QueryNotFoundException {

        ConsolidationQuery consolidationQuery;

        consolidationQuery = consolidationKeyFacade.getQuery(lookupData.getResultField15());

        consolidationQueryStore.addQuery(consolidationQuery, claim.getClaimId());

        claim.setDerivedColumns(consolidationQuery.getDerivedColumns());
    }

    public Map<BigDecimal, Key> getKeysFromDB(Map<ConsolidationQuery, List<BigDecimal>> queryStore) {

        return queryStore.entrySet().parallelStream()
                .flatMap(entry -> consolidationKeyFacade.getConsolidationKeys(entry.getKey(), entry.getValue()))
                .map(item -> new Key((BigDecimal) item[0], (String) item[1], (String) item[2]))
                .collect(Collectors.toMap(Key::getClaimId, Function.identity()));
    }

    public String getConsolidationKey(Claim claim, String partialKey) throws DerivedColumnNotMappedException {
        return consolidationKeyFacade.getConsolidationKey(claim, partialKey);
    }

    public String appendKeyForDivertMember(BigDecimal claimId, Map<BigDecimal, ClaimOtherEntity> claimOtherEntities, String key) {

        ClaimOtherEntity claimOtherEntity = claimOtherEntities.get(claimId);

        if (claimOtherEntity != null) {
            key += claimOtherEntity.getEntityTypeCode() + claimOtherEntity.getEntityId() +
                    claimOtherEntity.getEntityIdTypeCode();
        }

        return key;
    }

    public Map<BigDecimal, ClaimOtherEntity> getDivertMemberEntities(List<BigDecimal> claimIdsOfDivertMembers) throws ClaimOtherEntityNotFoundException {

        if (claimIdsOfDivertMembers != null && !claimIdsOfDivertMembers.isEmpty()) {
            return claimOtherEntityFacade.getOtherEntities(claimIdsOfDivertMembers);
        }

        return Collections.emptyMap();
    }
}
