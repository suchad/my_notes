package com.optum.pe.peservicespeconsolidation.partner;

public class PartnerConfigNotFoundException extends Exception {

    PartnerConfigNotFoundException(String message) {
        super(message);
    }
}
