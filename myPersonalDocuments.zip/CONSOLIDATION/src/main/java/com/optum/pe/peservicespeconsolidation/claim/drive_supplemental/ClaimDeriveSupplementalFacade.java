package com.optum.pe.peservicespeconsolidation.claim.drive_supplemental;

import com.optum.pe.peservicespeconsolidation.claim.Claim;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class ClaimDeriveSupplementalFacade {

    private final ClaimDeriveSupplementalRepository repository;

    public ClaimDeriveSupplementalFacade(ClaimDeriveSupplementalRepository repository) {
        this.repository = repository;
    }

    public void saveAll(List<ClaimDeriveSupplemental> claimDeriveSupplementals) {
        repository.saveAll(claimDeriveSupplementals);
    }

    public ClaimDeriveSupplemental map(Claim claim) {
        return ClaimDeriveSupplemental.builder()
                .claimId(claim.getClaimId())
                .memberPayConsolidationGroupCode(claim.getMemberPayConsolidationGroupCode())
                .memberInterestPayConsolidationGroupCode(claim.getMemberInterestPayConsolidationGroupCode())
                .memberPayeeConsolidationKeyId(claim.getPayeeConsolidationKeyId())
                .lastUpdateDate(LocalDate.now())
                .build();
    }
}
