package com.optum.pe.peservicespeconsolidation.claim.drive_supplemental;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

@Repository
interface ClaimDeriveSupplementalRepository extends JpaRepository<ClaimDeriveSupplemental, BigDecimal> {
}
