package com.optum.pe.peservicespeconsolidation.controller;

import com.optum.pe.peservicespeconsolidation.cycle_date.CycleDateException;
import com.optum.pe.peservicespeconsolidation.cycle_date.CycleDateFacade;
import com.optum.pe.peservicespeconsolidation.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.Duration;
import java.time.LocalDateTime;

@Slf4j
@RequestMapping("/api/v1/consolidation")
@RestController
class ConsolidationController {

    private final JobLauncher jobLauncher;
    private final Job consolidationJob;
    private final Job cleanupJob;

    private final CycleDateFacade cycleDateFacade;

    ConsolidationController(JobLauncher jobLauncher,
                            @Qualifier("consolidationJob") Job consolidationJob,
                            @Qualifier("cleanupJob") Job cleanupJob,
                            CycleDateFacade cycleDateFacade) {
        this.jobLauncher = jobLauncher;
        this.consolidationJob = consolidationJob;
        this.cleanupJob = cleanupJob;
        this.cycleDateFacade = cycleDateFacade;
    }

    @GetMapping("/{partnerProcGroupId}")
    public ExitStatus consolidation(@PathVariable String partnerProcGroupId)
            throws JobParametersInvalidException, JobExecutionAlreadyRunningException, JobRestartException, JobInstanceAlreadyCompleteException, CycleDateException {

        LocalDateTime startTime = LocalDateTime.now();

        String cycleDate = cycleDateFacade.findCycleDate(partnerProcGroupId);

        log.info("Consolidating for partnerProcGroupId - " + partnerProcGroupId
                + " and cycleDate - " + cycleDate);

        JobParameters parameters = new JobParametersBuilder()
                .addLong("uniqueness", System.nanoTime())
                .addString(Constants.JOB_PARAM_CYCLE_DATE, cycleDate)
                .addString(Constants.JOB_PARAM_PARTNER_PROC_GROUP_ID, partnerProcGroupId)
                .toJobParameters();

        JobExecution jobExecution = this.jobLauncher.run(consolidationJob, parameters);

        log.info("Ending process for - " + partnerProcGroupId + ", time - "
                + Duration.between(startTime, LocalDateTime.now()));

        return jobExecution.getExitStatus();
    }

    @GetMapping("/cleanup/{partnerProcGroupId}/{cycleDate}")
    public ExitStatus cleanup(@PathVariable String partnerProcGroupId,
                              @PathVariable String cycleDate) throws JobParametersInvalidException, JobExecutionAlreadyRunningException, JobRestartException, JobInstanceAlreadyCompleteException {

        LocalDateTime startTime = LocalDateTime.now();

        log.info("Cleaning up for partnerProcGroupId - " + partnerProcGroupId
                + " and cycleDate - " + cycleDate);

        JobParameters parameters = new JobParametersBuilder()
                .addLong("uniqueness", System.nanoTime())
                .addString(Constants.JOB_PARAM_CYCLE_DATE, cycleDate)
                .addString(Constants.JOB_PARAM_PARTNER_PROC_GROUP_ID, partnerProcGroupId)
                .toJobParameters();

        JobExecution jobExecution = this.jobLauncher.run(cleanupJob, parameters);

        log.info("Ending process for - " + partnerProcGroupId + ", time - "
                + Duration.between(startTime, LocalDateTime.now()));

        return jobExecution.getExitStatus();
    }
}
