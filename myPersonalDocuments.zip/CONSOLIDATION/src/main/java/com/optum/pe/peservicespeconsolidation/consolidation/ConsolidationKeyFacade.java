package com.optum.pe.peservicespeconsolidation.consolidation;

import com.optum.pe.peservicespeconsolidation.claim.Claim;
import com.optum.pe.peservicespeconsolidation.configuration.ConsolidationQuery;
import com.optum.pe.peservicespeconsolidation.configuration.QueryFacade;
import com.optum.pe.peservicespeconsolidation.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.StringJoiner;
import java.util.stream.Stream;

@Slf4j
@Service
public class ConsolidationKeyFacade {

    private final EntityManager entityManager;
    private final QueryFacade queryFacade;

    ConsolidationKeyFacade(EntityManager entityManager, QueryFacade queryFacade) {
        this.entityManager = entityManager;
        this.queryFacade = queryFacade;
    }

    public Stream<Object[]> getConsolidationKeys(ConsolidationQuery consolidationQuery,
                                                 List<BigDecimal> claimIds) {

        return entityManager.createNativeQuery(consolidationQuery.getQuery())
                .setParameter("claimIds", claimIds)
                .setParameter("ppid", consolidationQuery.getPartnerProcGoupId())
                .getResultStream();
    }

    public ConsolidationQuery getQuery(String queryId) throws QueryNotFoundException {

        Optional<ConsolidationQuery> queryOptional = queryFacade.getQuery(queryId);

        if (queryOptional.isPresent()) {
            return queryOptional.get();
        } else {
            throw new QueryNotFoundException(Constants.ER_504 + queryId);
        }
    }

    public String getConsolidationKey(Claim claim, String partialKey) throws DerivedColumnNotMappedException {

        StringJoiner joiner = new StringJoiner("", partialKey, "");

        for (String column : claim.getDerivedColumns()) {
            String s = derivedColumnMapper(claim, column);
            joiner.add(s);
        }
        return joiner.toString();
    }

    private String derivedColumnMapper(Claim claim, String column) throws DerivedColumnNotMappedException {

        String value = "";

        switch (column) {
            case "MBR_PAY_CONSOL_GRP_CD":
                value = claim.getMemberPayConsolidationGroupCode();
                break;
            case "PAYEE_CONSOL_KEY_ID":
                value = claim.getPayeeConsolidationKeyId();
                break;
            case "MBR_INT_PAY_CONSOL_GRP_CD":
                value = claim.getMemberInterestPayConsolidationGroupCode();
                break;
            default:
                throw new DerivedColumnNotMappedException(Constants.ER_504 + claim.getPartnerProcGroupId());
        }

        return value;
    }
}
