package com.optum.pe.peservicespeconsolidation.configuration;

import com.optum.paymentengine.common.lookup.dao.model.FeatureResultsEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
interface AppFeatureResultsRepository extends JpaRepository<FeatureResultsEntity, Long> {

    @Transactional(transactionManager = "jpaTransactionManager")
    @Modifying
    @Query(value = "DELETE FROM PE01.FEATURE_RESULTS fr " +
            "WHERE PARTNER_PROC_GRP_ID = :partnerProcGroupId " +
            "AND TRUNC(CYC_DT) = TO_DATE(:cycleDate, 'YYYYMMDD') " +
            "AND FEATURE_CAT_CD IN (:featureCategoryCodes)", nativeQuery = true)
    int deleteFeatureResultsByPartnerProcGroupIdAndCycleDateAndFeatureCategoryCodes(String partnerProcGroupId, String cycleDate, List<String> featureCategoryCodes);
}
