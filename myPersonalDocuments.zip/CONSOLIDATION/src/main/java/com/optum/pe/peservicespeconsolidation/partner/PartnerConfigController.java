package com.optum.pe.peservicespeconsolidation.partner;

import com.optum.pe.peservicespeconsolidation.utils.Constants;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("/api/v1/consolidation")
@RestController
class PartnerConfigController {

    private final CacheManager cacheManager;

    PartnerConfigController(@Qualifier("consolidationCacheManager") CacheManager cacheManager) {
        this.cacheManager = cacheManager;
    }

    @GetMapping("/partner/clear")
    public boolean cacheClear() {
        Cache cache = cacheManager.getCache(Constants.CACHE_NAME_PARTNER_CONFIGS);

        if (cache != null) {
            cache.clear();

            return Boolean.TRUE;
        }

        return Boolean.FALSE;
    }
}
