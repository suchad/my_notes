package com.optum.pe.peservicespeconsolidation.common_lookup;

public class CommonLookupDataNotFoundException extends Exception {

    public CommonLookupDataNotFoundException(String message) {
        super(message);
    }
}
