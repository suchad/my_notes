package com.optum.pe.peservicespeconsolidation.consolidation_offset;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ConsolidationOffsetFacade {

    private final ConsolidationOffsetRepository repository;

    ConsolidationOffsetFacade(ConsolidationOffsetRepository repository) {
        this.repository = repository;
    }

    public ConsolidationOffset findOne(String partnerProcGroupId, String partitionName)
            throws ConsolidationOffsetNotAvailableException {

        int updatedCount = repository.updateOffset(partnerProcGroupId, partitionName);

        if (updatedCount == 0) {
            throw new ConsolidationOffsetNotAvailableException("partition - " + partitionName);
        }

        return repository.findByPartnerProcGroupIdAndClaimedAndUpdatedBy(partnerProcGroupId, "Y", partitionName);
    }

    @Transactional(transactionManager = "jpaTransactionManager")
    public void save(ConsolidationOffset consolidationOffset) {
        repository.save(consolidationOffset);
    }

    public void cleanOffsetByPartnerProcGroupId(String partnerProcGroupId) {
        repository.cleanOffsetByPartnerProcGroupId(partnerProcGroupId);
    }
}
