package com.optum.pe.peservicespeconsolidation.common_lookup;

import com.optum.paymentengine.common.lookup.beans.CommonLookupResponse;
import com.optum.paymentengine.common.lookup.service.impl.CommonLookupServiceImpl;
import com.optum.pe.claim.ClaimConsolidatedPERecord;
import com.optum.pe.peservicespeconsolidation.claim.Claim;
import com.optum.pe.peservicespeconsolidation.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;

@Slf4j
@Service
public class CommonLookupService {

    private final CommonLookupServiceImpl commonLookupServiceImpl;

    public CommonLookupService(CommonLookupServiceImpl commonLookupServiceImpl) {
        this.commonLookupServiceImpl = commonLookupServiceImpl;
    }

    public CommonLookupResponse getCommonLookUp(List<ClaimConsolidatedPERecord> claimConsolidatedPERecords,
                                                Claim claim) {

        return commonLookupServiceImpl
                .getFeatureResults(claim.getMemberFinalReleaseDate()
                                .format(DateTimeFormatter.ofPattern(Constants.CYCLE_DATE_FORMAT)),
                        claim.getPartnerConfig().getConsolidationPayGroupMemberEftKeyId(),
                        Constants.RECORD_TYPE_CLAIM,
                        Arrays.asList(Constants.FEATURE_CATEGORY_CHECK, Constants.FEATURE_CATEGORY_EFT),
                        claimConsolidatedPERecords);
    }
}
