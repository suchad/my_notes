package com.optum.pe.peservicespeconsolidation.claim.activity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Objects;

@AllArgsConstructor
@NoArgsConstructor
@Builder
class ClaimActivityPK implements Serializable {

    private long claimId;
    private int activityTypeId;

    @Override
    public boolean equals(Object o) {

        if (this == o) {
            return true;
        }

        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        ClaimActivityPK that = (ClaimActivityPK) o;

        return claimId == that.claimId &&
                activityTypeId == that.activityTypeId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(claimId, activityTypeId);
    }
}
