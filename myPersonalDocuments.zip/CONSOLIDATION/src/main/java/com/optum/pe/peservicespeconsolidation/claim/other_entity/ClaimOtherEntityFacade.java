package com.optum.pe.peservicespeconsolidation.claim.other_entity;

import com.optum.pe.peservicespeconsolidation.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Slf4j
@Service
public class ClaimOtherEntityFacade {

    private final ClaimOtherEntityRepository repository;

    ClaimOtherEntityFacade(ClaimOtherEntityRepository repository) {
        this.repository = repository;
    }

    public Map<BigDecimal, ClaimOtherEntity> getOtherEntities(List<BigDecimal> claimIds) throws ClaimOtherEntityNotFoundException {

        List<Object[]> claimOtherEntities = repository.findAll(claimIds);

        if (claimOtherEntities == null || claimOtherEntities.isEmpty()
                || claimIds.size() != claimOtherEntities.size()) {
            throw new ClaimOtherEntityNotFoundException(Constants.OTHER_ENTITY_NOT_FOUND_FOR_CLAIM_ID);
        }

        return claimOtherEntities.parallelStream()
                .map(this::map)
                .collect(Collectors.toMap(ClaimOtherEntity::getClaimId, Function.identity()));
    }

    private ClaimOtherEntity map(Object[] row) {
        return ClaimOtherEntity.builder()
                .claimId((BigDecimal) row[0])
                .sequenceNumber((BigDecimal) row[1])
                .entityTypeCode((String) row[2])
                .entityId((String) row[3])
                .entityIdTypeCode((String) row[4])
                .build();
    }
}
