package com.optum.pe.peservicespeconsolidation.consolidation.service_consolidation;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
public class ServiceConsolidation {

    private String partnerId;
    private LocalDate cycleDate;
    private String consolidationKey;
    private BigDecimal claimId;
    private String partnerProcGroupId;
    private BigDecimal consolidationId;
    private LocalDateTime planEffectiveDate;
}
