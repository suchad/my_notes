package com.optum.pe.peservicespeconsolidation.service_endpoints;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface ServiceEndpointsRepository extends CrudRepository<ServiceEndpoints, ServiceEndpointsPk> {

    ServiceEndpoints findByPartnerProcGrpIdAndServiceNameAndEndpointName(String partnerProcGrpId, String serviceName, String endpointName);

    @Transactional(transactionManager = "jpaTransactionManager")
    @Modifying
    @Query(value = "UPDATE PE01.SERVICE_ENDPOINTS SET STATUS_FLAG = :status " +
            "WHERE PARTNER_PROC_GRP_ID = :partnerProcGrpId " +
            "AND SERVICE_NAME = :serviceName " +
            "AND ENDPOINT_NAME = :endpointName", nativeQuery = true)
    void updateServiceEndpointsStatus(String partnerProcGrpId, String serviceName, String endpointName, String status);
}
