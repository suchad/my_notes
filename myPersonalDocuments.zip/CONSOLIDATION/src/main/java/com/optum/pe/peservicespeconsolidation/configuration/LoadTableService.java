package com.optum.pe.peservicespeconsolidation.configuration;

import com.optum.pe.peservicespeconsolidation.claim.Claim;
import com.optum.pe.peservicespeconsolidation.claim.drive_supplemental.ClaimDeriveSupplemental;
import com.optum.pe.peservicespeconsolidation.claim.drive_supplemental.ClaimDeriveSupplementalFacade;
import com.optum.pe.peservicespeconsolidation.consolidation.Consolidation;
import com.optum.pe.peservicespeconsolidation.consolidation.ConsolidationFacade;
import com.optum.pe.peservicespeconsolidation.consolidation.join.ClaimConsolidationJoin;
import com.optum.pe.peservicespeconsolidation.consolidation.join.ClaimConsolidationJoinFacade;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
class LoadTableService {

    private final ConsolidationFacade consolidationFacade;
    private final ClaimConsolidationJoinFacade claimConsolidationJoinFacade;
    private final ClaimDeriveSupplementalFacade claimDeriveSupplementalFacade;

    LoadTableService(ConsolidationFacade consolidationFacade,
                     ClaimConsolidationJoinFacade claimConsolidationJoinFacade,
                     ClaimDeriveSupplementalFacade claimDeriveSupplementalFacade) {
        this.consolidationFacade = consolidationFacade;
        this.claimConsolidationJoinFacade = claimConsolidationJoinFacade;
        this.claimDeriveSupplementalFacade = claimDeriveSupplementalFacade;
    }

    void load(List<? extends Claim> claims) {

        claimDeriveSupplementalFacade
                .saveAll(getClaimDeriveSupplementals(claims));

        List<Claim> newlyGeneratedClaims = claims.parallelStream()
                .filter(Claim::isConsolidationIdNewlyGenerated)
                .collect(Collectors.toList());

        consolidationFacade
                .saveAll(getConsolidations(newlyGeneratedClaims));

        claimConsolidationJoinFacade
                .saveAll(getClaimConsolidationJoins(claims));
    }

    private List<ClaimDeriveSupplemental> getClaimDeriveSupplementals(List<? extends Claim> claims) {
        return claims.stream()
                .filter(Claim::isFullService)
                .map(claimDeriveSupplementalFacade::map)
                .collect(Collectors.toList());
    }

    private List<ClaimConsolidationJoin> getClaimConsolidationJoins(List<? extends Claim> claims) {
        return claims.stream()
                .map(claimConsolidationJoinFacade::map)
                .collect(Collectors.toList());
    }

    private List<Consolidation> getConsolidations(List<? extends Claim> newlyGeneratedClaims) {
        return newlyGeneratedClaims.stream()
                .map(consolidationFacade::map)
                .collect(Collectors.toList());
    }
}
