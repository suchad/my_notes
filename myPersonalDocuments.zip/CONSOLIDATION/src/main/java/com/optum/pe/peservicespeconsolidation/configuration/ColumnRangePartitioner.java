package com.optum.pe.peservicespeconsolidation.configuration;

import com.optum.pe.peservicespeconsolidation.utils.Constants;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.partition.support.Partitioner;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@StepScope
@Component
public class ColumnRangePartitioner implements Partitioner {

    @Value("#{jobParameters}")
    private Map<String, Object> jobParameters;

    private final PartitionerFacade partitionerFacade;

    public ColumnRangePartitioner(PartitionerFacade partitionerFacade) {
        this.partitionerFacade = partitionerFacade;
    }

    @Override
    public Map<String, ExecutionContext> partition(int gridSize) {

        String partnerProcGroupId = jobParameters.get(Constants.JOB_PARAM_PARTNER_PROC_GROUP_ID).toString();
        String cycleDate = jobParameters.get(Constants.JOB_PARAM_CYCLE_DATE).toString();

        Map<String, BigDecimal> partitions = partitionerFacade.getPartitions(partnerProcGroupId, cycleDate);

        Map<String, ExecutionContext> partitionExecutionContexts = new HashMap<>(gridSize + 1, 1);

        partitions.forEach((partition, value) -> {

            ExecutionContext executionContext = new ExecutionContext(new ConcurrentHashMap<>(6, 1));

            executionContext.put(Constants.JOB_PARAM_PARTITION, partition);
            executionContext.put(Constants.JOB_PARAM_PARTNER_PROC_GROUP_ID, partnerProcGroupId);
            executionContext.put(Constants.JOB_PARAM_CYCLE_DATE, cycleDate);
            executionContext.put(Constants.JOB_PARAM_PARTITION_NAME, partnerProcGroupId + "-" + cycleDate + "-" + partition);
            executionContext.put(Constants.JOB_PARAM_CLAIM_COUNT_NAME, value);

            partitionExecutionContexts.put("partition-" + partnerProcGroupId + "-" + cycleDate + "-" + partition, executionContext);
        });

        return partitionExecutionContexts;
    }
}
