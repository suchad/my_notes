package com.optum.pe.peservicespeconsolidation.configuration;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.Map;
import java.util.Optional;

@Setter
@Getter
@ConfigurationProperties(prefix = "spring")
@Configuration
public class QueryFacade {

    private Map<String, ConsolidationQuery> queryRepository;

    public Optional<ConsolidationQuery> getQuery(String queryId) {
        return Optional.ofNullable(queryRepository.get(queryId));
    }
}
