package com.optum.pe.peservicespeconsolidation;

import com.optum.paymentengine.common.lookup.config.CommonLookupLibraryConfig;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Import;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@EntityScan(basePackages = {"com.optum.pe.peservicespeconsolidation", "com.optum.paymentengine.common.lookup.dao.model"})
@EnableJpaRepositories(basePackages = {"com.optum.pe.peservicespeconsolidation", "com.optum.paymentengine.common.lookup.repo"})
@Import(CommonLookupLibraryConfig.class)
@EnableTransactionManagement
@EnableAsync
@EnableCaching
@EnableBatchProcessing
@SpringBootApplication
public class PeServicesPeConsolidationApplication {

    public static void main(String[] args) {
        SpringApplication.run(PeServicesPeConsolidationApplication.class, args);
    }
}
