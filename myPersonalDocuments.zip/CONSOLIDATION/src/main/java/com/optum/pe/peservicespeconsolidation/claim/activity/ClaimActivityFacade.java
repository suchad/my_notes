package com.optum.pe.peservicespeconsolidation.claim.activity;

import com.optum.pe.peservicespeconsolidation.claim.Claim;
import com.optum.pe.peservicespeconsolidation.consolidation.Mapper;
import com.optum.pe.peservicespeconsolidation.utils.Constants;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Service
public class ClaimActivityFacade implements Mapper<ClaimActivity> {

    @Override
    public ClaimActivity map(Claim claim) {

        return ClaimActivity.builder()
                .claimId(claim.getClaimId().longValueExact())
                .activityTypeId(Constants.CLAIM_ACTIVITY_TYPE_ID)
                .partnerProcGroupId(claim.getPartnerProcGroupId())
                .activityDateTime(LocalDateTime.now())
                .cycleDate(claim.getMemberFinalReleaseDate().toLocalDate())
                .creationDate(LocalDate.now())
                .lastUpdateDate(LocalDate.now())
                .build();
    }
}
