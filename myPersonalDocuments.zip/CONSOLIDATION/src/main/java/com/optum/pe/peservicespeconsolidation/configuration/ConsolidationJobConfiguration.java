package com.optum.pe.peservicespeconsolidation.configuration;

import com.optum.pe.peservicespeconsolidation.claim.Claim;
import com.optum.pe.peservicespeconsolidation.consolidation_offset.ConsolidationOffsetNotAvailableException;
import com.optum.pe.peservicespeconsolidation.utils.Constants;
import org.springframework.batch.core.ChunkListener;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.partition.support.Partitioner;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

import javax.persistence.EntityManagerFactory;

@Configuration
public class ConsolidationJobConfiguration {

    private final ItemReader<Claim> itemReader;
    private final ItemWriter<Claim> itemWriter;
    private final Partitioner partitioner;

    private final ChunkListener chunkListener;

    private final EntityManagerFactory entityManagerFactory;
    private final ApplicationConfiguration configuration;

    private final JobExecutionListener consolidationJobListener;

    public ConsolidationJobConfiguration(ItemReader<Claim> itemReader,
                                         ItemWriter<Claim> itemWriter,
                                         Partitioner partitioner,
                                         ChunkListener chunkListener,
                                         EntityManagerFactory entityManagerFactory,
                                         ApplicationConfiguration configuration,
                                         @Qualifier("consolidationJobListener") JobExecutionListener consolidationJobListener) {
        this.itemReader = itemReader;
        this.itemWriter = itemWriter;
        this.partitioner = partitioner;
        this.chunkListener = chunkListener;
        this.entityManagerFactory = entityManagerFactory;
        this.configuration = configuration;
        this.consolidationJobListener = consolidationJobListener;
    }

    @Autowired
    @Bean
    public Job consolidationJob(StepBuilderFactory stepBuilderFactory,
                                JobBuilderFactory jobBuilderFactory) {

        return jobBuilderFactory
                .get(Constants.JOB_NAME_CONSOLIDATION)
                .incrementer(new RunIdIncrementer())
                .listener(consolidationJobListener)
                .start(partitionerStep(stepBuilderFactory))
                .build();
    }

    private Step partitionerStep(StepBuilderFactory stepBuilderFactory) {

        return stepBuilderFactory.get(Constants.PARTITIONER_STEP)
                .partitioner(Constants.STEP_NAME_CONSOLIDATION, partitioner)
                .step(consolidationStep(stepBuilderFactory))
                .gridSize(101).taskExecutor(getSimpleAsyncTaskExecutor())
                .build();
    }

    private SimpleAsyncTaskExecutor getSimpleAsyncTaskExecutor() {

        SimpleAsyncTaskExecutor taskExecutor = new SimpleAsyncTaskExecutor();
        taskExecutor.setConcurrencyLimit(configuration.getConcurrency());

        return taskExecutor;
    }

    private Step consolidationStep(StepBuilderFactory stepBuilderFactory) {

        return stepBuilderFactory.get(Constants.STEP_NAME_CONSOLIDATION)
                .transactionManager(jpaTransactionManager())
                .<Claim, Claim>chunk(configuration.getChunkSize())
                .reader(itemReader)
                .writer(itemWriter)
                .faultTolerant()
                .retry(ConsolidationOffsetNotAvailableException.class)
                .retryLimit(5)
                .listener(chunkListener)
                .build();
    }

    @Bean
    PlatformTransactionManager jpaTransactionManager() {
        return new JpaTransactionManager(entityManagerFactory);
    }
}
