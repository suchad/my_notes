package com.optum.pe.peservicespeconsolidation.configuration;

import com.optum.pe.peservicespeconsolidation.service_endpoints.JobAlreadyRunningException;
import com.optum.pe.peservicespeconsolidation.service_endpoints.ServiceEndpointsFacade;
import com.optum.pe.peservicespeconsolidation.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.stereotype.Service;

@Slf4j
@Service
class ConsolidationJobListener implements JobExecutionListener {

    private final ServiceEndpointsFacade serviceEndpointsFacade;

    ConsolidationJobListener(ServiceEndpointsFacade serviceEndpointsFacade) {
        this.serviceEndpointsFacade = serviceEndpointsFacade;
    }

    @Override
    public void beforeJob(JobExecution jobExecution) {

        String partnerProcGroupId = jobExecution
                .getJobParameters()
                .getString(Constants.JOB_PARAM_PARTNER_PROC_GROUP_ID);

        try {
            serviceEndpointsFacade.flagServiceEndpointsJobStart(partnerProcGroupId);
        } catch (JobAlreadyRunningException e) {
            log.error("", e);

            jobExecution.stop();
        }
    }

    @Override
    public void afterJob(JobExecution jobExecution) {

        String partnerProcGroupId = jobExecution
                .getJobParameters()
                .getString(Constants.JOB_PARAM_PARTNER_PROC_GROUP_ID);

        serviceEndpointsFacade.flagServiceEndpointsJobEnd(partnerProcGroupId);
    }
}
