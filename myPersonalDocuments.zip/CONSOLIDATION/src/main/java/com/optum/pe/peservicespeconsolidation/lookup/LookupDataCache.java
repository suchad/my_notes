package com.optum.pe.peservicespeconsolidation.lookup;

import com.optum.pe.peservicespeconsolidation.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Slf4j
@Service
class LookupDataCache {

    private final LookupDataDao lookupDataDao;

    LookupDataCache(LookupDataDao lookupDataDao) {
        this.lookupDataDao = lookupDataDao;
    }

    @Cacheable(cacheManager = "consolidationCacheManager", value = Constants.CACHE_NAME_LOOKUP, sync = true)
    public List<LookupData> findAll(LocalDate cycleDate) {

        log.info("lookup_data cache missed!");
        return lookupDataDao.findAll(cycleDate);
    }
}
