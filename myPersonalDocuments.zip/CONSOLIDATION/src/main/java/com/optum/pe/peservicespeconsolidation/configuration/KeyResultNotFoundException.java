package com.optum.pe.peservicespeconsolidation.configuration;

class KeyResultNotFoundException extends Exception {

    KeyResultNotFoundException(String message) {
        super(message);
    }
}
