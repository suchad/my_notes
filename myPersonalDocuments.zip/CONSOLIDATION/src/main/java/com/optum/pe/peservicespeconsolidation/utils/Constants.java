package com.optum.pe.peservicespeconsolidation.utils;

public final class Constants {

    public static final String APPLICATION_NAME = "PE-CONSOLIDATION-APP";

    public static final String CACHE_NAME_PARTNER_CONFIGS = "partner_configs";
    public static final String CACHE_NAME_LOOKUP = "lookup_data";
    public static final String PAYEE_CONFIGURATION_SET_CODE = "PAYEE CONFIGURATION";

    public static final String JOB_NAME_CONSOLIDATION = "CONSOLIDATION_JOB";
    public static final String STEP_NAME_CONSOLIDATION = "PRE_CONSOLIDATION_STEP";

    public static final String FULL_SERVICE_INDICATOR = "F";

    public static final String JOB_PARAM_PARTNER_PROC_GROUP_ID = "partnerProcGroupId";
    public static final String JOB_PARAM_CYCLE_DATE = "cycleDate";
    public static final String JOB_PARAM_PARTITION = "partition";
    public static final String JOB_PARAM_PARTITION_NAME = "partitionName";
    public static final String JOB_PARAM_CLAIM_COUNT_NAME = "claimCount";

    public static final String PAYEE_TYPE_CODE_MEMBER = "EOB-P";
    public static final String PAYEE_TYPE_CODE_PROVIDER = "PRA-P";

    public static final String RECORD_TYPE_CLAIM = "CLM";

    public static final String FEATURE_CATEGORY_EFT = "Mem-EFT";
    public static final String FEATURE_CATEGORY_CHECK = "Mem-CHK";
    public static final String COMMON_RESULT_SUCCESS_IND = "N";

    public static final String WILDCARD = "*";
    public static final String REGEX_WILDCARD = ".*";

    public static final String ER500 = "ER500 Partner config record is not found for partner id: ";
    public static final String OTHER_ENTITY_NOT_FOUND_FOR_CLAIM_ID = "ClaimOtherEntityNotFound";
    public static final String ER_502 = "ER502 PAY GROUP Common Lookup Service Results Not Found: ";
    public static final String ER_504 = "ER504 Query in Payee Assignment Lookup is incorrect: ";
    public static final String ER_503 = "ER503 No Matching Payee Assignment Key Found: ";

    public static final String CYCLE_DATE_FORMAT = "MM-dd-YYYY";

    public static final int CONSOLIDATION_ACTIVITY_TYPE_ID = 2925;
    public static final int CLAIM_ACTIVITY_TYPE_ID = 1925;

    public static final String CONSOLIDATION_GROUP_CD_GLOBAL = "MGHIS";
    public static final String CONSOLIDATION_GROUP_CD_PSEUDO = "MBIC";

    public static final String PARTITIONER_STEP = "PARTITIONER_STEP";

    public static final String JOB_NAME_CLEANUP = "CLEANUP_JOB";

    public static final String FLOW_NAME_CLEANUP_CONSOLIDATION = "FLOW_NAME_CLEANUP_CONSOLIDATION";
    public static final String STEP_NAME_CLEANUP_CONSOLIDATION = "STEP_NAME_CLEANUP_CONSOLIDATION";

    public static final String FLOW_NAME_CLEANUP_CONSOLIDATION_ACTIVITY = "FLOW_NAME_CLEANUP_CONSOLIDATION_ACTIVITY";
    public static final String STEP_NAME_CLEANUP_CONSOLIDATION_ACTIVITY = "STEP_NAME_CLEANUP_CONSOLIDATION_ACTIVITY";

    public static final String FLOW_NAME_CLEANUP_PARTNER_CONSOLIDATION_JOIN = "FLOW_NAME_CLEANUP_PARTNER_CONSOLIDATION_JOIN";
    public static final String STEP_NAME_CLEANUP_PARTNER_CONSOLIDATION_JOIN = "STEP_NAME_CLEANUP_PARTNER_CONSOLIDATION_JOIN";

    public static final String FLOW_NAME_CLEANUP_CLAIM_CONSOLIDATION_JOIN = "FLOW_NAME_CLEANUP_CLAIM_CONSOLIDATION_JOIN";
    public static final String STEP_NAME_CLEANUP_CLAIM_CONSOLIDATION_JOIN = "STEP_NAME_CLEANUP_CLAIM_CONSOLIDATION_JOIN";

    public static final String FLOW_NAME_CLEANUP_CLAIM_ACTIVITY = "FLOW_NAME_CLEANUP_CLAIM_ACTIVITY";
    public static final String STEP_NAME_CLEANUP_CLAIM_ACTIVITY = "STEP_NAME_CLEANUP_CLAIM_ACTIVITY";

    public static final String FLOW_NAME_CLEANUP_FEATURE_RESULTS = "FLOW_NAME_CLEANUP_FEATURE_RESULTS";
    public static final String STEP_NAME_CLEANUP_FEATURE_RESULTS = "STEP_NAME_CLEANUP_FEATURE_RESULTS";

    public static final String FLOW_NAME_CLEANUP_CONSOLIDATION_OFFSET = "FLOW_NAME_CLEANUP_CONSOLIDATION_OFFSET";
    public static final String STEP_NAME_CLEANUP_CONSOLIDATION_OFFSET = "STEP_NAME_CLEANUP_CONSOLIDATION_OFFSET";

    public static final String FLOW_NAME_CLEANUP_SERVICE_ENDPOINTS = "FLOW_NAME_CLEANUP_SERVICE_ENDPOINTS";
    public static final String STEP_NAME_CLEANUP_SERVICE_ENDPOINTS = "STEP_NAME_CLEANUP_SERVICE_ENDPOINTS";

    public static final String JOB_START_FLAG = "N";
    public static final String JOB_END_FLAG = "Y";

    private Constants() {
    }
}
