package com.optum.pe.peservicespeconsolidation.claim.other_entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Objects;

class ClaimOtherEntityPK implements Serializable {

    private BigDecimal claimId;
    private BigDecimal sequenceNumber;

    @Override
    public boolean equals(Object o) {

        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        ClaimOtherEntityPK that = (ClaimOtherEntityPK) o;
        return Objects.equals(claimId, that.claimId) &&
                Objects.equals(sequenceNumber, that.sequenceNumber);
    }

    @Override
    public int hashCode() {
        return Objects.hash(claimId, sequenceNumber);
    }
}
