package com.optum.pe.peservicespeconsolidation.consolidation.activity;

import com.optum.pe.peservicespeconsolidation.claim.Claim;
import com.optum.pe.peservicespeconsolidation.consolidation.Mapper;
import com.optum.pe.peservicespeconsolidation.utils.Constants;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Service
public class ConsolidationActivityFacade implements Mapper<ConsolidationActivity> {

    @Override
    public ConsolidationActivity map(Claim claim) {

        return ConsolidationActivity.builder()
                .consolidationId(claim.getConsolidationId())
                .activityTypeId(Constants.CONSOLIDATION_ACTIVITY_TYPE_ID)
                .partnerProcGroupId(claim.getPartnerProcGroupId())
                .activityDateTime(LocalDateTime.now())
                .claimLifeTrackEventSentDateTime(null)
                .creationDate(LocalDate.now())
                .lastUpdateDate(LocalDate.now())
                .build();
    }
}
