package com.optum.pe.peservicespeconsolidation.claim;

import com.optum.paymentengine.common.lookup.dao.model.FeatureResultsEntity;
import com.optum.pe.peservicespeconsolidation.partner.PartnerConfig;
import com.optum.pe.peservicespeconsolidation.utils.Constants;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Setter
@Getter
@Builder
public class Claim implements Serializable {

    private BigDecimal claimId;
    private String intake835ErrorStatusCode;
    private String release835PostableIndicator;
    private LocalDateTime memberFinalReleaseDate;
    private LocalDateTime memberInitialReleaseDate;
    private String memberPayMethodCode;
    private String memberPayConsolidationGroupCode;
    private String memberInterestPayConsolidationGroupCode;
    private String payeeConsolidationKeyId;
    private String payerId;
    private String partnerId;
    private String adjustedSystemSubmittedClaimId;
    private String transTypeCode;
    private String globalSolutionIndicator;
    private String eobDocumentCode;
    private String paymentSuppressionIndicator;
    private String peGen835Indicator;
    private String pseudoIndicator;
    private String rvrslCorrectionAssocId;
    private String divertMemberPaymentIndicator;
    private String fundingArngCode;
    private String peServiceModelCode;
    private String csPeGen835Indicator;
    private String interestAssocId;
    private String manual835RemediationIndicator;
    private String networkTypeCode;
    private String policyNumber;
    private String externalPayerIndicator;
    private BigDecimal payId;
    private String partnerProcGroupId;
    private LocalDateTime planEffectiveDate;
    private String payeeTypeCode;
    private String asoCrossPlanRecoveryOptOutIndicator;
    private String memberAdjudicatedIdNumber;
    private String memberAdjudicatedIdTypeCode;
    private String memberAdjudicatedFirstName;
    private String memberAdjudicatedMiddleName;
    private String memberAdjudicatedLastName;
    private String memberAdjudicatedNameSuffix;
    private String sgaIndicator;
    private String legalEntityCode;
    private String policySfxCode;
    private String memberMarketTypeCode;
    private String memberMarketSiteNumber;
    private String coverageTypeCode;
    private String bankCode;
    private String adjustedSystemCode;

    private String consolidationKey;
    private long consolidationId;
    private boolean isConsolidationIdNewlyGenerated;
    private boolean isFullService;

    private List<String> derivedColumns;

    private PartnerConfig partnerConfig;

    public boolean isMemberCheck() {
        return partnerConfig.isMemberCheck();
    }

    public void assignGroupCodes(FeatureResultsEntity featureResults) {
        this.setMemberPayConsolidationGroupCode(featureResults.getResultFld01());
        this.setMemberInterestPayConsolidationGroupCode(featureResults.getResultFld02());
    }

    public boolean isDerivePayeeAssignmentKey() {

        return this.partnerConfig.derivePayeeAssignmentKey();
    }

    public String getFeatureCategory() {

        if ("E".equals(this.memberPayMethodCode)) {
            return Constants.FEATURE_CATEGORY_EFT;
        }

        return Constants.FEATURE_CATEGORY_CHECK;
    }

    public boolean isDivertMemberPayment() {
        return "Y".equals(this.divertMemberPaymentIndicator);
    }
}
