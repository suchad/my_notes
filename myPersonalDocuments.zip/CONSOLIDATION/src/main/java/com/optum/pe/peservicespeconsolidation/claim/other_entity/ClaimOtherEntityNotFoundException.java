package com.optum.pe.peservicespeconsolidation.claim.other_entity;

public class ClaimOtherEntityNotFoundException extends Exception {

    ClaimOtherEntityNotFoundException(String message) {
        super(message);
    }
}
