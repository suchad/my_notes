package com.optum.pe.peservicespeconsolidation.cycle_date;

public class CycleDateException extends Exception {

    CycleDateException(String message) {
        super(message);
    }
}
