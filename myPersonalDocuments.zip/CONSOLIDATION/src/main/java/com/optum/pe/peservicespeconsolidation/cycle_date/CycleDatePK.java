package com.optum.pe.peservicespeconsolidation.cycle_date;

import java.io.Serializable;
import java.util.Objects;

class CycleDatePK implements Serializable {

    private static final long serialVersionUID = 1L;

    private String partnerProcGrpId;
    private String cycleDateValue;

    @Override
    public boolean equals(Object o) {

        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        CycleDatePK that = (CycleDatePK) o;
        return Objects.equals(partnerProcGrpId, that.partnerProcGrpId) &&
                Objects.equals(cycleDateValue, that.cycleDateValue);
    }

    @Override
    public int hashCode() {
        return Objects.hash(partnerProcGrpId, cycleDateValue);
    }
}
