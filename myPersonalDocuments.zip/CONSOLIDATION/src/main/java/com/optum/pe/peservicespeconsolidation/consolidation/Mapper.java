package com.optum.pe.peservicespeconsolidation.consolidation;

import com.optum.pe.peservicespeconsolidation.claim.Claim;

public interface Mapper<T> {

    T map(Claim claim);
}
