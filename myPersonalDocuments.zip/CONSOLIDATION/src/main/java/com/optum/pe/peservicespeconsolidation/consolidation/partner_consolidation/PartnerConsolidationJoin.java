package com.optum.pe.peservicespeconsolidation.consolidation.partner_consolidation;

import com.optum.pe.peservicespeconsolidation.consolidation.Consolidation;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;
import org.springframework.data.domain.Persistable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import java.time.LocalDate;
import java.util.Objects;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "PARTNER_CONSOLIDATION_JOIN", schema = "PE01")
@IdClass(PartnerConsolidationJoinPK.class)
public class PartnerConsolidationJoin implements Persistable<PartnerConsolidationJoinPK> {

    @Id
    @Column(name = "CONSOL_ID")
    private long consolidationId;

    @Id
    @Column(name = "PARTNER_ID")
    private String partnerId;

    @Column(name = "PARTNER_PROC_GRP_ID")
    private String partnerProcGroupId;

    @Column(name = "CREATION_DT")
    private LocalDate creationDate;

    @Column(name = "LAST_UPDATE_DT")
    private LocalDate lastUpdateDate;

    @MapsId("consolidationId")
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CONSOL_ID")
    private Consolidation consolidation;

    @Override
    public PartnerConsolidationJoinPK getId() {
        return PartnerConsolidationJoinPK.builder()
                .consolidationId(this.consolidationId)
                .partnerId(this.partnerId)
                .build();
    }

    @Override
    public boolean isNew() {
        return Boolean.TRUE;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        PartnerConsolidationJoin that = (PartnerConsolidationJoin) o;
        return consolidationId == that.consolidationId &&
                partnerId.equals(that.partnerId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(consolidationId, partnerId);
    }
}
