package com.optum.pe.peservicespeconsolidation.configuration;

import com.optum.pe.peservicespeconsolidation.claim.Claim;
import com.optum.pe.peservicespeconsolidation.claim.ClaimFacade;
import com.optum.pe.peservicespeconsolidation.claim.other_entity.ClaimOtherEntity;
import com.optum.pe.peservicespeconsolidation.claim.other_entity.ClaimOtherEntityNotFoundException;
import com.optum.pe.peservicespeconsolidation.consolidation.DerivedColumnNotMappedException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
class PayeeConsolidationKeyDecorator {

    private final ClaimFacade claimFacade;

    PayeeConsolidationKeyDecorator(ClaimFacade claimFacade) {
        this.claimFacade = claimFacade;
    }

    void decorate(ConsolidationQueryStore consolidationQueryStore, List<Claim> claimsForQuery) throws ClaimOtherEntityNotFoundException, DerivedColumnNotMappedException, KeyResultNotFoundException {

        if (!consolidationQueryStore.getQueryStore().isEmpty()) {
            Map<BigDecimal, Key> keys = claimFacade.getKeysFromDB(consolidationQueryStore.getQueryStore());

            if (keys.size() != claimsForQuery.size()) {
                throw new KeyResultNotFoundException("");
            }

            List<BigDecimal> claimIdsOfDivertMembers = claimsForQuery.parallelStream()
                    .filter(Claim::isDivertMemberPayment)
                    .map(Claim::getClaimId)
                    .collect(Collectors.toList());

            Map<BigDecimal, ClaimOtherEntity> claimOtherEntities =
                    claimFacade.getDivertMemberEntities(claimIdsOfDivertMembers);

            for (Claim claim : claimsForQuery) {

                Key key = keys.get(claim.getClaimId());

                if (key != null) {
                    String payeeConsolidationKeyId =
                            claimFacade.appendKeyForDivertMember(claim.getClaimId(),
                                    claimOtherEntities, key.getPartialConsolidationKeyId());

                    claim.setPayeeConsolidationKeyId(payeeConsolidationKeyId);

                    claim.setConsolidationKey(
                            claimFacade.getConsolidationKey(claim, key.getPartialConsolidationKey()));
                }
            }
        }
    }
}
