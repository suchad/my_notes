package com.optum.pe.peservicespeconsolidation.consolidation.partner_consolidation;

import com.optum.pe.peservicespeconsolidation.claim.Claim;
import com.optum.pe.peservicespeconsolidation.consolidation.Mapper;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class PartnerConsolidationJoinFacade implements Mapper<PartnerConsolidationJoin> {

    private final PartnerConsolidationJoinRepository repository;

    PartnerConsolidationJoinFacade(PartnerConsolidationJoinRepository repository) {
        this.repository = repository;
    }

    @Override
    public PartnerConsolidationJoin map(Claim claim) {

        return PartnerConsolidationJoin.builder()
                .consolidationId(claim.getConsolidationId())
                .partnerId(claim.getPartnerId())
                .partnerProcGroupId(claim.getPartnerProcGroupId())
                .creationDate(LocalDate.now())
                .lastUpdateDate(LocalDate.now())
                .build();
    }

    public void saveAll(List<PartnerConsolidationJoin> partnerConsolidationJoins) {
        repository.saveAll(partnerConsolidationJoins);
    }
}
