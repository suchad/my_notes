package com.optum.pe.peservicespeconsolidation.configuration;

import com.optum.pe.peservicespeconsolidation.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.ChunkListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.context.annotation.Configuration;

@Slf4j
@Configuration
class ConsolidationChunkListener implements ChunkListener {

    @Override
    public void beforeChunk(ChunkContext context) {
        // don't want to take any action.
    }

    @Override
    public void afterChunk(ChunkContext context) {
        // don't want to take any action.
    }

    @Override
    public void afterChunkError(ChunkContext context) {

        log.warn("Chunk failed for partition - " + context.getStepContext()
                .getStepExecutionContext().get(Constants.JOB_PARAM_PARTITION_NAME));

        log.warn("consolidationJob-execution-id - " + context.getStepContext().getStepExecution().getJobExecutionId());

        log.warn("step-execution-id - " + context.getStepContext().getStepExecution().getId());
    }
}
