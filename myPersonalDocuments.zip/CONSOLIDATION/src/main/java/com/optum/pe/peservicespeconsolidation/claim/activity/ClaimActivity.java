package com.optum.pe.peservicespeconsolidation.claim.activity;

import com.optum.pe.peservicespeconsolidation.consolidation.join.ClaimConsolidationJoin;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;
import org.springframework.data.domain.Persistable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "CLAIM_ACTIVITY", schema = "PE01")
@IdClass(ClaimActivityPK.class)
public class ClaimActivity implements Persistable<ClaimActivityPK> {

    @Id
    @Column(name = "CLM_ID")
    private long claimId;

    @Id
    @Column(name = "ACTV_TYP_ID")
    private int activityTypeId;

    @Column(name = "PARTNER_PROC_GRP_ID")
    private String partnerProcGroupId;

    @Column(name = "ACTV_DT_TM")
    private LocalDateTime activityDateTime;

    @Column(name = "CYC_DT")
    private LocalDate cycleDate;

    @Column(name = "CREATION_DT")
    private LocalDate creationDate;

    @Column(name = "LAST_UPDATE_DT")
    private LocalDate lastUpdateDate;

    @MapsId("claimId")
    @OneToOne(fetch = FetchType.LAZY)
    private ClaimConsolidationJoin claimConsolidationJoin;

    @Override
    public ClaimActivityPK getId() {
        return ClaimActivityPK.builder()
                .claimId(this.claimId)
                .activityTypeId(this.activityTypeId)
                .build();
    }

    @Override
    public boolean isNew() {
        return Boolean.TRUE;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        ClaimActivity that = (ClaimActivity) o;
        return claimId == that.claimId &&
                activityTypeId == that.activityTypeId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(claimId, activityTypeId);
    }
}
