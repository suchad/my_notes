package com.optum.pe.peservicespeconsolidation.configuration;

import com.optum.pe.peservicespeconsolidation.claim.Claim;
import com.optum.pe.peservicespeconsolidation.claim.other_entity.ClaimOtherEntityNotFoundException;
import com.optum.pe.peservicespeconsolidation.common_lookup.CommonLookupDataNotFoundException;
import com.optum.pe.peservicespeconsolidation.consolidation.DerivedColumnNotMappedException;
import com.optum.pe.peservicespeconsolidation.consolidation.QueryNotFoundException;
import com.optum.pe.peservicespeconsolidation.lookup.LookUpDataNotFoundException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

@Slf4j
@Service
class CompositeDecorator {

    private final PartnerConfigurationFilter partnerConfigurationFilter;
    private final PayGroupFilter payGroupFilter;
    private final PayGroupDecorator payGroupDecorator;
    private final PayeeConsolidationKeyFilter payeeConsolidationKeyFilter;
    private final PayeeConsolidationKeyDecorator payeeConsolidationKeyDecorator;

    CompositeDecorator(PartnerConfigurationFilter partnerConfigurationFilter,
                       PayGroupFilter payGroupFilter,
                       PayGroupDecorator payGroupDecorator,
                       PayeeConsolidationKeyFilter payeeConsolidationKeyFilter, PayeeConsolidationKeyDecorator payeeConsolidationKeyDecorator) {
        this.partnerConfigurationFilter = partnerConfigurationFilter;
        this.payGroupFilter = payGroupFilter;
        this.payGroupDecorator = payGroupDecorator;
        this.payeeConsolidationKeyFilter = payeeConsolidationKeyFilter;
        this.payeeConsolidationKeyDecorator = payeeConsolidationKeyDecorator;
    }

    void decorate(List<? extends Claim> claims) throws CommonLookupDataNotFoundException, QueryNotFoundException, LookUpDataNotFoundException, ClaimOtherEntityNotFoundException, DerivedColumnNotMappedException, KeyResultNotFoundException {

        decoratePartnerConfigAndPayGroups(claims);

        ConsolidationQueryStore consolidationQueryStore = new ConsolidationQueryStore();

        List<Claim> claimsForQuery = getClaimsForQuery(claims, consolidationQueryStore);

        payeeConsolidationKeyDecorator.decorate(consolidationQueryStore, claimsForQuery);
    }

    private List<Claim> getClaimsForQuery(List<? extends Claim> claims, ConsolidationQueryStore consolidationQueryStore) throws QueryNotFoundException, LookUpDataNotFoundException {

        List<Claim> claimsForQuery = new ArrayList<>();

        for (Claim claim : claims) {

            Claim claimForQuery = payeeConsolidationKeyFilter.process(claim, consolidationQueryStore);

            if (claimForQuery != null) {
                claimsForQuery.add(claimForQuery);
            }
        }
        return claimsForQuery;
    }

    private void decoratePartnerConfigAndPayGroups(List<? extends Claim> claims)
            throws CommonLookupDataNotFoundException {

        List<Claim> claimsThatNeedCommonLookup = claims.parallelStream()
                .map(partnerConfigurationFilter::asyncProcess)
                .map(CompletableFuture::join)
                .map(payGroupFilter::process)
                .filter(this::isNotNull)
                .collect(Collectors.toList());

        payGroupDecorator.commonLookup(claimsThatNeedCommonLookup);
    }

    private boolean isNotNull(Claim claim) {
        return claim != null;
    }
}
