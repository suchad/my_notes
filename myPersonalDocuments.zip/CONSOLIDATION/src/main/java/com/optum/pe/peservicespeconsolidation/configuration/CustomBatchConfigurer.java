package com.optum.pe.peservicespeconsolidation.configuration;

import org.springframework.batch.core.configuration.JobRegistry;
import org.springframework.batch.core.configuration.annotation.DefaultBatchConfigurer;
import org.springframework.batch.core.configuration.support.JobRegistryBeanPostProcessor;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.explore.support.JobExplorerFactoryBean;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.JobOperator;
import org.springframework.batch.core.launch.support.SimpleJobOperator;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.repository.dao.Jackson2ExecutionContextStringSerializer;
import org.springframework.batch.core.repository.support.JobRepositoryFactoryBean;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;
import java.sql.Timestamp;

@Configuration
class CustomBatchConfigurer extends DefaultBatchConfigurer {

    @Value("${spring.batch.table-prefix}")
    private String tablePrefix;

    private final PlatformTransactionManager oracleTransactionManager;
    private final DataSource oracleDataSource;

    CustomBatchConfigurer(@Qualifier("transactionManager") PlatformTransactionManager oracleTransactionManager, DataSource oracleDataSource) {
        this.oracleTransactionManager = oracleTransactionManager;
        this.oracleDataSource = oracleDataSource;
    }

    @Override
    public JobRepository createJobRepository() throws Exception {
        JobRepositoryFactoryBean factoryBean = new JobRepositoryFactoryBean();

        factoryBean.setDataSource(oracleDataSource);
        factoryBean.setTransactionManager(oracleTransactionManager);
        factoryBean.setIsolationLevelForCreate("ISOLATION_READ_COMMITTED");
        factoryBean.setTablePrefix(tablePrefix);
        factoryBean.setSerializer(new Jackson2ExecutionContextStringSerializer(Timestamp.class.toString()));

        return factoryBean.getObject();
    }

    @Bean
    public JobOperator jobOperator(final JobLauncher jobLauncher, final JobRepository jobRepository,
                                   final JobRegistry jobRegistry) throws Exception {
        final SimpleJobOperator jobOperator = new SimpleJobOperator();

        jobOperator.setJobLauncher(jobLauncher);
        jobOperator.setJobRepository(jobRepository);
        jobOperator.setJobRegistry(jobRegistry);
        jobOperator.setJobExplorer(jobExplorerCustom());

        jobOperator.afterPropertiesSet();

        return jobOperator;
    }

    @Bean
    JobExplorer jobExplorerCustom() throws Exception {
        final JobExplorerFactoryBean bean = new JobExplorerFactoryBean();

        bean.setDataSource(oracleDataSource);
        bean.setTablePrefix(tablePrefix);
        bean.setJdbcOperations(new JdbcTemplate(oracleDataSource));
        bean.setSerializer(new Jackson2ExecutionContextStringSerializer(Timestamp.class.toString()));
        bean.afterPropertiesSet();

        return bean.getObject();
    }

    @Bean
    public JobRegistryBeanPostProcessor jobRegistryBeanPostProcessor(JobRegistry jobRegistry) throws Exception {
        JobRegistryBeanPostProcessor postProcessor = new JobRegistryBeanPostProcessor();
        postProcessor.setJobRegistry(jobRegistry);

        postProcessor.afterPropertiesSet();

        return postProcessor;
    }
}
