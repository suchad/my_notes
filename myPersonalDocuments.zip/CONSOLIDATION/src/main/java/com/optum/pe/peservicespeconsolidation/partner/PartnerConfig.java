package com.optum.pe.peservicespeconsolidation.partner;

import com.optum.pe.peservicespeconsolidation.utils.Constants;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Data
@Table(name = "PARTNER_CONFIG", schema = "PE01")
public class PartnerConfig implements Serializable {

    @Id
    @Column(name = "PARTNER_ID")
    private String partnerId;

    @Column(name = "PARTNER_PROC_GRP_ID")
    private String partnerProcGroupId;

    @Column(name = "GEN_EOB_IND")
    private String genEobInd;

    @Column(name = "MBR_SCHED_IND")
    private String mbrSchedInd;

    @Column(name = "MBR_SCHED_IMMED_RLSE_IND")
    private String mbrSchedImmedRlseInd;

    @Column(name = "MBR_SCHED_SAME_AS_PROV_IND")
    private String mbrSchedSameAsProvInd;

    @Column(name = "PE_SERVICE_MODEL_CD")
    private String peServiceModelCode;

    @Column(name = "CONSOL_PAY_GRP_MBR_CHK_IND")
    private String consolidationPayGroupMemberCheckIndicator;

    @Column(name = "CONSOL_PAYEE_ASSIGNMENT_IND")
    private String consolidationPayeeAssignmentIndicator;

    @Column(name = "CONSOL_PAYEE_ASSIGNMENT_KEY_ID")
    private String consolidationPayeeAssignmentKeyId;

    @Column(name = "CONSOL_PAY_GRP_MBR_EFT_KEY_ID")
    private String consolidationPayGroupMemberEftKeyId;

    public boolean isMemberCheck() {
        return "Y".equals(this.consolidationPayGroupMemberCheckIndicator);
    }

    public boolean isFullService() {
        return Constants.FULL_SERVICE_INDICATOR
                .equals(this.getPeServiceModelCode());
    }

    public boolean derivePayeeAssignmentKey() {

        return "Y".equals(this.consolidationPayeeAssignmentIndicator);
    }
}
