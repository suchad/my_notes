package com.optum.pe.peservicespeconsolidation.consolidation.service_consolidation;

import com.optum.pe.peservicespeconsolidation.claim.Claim;
import com.optum.pe.peservicespeconsolidation.consolidation.Mapper;
import org.springframework.stereotype.Service;

@Service
class ServiceConsolidationMapper implements Mapper<ServiceConsolidation> {

    @Override
    public ServiceConsolidation map(Claim claim) {

        return ServiceConsolidation.builder()
                .partnerProcGroupId(claim.getPartnerProcGroupId())
                .partnerId(claim.getPartnerId())
                .cycleDate(claim.getMemberFinalReleaseDate().toLocalDate())
                .consolidationKey(claim.getConsolidationKey())
                .claimId(claim.getClaimId())
                .planEffectiveDate(claim.getPlanEffectiveDate())
                .build();
    }
}
