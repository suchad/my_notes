package com.optum.pe.peservicespeconsolidation.configuration;

import com.optum.pe.peservicespeconsolidation.utils.Constants;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.job.builder.FlowBuilder;
import org.springframework.batch.core.job.flow.Flow;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
class CleanupJobConfiguration {

    private final Tasklet cleanupConsolidationTasklet;
    private final Tasklet cleanupConsolidationActivityTasklet;
    private final Tasklet cleanupPartnerConsolidationJoinTasklet;

    private final Tasklet cleanupClaimConsolidationJoinTasklet;
    private final Tasklet cleanupClaimActivityTasklet;

    private final Tasklet cleanupFeatureResultsTasklet;
    private final Tasklet cleanupConsolidationOffsetTasklet;
    private final Tasklet cleanupServiceEndpointsTasklet;

    private final PlatformTransactionManager transactionManager;

    CleanupJobConfiguration(@Qualifier("cleanupConsolidationTasklet") Tasklet cleanupConsolidationTasklet,
                            @Qualifier("cleanupConsolidationActivityTasklet") Tasklet cleanupConsolidationActivityTasklet,
                            @Qualifier("cleanupPartnerConsolidationJoinTasklet") Tasklet cleanupPartnerConsolidationJoinTasklet,
                            @Qualifier("cleanupClaimConsolidationJoinTasklet") Tasklet cleanupClaimConsolidationJoinTasklet,
                            @Qualifier("cleanupClaimActivityTasklet") Tasklet cleanupClaimActivityTasklet,
                            @Qualifier("cleanupFeatureResultsTasklet") Tasklet cleanupFeatureResultsTasklet,
                            @Qualifier("cleanupConsolidationOffsetTasklet") Tasklet cleanupConsolidationOffsetTasklet,
                            @Qualifier("cleanupServiceEndpointsTasklet") Tasklet cleanupServiceEndpointsTasklet,
                            @Qualifier("jpaTransactionManager") PlatformTransactionManager transactionManager) {
        this.cleanupConsolidationTasklet = cleanupConsolidationTasklet;
        this.cleanupConsolidationActivityTasklet = cleanupConsolidationActivityTasklet;
        this.cleanupPartnerConsolidationJoinTasklet = cleanupPartnerConsolidationJoinTasklet;
        this.cleanupClaimConsolidationJoinTasklet = cleanupClaimConsolidationJoinTasklet;
        this.cleanupClaimActivityTasklet = cleanupClaimActivityTasklet;
        this.cleanupFeatureResultsTasklet = cleanupFeatureResultsTasklet;
        this.cleanupConsolidationOffsetTasklet = cleanupConsolidationOffsetTasklet;
        this.cleanupServiceEndpointsTasklet = cleanupServiceEndpointsTasklet;
        this.transactionManager = transactionManager;
    }

    @Autowired
    @Bean
    public Job cleanupJob(StepBuilderFactory stepBuilderFactory,
                          JobBuilderFactory jobBuilderFactory) {

        return jobBuilderFactory
                .get(Constants.JOB_NAME_CLEANUP)
                .incrementer(new RunIdIncrementer())
                .start(cleanupConsolidationActivityFlow(stepBuilderFactory))
                .split(getTaskExecutor())
                .add(cleanupPartnerConsolidationJoinFlow(stepBuilderFactory))
                .split(getTaskExecutor())
                .add(cleanupClaimConsolidationJoinFlow(stepBuilderFactory))
                .split(getTaskExecutor())
                .add(cleanupFeatureResultsFlow(stepBuilderFactory))
                .split(getTaskExecutor())
                .add(cleanupConsolidationOffsetFlow(stepBuilderFactory))
                .split(getTaskExecutor())
                .add(cleanupServiceEndpointsFlow(stepBuilderFactory))
                .next(cleanupConsolidationFlow(stepBuilderFactory))
                .next(cleanupClaimActivityFlow(stepBuilderFactory))
                .end()
                .build();
    }

    @Bean
    public TaskExecutor getTaskExecutor() {
        return new SimpleAsyncTaskExecutor();
    }

    private Flow cleanupConsolidationFlow(StepBuilderFactory stepBuilderFactory) {
        return new FlowBuilder<Flow>(Constants.FLOW_NAME_CLEANUP_CONSOLIDATION)
                .start(cleanupConsolidationStep(stepBuilderFactory))
                .build();
    }

    private Step cleanupConsolidationStep(StepBuilderFactory stepBuilderFactory) {
        return stepBuilderFactory.get(Constants.STEP_NAME_CLEANUP_CONSOLIDATION)
                .transactionManager(transactionManager)
                .tasklet(cleanupConsolidationTasklet)
                .build();
    }

    private Flow cleanupConsolidationActivityFlow(StepBuilderFactory stepBuilderFactory) {
        return new FlowBuilder<Flow>(Constants.FLOW_NAME_CLEANUP_CONSOLIDATION_ACTIVITY)
                .start(cleanupConsolidationActivityStep(stepBuilderFactory))
                .build();
    }

    private Step cleanupConsolidationActivityStep(StepBuilderFactory stepBuilderFactory) {
        return stepBuilderFactory.get(Constants.STEP_NAME_CLEANUP_CONSOLIDATION_ACTIVITY)
                .transactionManager(transactionManager)
                .tasklet(cleanupConsolidationActivityTasklet)
                .build();
    }

    private Flow cleanupPartnerConsolidationJoinFlow(StepBuilderFactory stepBuilderFactory) {
        return new FlowBuilder<Flow>(Constants.FLOW_NAME_CLEANUP_PARTNER_CONSOLIDATION_JOIN)
                .start(cleanupPartnerConsolidationJoinStep(stepBuilderFactory))
                .build();
    }

    private Step cleanupPartnerConsolidationJoinStep(StepBuilderFactory stepBuilderFactory) {
        return stepBuilderFactory.get(Constants.STEP_NAME_CLEANUP_PARTNER_CONSOLIDATION_JOIN)
                .transactionManager(transactionManager)
                .tasklet(cleanupPartnerConsolidationJoinTasklet)
                .build();
    }

    private Flow cleanupClaimConsolidationJoinFlow(StepBuilderFactory stepBuilderFactory) {
        return new FlowBuilder<Flow>(Constants.FLOW_NAME_CLEANUP_CLAIM_CONSOLIDATION_JOIN)
                .start(cleanupClaimConsolidationJoinStep(stepBuilderFactory))
                .build();
    }

    private Step cleanupClaimConsolidationJoinStep(StepBuilderFactory stepBuilderFactory) {
        return stepBuilderFactory.get(Constants.STEP_NAME_CLEANUP_CLAIM_CONSOLIDATION_JOIN)
                .transactionManager(transactionManager)
                .tasklet(cleanupClaimConsolidationJoinTasklet)
                .build();
    }

    private Flow cleanupClaimActivityFlow(StepBuilderFactory stepBuilderFactory) {
        return new FlowBuilder<Flow>(Constants.FLOW_NAME_CLEANUP_CLAIM_ACTIVITY)
                .start(cleanupClaimActivityStep(stepBuilderFactory))
                .build();
    }

    private Step cleanupClaimActivityStep(StepBuilderFactory stepBuilderFactory) {
        return stepBuilderFactory.get(Constants.STEP_NAME_CLEANUP_CLAIM_ACTIVITY)
                .transactionManager(transactionManager)
                .tasklet(cleanupClaimActivityTasklet)
                .build();
    }

    private Flow cleanupFeatureResultsFlow(StepBuilderFactory stepBuilderFactory) {
        return new FlowBuilder<Flow>(Constants.FLOW_NAME_CLEANUP_FEATURE_RESULTS)
                .start(cleanupFeatureResultsStep(stepBuilderFactory))
                .build();
    }

    private Step cleanupFeatureResultsStep(StepBuilderFactory stepBuilderFactory) {
        return stepBuilderFactory.get(Constants.STEP_NAME_CLEANUP_FEATURE_RESULTS)
                .transactionManager(transactionManager)
                .tasklet(cleanupFeatureResultsTasklet)
                .build();
    }

    private Flow cleanupConsolidationOffsetFlow(StepBuilderFactory stepBuilderFactory) {
        return new FlowBuilder<Flow>(Constants.FLOW_NAME_CLEANUP_CONSOLIDATION_OFFSET)
                .start(cleanupConsolidationOffsetStep(stepBuilderFactory))
                .build();
    }

    private Step cleanupConsolidationOffsetStep(StepBuilderFactory stepBuilderFactory) {
        return stepBuilderFactory.get(Constants.STEP_NAME_CLEANUP_CONSOLIDATION_OFFSET)
                .transactionManager(transactionManager)
                .tasklet(cleanupConsolidationOffsetTasklet)
                .build();
    }

    private Flow cleanupServiceEndpointsFlow(StepBuilderFactory stepBuilderFactory) {
        return new FlowBuilder<Flow>(Constants.FLOW_NAME_CLEANUP_SERVICE_ENDPOINTS)
                .start(cleanupServiceEndpointsStep(stepBuilderFactory))
                .build();
    }

    private Step cleanupServiceEndpointsStep(StepBuilderFactory stepBuilderFactory) {
        return stepBuilderFactory.get(Constants.STEP_NAME_CLEANUP_SERVICE_ENDPOINTS)
                .transactionManager(transactionManager)
                .tasklet(cleanupServiceEndpointsTasklet)
                .build();
    }
}
