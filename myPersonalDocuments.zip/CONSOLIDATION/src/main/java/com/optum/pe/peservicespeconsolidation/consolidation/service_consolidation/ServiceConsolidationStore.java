package com.optum.pe.peservicespeconsolidation.consolidation.service_consolidation;

import com.optum.pe.peservicespeconsolidation.consolidation_offset.ConsolidationOffset;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

public class ServiceConsolidationStore {

    private Map<String, ServiceConsolidation> store;
    private ConsolidationOffset consolidationOffset;

    ServiceConsolidationStore(ConsolidationOffset consolidationOffset, BigDecimal claimCount) {
        this.store = new HashMap<>(claimCount.intValueExact() + 1, 1);
        this.consolidationOffset = consolidationOffset;
    }

    ServiceConsolidation saveAndGet(ServiceConsolidation serviceConsolidation) {

        if (store.containsKey(serviceConsolidation.getConsolidationKey())) {

            ServiceConsolidation serviceConsolidationFromStore
                    = store.get(serviceConsolidation.getConsolidationKey());

            if (isRecentClaim(serviceConsolidation, serviceConsolidationFromStore)) {
                replaceConsolidationAsRecentClaimReceived(serviceConsolidation, serviceConsolidationFromStore);
            }

            return store.get(serviceConsolidation.getConsolidationKey());
        }

        this.consolidationOffset.setCurrentConsolidationId(
                this.consolidationOffset.getCurrentConsolidationId()
                        .add(BigDecimal.ONE));

        serviceConsolidation
                .setConsolidationId(this.consolidationOffset.getCurrentConsolidationId());

        store.put(serviceConsolidation.getConsolidationKey(), serviceConsolidation);

        return serviceConsolidation;
    }

    private boolean isRecentClaim(ServiceConsolidation serviceConsolidation, ServiceConsolidation serviceConsolidationFromStore) {
        return (serviceConsolidation.getPlanEffectiveDate().isAfter(serviceConsolidationFromStore.getPlanEffectiveDate()))
                || (serviceConsolidation.getPlanEffectiveDate().isEqual(serviceConsolidationFromStore.getPlanEffectiveDate())
                && serviceConsolidation.getClaimId().compareTo(serviceConsolidationFromStore.getClaimId()) > 0);
    }

    private void replaceConsolidationAsRecentClaimReceived(ServiceConsolidation serviceConsolidation, ServiceConsolidation serviceConsolidationFromStore) {
        serviceConsolidation.setConsolidationId(serviceConsolidationFromStore.getConsolidationId());

        store.put(serviceConsolidation.getConsolidationKey(), serviceConsolidation);
    }

    public ConsolidationOffset getConsolidationOffset() {
        return this.consolidationOffset;
    }

    public void clear() {
        this.store = null;
        this.consolidationOffset = null;
    }
}
