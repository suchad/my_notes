package com.optum.pe.peservicespeconsolidation.configuration;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.math.BigDecimal;

@AllArgsConstructor
@Getter
public class Key {

    private BigDecimal claimId;
    private String partialConsolidationKeyId;
    private String partialConsolidationKey;
}
