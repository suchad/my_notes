package com.optum.pe.peservicespeconsolidation.claim;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class ClaimMapper implements RowMapper<Claim> {

    @Override
    public Claim mapRow(ResultSet resultSet, int i) throws SQLException {

        return Claim.builder()
                .claimId(resultSet.getBigDecimal("CLM_ID"))
                .intake835ErrorStatusCode(resultSet.getString("INTAKE_835_ERR_STATUS_CD"))
                .release835PostableIndicator(resultSet.getString("RLSE_835_POSTABLE_IND"))
                .memberFinalReleaseDate(resultSet.getTimestamp("MBR_FINAL_RLSE_DT").toLocalDateTime())
                .memberInitialReleaseDate(resultSet.getTimestamp("MBR_INITIAL_RLSE_DT").toLocalDateTime())
                .memberPayMethodCode(resultSet.getString("MBR_PAY_METH_CD"))
                .memberPayConsolidationGroupCode(resultSet.getString("MBR_PAY_CONSOL_GRP_CD"))
                .memberInterestPayConsolidationGroupCode(resultSet.getString("MBR_PAY_CONSOL_GRP_CD"))
                .payeeConsolidationKeyId(resultSet.getString("PAYEE_CONSOL_KEY_ID"))
                .payerId(resultSet.getString("PAYER_ID"))
                .partnerId(resultSet.getString("PARTNER_ID"))
                .adjustedSystemSubmittedClaimId(resultSet.getString("ADJD_SYS_SUBMITTED_CLM_ID"))
                .transTypeCode(resultSet.getString("TRANS_TYP_CD"))
                .globalSolutionIndicator(resultSet.getString("GLB_SOL_IND"))
                .eobDocumentCode(resultSet.getString("EOB_DOC_CD"))
                .paymentSuppressionIndicator(resultSet.getString("PMT_SPRS_IND"))
                .peGen835Indicator(resultSet.getString("PE_GEN_835_IND"))
                .pseudoIndicator(resultSet.getString("PSEUDO_IND"))
                .rvrslCorrectionAssocId(resultSet.getString("RVRSL_CORRCTN_ASSOC_ID"))
                .divertMemberPaymentIndicator(resultSet.getString("DIVERT_MBR_PMT_IND"))
                .fundingArngCode(resultSet.getString("FUND_ARNG_CD"))
                .peServiceModelCode(resultSet.getString("PE_SERVICE_MODEL_CD"))
                .csPeGen835Indicator(resultSet.getString("CS_PE_GEN_835_IND"))
                .interestAssocId(resultSet.getString("INTEREST_ASSOC_ID"))
                .manual835RemediationIndicator(resultSet.getString("MANUAL_835_REMED_IND"))
                .networkTypeCode(resultSet.getString("NTWRK_TYP_CD"))
                .policyNumber(resultSet.getString("POL_NBR"))
                .externalPayerIndicator(resultSet.getString("EXT_PAYER_IND"))
                .payId(resultSet.getBigDecimal("PAY_ID"))
                .partnerProcGroupId(resultSet.getString("PARTNER_PROC_GRP_ID"))
                .planEffectiveDate(resultSet.getTimestamp("PLN_EFF_DT").toLocalDateTime())
                .payeeTypeCode(resultSet.getString("PAYEE_TYP_CD"))
                .asoCrossPlanRecoveryOptOutIndicator(resultSet.getString("ASO_CRSS_PLN_RECOV_OPT_OUT_IND"))
                .memberAdjudicatedIdNumber(resultSet.getString("ADJD_SBSCR_ID"))
                .memberAdjudicatedIdTypeCode(resultSet.getString("ADJD_SBSCR_ID_TYP_CD"))
                .memberAdjudicatedFirstName(resultSet.getString("ADJD_FST_NM"))
                .memberAdjudicatedMiddleName(resultSet.getString("ADJD_MIDL_NM"))
                .memberAdjudicatedLastName(resultSet.getString("ADJD_LST_NM"))
                .memberAdjudicatedNameSuffix(resultSet.getString("ADJD_NM_SFX_TXT"))
                .sgaIndicator(resultSet.getString("SGA_IND"))
                .legalEntityCode(resultSet.getString("LGL_ENTY_CD"))
                .policySfxCode(resultSet.getString("POL_SFX_CD"))
                .memberMarketTypeCode(resultSet.getString("MBR_MKT_TYP_CD"))
                .memberMarketSiteNumber(resultSet.getString("MBR_MKT_SITE_NBR"))
                .coverageTypeCode(resultSet.getString("COV_TYP_CD"))
                .bankCode(resultSet.getString("BNK_CD"))
                .adjustedSystemCode(resultSet.getString("ADJD_SYS_CD"))
                .build();
    }
}
