package com.optum.pe.peservicespeconsolidation.consolidation.join;

import com.optum.pe.peservicespeconsolidation.claim.Claim;
import com.optum.pe.peservicespeconsolidation.claim.activity.ClaimActivityFacade;
import com.optum.pe.peservicespeconsolidation.consolidation.Mapper;
import com.optum.pe.peservicespeconsolidation.utils.Constants;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class ClaimConsolidationJoinFacade implements Mapper<ClaimConsolidationJoin> {

    private final ClaimConsolidationJoinRepository repository;
    private final ClaimActivityFacade activityFacade;

    public ClaimConsolidationJoinFacade(ClaimConsolidationJoinRepository repository, ClaimActivityFacade activityFacade) {
        this.repository = repository;
        this.activityFacade = activityFacade;
    }

    @Override
    public ClaimConsolidationJoin map(Claim claim) {

        return ClaimConsolidationJoin.builder()
                .consolidationId(claim.getConsolidationId())
                .claimOrInterestId(claim.getClaimId().longValueExact())
                .idTypeCode("C")
                .partnerProcGroupId(claim.getPartnerProcGroupId())
                .creationDate(LocalDate.now())
                .lastUpdateDate(LocalDate.now())
                .claimActivity(activityFacade.map(claim))
                .build();
    }

    public void saveAll(List<ClaimConsolidationJoin> claimConsolidationJoins) {
        repository.saveAll(claimConsolidationJoins);
    }

    public int deleteClaimConsolidationJoinsByPartnerProcGroupIdAndCycleDate(String partnerProcGroupId, String cycleDate) {
        return repository.deleteClaimConsolidationJoinsByPartnerProcGroupIdAndCycleDate(partnerProcGroupId, cycleDate, Constants.CLAIM_ACTIVITY_TYPE_ID, Constants.PAYEE_TYPE_CODE_MEMBER);
    }

    public int deleteClaimActivitiesByPartnerProcGroupIdAndCycleDate(String partnerProcGroupId, String cycleDate) {
        return repository.deleteClaimActivitiesByPartnerProcGroupIdAndCycleDate(partnerProcGroupId, cycleDate, Constants.CLAIM_ACTIVITY_TYPE_ID);
    }
}
