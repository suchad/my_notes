package com.optum.pe.peservicespeconsolidation.configuration;

import com.optum.pe.peservicespeconsolidation.claim.Claim;
import com.optum.pe.peservicespeconsolidation.utils.Constants;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.database.JdbcPagingItemReader;
import org.springframework.batch.item.database.Order;
import org.springframework.batch.item.database.PagingQueryProvider;
import org.springframework.batch.item.database.builder.JdbcPagingItemReaderBuilder;
import org.springframework.batch.item.database.support.SqlPagingQueryProviderFactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.RowMapper;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

@Configuration
class ClaimJdbcPagingItemReader {

    private final RowMapper<Claim> claimMapper;
    private final DataSource dataSource;

    private final ApplicationConfiguration configuration;

    ClaimJdbcPagingItemReader(RowMapper<Claim> claimMapper, DataSource dataSource, ApplicationConfiguration configuration) {
        this.claimMapper = claimMapper;
        this.dataSource = dataSource;
        this.configuration = configuration;
    }

    @StepScope
    @Autowired
    @Bean
    public JdbcPagingItemReader<Claim> itemReader(PagingQueryProvider queryProvider,
                                                  @Value("#{stepExecution}") StepExecution stepExecution) {

        return new JdbcPagingItemReaderBuilder<Claim>()
                .name("claimJdbcPagingItemReader")
                .dataSource(dataSource)
                .queryProvider(queryProvider)
                .parameterValues(getParameterValues(stepExecution))
                .rowMapper(claimMapper)
                .pageSize(configuration.getPageSize())
                .saveState(Boolean.TRUE)
                .build();
    }

    private Map<String, Object> getParameterValues(StepExecution stepExecution) {

        Map<String, Object> parameterValues = new HashMap<>(4, 1);

        parameterValues.put("partnerProcGroupId", stepExecution.getExecutionContext().get(Constants.JOB_PARAM_PARTNER_PROC_GROUP_ID));
        parameterValues.put("cycleDate", stepExecution.getExecutionContext().get(Constants.JOB_PARAM_CYCLE_DATE));
        parameterValues.put("partition", stepExecution.getExecutionContext().get(Constants.JOB_PARAM_PARTITION));

        return parameterValues;
    }

    @Bean
    public SqlPagingQueryProviderFactoryBean queryProvider() {
        SqlPagingQueryProviderFactoryBean provider = new SqlPagingQueryProviderFactoryBean();

        Map<String, Order> sortKeys = new LinkedHashMap<>(3, 1);
        sortKeys.put("PLN_EFF_DT", Order.DESCENDING);
        sortKeys.put("CLM_ID", Order.DESCENDING);

        provider.setSelectClause("SELECT cds.CLM_ID, cds.INTAKE_835_ERR_STATUS_CD, cds.RLSE_835_POSTABLE_IND, cds.MBR_FINAL_RLSE_DT, " +
                "cds.MBR_INITIAL_RLSE_DT, cds.MBR_PAY_METH_CD, cp.MBR_PAY_CONSOL_GRP_CD, " +
                "cds.MBR_PAYEE_CONSOL_KEY_ID AS PAYEE_CONSOL_KEY_ID, cds.PAYER_ID, cr.PARTNER_ID, cr.ADJD_SYS_SUBMITTED_CLM_ID, " +
                "cr.TRANS_TYP_CD, cr.GLB_SOL_IND, cr.EOB_DOC_CD, cr.PMT_SPRS_IND, cr.PE_GEN_835_IND, cr.PSEUDO_IND, cr.RVRSL_CORRCTN_ASSOC_ID, " +
                "cr.DIVERT_MBR_PMT_IND, cp.FUND_ARNG_CD, 'N' AS PE_SERVICE_MODEL_CD, cds.PE_GEN_835_IND   AS CS_PE_GEN_835_IND, " +
                "cr.INTEREST_ASSOC_ID, cds.MANUAL_835_REMED_IND, cr.NTWRK_TYP_CD, cp.POL_NBR, cr.EXT_PAYER_IND, " +
                "cr.PAY_ID, cds.PARTNER_PROC_GRP_ID, cp.PLN_EFF_DT, 'S' as PAYEE_TYP_CD, " +
                "cds.ASO_CRSS_PLN_RECOV_OPT_OUT_IND, " +
                "csr.ADJD_SBSCR_ID, csr.ADJD_SBSCR_ID_TYP_CD, csr.ADJD_FST_NM, csr.ADJD_MIDL_NM, " +
                "csr.ADJD_LST_NM, csr.ADJD_NM_SFX_TXT, cr.SGA_IND, cp.LGL_ENTY_CD, cp.POL_SFX_CD, cp.MBR_MKT_TYP_CD, " +
                "cp.MBR_MKT_SITE_NBR, cr.COV_TYP_CD, cp.BNK_CD, cr.ADJD_SYS_CD");

        provider.setFromClause("FROM PE01.CLAIM_DERIV_SUPPLEMENTAL cds " +
                "INNER JOIN PE01.CLAIM_RLSE cr ON cds.clm_id = cr.clm_id " +
                "INNER JOIN PE01.CLM_POL_PLAN_RLSE cp ON cr.clm_id = cp.clm_id " +
                "INNER JOIN PE01.CLM_SUBSCRIBER_RLSE csr ON cds.clm_id = csr.CLM_ID");

        provider.setWhereClause("WHERE cds.PARTNER_PROC_GRP_ID = :partnerProcGroupId " +
                "AND cds.MBR_PAY_METH_CD IN ('P', 'E') " +
                "AND cds.MBR_FINAL_RLSE_DT = TO_DATE (:cycleDate, 'YYYYMMDD') " +
                "AND NVL(substr(csr.ADJD_SBSCR_ID,-2), '101') = :partition");

        provider.setSortKeys(sortKeys);
        provider.setDataSource(dataSource);

        return provider;
    }
}
