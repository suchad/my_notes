package com.optum.pe.peservicespeconsolidation.consolidation;

import com.optum.pe.peservicespeconsolidation.consolidation.activity.ConsolidationActivity;
import com.optum.pe.peservicespeconsolidation.consolidation.partner_consolidation.PartnerConsolidationJoin;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.domain.Persistable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Objects;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Builder
@Entity
@Table(name = "CONSOLIDATION", schema = "PE01")
public class Consolidation implements Persistable<Long> {

    @Id
    @Column(name = "CONSOL_ID")
    private long consolidationId;

    @Column(name = "PARTNER_PROC_GRP_ID")
    private String partnerProcGroupId;

    @Column(name = "CONSOL_TYP_CD")
    private String consolidationTypeCode;

    @Column(name = "PAY_ID")
    private BigDecimal payId;

    @Column(name = "PAY_METH_CD")
    private String payMethodCode;

    @Column(name = "PAY_CONSOL_GRP_CD")
    private String payConsolidationGroupCode;

    @Column(name = "PAYEE_ID")
    private String payeeId;

    @Column(name = "PAYEE_ID_TYP_CD")
    private String payeeIdTypeCode;

    @Column(name = "PAYEE_NM")
    private String payeeName;

    @Column(name = "RLSE_DT")
    private LocalDate releaseDate;

    @Column(name = "GLOBAL_HUB_IND")
    private String globalHubIndicator;

    @Column(name = "PSEUDO_IND")
    private String pseudoIndicator;

    @Column(name = "PAYEE_CONSOL_KEY_ID")
    private String payeeConsolidationKeyId;

    @Column(name = "CREATION_DT")
    private LocalDate creationDate;

    @Column(name = "LAST_UPDATE_DT")
    private LocalDate lastUpdateDate;

    @Column(name = "ASO_CRSS_PLN_RECOV_OPT_OUT_IND")
    private String asoCrossPlanRecoveryOptOutIndicator;

    @OneToOne(mappedBy = "consolidation", cascade = CascadeType.ALL)
    private ConsolidationActivity consolidationActivity;

    @OneToOne(mappedBy = "consolidation", cascade = CascadeType.ALL)
    private PartnerConsolidationJoin partnerConsolidationJoin;

    @Override
    public Long getId() {
        return this.consolidationId;
    }

    @Override
    public boolean isNew() {
        return Boolean.TRUE;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Consolidation that = (Consolidation) o;
        return consolidationId == that.consolidationId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(consolidationId);
    }
}
