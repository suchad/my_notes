package com.optum.pe.peservicespeconsolidation.partner;

import com.optum.pe.peservicespeconsolidation.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
class PartnerConfigCache {

    private final AppPartnerConfigRepository repository;

    PartnerConfigCache(AppPartnerConfigRepository repository) {
        this.repository = repository;
    }

    @Cacheable(cacheManager = "consolidationCacheManager", value = Constants.CACHE_NAME_PARTNER_CONFIGS, sync = true)
    public List<PartnerConfig> findAll() {
        log.info("partner cache missed!");
        return repository.findAll();
    }
}
