package com.optum.pe.peservicespeconsolidation.configuration;

import com.optum.pe.peservicespeconsolidation.service_endpoints.ServiceEndpointsFacade;
import com.optum.pe.peservicespeconsolidation.utils.Constants;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.stereotype.Service;

@Service
class CleanupServiceEndpointsTasklet implements Tasklet {

    private final ServiceEndpointsFacade facade;

    CleanupServiceEndpointsTasklet(ServiceEndpointsFacade facade) {
        this.facade = facade;
    }

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        facade.flagServiceEndpointsJobEnd(
                contribution.getStepExecution().getJobParameters()
                        .getString(Constants.JOB_PARAM_PARTNER_PROC_GROUP_ID));

        return RepeatStatus.FINISHED;
    }
}
