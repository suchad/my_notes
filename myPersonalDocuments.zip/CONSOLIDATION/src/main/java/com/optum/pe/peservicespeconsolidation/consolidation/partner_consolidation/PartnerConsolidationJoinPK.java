package com.optum.pe.peservicespeconsolidation.consolidation.partner_consolidation;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Objects;

@NoArgsConstructor
@AllArgsConstructor
@Builder
class PartnerConsolidationJoinPK implements Serializable {

    private long consolidationId;
    private String partnerId;

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        PartnerConsolidationJoinPK that = (PartnerConsolidationJoinPK) o;

        return consolidationId == that.consolidationId &&
                Objects.equals(partnerId, that.partnerId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(consolidationId, partnerId);
    }
}
