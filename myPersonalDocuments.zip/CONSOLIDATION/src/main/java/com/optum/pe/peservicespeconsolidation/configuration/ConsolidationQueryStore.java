package com.optum.pe.peservicespeconsolidation.configuration;

import lombok.Getter;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Getter
public class ConsolidationQueryStore {

    private final Map<ConsolidationQuery, List<BigDecimal>> queryStore = new ConcurrentHashMap<>();

    public void addQuery(ConsolidationQuery consolidationQuery, BigDecimal claimId) {

        if (!queryStore.containsKey(consolidationQuery)) {
            queryStore.put(consolidationQuery, new ArrayList<>());
        }

        queryStore.get(consolidationQuery).add(claimId);
    }
}
