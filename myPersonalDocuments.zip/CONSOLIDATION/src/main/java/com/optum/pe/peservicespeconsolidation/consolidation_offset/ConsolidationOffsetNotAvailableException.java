package com.optum.pe.peservicespeconsolidation.consolidation_offset;

public class ConsolidationOffsetNotAvailableException extends Exception {

    ConsolidationOffsetNotAvailableException(String message) {
        super(message);
    }
}
