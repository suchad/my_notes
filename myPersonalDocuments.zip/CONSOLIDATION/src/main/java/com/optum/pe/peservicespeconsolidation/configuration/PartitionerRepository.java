package com.optum.pe.peservicespeconsolidation.configuration;

import com.optum.pe.peservicespeconsolidation.claim.drive_supplemental.ClaimDeriveSupplemental;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Repository
interface PartitionerRepository extends JpaRepository<ClaimDeriveSupplemental, BigDecimal> {

    @Query(value = "SELECT\n" +
            "       NVL(substr(csr.ADJD_SBSCR_ID,-2), '101') AS data_split_key, count(*) AS count_of_claims\n" +
            "  FROM\n" +
            "       PE01.CLAIM_DERIV_SUPPLEMENTAL cds\n" +
            "       INNER JOIN PE01.CLM_SUBSCRIBER_RLSE csr\n" +
            "           ON cds.clm_id = csr.clm_id\n" +
            " WHERE\n" +
            "           cds.PARTNER_PROC_GRP_ID = :partnerProcGroupId\n" +
            "       AND cds.MBR_PAY_METH_CD IN ('P', 'E')\n" +
            "       AND cds.MBR_FINAL_RLSE_DT = TO_DATE (:cycleDate, 'YYYYMMDD') \n" +
            "       GROUP BY NVL(substr(csr.ADJD_SBSCR_ID,-2), '101') ", nativeQuery = true)
    List<Map<String, Object>> getPartitionStats(String partnerProcGroupId, String cycleDate);
}
