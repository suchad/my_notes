package com.optum.pe.peservicespeconsolidation.configuration;

import com.optum.pe.peservicespeconsolidation.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.stereotype.Service;

import java.util.Arrays;

@Slf4j
@Service
class CleanupFeatureResultsTasklet implements Tasklet {

    private final AppFeatureResultsRepository repository;

    public CleanupFeatureResultsTasklet(AppFeatureResultsRepository repository) {
        this.repository = repository;
    }

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        int deletionCount = repository.deleteFeatureResultsByPartnerProcGroupIdAndCycleDateAndFeatureCategoryCodes(
                contribution.getStepExecution().getJobParameters()
                        .getString(Constants.JOB_PARAM_PARTNER_PROC_GROUP_ID),
                contribution.getStepExecution().getJobParameters()
                        .getString(Constants.JOB_PARAM_CYCLE_DATE),
                Arrays.asList(Constants.FEATURE_CATEGORY_EFT, Constants.FEATURE_CATEGORY_CHECK));

        log.info("TABLE PE01.FEATURE_RESULTS DELETION COUNT - " + deletionCount);

        return RepeatStatus.FINISHED;
    }
}
