package com.optum.pe.peservicespeconsolidation.configuration;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;
import java.util.Objects;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
public class ConsolidationQuery {

    private String partnerProcGoupId;
    private String queryId;
    private String query;
    private List<String> derivedColumns;

    @Override
    public boolean equals(Object o) {

        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        ConsolidationQuery that = (ConsolidationQuery) o;
        return Objects.equals(getQueryId(), that.getQueryId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getQueryId());
    }
}
