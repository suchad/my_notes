package com.optum.pe.peservicespeconsolidation.configuration;

import com.optum.paymentengine.common.lookup.beans.CommonLookupResponse;
import com.optum.paymentengine.common.lookup.dao.model.FeatureResultsEntity;
import com.optum.pe.claim.ClaimConsolidatedPERecord;
import com.optum.pe.claim.ClaimHold;
import com.optum.pe.claim.ClaimPolPlanHold;
import com.optum.pe.peservicespeconsolidation.claim.Claim;
import com.optum.pe.peservicespeconsolidation.common_lookup.CommonLookupDataNotFoundException;
import com.optum.pe.peservicespeconsolidation.common_lookup.CommonLookupService;
import com.optum.pe.peservicespeconsolidation.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Slf4j
@Component
public class PayGroupDecorator {

    private final CommonLookupService lookupService;

    public PayGroupDecorator(CommonLookupService lookupService) {
        this.lookupService = lookupService;
    }

    void commonLookup(List<Claim> claims) throws CommonLookupDataNotFoundException {

        if (claims == null || claims.isEmpty()) {
            return;
        }

        Map<String, List<Claim>> claimsByConsolidationPayGroupMemberEftKeyId =
                claims.parallelStream()
                        .collect(Collectors.groupingBy(this::getConsolidationPayGroupMemberEftKeyId));

        List<FeatureResultsEntity> featureResultsEntities = new ArrayList<>(claims.size() * 2);

        claimsByConsolidationPayGroupMemberEftKeyId
                .forEach((eftKeyId, claimsForEftKeyId) -> {

                    List<ClaimConsolidatedPERecord> claimConsolidatedPERecords = claimsForEftKeyId.parallelStream()
                            .map(this::getClaimConsolidatedPERecord).collect(Collectors.toList());

                    CommonLookupResponse commonLookupResponse
                            = lookupService.getCommonLookUp(claimConsolidatedPERecords, claimsForEftKeyId.get(0));

                    featureResultsEntities.addAll(commonLookupResponse.getFeatureResults());
                });

        if (featureResultsEntities.isEmpty()) {
            throw new CommonLookupDataNotFoundException(Constants.ER_502 + claims.get(0).getPartnerId());
        }

        for (Claim claim : claims) {

            Optional<FeatureResultsEntity> featureResultsOptional =
                    featureResultsEntities.parallelStream()
                            .filter(result -> Constants.COMMON_RESULT_SUCCESS_IND.equals(result.getResultNotFoundInd()))
                            .filter(result -> result.getRecordId().equals(claim.getClaimId().longValueExact()))
                            .filter(result -> result.getFeatureCatCd().equals(claim.getFeatureCategory()))
                            .findAny();

            if (featureResultsOptional.isPresent()) {
                claim.assignGroupCodes(featureResultsOptional.get());
            } else {
                throw new CommonLookupDataNotFoundException(Constants.ER_502 + claims.get(0).getPartnerId());
            }

        }
    }

    private String getConsolidationPayGroupMemberEftKeyId(Claim claim) {
        return claim.getPartnerConfig().getConsolidationPayGroupMemberEftKeyId();
    }

    private ClaimConsolidatedPERecord getClaimConsolidatedPERecord(Claim claim) {

        return ClaimConsolidatedPERecord.newBuilder()
                .setClaimHoldRecord(getClaimHoldRecord(claim))
                .setClaimPolPlanHoldRecord(getClaimPolPlanHoldRecord(claim))
                .build();
    }

    private ClaimPolPlanHold getClaimPolPlanHoldRecord(Claim claim) {

        return ClaimPolPlanHold.newBuilder()
                .setFundArngCd(claim.getFundingArngCode())
                .setLglEntyCd(claim.getLegalEntityCode())
                .setPolNbr(claim.getPolicyNumber())
                .setPolSfxCd(claim.getPolicySfxCode())
                .setBnkCd(claim.getBankCode())
                .setMbrMktTypCd(claim.getMemberMarketTypeCode())
                .setMbrMktSiteNbr(claim.getMemberMarketSiteNumber())
                .build();
    }

    private ClaimHold getClaimHoldRecord(Claim claim) {

        return ClaimHold.newBuilder()
                .setAdjdSysClmId(claim.getAdjustedSystemSubmittedClaimId())
                .setAdjdSysCd(claim.getAdjustedSystemCode())
                .setAdjdSysClmTransSeqId("1")
                .setPartnerProcGrpId(claim.getPartnerProcGroupId())
                .setPartnerId(claim.getPartnerId())
                .setClmId(claim.getClaimId().longValueExact())
                .setMbrPayMethCd(claim.getMemberPayMethodCode())
                .setSgaInd(claim.getSgaIndicator())
                .build();
    }
}
