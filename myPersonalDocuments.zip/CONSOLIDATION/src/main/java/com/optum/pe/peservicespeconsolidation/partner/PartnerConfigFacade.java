package com.optum.pe.peservicespeconsolidation.partner;

import com.optum.pe.peservicespeconsolidation.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Slf4j
@Service
public class PartnerConfigFacade {

    private final PartnerConfigCache partnerConfigCache;

    public PartnerConfigFacade(PartnerConfigCache partnerConfigCache) {
        this.partnerConfigCache = partnerConfigCache;
    }

    public PartnerConfig findOne(String partnerId) throws PartnerConfigNotFoundException {

        Optional<PartnerConfig> partnerConfigOptional = getPartnerConfig(partnerId);

        return partnerConfigOptional
                .orElseThrow(() ->
                        new PartnerConfigNotFoundException(Constants.ER500 + partnerId));
    }

    private Optional<PartnerConfig> getPartnerConfig(String partnerId) {
        return partnerConfigCache.findAll().stream()
                .filter(partnerConfig -> partnerConfig.getPartnerId().equals(partnerId))
                .findAny();
    }
}
