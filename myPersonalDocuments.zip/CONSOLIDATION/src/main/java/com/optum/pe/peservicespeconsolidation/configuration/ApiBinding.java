package com.optum.pe.peservicespeconsolidation.configuration;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.oauth2.client.OAuth2ClientContext;
import org.springframework.security.oauth2.client.token.grant.client.ClientCredentialsResourceDetails;
import org.springframework.web.client.RestTemplate;

@Configuration
class ApiBinding {

    @Bean
    protected RestTemplate restTemplate(OAuth2ClientContext oauth2ClientContext) {
        return new CustomOAuth2RestTemplate(oAuthDetails(), oauth2ClientContext);
    }

    @Bean
    @ConfigurationProperties("api.oauth2.client")
    protected ClientCredentialsResourceDetails oAuthDetails() {
        return new ClientCredentialsResourceDetails();
    }
}
