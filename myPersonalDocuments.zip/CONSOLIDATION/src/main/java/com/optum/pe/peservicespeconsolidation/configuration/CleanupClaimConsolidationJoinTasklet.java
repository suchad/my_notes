package com.optum.pe.peservicespeconsolidation.configuration;

import com.optum.pe.peservicespeconsolidation.consolidation.join.ClaimConsolidationJoinFacade;
import com.optum.pe.peservicespeconsolidation.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.stereotype.Service;

@Slf4j
@Service
class CleanupClaimConsolidationJoinTasklet implements Tasklet {

    private final ClaimConsolidationJoinFacade facade;

    CleanupClaimConsolidationJoinTasklet(ClaimConsolidationJoinFacade facade) {
        this.facade = facade;
    }

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        int deletionCount = facade.deleteClaimConsolidationJoinsByPartnerProcGroupIdAndCycleDate(
                contribution.getStepExecution().getJobParameters()
                        .getString(Constants.JOB_PARAM_PARTNER_PROC_GROUP_ID),
                contribution.getStepExecution().getJobParameters()
                        .getString(Constants.JOB_PARAM_CYCLE_DATE));

        log.info("TABLE PE01.CLAIM_CONSOLIDATION_JOIN DELETION COUNT - " + deletionCount);

        return RepeatStatus.FINISHED;
    }
}
