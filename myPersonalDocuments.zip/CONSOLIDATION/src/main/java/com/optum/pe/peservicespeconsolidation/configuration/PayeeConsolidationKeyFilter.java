package com.optum.pe.peservicespeconsolidation.configuration;

import com.optum.pe.peservicespeconsolidation.claim.Claim;
import com.optum.pe.peservicespeconsolidation.claim.ClaimFacade;
import com.optum.pe.peservicespeconsolidation.consolidation.QueryNotFoundException;
import com.optum.pe.peservicespeconsolidation.lookup.LookUpDataNotFoundException;
import org.springframework.stereotype.Service;

@Service
class PayeeConsolidationKeyFilter {

    private final ClaimFacade claimFacade;

    PayeeConsolidationKeyFilter(ClaimFacade claimFacade) {
        this.claimFacade = claimFacade;
    }

    Claim process(Claim claim, ConsolidationQueryStore consolidationQueryStore)
            throws QueryNotFoundException, LookUpDataNotFoundException {

        if (claim.isDerivePayeeAssignmentKey() && claim.isFullService()) {
            claimFacade.derivePayeeAssignmentKey(claim, consolidationQueryStore);
        } else {
            claim.setPayeeConsolidationKeyId(claim.getClaimId().toString());
            claim.setConsolidationKey(claim.getClaimId().toString());

            return null;
        }

        return claim;
    }
}
