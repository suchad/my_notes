package com.optum.pe.peservicespeconsolidation.configuration;

import com.optum.pe.peservicespeconsolidation.claim.Claim;
import com.optum.pe.peservicespeconsolidation.partner.PartnerConfig;
import com.optum.pe.peservicespeconsolidation.partner.PartnerConfigFacade;
import com.optum.pe.peservicespeconsolidation.partner.PartnerConfigNotFoundException;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;

@Component
class PartnerConfigurationFilter implements ItemProcessor<Claim, Claim> {

    private final PartnerConfigFacade partnerConfigFacade;

    PartnerConfigurationFilter(PartnerConfigFacade partnerConfigFacade) {
        this.partnerConfigFacade = partnerConfigFacade;
    }

    CompletableFuture<Claim> asyncProcess(Claim claim) {

        return CompletableFuture.supplyAsync(() -> {
            try {
                return this.process(claim);
            } catch (PartnerConfigNotFoundException e) {
                throw new CompletionException(e);
            }
        });
    }

    @Override
    public Claim process(Claim claim) throws PartnerConfigNotFoundException {

        PartnerConfig partnerConfig = partnerConfigFacade.findOne(claim.getPartnerId());

        boolean isFullService = partnerConfig.isFullService();

        claim.setPartnerConfig(partnerConfig);
        claim.setFullService(isFullService);

        return claim;
    }
}
