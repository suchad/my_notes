package com.optum.pe.peservicespeconsolidation.claim.other_entity;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Repository
interface ClaimOtherEntityRepository extends JpaRepository<ClaimOtherEntity, ClaimOtherEntityPK> {

    @Query(value = "SELECT CLM_ID, SEQ_NBR, ENTITY_TYP_CD, ENTITY_ID, ENTITY_ID_TYP_CD " +
            "FROM PE01.CLM_OTHR_ENTITY_RLSE WHERE (CLM_ID, SEQ_NBR) \n" +
            "IN (SELECT CLM_ID, MAX(SEQ_NBR) FROM PE01.CLM_OTHR_ENTITY_RLSE \n" +
            "WHERE CLM_ID IN (:claimIds)\n" +
            "GROUP BY CLM_ID)", nativeQuery = true)
    List<Object[]> findAll(List<BigDecimal> claimIds);
}
