package com.optum.pe.peservicespeconsolidation.consolidation_offset;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.math.BigDecimal;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "CONSOLIDATION_OFFSETS", schema = "PE01")
public class ConsolidationOffset implements Serializable {

    @Id
    @GeneratedValue
    @Column(name = "ID")
    private long id;

    @Column(name = "PARTNER_PROC_GRP_ID")
    private String partnerProcGroupId;

    @Column(name = "CURRENT_CONSOL_ID")
    private BigDecimal currentConsolidationId;

    @Column(name = "CLAIMED")
    private String claimed;

    @Column(name = "UPDATED_BY")
    private String updatedBy;
}
