package com.optum.pe.peservicespeconsolidation.consolidation;

public class DerivedColumnNotMappedException extends Exception {

    DerivedColumnNotMappedException(String message) {
        super(message);
    }
}
