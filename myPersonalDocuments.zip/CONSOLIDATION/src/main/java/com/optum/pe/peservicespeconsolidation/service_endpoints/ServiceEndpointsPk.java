package com.optum.pe.peservicespeconsolidation.service_endpoints;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import java.io.Serializable;

@EqualsAndHashCode
@Data
@NoArgsConstructor
class ServiceEndpointsPk implements Serializable {

    private static final long serialVersionUID = 1L;

    @Column(name = "PARTNER_PROC_GRP_ID")
    private String partnerProcGrpId;

    @Column(name = "SERVICE_NAME")
    private String serviceName;

    @Column(name = "ENDPOINT_NAME")
    private String endpointName;
}
