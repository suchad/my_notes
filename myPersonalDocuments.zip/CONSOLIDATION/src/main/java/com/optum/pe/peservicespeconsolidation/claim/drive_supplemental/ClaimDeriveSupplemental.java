package com.optum.pe.peservicespeconsolidation.claim.drive_supplemental;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Objects;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Data
@Table(schema = "PE01", name = "CLAIM_DERIV_SUPPLEMENTAL")
public class ClaimDeriveSupplemental {

    @Id
    @Column(name = "CLM_ID", updatable = false)
    private BigDecimal claimId;

    @Column(name = "MBR_PAY_CONSOL_GRP_CD")
    private String memberPayConsolidationGroupCode;

    @Column(name = "MBR_INT_PAY_CONSOL_GRP_CD")
    private String memberInterestPayConsolidationGroupCode;

    @Column(name = "MBR_PAYEE_CONSOL_KEY_ID")
    private String memberPayeeConsolidationKeyId;

    @Column(name = "LAST_UPDATE_DT")
    private LocalDate lastUpdateDate;

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        ClaimDeriveSupplemental that = (ClaimDeriveSupplemental) o;
        return Objects.equals(claimId, that.claimId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(claimId);
    }
}
