package com.optum.pe.peservicespeconsolidation.cycle_date;

import org.springframework.stereotype.Service;

@Service
public class CycleDateFacade {

    private final CycleDateRepository repository;

    public CycleDateFacade(CycleDateRepository repository) {
        this.repository = repository;
    }

    public String findCycleDate(String partnerProcGrpId)
            throws CycleDateException {
        
        String cycleDate = repository.findCycleDate(partnerProcGrpId);

        if (cycleDate == null) {
            throw new CycleDateException("Got CycleDate - " + cycleDate);
        }

        return cycleDate;
    }
}
