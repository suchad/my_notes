package com.optum.pe.peservicespeconsolidation.consolidation;

import com.optum.pe.peservicespeconsolidation.claim.Claim;
import com.optum.pe.peservicespeconsolidation.consolidation.activity.ConsolidationActivityFacade;
import com.optum.pe.peservicespeconsolidation.consolidation.partner_consolidation.PartnerConsolidationJoinFacade;
import com.optum.pe.peservicespeconsolidation.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Slf4j
@Service
public class ConsolidationFacade implements Mapper<Consolidation> {

    private final ConsolidationRepository repository;
    private final ConsolidationActivityFacade activityFacade;
    private final PartnerConsolidationJoinFacade partnerConsolidationJoinFacade;

    ConsolidationFacade(ConsolidationRepository repository, ConsolidationActivityFacade activityFacade, PartnerConsolidationJoinFacade partnerConsolidationJoinFacade) {
        this.repository = repository;
        this.activityFacade = activityFacade;
        this.partnerConsolidationJoinFacade = partnerConsolidationJoinFacade;
    }

    @Override
    public Consolidation map(Claim claim) {

        return Consolidation.builder()
                .consolidationId(claim.getConsolidationId())
                .partnerProcGroupId(claim.getPartnerProcGroupId())
                .consolidationTypeCode(getConsolidationTypeCode(claim))
                .payId(claim.getPayId())
                .payMethodCode(claim.getMemberPayMethodCode())
                .payConsolidationGroupCode(claim.getMemberPayConsolidationGroupCode())
                .payeeId(getPayeeId(claim))
                .payeeIdTypeCode(getPayeeIdTypeCode(claim))
                .payeeName(getPayeeName(claim))
                .releaseDate(claim.getMemberFinalReleaseDate().toLocalDate())
                .globalHubIndicator(claim.getGlobalSolutionIndicator())
                .pseudoIndicator(claim.getPseudoIndicator())
                .payeeConsolidationKeyId(claim.getPayeeConsolidationKeyId())
                .creationDate(LocalDate.now())
                .lastUpdateDate(LocalDate.now())
                .asoCrossPlanRecoveryOptOutIndicator(claim.getAsoCrossPlanRecoveryOptOutIndicator())
                .consolidationActivity(activityFacade.map(claim))
                .partnerConsolidationJoin(partnerConsolidationJoinFacade.map(claim))
                .build();
    }

    public void saveAll(List<Consolidation> consolidations) {
        repository.saveAll(consolidations);
    }

    public int deleteConsolidationsByPartnerProcGroupIdAndCycleDate(String partnerProcGroupId, String cycleDate) {
        return repository.deleteConsolidationsByPartnerProcGroupIdAndCycleDate(partnerProcGroupId, cycleDate, Constants.PAYEE_TYPE_CODE_MEMBER);
    }

    public int deleteConsolidationActivitiesByPartnerProcGroupIdAndCycleDate(String partnerProcGroupId, String cycleDate) {
        return repository.deleteConsolidationActivitiesByPartnerProcGroupIdAndCycleDate(partnerProcGroupId, cycleDate, Constants.CONSOLIDATION_ACTIVITY_TYPE_ID, Constants.PAYEE_TYPE_CODE_MEMBER);
    }

    public int deletePartnerConsolidationJoinsByPartnerProcGroupIdAndCycleDate(String partnerProcGroupId, String cycleDate) {
        return repository.deletePartnerConsolidationJoinsByPartnerProcGroupIdAndCycleDate(partnerProcGroupId, cycleDate, Constants.PAYEE_TYPE_CODE_MEMBER);
    }

    private String getPayeeName(Claim claim) {
        return getPayeeNameForMember(claim);
    }

    private String getPayeeNameForMember(Claim claim) {
        return claim.getMemberAdjudicatedFirstName() + claim.getMemberAdjudicatedMiddleName() +
                claim.getMemberAdjudicatedLastName() + claim.getMemberAdjudicatedNameSuffix();
    }

    private String getPayeeIdTypeCode(Claim claim) {
        return claim.getMemberAdjudicatedIdTypeCode();
    }

    private String getPayeeId(Claim claim) {
        return claim.getMemberAdjudicatedIdNumber();
    }

    private String getConsolidationTypeCode(Claim claim) {

        if ("S".equals(claim.getPayeeTypeCode())) {
            return Constants.PAYEE_TYPE_CODE_MEMBER;
        }

        return Constants.PAYEE_TYPE_CODE_PROVIDER;
    }
}
