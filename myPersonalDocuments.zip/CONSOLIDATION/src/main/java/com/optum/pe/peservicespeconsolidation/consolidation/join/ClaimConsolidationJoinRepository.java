package com.optum.pe.peservicespeconsolidation.consolidation.join;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
interface ClaimConsolidationJoinRepository extends JpaRepository<ClaimConsolidationJoin, ClaimConsolidationJoinPK> {

    @Transactional(transactionManager = "jpaTransactionManager")
    @Modifying
    @Query(value = "DELETE FROM PE01.CLAIM_CONSOLIDATION_JOIN ccj " +
            "WHERE ID_TYP_CD = 'C' AND ccj.CLM_OR_INT_ID IN " +
            "(SELECT CLM_ID FROM PE01.CLAIM_ACTIVITY ca " +
            "WHERE PARTNER_PROC_GRP_ID = :partnerProcGroupId " +
            "AND ACTV_TYP_ID = :activityTypeId " +
            "AND CYC_DT = TO_DATE(:cycleDate, 'YYYYMMDD')) " +
            "AND CONSOL_ID IN " +
            "(SELECT CONSOL_ID FROM PE01.CONSOLIDATION c " +
            "WHERE PARTNER_PROC_GRP_ID = :partnerProcGroupId " +
            "AND CONSOL_TYP_CD = :consolidationTypeCode " +
            "AND RLSE_DT = TO_DATE(:cycleDate, 'YYYYMMDD'))", nativeQuery = true)
    int deleteClaimConsolidationJoinsByPartnerProcGroupIdAndCycleDate(String partnerProcGroupId, String cycleDate, int activityTypeId, String consolidationTypeCode);

    @Transactional(transactionManager = "jpaTransactionManager")
    @Modifying
    @Query(value = "DELETE FROM PE01.CLAIM_ACTIVITY ca " +
            "WHERE PARTNER_PROC_GRP_ID = :partnerProcGroupId " +
            "AND ACTV_TYP_ID = :activityTypeId " +
            "AND CYC_DT = TO_DATE(:cycleDate, 'YYYYMMDD')", nativeQuery = true)
    int deleteClaimActivitiesByPartnerProcGroupIdAndCycleDate(String partnerProcGroupId, String cycleDate, int activityTypeId);
}
