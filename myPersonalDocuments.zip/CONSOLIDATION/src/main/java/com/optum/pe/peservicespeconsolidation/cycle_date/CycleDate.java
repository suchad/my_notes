package com.optum.pe.peservicespeconsolidation.cycle_date;

import lombok.Data;
import lombok.Getter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Data
@Getter
@Table(schema = "PE01", name = "CYCLE_DATE")
@IdClass(CycleDatePK.class)
class CycleDate implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "PARTNER_PROC_GRP_ID")
    private String partnerProcGrpId;

    @Id
    @Column(name = "CYC_DT_NM")
    private String cycleDateValue;

    @Column(name = "CYC_DT_USED_IND")
    private String cycleDateUsedIndicator;

}