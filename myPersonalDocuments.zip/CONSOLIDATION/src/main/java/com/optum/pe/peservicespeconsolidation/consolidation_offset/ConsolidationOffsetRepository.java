package com.optum.pe.peservicespeconsolidation.consolidation_offset;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
interface ConsolidationOffsetRepository extends JpaRepository<ConsolidationOffset, Long> {

    ConsolidationOffset findByPartnerProcGroupIdAndClaimedAndUpdatedBy(String partnerProcGroupId, String claimed, String updatedBy);

    @Transactional(transactionManager = "jpaTransactionManager")
    @Modifying
    @Query(value = "UPDATE PE01.CONSOLIDATION_OFFSETS SET CLAIMED = 'Y', UPDATED_BY = :partitionName\n" +
            "WHERE CLAIMED = 'N' AND PARTNER_PROC_GRP_ID = :partnerProcGroupId AND ROWNUM = 1", nativeQuery = true)
    int updateOffset(String partnerProcGroupId, String partitionName);

    @Transactional(transactionManager = "jpaTransactionManager")
    @Modifying
    @Query(value = "UPDATE PE01.CONSOLIDATION_OFFSETS SET CLAIMED = 'N', UPDATED_BY = '' " +
            "WHERE PARTNER_PROC_GRP_ID = :partnerProcGroupId ", nativeQuery = true)
    int cleanOffsetByPartnerProcGroupId(String partnerProcGroupId);
}
