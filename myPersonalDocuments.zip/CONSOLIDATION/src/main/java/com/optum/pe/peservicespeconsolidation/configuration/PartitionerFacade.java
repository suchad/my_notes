package com.optum.pe.peservicespeconsolidation.configuration;

import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
class PartitionerFacade {

    private final PartitionerRepository repository;

    PartitionerFacade(PartitionerRepository repository) {
        this.repository = repository;
    }

    Map<String, BigDecimal> getPartitions(String partnerProcGroupId, String cycleDate) {

        List<Map<String, Object>> rows
                = repository.getPartitionStats(partnerProcGroupId, cycleDate);

        return rows.stream()
                .collect(Collectors.toMap(s -> (String) s.get("data_split_key"),
                        s -> (BigDecimal) s.get("count_of_claims")));
    }
}
