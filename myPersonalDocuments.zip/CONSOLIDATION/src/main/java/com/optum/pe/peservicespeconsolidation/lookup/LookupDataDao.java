package com.optum.pe.peservicespeconsolidation.lookup;

import com.optum.pe.peservicespeconsolidation.utils.Constants;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

@Repository
class LookupDataDao {

    @PersistenceContext
    private EntityManager entityManager;

    private final List<String> lookupSetCdList =
            Collections.singletonList(Constants.PAYEE_CONFIGURATION_SET_CODE);

    List<LookupData> findAll(LocalDate date) {

        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();

        CriteriaQuery<LookupData> criteriaQuery = criteriaBuilder.createQuery(LookupData.class);
        Root<LookupData> lookupDataRoot = criteriaQuery.from(LookupData.class);

        Predicate effectiveDatePredicate = criteriaBuilder.lessThanOrEqualTo(lookupDataRoot.get(LookupData_.effectiveDate), date);
        Predicate endDatePredicate = criteriaBuilder.greaterThanOrEqualTo(lookupDataRoot.get(LookupData_.endDate), date);

        Expression<String> lookupSetCdExpression = lookupDataRoot.get(LookupData_.LOOKUP_SET_CODE);

        Predicate lookupSetCdPredicate = lookupSetCdExpression.in(lookupSetCdList);

        Predicate lookupPredicate = criteriaBuilder.and(
                effectiveDatePredicate, endDatePredicate, lookupSetCdPredicate);

        criteriaQuery.where(lookupPredicate);

        criteriaQuery.orderBy(criteriaBuilder.desc(lookupDataRoot.get(LookupData_.keyField04)));

        return entityManager.createQuery(criteriaQuery).getResultList();
    }
}
