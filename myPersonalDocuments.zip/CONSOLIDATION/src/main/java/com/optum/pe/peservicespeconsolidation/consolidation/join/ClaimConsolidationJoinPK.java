package com.optum.pe.peservicespeconsolidation.consolidation.join;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Objects;

@AllArgsConstructor
@NoArgsConstructor
@Builder
class ClaimConsolidationJoinPK implements Serializable {

    private long consolidationId;
    private long claimOrInterestId;
    private String idTypeCode;

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        ClaimConsolidationJoinPK that = (ClaimConsolidationJoinPK) o;

        return consolidationId == that.consolidationId &&
                claimOrInterestId == that.claimOrInterestId &&
                Objects.equals(idTypeCode, that.idTypeCode);
    }

    @Override
    public int hashCode() {
        return Objects.hash(consolidationId, claimOrInterestId, idTypeCode);
    }
}
