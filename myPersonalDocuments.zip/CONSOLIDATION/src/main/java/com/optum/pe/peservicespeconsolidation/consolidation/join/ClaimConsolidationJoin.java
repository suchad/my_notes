package com.optum.pe.peservicespeconsolidation.consolidation.join;

import com.optum.pe.peservicespeconsolidation.claim.activity.ClaimActivity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;
import org.springframework.data.domain.Persistable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import java.time.LocalDate;
import java.util.Objects;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "CLAIM_CONSOLIDATION_JOIN", schema = "PE01")
@IdClass(ClaimConsolidationJoinPK.class)
public class ClaimConsolidationJoin implements Persistable<ClaimConsolidationJoinPK> {

    @Id
    @Column(name = "CONSOL_ID")
    private long consolidationId;

    @Id
    @Column(name = "CLM_OR_INT_ID")
    private long claimOrInterestId;

    @Id
    @Column(name = "ID_TYP_CD")
    private String idTypeCode;

    @Column(name = "PARTNER_PROC_GRP_ID")
    private String partnerProcGroupId;

    @Column(name = "CREATION_DT")
    private LocalDate creationDate;

    @Column(name = "LAST_UPDATE_DT")
    private LocalDate lastUpdateDate;

    @MapsId("claimOrInterestId")
    @OneToOne(mappedBy = "claimConsolidationJoin", cascade = CascadeType.ALL)
    private ClaimActivity claimActivity;

    @Override
    public ClaimConsolidationJoinPK getId() {
        return ClaimConsolidationJoinPK.builder()
                .consolidationId(this.consolidationId)
                .claimOrInterestId(this.claimOrInterestId)
                .idTypeCode(this.idTypeCode)
                .build();
    }

    @Override
    public boolean isNew() {
        return Boolean.TRUE;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        ClaimConsolidationJoin that = (ClaimConsolidationJoin) o;
        return consolidationId == that.consolidationId &&
                claimOrInterestId == that.claimOrInterestId &&
                Objects.equals(idTypeCode, that.idTypeCode);
    }

    @Override
    public int hashCode() {
        return Objects.hash(consolidationId, claimOrInterestId, idTypeCode);
    }
}
