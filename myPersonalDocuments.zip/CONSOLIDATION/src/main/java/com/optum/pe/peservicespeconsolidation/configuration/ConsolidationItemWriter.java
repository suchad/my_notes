package com.optum.pe.peservicespeconsolidation.configuration;

import com.optum.pe.peservicespeconsolidation.claim.Claim;
import com.optum.pe.peservicespeconsolidation.consolidation.service_consolidation.ServiceConsolidationFacade;
import com.optum.pe.peservicespeconsolidation.consolidation.service_consolidation.ServiceConsolidationStore;
import com.optum.pe.peservicespeconsolidation.consolidation_offset.ConsolidationOffsetNotAvailableException;
import com.optum.pe.peservicespeconsolidation.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.AfterStep;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemWriter;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import java.math.BigDecimal;
import java.util.List;

@Slf4j
@StepScope
@Component
class ConsolidationItemWriter implements ItemWriter<Claim> {

    private final CompositeDecorator compositeDecorator;
    private final LoadTableService loadTableService;
    private final ConsolidationFilter consolidationFilter;
    private final ServiceConsolidationFacade serviceConsolidationFacade;

    private ServiceConsolidationStore serviceConsolidationStore;
    
    private final EntityManager entityManager;

    ConsolidationItemWriter(LoadTableService loadTableService,
                            ServiceConsolidationFacade serviceConsolidationFacade,
                            CompositeDecorator compositeDecorator,
                            ConsolidationFilter consolidationFilter,
                            EntityManager entityManager) {
        this.loadTableService = loadTableService;
        this.serviceConsolidationFacade = serviceConsolidationFacade;
        this.compositeDecorator = compositeDecorator;
        this.consolidationFilter = consolidationFilter;
        this.entityManager = entityManager;
    }

    @BeforeStep
    public void initializeState(StepExecution stepExecution)
            throws ConsolidationOffsetNotAvailableException {

        this.serviceConsolidationStore = serviceConsolidationFacade
                .initializeServiceConsolidationStore(stepExecution
                                .getExecutionContext()
                                .getString(Constants.JOB_PARAM_PARTNER_PROC_GROUP_ID),
                        stepExecution
                                .getExecutionContext()
                                .getString(Constants.JOB_PARAM_PARTITION_NAME),
                        (BigDecimal) stepExecution
                                .getExecutionContext()
                                .get(Constants.JOB_PARAM_CLAIM_COUNT_NAME));

        log.info("serviceConsolidationStore initialized ID - " + this.serviceConsolidationStore.getConsolidationOffset().getId());
    }

    @Override
    public void write(List<? extends Claim> claims) throws Exception {

        log.info("Got Batch - " + claims.get(0).getClaimId());

        compositeDecorator.decorate(claims);

        consolidateClaims(claims);

        loadTableService.load(claims);

        entityManager.flush();
    }

    private void consolidateClaims(List<? extends Claim> claims) {
        claims.forEach(claim -> consolidationFilter.process(claim, this.serviceConsolidationStore));
    }

    @AfterStep
    public void afterWriter(StepExecution stepExecution) {

        serviceConsolidationFacade.saveStore(this.serviceConsolidationStore.getConsolidationOffset());

        log.info("serviceConsolidationStore persisted ID - "
                + this.serviceConsolidationStore.getConsolidationOffset().getId());

        serviceConsolidationStore.clear();
    }
}
