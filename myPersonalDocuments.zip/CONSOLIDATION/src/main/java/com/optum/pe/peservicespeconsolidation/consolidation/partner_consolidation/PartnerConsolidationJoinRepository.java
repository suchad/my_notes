package com.optum.pe.peservicespeconsolidation.consolidation.partner_consolidation;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
interface PartnerConsolidationJoinRepository extends JpaRepository<PartnerConsolidationJoin, PartnerConsolidationJoinPK> {
}
