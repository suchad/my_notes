package com.optum.pe.peservicespeconsolidation.cycle_date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
interface CycleDateRepository extends JpaRepository<CycleDate, CycleDatePK> {

    @Query(value = "SELECT MAX(CYC_DT_NM) FROM PE01.CYCLE_DATE cd " +
            "WHERE PARTNER_PROC_GRP_ID = :partnerProcGrpId " +
            "AND CYC_DT_USED_IND = 'Y'", nativeQuery = true)
    String findCycleDate(String partnerProcGrpId);
}
