package com.optum.pe.peservicespeconsolidation.consolidation;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
interface ConsolidationRepository extends JpaRepository<Consolidation, Long> {

    @Transactional(transactionManager = "jpaTransactionManager")
    @Modifying
    @Query(value = "DELETE FROM PE01.CONSOLIDATION c " +
            "WHERE PARTNER_PROC_GRP_ID = :partnerProcGroupId " +
            "AND CONSOL_TYP_CD = :consolidationTypeCode " +
            "AND RLSE_DT = TO_DATE(:cycleDate, 'YYYYMMDD')", nativeQuery = true)
    int deleteConsolidationsByPartnerProcGroupIdAndCycleDate(String partnerProcGroupId, String cycleDate, String consolidationTypeCode);

    @Transactional(transactionManager = "jpaTransactionManager")
    @Modifying
    @Query(value = "DELETE FROM PE01.CONSOLIDATION_ACTIVITY ca " +
            "WHERE ca.ACTV_TYP_ID = :activityTypeId " +
            "AND ca.CONSOL_ID IN (SELECT CONSOL_ID FROM PE01.CONSOLIDATION c " +
            "WHERE PARTNER_PROC_GRP_ID = :partnerProcGroupId " +
            "AND CONSOL_TYP_CD = :consolidationTypeCode " +
            "AND RLSE_DT = TO_DATE(:cycleDate, 'YYYYMMDD'))", nativeQuery = true)
    int deleteConsolidationActivitiesByPartnerProcGroupIdAndCycleDate(String partnerProcGroupId, String cycleDate, int activityTypeId, String consolidationTypeCode);

    @Transactional(transactionManager = "jpaTransactionManager")
    @Modifying
    @Query(value = "DELETE FROM PE01.PARTNER_CONSOLIDATION_JOIN pcj " +
            "WHERE pcj.CONSOL_ID IN (SELECT CONSOL_ID FROM PE01.CONSOLIDATION c " +
            "WHERE PARTNER_PROC_GRP_ID = :partnerProcGroupId " +
            "AND CONSOL_TYP_CD = :consolidationTypeCode " +
            "AND RLSE_DT = TO_DATE(:cycleDate, 'YYYYMMDD'))", nativeQuery = true)
    int deletePartnerConsolidationJoinsByPartnerProcGroupIdAndCycleDate(String partnerProcGroupId, String cycleDate, String consolidationTypeCode);
}
