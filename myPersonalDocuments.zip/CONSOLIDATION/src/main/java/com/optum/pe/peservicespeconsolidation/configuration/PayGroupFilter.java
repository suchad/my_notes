package com.optum.pe.peservicespeconsolidation.configuration;

import com.optum.pe.peservicespeconsolidation.claim.Claim;
import com.optum.pe.peservicespeconsolidation.utils.Constants;
import org.springframework.stereotype.Service;

@Service
class PayGroupFilter {

    Claim process(Claim claim) {

        if (claim.isFullService() && claim.isMemberCheck()) {

            if ("Y".equals(claim.getGlobalSolutionIndicator())) {
                claim.setMemberPayConsolidationGroupCode(Constants.CONSOLIDATION_GROUP_CD_GLOBAL);
                claim.setMemberInterestPayConsolidationGroupCode(Constants.CONSOLIDATION_GROUP_CD_GLOBAL);

                return null;
            } else if ("Y".equals(claim.getPseudoIndicator())) {
                claim.setMemberPayConsolidationGroupCode(Constants.CONSOLIDATION_GROUP_CD_PSEUDO);
                claim.setMemberInterestPayConsolidationGroupCode(Constants.CONSOLIDATION_GROUP_CD_PSEUDO);

                return null;
            }

            return claim;
        }

        return null;
    }
}
