package com.optum.pe.peservicespeconsolidation.configuration;

import com.optum.pe.peservicespeconsolidation.utils.Constants;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.concurrent.ConcurrentMapCache;
import org.springframework.cache.support.SimpleCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Arrays;

@Configuration
class CacheConfiguration {

    @Bean
    public CacheManager consolidationCacheManager() {

        Cache cacheLookup = new ConcurrentMapCache(Constants.CACHE_NAME_LOOKUP);
        Cache cachePartnerConfig = new ConcurrentMapCache(Constants.CACHE_NAME_PARTNER_CONFIGS);

        SimpleCacheManager cacheManager = new SimpleCacheManager();
        cacheManager.setCaches(Arrays.asList(cacheLookup, cachePartnerConfig));

        return cacheManager;
    }
}