package com.optum.pe.peservicespeconsolidation.lookup;

import lombok.Data;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

@ToString
@Entity
@Table(name = "LOOKUP_DATA", schema = "PE01")
@Data
public class LookupData implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "LOOKUP_SET_CD")
    private String lookupSetCode;
    @Id
    @Column(name = "PARTNER_DATA_OWNER_GRP_ID")
    private String partnerDataOwnerGrpId;

    @Column(name = "DESC_TXT")
    private String descText;
    @Id
    @Column(name = "KEY_FLD01")
    private String keyField01;
    @Id
    @Column(name = "KEY_FLD02")
    private String keyField02;
    @Id
    @Column(name = "KEY_FLD03")
    private String keyField03;
    @Id
    @Column(name = "KEY_FLD04")
    private String keyField04;
    @Id
    @Column(name = "KEY_FLD05")
    private String keyField05;
    @Id
    @Column(name = "KEY_FLD06")
    private String keyField06;
    @Id
    @Column(name = "KEY_FLD07")
    private String keyField07;
    @Id
    @Column(name = "KEY_FLD08")
    private String keyField08;
    @Id
    @Column(name = "KEY_FLD09")
    private String keyField09;
    @Id
    @Column(name = "KEY_FLD10")
    private String keyField10;
    @Id
    @Column(name = "KEY_FLD11")
    private String keyField11;
    @Id
    @Column(name = "KEY_FLD12")
    private String keyField12;
    @Id
    @Column(name = "KEY_FLD13")
    private String keyField13;
    @Id
    @Column(name = "KEY_FLD14")
    private String keyField14;
    @Id
    @Column(name = "KEY_FLD15")
    private String keyField15;

    @Column(name = "RESULT_FLD01")
    private String resultField01;

    @Column(name = "RESULT_FLD02")
    private String resultField02;

    @Column(name = "RESULT_FLD03")
    private String resultField03;

    @Column(name = "RESULT_FLD04")
    private String resultField04;

    @Column(name = "RESULT_FLD05")
    private String resultField05;

    @Column(name = "RESULT_FLD06")
    private String resultField06;

    @Column(name = "RESULT_FLD07")
    private String resultField07;

    @Column(name = "RESULT_FLD08")
    private String resultField08;

    @Column(name = "RESULT_FLD09")
    private String resultField09;

    @Column(name = "RESULT_FLD10")
    private String resultField10;

    @Column(name = "RESULT_FLD11")
    private String resultField11;

    @Column(name = "RESULT_FLD12")
    private String resultField12;

    @Column(name = "RESULT_FLD13")
    private String resultField13;

    @Column(name = "RESULT_FLD14")
    private String resultField14;

    @Column(name = "RESULT_FLD15")
    private String resultField15;

    @Column(name = "EFF_DT")
    private LocalDate effectiveDate;

    @Column(name = "END_DT")
    private LocalDate endDate;

    @Column(name = "CREATION_DT")
    private LocalDateTime creationDate;

    @Column(name = "CREATED_BY_NM")
    private String createdBy;

    @Column(name = "LAST_UPDATE_DT")
    private LocalDateTime lastUpdatedDate;

    @Column(name = "LAST_UPDATE_BY_NM")
    private String lastUpdatedBy;
}
