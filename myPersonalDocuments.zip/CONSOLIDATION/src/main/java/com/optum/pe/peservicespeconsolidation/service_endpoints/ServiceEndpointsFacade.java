package com.optum.pe.peservicespeconsolidation.service_endpoints;

import com.optum.pe.peservicespeconsolidation.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class ServiceEndpointsFacade {

    private final ServiceEndpointsRepository repository;

    ServiceEndpointsFacade(ServiceEndpointsRepository repository) {
        this.repository = repository;
    }

    public void flagServiceEndpointsJobStart(String partnerProcGrpId) throws JobAlreadyRunningException {
        ServiceEndpoints serviceEndpoints = repository.findByPartnerProcGrpIdAndServiceNameAndEndpointName(
                partnerProcGrpId, Constants.APPLICATION_NAME, Constants.JOB_NAME_CONSOLIDATION);

        if (isJobRunning(serviceEndpoints)) {
            serviceEndpoints.setStatusFlag(Constants.JOB_START_FLAG);

            repository.save(serviceEndpoints);
        } else {
            throw new JobAlreadyRunningException("PartnerProcGroupId - " + partnerProcGrpId);
        }
    }

    private boolean isJobRunning(ServiceEndpoints serviceEndpoints) {
        return "Y".equals(serviceEndpoints.getStatusFlag());
    }

    public void flagServiceEndpointsJobEnd(String partnerProcGrpId) {
        repository.updateServiceEndpointsStatus(partnerProcGrpId,
                Constants.APPLICATION_NAME, Constants.JOB_NAME_CONSOLIDATION, Constants.JOB_END_FLAG);
    }
}
