package com.optum.pe.peservicespeconsolidation.consolidation.service_consolidation;

import com.optum.pe.peservicespeconsolidation.claim.Claim;
import com.optum.pe.peservicespeconsolidation.consolidation_offset.ConsolidationOffsetNotAvailableException;
import com.optum.pe.peservicespeconsolidation.consolidation.Mapper;
import com.optum.pe.peservicespeconsolidation.consolidation_offset.ConsolidationOffset;
import com.optum.pe.peservicespeconsolidation.consolidation_offset.ConsolidationOffsetFacade;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
public class ServiceConsolidationFacade implements Mapper<ServiceConsolidation> {

    private final ServiceConsolidationMapper serviceConsolidationMapper;
    private final ConsolidationOffsetFacade consolidationOffsetFacade;

    public ServiceConsolidationFacade(ServiceConsolidationMapper serviceConsolidationMapper,
                                      ConsolidationOffsetFacade consolidationOffsetFacade) {
        this.serviceConsolidationMapper = serviceConsolidationMapper;
        this.consolidationOffsetFacade = consolidationOffsetFacade;
    }

    @Override
    public ServiceConsolidation map(Claim claim) {
        return serviceConsolidationMapper.map(claim);
    }

    public ServiceConsolidation getSelectedServiceConsolidation(ServiceConsolidation serviceConsolidation,
                                                                ServiceConsolidationStore store) {
        return store.saveAndGet(serviceConsolidation);
    }

    public ServiceConsolidationStore initializeServiceConsolidationStore(String partnerProcGroupId,
                                                                         String partitionName, BigDecimal claimCount)
            throws ConsolidationOffsetNotAvailableException {

        ConsolidationOffset consolidationOffset = consolidationOffsetFacade.findOne(partnerProcGroupId, partitionName);

        return new ServiceConsolidationStore(consolidationOffset, claimCount);
    }

    public void saveStore(ConsolidationOffset consolidationOffset) {

        consolidationOffset.setClaimed("N");

        consolidationOffsetFacade.save(consolidationOffset);
    }
}
