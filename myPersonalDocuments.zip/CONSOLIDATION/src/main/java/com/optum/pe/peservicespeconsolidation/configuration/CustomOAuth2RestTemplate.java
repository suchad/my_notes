package com.optum.pe.peservicespeconsolidation.configuration;

import org.springframework.http.HttpMethod;
import org.springframework.http.client.ClientHttpRequest;
import org.springframework.security.oauth2.client.DefaultOAuth2RequestAuthenticator;
import org.springframework.security.oauth2.client.OAuth2ClientContext;
import org.springframework.security.oauth2.client.OAuth2RequestAuthenticator;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.security.oauth2.client.resource.OAuth2ProtectedResourceDetails;
import org.springframework.security.oauth2.client.resource.UserRedirectRequiredException;
import org.springframework.security.oauth2.common.AuthenticationScheme;
import org.springframework.security.oauth2.common.OAuth2AccessToken;

import java.io.IOException;
import java.net.URI;

public class CustomOAuth2RestTemplate extends OAuth2RestTemplate {

    private OAuth2RequestAuthenticator authenticator = new DefaultOAuth2RequestAuthenticator();

    public CustomOAuth2RestTemplate(OAuth2ProtectedResourceDetails resource) {
        super(resource);
    }

    CustomOAuth2RestTemplate(OAuth2ProtectedResourceDetails resource, OAuth2ClientContext context) {
        super(resource, context);
    }

    @Override
    protected ClientHttpRequest createRequest(URI uri, HttpMethod method) throws IOException {
        OAuth2AccessToken accessToken = validateAndReturnAccessToken();
        AuthenticationScheme authenticationScheme = getResource().getAuthenticationScheme();
        if (AuthenticationScheme.query.equals(authenticationScheme)
                || AuthenticationScheme.form.equals(authenticationScheme)) {
            uri = appendQueryParameter(uri, accessToken);
        }
        ClientHttpRequest req = super.createRequest(uri, method);
        if (AuthenticationScheme.header.equals(authenticationScheme)) {
            authenticator.authenticate(getResource(), getOAuth2ClientContext(), req);
        }
        return req;
    }

    @Override
    public OAuth2AccessToken getAccessToken() {

        OAuth2AccessToken accessToken = null;

        try {
            accessToken = acquireAccessToken(getOAuth2ClientContext());
        } catch (UserRedirectRequiredException e) {
            getOAuth2ClientContext().setAccessToken(null); // No point hanging onto it now
            String stateKey = e.getStateKey();
            if (stateKey != null) {
                Object stateToPreserve = e.getStateToPreserve();
                if (stateToPreserve == null) {
                    stateToPreserve = "NONE";
                }
                getOAuth2ClientContext().setPreservedState(stateKey, stateToPreserve);
            }
            throw e;
        }

        return accessToken;
    }

    private synchronized OAuth2AccessToken validateAndReturnAccessToken() {
        OAuth2AccessToken accessToken = getOAuth2ClientContext().getAccessToken();
        if (accessToken == null || accessToken.isExpired()) {
            return getAccessToken();
        }
        return accessToken;
    }
}