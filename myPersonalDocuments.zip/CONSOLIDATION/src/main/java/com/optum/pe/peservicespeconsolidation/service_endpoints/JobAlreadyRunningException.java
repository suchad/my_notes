package com.optum.pe.peservicespeconsolidation.service_endpoints;

public class JobAlreadyRunningException extends Exception {

    JobAlreadyRunningException(String message) {
        super(message);
    }
}
