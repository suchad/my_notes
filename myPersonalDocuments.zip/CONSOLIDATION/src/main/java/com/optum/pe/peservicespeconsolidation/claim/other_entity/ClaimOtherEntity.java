package com.optum.pe.peservicespeconsolidation.claim.other_entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import java.math.BigDecimal;

@Builder
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "CLM_OTHR_ENTITY_RLSE", schema = "PE01")
@IdClass(ClaimOtherEntityPK.class)
public class ClaimOtherEntity {

    @Id
    @Column(name = "CLM_ID")
    private BigDecimal claimId;

    @Id
    @Column(name = "SEQ_NBR")
    private BigDecimal sequenceNumber;

    @Column(name = "ENTITY_TYP_CD")
    private String entityTypeCode;

    @Column(name = "ENTITY_ID")
    private String entityId;

    @Column(name = "ENTITY_ID_TYP_CD")
    private String entityIdTypeCode;
}
