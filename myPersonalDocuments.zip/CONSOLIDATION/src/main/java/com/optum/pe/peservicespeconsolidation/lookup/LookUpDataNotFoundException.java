package com.optum.pe.peservicespeconsolidation.lookup;

public class LookUpDataNotFoundException extends Exception {

    LookUpDataNotFoundException(String message) {
        super(message);
    }
}
