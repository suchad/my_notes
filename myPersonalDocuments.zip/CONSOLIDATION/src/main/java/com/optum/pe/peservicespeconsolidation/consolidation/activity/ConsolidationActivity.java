package com.optum.pe.peservicespeconsolidation.consolidation.activity;

import com.optum.pe.peservicespeconsolidation.consolidation.Consolidation;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;
import org.springframework.data.domain.Persistable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "CONSOLIDATION_ACTIVITY", schema = "PE01")
public class ConsolidationActivity implements Persistable<Long> {

    @Id
    @Column(name = "CONSOL_ID")
    private long consolidationId;

    @Column(name = "ACTV_TYP_ID")
    private int activityTypeId;

    @Column(name = "PARTNER_PROC_GRP_ID")
    private String partnerProcGroupId;

    @Column(name = "ACTV_DT_TM")
    private LocalDateTime activityDateTime;

    @Column(name = "CLT_EVNT_SNT_DT_TM")
    private LocalDateTime claimLifeTrackEventSentDateTime;

    @Column(name = "CREATION_DT")
    private LocalDate creationDate;

    @Column(name = "LAST_UPDATE_DT")
    private LocalDate lastUpdateDate;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CONSOL_ID")
    private Consolidation consolidation;

    @Override
    public Long getId() {
        return this.consolidationId;
    }

    @Override
    public boolean isNew() {
        return Boolean.TRUE;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        ConsolidationActivity that = (ConsolidationActivity) o;
        return consolidationId == that.consolidationId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(consolidationId);
    }
}
