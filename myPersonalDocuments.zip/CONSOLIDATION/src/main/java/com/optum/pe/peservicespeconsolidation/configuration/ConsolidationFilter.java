package com.optum.pe.peservicespeconsolidation.configuration;

import com.optum.pe.peservicespeconsolidation.claim.Claim;
import com.optum.pe.peservicespeconsolidation.consolidation.service_consolidation.ServiceConsolidation;
import com.optum.pe.peservicespeconsolidation.consolidation.service_consolidation.ServiceConsolidationFacade;
import com.optum.pe.peservicespeconsolidation.consolidation.service_consolidation.ServiceConsolidationStore;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
class ConsolidationFilter {

    private final ServiceConsolidationFacade serviceConsolidationFacade;

    ConsolidationFilter(ServiceConsolidationFacade serviceConsolidationFacade) {
        this.serviceConsolidationFacade = serviceConsolidationFacade;
    }

    void process(Claim claim, ServiceConsolidationStore store) {

        ServiceConsolidation serviceConsolidation = serviceConsolidationFacade.map(claim);

        ServiceConsolidation selectedServiceConsolidation =
                serviceConsolidationFacade.getSelectedServiceConsolidation(serviceConsolidation, store);

        claim.setConsolidationId(
                selectedServiceConsolidation.getConsolidationId().longValueExact());

        if (selectedServiceConsolidation.getClaimId().equals(claim.getClaimId())) {
            claim.setConsolidationIdNewlyGenerated(Boolean.TRUE);
        }
    }
}
