package com.optum.pe.peservicespeconsolidation.configuration;

import com.optum.pe.peservicespeconsolidation.consolidation.ConsolidationFacade;
import com.optum.pe.peservicespeconsolidation.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.stereotype.Service;

@Slf4j
@Service
class CleanupConsolidationActivityTasklet implements Tasklet {

    private final ConsolidationFacade facade;

    CleanupConsolidationActivityTasklet(ConsolidationFacade facade) {
        this.facade = facade;
    }

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        int deletionCount = facade.deleteConsolidationActivitiesByPartnerProcGroupIdAndCycleDate(
                contribution.getStepExecution().getJobParameters()
                        .getString(Constants.JOB_PARAM_PARTNER_PROC_GROUP_ID),
                contribution.getStepExecution().getJobParameters()
                        .getString(Constants.JOB_PARAM_CYCLE_DATE));

        log.info("TABLE PE01.CONSOLIDATION_ACTIVITY DELETION COUNT - " + deletionCount);

        return RepeatStatus.FINISHED;
    }
}
