package com.optum.pe.peservicespeconsolidation.consolidation_offset;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class ConsolidationOffsetFacadeTest {

    @InjectMocks
    private ConsolidationOffsetFacade facade;

    @Mock
    private ConsolidationOffsetRepository repository;

    @Test
    public void findOne() throws ConsolidationOffsetNotAvailableException {

        Mockito.when(repository.updateOffset("1", "1"))
                .thenReturn(1);

        Mockito.when(repository.findByPartnerProcGroupIdAndClaimedAndUpdatedBy("1", "Y", "1"))
                .thenReturn(new ConsolidationOffset());

        assertNotNull(facade.findOne("1", "1"));
    }

    @Test(expected = ConsolidationOffsetNotAvailableException.class)
    public void findOneException() throws ConsolidationOffsetNotAvailableException {

        Mockito.when(repository.updateOffset("", ""))
                .thenReturn(0);

        facade.findOne("", "");
    }

    @Test
    public void save() {

        ConsolidationOffset consolidationOffset = new ConsolidationOffset();

        Mockito.when(repository.save(consolidationOffset))
                .thenReturn(consolidationOffset);

        facade.save(consolidationOffset);

        assertTrue(Boolean.TRUE);
    }
}