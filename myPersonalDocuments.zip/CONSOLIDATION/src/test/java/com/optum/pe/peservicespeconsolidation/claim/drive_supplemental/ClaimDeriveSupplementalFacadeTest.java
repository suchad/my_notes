package com.optum.pe.peservicespeconsolidation.claim.drive_supplemental;

import com.optum.pe.peservicespeconsolidation.claim.Claim;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Collections;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class ClaimDeriveSupplementalFacadeTest {

    @InjectMocks
    private ClaimDeriveSupplementalFacade facade;

    @Mock
    private ClaimDeriveSupplementalRepository repository;

    @Test
    public void map() {

        assertNotNull(facade.map(getClaim()));
    }

    @Test
    public void saveAll() {

        facade.saveAll(Collections.emptyList());

        assertTrue(Boolean.TRUE);
    }

    private Claim getClaim() {

        return Claim.builder()
                .payeeTypeCode("")
                .memberFinalReleaseDate(LocalDateTime.now())
                .memberPayMethodCode("")
                .coverageTypeCode("")
                .claimId(BigDecimal.ONE)
                .partnerProcGroupId("")
                .divertMemberPaymentIndicator("Y")
                .memberPayConsolidationGroupCode("")
                .memberInterestPayConsolidationGroupCode("")
                .payeeConsolidationKeyId("")
                .build();
    }
}