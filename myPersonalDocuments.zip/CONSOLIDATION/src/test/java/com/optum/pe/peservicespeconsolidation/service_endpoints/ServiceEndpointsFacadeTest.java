package com.optum.pe.peservicespeconsolidation.service_endpoints;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;

@RunWith(MockitoJUnitRunner.class)
public class ServiceEndpointsFacadeTest {

    @InjectMocks
    private ServiceEndpointsFacade facade;

    @Mock
    private ServiceEndpointsRepository repository;

    @Test
    public void flagServiceEndpointsJobStart() throws JobAlreadyRunningException {

        ServiceEndpoints serviceEndpoints = new ServiceEndpoints();
        serviceEndpoints.setStatusFlag("Y");

        Mockito.when(repository
                .findByPartnerProcGrpIdAndServiceNameAndEndpointName(anyString(), anyString(), anyString()))
                .thenReturn(serviceEndpoints);

        Mockito.when(repository.save(any())).thenReturn(serviceEndpoints);

        facade.flagServiceEndpointsJobStart("");

        assertTrue(Boolean.TRUE);
    }

    @Test(expected = JobAlreadyRunningException.class)
    public void flagServiceEndpointsJobStartWithException() throws JobAlreadyRunningException {

        ServiceEndpoints serviceEndpoints = new ServiceEndpoints();
        serviceEndpoints.setStatusFlag("N");

        Mockito.when(repository
                .findByPartnerProcGrpIdAndServiceNameAndEndpointName(anyString(), anyString(), anyString()))
                .thenReturn(serviceEndpoints);

        facade.flagServiceEndpointsJobStart("");
    }

    @Test
    public void flagServiceEndpointsJobEnd() {

        Mockito.doNothing()
                .when(repository)
                .updateServiceEndpointsStatus(anyString(), anyString(), anyString(), anyString());

        facade.flagServiceEndpointsJobEnd("");

        assertTrue(Boolean.TRUE);
    }
}