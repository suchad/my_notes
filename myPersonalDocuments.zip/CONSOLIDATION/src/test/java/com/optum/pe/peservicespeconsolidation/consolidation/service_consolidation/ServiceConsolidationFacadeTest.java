package com.optum.pe.peservicespeconsolidation.consolidation.service_consolidation;

import com.optum.pe.peservicespeconsolidation.claim.Claim;
import com.optum.pe.peservicespeconsolidation.consolidation_offset.ConsolidationOffset;
import com.optum.pe.peservicespeconsolidation.consolidation_offset.ConsolidationOffsetFacade;
import com.optum.pe.peservicespeconsolidation.consolidation_offset.ConsolidationOffsetNotAvailableException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.Silent.class)
public class ServiceConsolidationFacadeTest {

    @InjectMocks
    private ServiceConsolidationFacade facade;

    @Mock
    private ServiceConsolidationMapper serviceConsolidationMapper;

    @Mock
    private ConsolidationOffsetFacade consolidationOffsetFacade;

    @Test
    public void map() {

        Claim claim = getClaimAnother();

        Mockito.when(serviceConsolidationMapper.map(claim))
                .thenReturn(new ServiceConsolidation());

        assertNotNull(facade.map(claim));
    }

    private Claim getClaimAnother() {

        return Claim.builder()
                .payeeTypeCode("S")
                .memberFinalReleaseDate(LocalDateTime.now())
                .build();
    }

    @Test
    public void getSelectedServiceConsolidation() {

        ServiceConsolidation serviceConsolidation = new ServiceConsolidation();
        ServiceConsolidationStore store = new ServiceConsolidationStore(
                new ConsolidationOffset(1L, "", BigDecimal.ZERO, "", ""), BigDecimal.ONE);

        assertEquals(serviceConsolidation,
                facade.getSelectedServiceConsolidation(serviceConsolidation, store));
    }

    @Test
    public void getSelectedServiceConsolidationContains() {

        ServiceConsolidation serviceConsolidation = new ServiceConsolidation();
        serviceConsolidation.setPlanEffectiveDate(LocalDateTime.now());
        serviceConsolidation.setClaimId(BigDecimal.ONE);

        ServiceConsolidationStore store = new ServiceConsolidationStore(
                new ConsolidationOffset(1L, "", BigDecimal.ZERO, "", ""), BigDecimal.ONE);

        store.saveAndGet(serviceConsolidation);

        ServiceConsolidation serviceConsolidation1 = new ServiceConsolidation();
        serviceConsolidation1.setPlanEffectiveDate(LocalDateTime.MAX);
        serviceConsolidation1.setClaimId(BigDecimal.TEN);

        assertEquals(serviceConsolidation1,
                facade.getSelectedServiceConsolidation(serviceConsolidation1, store));

        store.clear();
    }

    @Test
    public void initializeServiceConsolidationStore() throws ConsolidationOffsetNotAvailableException {

        Mockito.when(consolidationOffsetFacade.findOne("", ""))
                .thenReturn(new ConsolidationOffset());

        assertNotNull(facade.initializeServiceConsolidationStore("", "", BigDecimal.ONE));
    }

    @Test
    public void saveStore() {

        consolidationOffsetFacade.save(new ConsolidationOffset());

        assertTrue(Boolean.TRUE);
    }
}