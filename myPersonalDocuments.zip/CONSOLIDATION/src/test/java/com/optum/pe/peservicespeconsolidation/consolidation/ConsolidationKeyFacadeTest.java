package com.optum.pe.peservicespeconsolidation.consolidation;

import com.optum.pe.peservicespeconsolidation.claim.Claim;
import com.optum.pe.peservicespeconsolidation.configuration.ConsolidationQuery;
import com.optum.pe.peservicespeconsolidation.configuration.QueryFacade;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import javax.persistence.EntityManager;
import javax.persistence.FlushModeType;
import javax.persistence.LockModeType;
import javax.persistence.Parameter;
import javax.persistence.Query;
import javax.persistence.TemporalType;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
public class ConsolidationKeyFacadeTest {

    @InjectMocks
    private ConsolidationKeyFacade consolidationKeyFacade;

    @Mock
    private EntityManager entityManager;

    @Mock
    private QueryFacade queryFacade;

    @Test
    public void getQuery() throws QueryNotFoundException {

        Mockito.when(queryFacade.getQuery(""))
                .thenReturn(Optional.of(new ConsolidationQuery()));

        assertNotNull(consolidationKeyFacade.getQuery(""));
    }

    @Test(expected = QueryNotFoundException.class)
    public void getQueryException() throws QueryNotFoundException {

        Mockito.when(queryFacade.getQuery(""))
                .thenReturn(Optional.ofNullable(null));

        consolidationKeyFacade.getQuery("");
    }

    @Test
    public void getConsolidationKey() throws DerivedColumnNotMappedException {

        assertEquals("", consolidationKeyFacade.getConsolidationKey(getAnotherClaim(), ""));
    }

    private Claim getAnotherClaim() {

        return Claim.builder()
                .payeeTypeCode("P")
                .memberFinalReleaseDate(LocalDateTime.now())
                .memberPayConsolidationGroupCode("")
                .payeeConsolidationKeyId("")
                .derivedColumns(Collections.singletonList("MBR_PAY_CONSOL_GRP_CD"))
                .build();
    }

    @Test(expected = DerivedColumnNotMappedException.class)
    public void getConsolidationKeyException() throws DerivedColumnNotMappedException {

        consolidationKeyFacade.getConsolidationKey(getClaim(), "");
    }

    private Claim getClaim() {

        return Claim.builder()
                .payeeTypeCode("P")
                .memberFinalReleaseDate(LocalDateTime.now())
                .memberPayConsolidationGroupCode("")
                .payeeConsolidationKeyId("")
                .derivedColumns(Collections.singletonList(""))
                .build();
    }

    @Test
    public void getConsolidationKeys() {

        Mockito.when(entityManager.createNativeQuery(""))
                .thenReturn(getTestQuery());

        ConsolidationQuery consolidationQuery = new ConsolidationQuery();
        consolidationQuery.setQuery("");

        assertNotNull(
                consolidationKeyFacade.getConsolidationKeys(consolidationQuery, Collections.singletonList(BigDecimal.ONE)));
    }

    private Query getTestQuery() {
        return new Query() {
            @Override
            public List getResultList() {
                return Collections.emptyList();
            }

            @Override
            public Object getSingleResult() {
                return new Object[]{};
            }

            @Override
            public int executeUpdate() {
                return 0;
            }

            @Override
            public Query setMaxResults(int maxResult) {
                return null;
            }

            @Override
            public int getMaxResults() {
                return 0;
            }

            @Override
            public Query setFirstResult(int startPosition) {
                return null;
            }

            @Override
            public int getFirstResult() {
                return 0;
            }

            @Override
            public Query setHint(String hintName, Object value) {
                return null;
            }

            @Override
            public Map<String, Object> getHints() {
                return null;
            }

            @Override
            public <T> Query setParameter(Parameter<T> param, T value) {
                return this;
            }

            @Override
            public Query setParameter(Parameter<Calendar> param, Calendar value, TemporalType temporalType) {
                return null;
            }

            @Override
            public Query setParameter(Parameter<Date> param, Date value, TemporalType temporalType) {
                return null;
            }

            @Override
            public Query setParameter(String name, Object value) {
                return this;
            }

            @Override
            public Query setParameter(String name, Calendar value, TemporalType temporalType) {
                return null;
            }

            @Override
            public Query setParameter(String name, Date value, TemporalType temporalType) {
                return null;
            }

            @Override
            public Query setParameter(int position, Object value) {
                return null;
            }

            @Override
            public Query setParameter(int position, Calendar value, TemporalType temporalType) {
                return null;
            }

            @Override
            public Query setParameter(int position, Date value, TemporalType temporalType) {
                return null;
            }

            @Override
            public Set<Parameter<?>> getParameters() {
                return null;
            }

            @Override
            public Parameter<?> getParameter(String name) {
                return null;
            }

            @Override
            public <T> Parameter<T> getParameter(String name, Class<T> type) {
                return null;
            }

            @Override
            public Parameter<?> getParameter(int position) {
                return null;
            }

            @Override
            public <T> Parameter<T> getParameter(int position, Class<T> type) {
                return null;
            }

            @Override
            public boolean isBound(Parameter<?> param) {
                return false;
            }

            @Override
            public <T> T getParameterValue(Parameter<T> param) {
                return null;
            }

            @Override
            public Object getParameterValue(String name) {
                return null;
            }

            @Override
            public Object getParameterValue(int position) {
                return null;
            }

            @Override
            public Query setFlushMode(FlushModeType flushMode) {
                return null;
            }

            @Override
            public FlushModeType getFlushMode() {
                return null;
            }

            @Override
            public Query setLockMode(LockModeType lockMode) {
                return null;
            }

            @Override
            public LockModeType getLockMode() {
                return null;
            }

            @Override
            public <T> T unwrap(Class<T> cls) {
                return null;
            }
        };
    }
}