package com.optum.pe.peservicespeconsolidation.consolidation.service_consolidation;

import com.optum.pe.peservicespeconsolidation.claim.Claim;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import java.time.LocalDateTime;

import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
public class ServiceConsolidationMapperTest {

    @InjectMocks
    private ServiceConsolidationMapper mapper;

    @Test
    public void map() {

        assertNotNull(mapper.map(getClaim()));
    }

    private Claim getClaim() {

        return Claim.builder()
                .payeeTypeCode("S")
                .memberFinalReleaseDate(LocalDateTime.now())
                .build();
    }
}