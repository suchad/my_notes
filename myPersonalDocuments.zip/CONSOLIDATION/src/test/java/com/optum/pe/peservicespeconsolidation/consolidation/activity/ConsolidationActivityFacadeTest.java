package com.optum.pe.peservicespeconsolidation.consolidation.activity;

import com.optum.pe.peservicespeconsolidation.claim.Claim;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import java.time.LocalDateTime;

import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
public class ConsolidationActivityFacadeTest {

    @InjectMocks
    private ConsolidationActivityFacade consolidationActivityFacade;

    @Test
    public void map() {

        assertNotNull(consolidationActivityFacade.map(getClaim()));
    }

    private Claim getClaim() {

        return Claim.builder()
                .payeeTypeCode("P")
                .memberFinalReleaseDate(LocalDateTime.now())
                .build();
    }
}