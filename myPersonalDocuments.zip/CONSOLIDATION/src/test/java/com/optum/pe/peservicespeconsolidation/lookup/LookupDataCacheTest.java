package com.optum.pe.peservicespeconsolidation.lookup;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.class)
public class LookupDataCacheTest {

    @InjectMocks
    private LookupDataCache lookupDataCache;

    @Mock
    private LookupDataDao repository;

    @Test
    public void findAll() {

        List<LookupData> lookupData = Collections.emptyList();

        Mockito.when(repository.findAll(LocalDate.now())).thenReturn(lookupData);

        assertEquals(lookupData, lookupDataCache.findAll(LocalDate.now()));
    }
}