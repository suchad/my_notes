package com.optum.pe.peservicespeconsolidation.partner;

import com.optum.pe.peservicespeconsolidation.utils.Constants;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;

import java.util.concurrent.Callable;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class PartnerConfigControllerTest {

    @InjectMocks
    private PartnerConfigController configController;

    @Mock
    private CacheManager cacheManager;

    @Test
    public void cacheClear() {

        Mockito.when(cacheManager.getCache(Constants.CACHE_NAME_PARTNER_CONFIGS))
                .thenReturn(getCache());

        assertTrue(configController.cacheClear());
    }

    @Test
    public void cacheClearFailure() {

        Mockito.when(cacheManager.getCache(Constants.CACHE_NAME_PARTNER_CONFIGS))
                .thenReturn(null);

        assertFalse(configController.cacheClear());
    }

    private Cache getCache() {
        return new Cache() {
            @Override
            public String getName() {
                return Constants.CACHE_NAME_PARTNER_CONFIGS;
            }

            @Override
            public Object getNativeCache() {
                return null;
            }

            @Override
            public ValueWrapper get(Object o) {
                return null;
            }

            @Override
            public <T> T get(Object o, Class<T> aClass) {
                return null;
            }

            @Override
            public <T> T get(Object o, Callable<T> callable) {
                return null;
            }

            @Override
            public void put(Object o, Object o1) {

            }

            @Override
            public void evict(Object o) {

            }

            @Override
            public void clear() {

            }
        };
    }
}