package com.optum.pe.peservicespeconsolidation.lookup;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
public class LookupDataFacadeTest {

    @InjectMocks
    private LookupDataFacade facade;

    @Mock
    private LookupDataCache lookupDataCache;

    @Test(expected = LookUpDataNotFoundException.class)
    public void findOneException() throws LookUpDataNotFoundException {

        Mockito.when(lookupDataCache.findAll(LocalDate.now()))
                .thenReturn(Collections.emptyList());

        facade.findOne(LocalDate.now(), "", "", "", "", "");
    }

    @Test
    public void findOne() throws LookUpDataNotFoundException {

        Mockito.when(lookupDataCache.findAll(LocalDate.now()))
                .thenReturn(getLookupData());

        assertNotNull(facade.findOne(LocalDate.now(), "", "", "", "", ""));
    }

    private List<LookupData> getLookupData() {

        LookupData lookupData = new LookupData();
        lookupData.setKeyField01("");
        lookupData.setKeyField02("");
        lookupData.setKeyField03("");
        lookupData.setKeyField04("");

        return Collections.singletonList(lookupData);
    }
}