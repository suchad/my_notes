package com.optum.pe.peservicespeconsolidation.controller;

import com.optum.pe.peservicespeconsolidation.cycle_date.CycleDateException;
import com.optum.pe.peservicespeconsolidation.cycle_date.CycleDateFacade;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.class)
public class ConsolidationControllerTest {

    @InjectMocks
    private ConsolidationController controller;

    @Mock
    private JobLauncher jobLauncher;

    @Mock
    private Job job;

    @Mock
    private CycleDateFacade cycleDateFacade;

    @Test
    public void consolidation() throws JobParametersInvalidException, JobExecutionAlreadyRunningException, JobRestartException, JobInstanceAlreadyCompleteException, CycleDateException {

        ZoneId defaultZoneId = ZoneId.systemDefault();
        Date date = Date.from(LocalDate.now().atStartOfDay(defaultZoneId).toInstant());

        JobExecution jobExecution = new JobExecution(1L);
        jobExecution.setEndTime(date);

        Mockito.when(cycleDateFacade.findCycleDate(""))
                .thenReturn("00010101");

        Mockito.when(jobLauncher.run(Mockito.anyObject(), Mockito.anyObject()))
                .thenReturn(jobExecution);

        assertEquals(ExitStatus.UNKNOWN, controller.consolidation(""));

    }
}