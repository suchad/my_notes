package com.optum.pe.peservicespeconsolidation.claim;

import com.optum.pe.peservicespeconsolidation.claim.other_entity.ClaimOtherEntity;
import com.optum.pe.peservicespeconsolidation.claim.other_entity.ClaimOtherEntityFacade;
import com.optum.pe.peservicespeconsolidation.claim.other_entity.ClaimOtherEntityNotFoundException;
import com.optum.pe.peservicespeconsolidation.configuration.ConsolidationQuery;
import com.optum.pe.peservicespeconsolidation.configuration.ConsolidationQueryStore;
import com.optum.pe.peservicespeconsolidation.consolidation.ConsolidationKeyFacade;
import com.optum.pe.peservicespeconsolidation.consolidation.DerivedColumnNotMappedException;
import com.optum.pe.peservicespeconsolidation.consolidation.QueryNotFoundException;
import com.optum.pe.peservicespeconsolidation.lookup.LookUpDataNotFoundException;
import com.optum.pe.peservicespeconsolidation.lookup.LookupData;
import com.optum.pe.peservicespeconsolidation.lookup.LookupDataFacade;
import com.optum.pe.peservicespeconsolidation.partner.PartnerConfig;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;

@RunWith(MockitoJUnitRunner.Silent.class)
public class ClaimFacadeTest {

    @InjectMocks
    private ClaimFacade claimFacade;

    @Mock
    private LookupDataFacade lookupDataFacade;

    @Mock
    private ConsolidationKeyFacade consolidationKeyFacade;

    @Mock
    private ClaimOtherEntityFacade claimOtherEntityFacade;

    @Test
    public void derivePayeeAssignmentKey() throws QueryNotFoundException, LookUpDataNotFoundException {

        LookupData lookupData = new LookupData();
        lookupData.setResultField15("");

        Mockito.when(lookupDataFacade.findOne(LocalDate.now(), "",
                "", "", "", ""))
                .thenReturn(lookupData);

        ConsolidationQuery consolidationQuery = new ConsolidationQuery("", "", "", Collections.emptyList());

        Mockito.when(consolidationKeyFacade.getQuery("")).thenReturn(consolidationQuery);

        ConsolidationQueryStore store = new ConsolidationQueryStore();

        claimFacade.derivePayeeAssignmentKey(getClaim(), store);

        assertTrue(Boolean.TRUE);
    }

    @Test
    public void getKeysFromDB() {

        assertNotNull(claimFacade.getKeysFromDB(Collections.emptyMap()));
    }

    @Test
    public void getConsolidationKey() throws DerivedColumnNotMappedException {

        Mockito.when(consolidationKeyFacade.getConsolidationKey(any(), any())).thenReturn("");

        assertEquals("", claimFacade.getConsolidationKey(getClaim(), ""));
    }

    @Test
    public void appendKeyForDivertMember() {

        ClaimOtherEntity claimOtherEntity = ClaimOtherEntity.builder()
                .entityTypeCode("")
                .entityId("")
                .entityIdTypeCode("")
                .build();

        Map<BigDecimal, ClaimOtherEntity> claimOtherEntities = new HashMap<>();
        claimOtherEntities.put(BigDecimal.ONE, claimOtherEntity);

        assertEquals("", claimFacade.appendKeyForDivertMember(BigDecimal.ONE, claimOtherEntities, ""));
    }

    @Test
    public void getDivertMemberEntities() throws ClaimOtherEntityNotFoundException {

        List<BigDecimal> claimIdsOfDivertMembers = Collections.singletonList(BigDecimal.ONE);

        Mockito.when(claimOtherEntityFacade.getOtherEntities(claimIdsOfDivertMembers))
                .thenReturn(Collections.emptyMap());

        claimFacade.getDivertMemberEntities(claimIdsOfDivertMembers);

        assertTrue(Boolean.TRUE);
    }

    @Test
    public void getDivertMemberEntitiesEmpty() throws ClaimOtherEntityNotFoundException {

        claimFacade.getDivertMemberEntities(null);

        assertTrue(Boolean.TRUE);
    }

    private Claim getClaim() {

        return Claim.builder()
                .payeeTypeCode("")
                .memberFinalReleaseDate(LocalDateTime.now())
                .memberPayMethodCode("")
                .coverageTypeCode("")
                .partnerConfig(getPartnerConfig())
                .claimId(BigDecimal.ONE)
                .partnerProcGroupId("")
                .divertMemberPaymentIndicator("Y")
                .partnerId("")
                .build();
    }

    private PartnerConfig getPartnerConfig() {
        PartnerConfig partnerConfig = new PartnerConfig();
        partnerConfig.setConsolidationPayeeAssignmentKeyId("");

        return partnerConfig;
    }
}