package com.optum.pe.peservicespeconsolidation.cycle_date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.class)
public class CycleDateFacadeTest {

    @InjectMocks
    private CycleDateFacade facade;

    @Mock
    private CycleDateRepository repository;

    @Test
    public void findCycleDate() throws CycleDateException {

        Mockito.when(repository.findCycleDate(""))
                .thenReturn("");

        assertEquals("", facade.findCycleDate(""));
    }

    @Test(expected = CycleDateException.class)
    public void findCycleDateException() throws CycleDateException {

        Mockito.when(repository.findCycleDate(""))
                .thenReturn(null);

        facade.findCycleDate("");
    }
}