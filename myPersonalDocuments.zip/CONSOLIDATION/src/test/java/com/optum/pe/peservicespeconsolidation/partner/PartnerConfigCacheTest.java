package com.optum.pe.peservicespeconsolidation.partner;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.class)
public class PartnerConfigCacheTest {

    @InjectMocks
    private PartnerConfigCache partnerConfigCache;

    @Mock
    private AppPartnerConfigRepository repository;

    @Test
    public void findAll() {

        List<PartnerConfig> partnerConfigs = Collections.emptyList();

        Mockito.when(repository.findAll()).thenReturn(partnerConfigs);

        assertEquals(partnerConfigs, partnerConfigCache.findAll());
    }
}