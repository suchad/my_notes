package com.optum.pe.peservicespeconsolidation.partner;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
public class PartnerConfigFacadeTest {

    @InjectMocks
    private PartnerConfigFacade partnerConfigFacade;

    @Mock
    private PartnerConfigCache partnerConfigCache;

    @Test(expected = PartnerConfigNotFoundException.class)
    public void findOneException() throws PartnerConfigNotFoundException {

        Mockito.when(partnerConfigCache.findAll())
                .thenReturn(Collections.emptyList());

        partnerConfigFacade.findOne("");
    }

    @Test
    public void findOne() throws PartnerConfigNotFoundException {

        Mockito.when(partnerConfigCache.findAll())
                .thenReturn(getPartnerConfigList());

        assertNotNull(partnerConfigFacade.findOne(""));
    }

    private List<PartnerConfig> getPartnerConfigList() {

        PartnerConfig partnerConfig = new PartnerConfig();
        partnerConfig.setPartnerId("");

        return Collections.singletonList(partnerConfig);
    }
}