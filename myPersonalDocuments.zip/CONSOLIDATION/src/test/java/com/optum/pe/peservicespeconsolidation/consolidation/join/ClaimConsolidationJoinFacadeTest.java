package com.optum.pe.peservicespeconsolidation.consolidation.join;

import com.optum.pe.peservicespeconsolidation.claim.Claim;
import com.optum.pe.peservicespeconsolidation.claim.activity.ClaimActivity;
import com.optum.pe.peservicespeconsolidation.claim.activity.ClaimActivityFacade;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Collections;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;

@RunWith(MockitoJUnitRunner.class)
public class ClaimConsolidationJoinFacadeTest {

    @InjectMocks
    private ClaimConsolidationJoinFacade facade;

    @Mock
    private ClaimConsolidationJoinRepository repository;

    @Mock
    private ClaimActivityFacade activityFacade;

    @Test
    public void map() {

        Mockito.when(activityFacade.map(any()))
                .thenReturn(ClaimActivity.builder().build());

        assertNotNull(facade.map(getClaimAnother()));
    }

    private Claim getClaimAnother() {

        return Claim.builder()
                .payeeTypeCode("S")
                .memberFinalReleaseDate(LocalDateTime.now())
                .claimId(BigDecimal.ONE)
                .build();
    }

    @Test
    public void saveAll() {

        Mockito.when(repository.saveAll(Collections.emptyList()))
                .thenReturn(Collections.emptyList());

        facade.saveAll(Collections.emptyList());

        assertTrue(Boolean.TRUE);
    }
}