package com.optum.pe.peservicespeconsolidation.claim.other_entity;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class ClaimOtherEntityFacadeTest {

    @InjectMocks
    private ClaimOtherEntityFacade facade;

    @Mock
    private ClaimOtherEntityRepository repository;

    @Test
    public void getOtherEntities() throws ClaimOtherEntityNotFoundException {

        List<BigDecimal> claimIdsOfDivertMembers = Collections.singletonList(BigDecimal.ONE);

        Object[] row = {BigDecimal.ONE, BigDecimal.ONE, "", "", ""};

        Mockito.when(repository.findAll(claimIdsOfDivertMembers))
                .thenReturn(Collections.singletonList(row));

        facade.getOtherEntities(claimIdsOfDivertMembers);

        assertTrue(Boolean.TRUE);
    }

    @Test(expected = ClaimOtherEntityNotFoundException.class)
    public void getOtherEntitiesException() throws ClaimOtherEntityNotFoundException {

        List<BigDecimal> claimIdsOfDivertMembers = Collections.singletonList(BigDecimal.ONE);

        Mockito.when(repository.findAll(claimIdsOfDivertMembers))
                .thenReturn(null);

        facade.getOtherEntities(claimIdsOfDivertMembers);
    }
}