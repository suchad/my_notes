package com.optum.pe.peservicespeconsolidation.consolidation.partner_consolidation;

import com.optum.pe.peservicespeconsolidation.claim.Claim;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.time.LocalDateTime;
import java.util.Collections;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class PartnerConsolidationJoinFacadeTest {

    @InjectMocks
    private PartnerConsolidationJoinFacade facade;

    @Mock
    private PartnerConsolidationJoinRepository repository;

    @Test
    public void map() {

        assertNotNull(facade.map(getClaimAnother()));
    }

    private Claim getClaimAnother() {

        return Claim.builder()
                .payeeTypeCode("S")
                .memberFinalReleaseDate(LocalDateTime.now())
                .build();
    }

    @Test
    public void saveAll() {

        Mockito.when(repository.saveAll(Collections.emptyList()))
                .thenReturn(Collections.emptyList());

        facade.saveAll(Collections.emptyList());

        assertTrue(Boolean.TRUE);
    }
}