package com.optum.pe.peservicespeconsolidation.claim.activity;

import com.optum.pe.peservicespeconsolidation.claim.Claim;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
public class ClaimActivityFacadeTest {

    @InjectMocks
    private ClaimActivityFacade claimActivityFacade;

    @Test
    public void map() {

        assertNotNull(claimActivityFacade.map(getClaim()));
    }

    private Claim getClaim() {

        return Claim.builder()
                .payeeTypeCode("")
                .memberFinalReleaseDate(LocalDateTime.now())
                .memberPayMethodCode("")
                .coverageTypeCode("")
                .claimId(BigDecimal.ONE)
                .partnerProcGroupId("")
                .divertMemberPaymentIndicator("Y")
                .build();
    }
}