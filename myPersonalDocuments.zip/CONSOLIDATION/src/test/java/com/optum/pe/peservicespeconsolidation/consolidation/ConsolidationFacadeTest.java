package com.optum.pe.peservicespeconsolidation.consolidation;

import com.optum.pe.peservicespeconsolidation.claim.Claim;
import com.optum.pe.peservicespeconsolidation.consolidation.activity.ConsolidationActivityFacade;
import com.optum.pe.peservicespeconsolidation.consolidation.partner_consolidation.PartnerConsolidationJoinFacade;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.time.LocalDateTime;
import java.util.Collections;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class ConsolidationFacadeTest {

    @InjectMocks
    private ConsolidationFacade consolidationFacade;

    @Mock
    private ConsolidationRepository consolidationRepository;

    @Mock
    private ConsolidationActivityFacade activityFacade;

    @Mock
    private PartnerConsolidationJoinFacade partnerConsolidationJoinFacade;

    @Test
    public void map() {

        assertNotNull(consolidationFacade.map(getClaim()));
    }

    private Claim getClaim() {

        return Claim.builder()
                .payeeTypeCode("P")
                .memberFinalReleaseDate(LocalDateTime.now())
                .build();
    }

    @Test
    public void mapAnother() {

        assertNotNull(consolidationFacade.map(getClaimAnother()));
    }

    private Claim getClaimAnother() {

        return Claim.builder()
                .payeeTypeCode("S")
                .memberFinalReleaseDate(LocalDateTime.now())
                .build();
    }

    @Test
    public void saveAll() {

        Mockito.when(consolidationRepository.saveAll(Collections.emptyList()))
                .thenReturn(Collections.emptyList());

        consolidationFacade.saveAll(Collections.emptyList());

        assertTrue(true);
    }
}