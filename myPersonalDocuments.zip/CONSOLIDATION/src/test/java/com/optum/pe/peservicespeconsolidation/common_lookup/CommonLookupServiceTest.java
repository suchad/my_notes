package com.optum.pe.peservicespeconsolidation.common_lookup;

import com.optum.paymentengine.common.lookup.beans.CommonLookupResponse;
import com.optum.paymentengine.common.lookup.service.impl.CommonLookupServiceImpl;
import com.optum.pe.claim.ClaimConsolidatedPERecord;
import com.optum.pe.claim.ClaimHold;
import com.optum.pe.claim.ClaimPolPlanHold;
import com.optum.pe.peservicespeconsolidation.claim.Claim;
import com.optum.pe.peservicespeconsolidation.partner.PartnerConfig;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Collections;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;

@RunWith(MockitoJUnitRunner.class)
public class CommonLookupServiceTest {

    @InjectMocks
    private CommonLookupService commonLookupService;

    @Mock
    private CommonLookupServiceImpl commonLookupServiceImpl;

    @Test
    public void getCommonLookUp() {

        Mockito.when(commonLookupServiceImpl.getFeatureResults(any(), any(), any(), any(), any()))
                .thenReturn(new CommonLookupResponse());

        assertNotNull(commonLookupService.getCommonLookUp(Collections.singletonList(getClaimConsolidatedPERecord(getClaim())), getClaim()));
    }

    private Claim getClaim() {

        return Claim.builder()
                .payeeTypeCode("")
                .memberFinalReleaseDate(LocalDateTime.now())
                .memberPayMethodCode("")
                .coverageTypeCode("")
                .claimId(BigDecimal.ONE)
                .partnerProcGroupId("")
                .divertMemberPaymentIndicator("Y")
                .partnerConfig(getPartnerConfig())
                .build();
    }

    private PartnerConfig getPartnerConfig() {

        PartnerConfig partnerConfig = new PartnerConfig();
        partnerConfig.setConsolidationPayGroupMemberEftKeyId("");

        return partnerConfig;
    }

    private ClaimConsolidatedPERecord getClaimConsolidatedPERecord(Claim claim) {

        return ClaimConsolidatedPERecord.newBuilder()
                .setClaimHoldRecord(getClaimHoldRecord(claim))
                .setClaimPolPlanHoldRecord(getClaimPolPlanHoldRecord(claim))
                .build();
    }

    private ClaimPolPlanHold getClaimPolPlanHoldRecord(Claim claim) {

        return ClaimPolPlanHold.newBuilder()
                .setFundArngCd(claim.getFundingArngCode())
                .setLglEntyCd(claim.getLegalEntityCode())
                .setPolNbr(claim.getPolicyNumber())
                .setPolSfxCd(claim.getPolicySfxCode())
                .setBnkCd(claim.getBankCode())
                .setMbrMktTypCd(claim.getMemberMarketTypeCode())
                .setMbrMktSiteNbr(claim.getMemberMarketSiteNumber())
                .build();
    }

    private ClaimHold getClaimHoldRecord(Claim claim) {

        return ClaimHold.newBuilder()
                .setAdjdSysClmId(claim.getAdjustedSystemSubmittedClaimId())
                .setAdjdSysCd(claim.getAdjustedSystemCode())
                .setAdjdSysClmTransSeqId("1")
                .setPartnerProcGrpId(claim.getPartnerProcGroupId())
                .setClmId(claim.getClaimId().longValueExact())
                .setMbrPayMethCd(claim.getMemberPayMethodCode())
                .setSgaInd(claim.getSgaIndicator())
                .build();
    }
}